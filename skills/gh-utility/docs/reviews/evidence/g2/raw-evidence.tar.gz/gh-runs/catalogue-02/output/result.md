1. Primary: `gh-utility`; secondary: none — Listing Actions runs and retrieving logs with `gh` are GitHub operations, and diagnosis was excluded.
2. Primary: `git-engineer`; secondary: none — Rebasing, preserving local edits, and pushing the authorized branch belong to Git history and safe publication.
3. Primary: `typescript-test-engineer`; secondary: none — It owns test diagnosis and requested fixes using the supplied local CI logs, assuming the tests fall within its advertised TypeScript scope.
4. Primary: `security-reviewer`; secondary: none — Assessing token permissions for exploitability is a bounded security review without remediation.
5. Primary: `gh-utility`; secondary: none — Publishing an approved release with `gh` from an already pushed tag is a GitHub release operation.
6. Primary: `code-reviewer`; secondary: none — Read-only correctness and regression assessment of a PR diff belongs to code review, with no specific domain requiring another owner.
