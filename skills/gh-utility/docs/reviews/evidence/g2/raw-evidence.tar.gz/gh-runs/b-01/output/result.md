По предоставленным синтетическим данным для github.com, owner `example-lab`:

| Project | Number |
|---|---:|
| Delivery | 9 |
| Discovery | 12 |

Репозиторий `github.com/example-lab/widget`: имя `widget`, видимость `PRIVATE`. Это сведения из сценария, не результат живого запроса.

Обновление Status подготовлено частично: действие авторизовано, project ID `PVT_delivery`, field ID `PVTSSF_status`, option Done `opt_done` известны. Не хватает project item ID для точного issue URL `https://github.com/example-lab/widget/issues/42`. Номер issue `42` не является project item ID. Нельзя подставить его в `--id`, угадывать ID или добавлять новый item вместо поиска существующего. Повторное разрешение на уже авторизованное обновление не требуется.

Ниже будущие нативные команды, здесь они НЕ выполнялись:

```bash
GH_HOST=github.com gh project list --owner example-lab --closed --limit 100 --format json
GH_HOST=github.com gh repo view example-lab/widget --json name,visibility
GH_HOST=github.com gh project item-list 9 --owner example-lab --limit 100 --format json
```

Сначала по инвентарю project 9 сопоставить точный URL содержимого с указанным issue и взять ID именно project item. Если выдача ограничена, увеличить limit до полного охвата; отсутствие в первых 100 не доказывает отсутствия item. Для списка Projects также проверить полноту относительно лимита. Если item не найден при полном охвате либо соответствие неоднозначно, обновление остаётся заблокированным отсутствием однозначной цели; другие результаты уже готовы.

После получения подтверждённого item ID подставить его вместо явного шаблона `VERIFIED_PROJECT_ITEM_ID`:

```bash
GH_HOST=github.com gh project item-edit --id VERIFIED_PROJECT_ITEM_ID --project-id PVT_delivery --field-id PVTSSF_status --single-select-option-id opt_done
GH_HOST=github.com gh project item-list 9 --owner example-lab --limit 100 --format json
```

Последнее чтение должно заново подтвердить у того же item с тем же issue URL Status `Done`; при необходимости увеличить limit для его включения. Успешный exit code изменения без свежего чтения не подтверждает конечное состояние.

Локально фактически выполнены только чтения инструкций и `gh --version`, `gh project list --help`, `gh project item-list --help`, `gh project item-edit --help`, `gh repo view --help`. Установлен gh 2.96.0; help подтверждает приведённые флаги и JSON-поля `name,visibility`. Сетевые команды, изменение Status и настроек репозитория не выполнялись. Permissions/scopes приняты как заданные сценарием; живое состояние и завершение изменения не подтверждены.
