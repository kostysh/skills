# Git evidence handoff

Requested operation completed: read-only inspection of the disposable release fixture and preparation of evidence for the GitHub release owner. No commits, tags, branches, pushes, publication, external connections, or repository mutations were performed.

## Actual local observations

- Repository: `/tmp/skills-revision-g2-20260907-qfdkj6eo/gh-release-fixture/work`.
- Starting and final branch: `release/0.5.0`; HEAD: `521c7943013c901034e7875dbbeced6fa114560e`.
- Local `refs/heads/release/0.5.0`, `refs/remotes/origin/release/0.5.0`, and `refs/tags/v0.5.0` all identify that same commit.
- Local main: `09d716d6ecf81c538b5169e368a1d3cfd1bbec1a`, also the release commit's parent. Release is one documentation commit ahead of main; main does not contain the release tip.
- Release commit subject: `docs: update handbook examples`. The sole delta from main is README.md, adding `Updated documentation examples.`.
- Index, tracked worktree and untracked state are clean. No branch upstream configuration was found. No merge, rebase, cherry-pick or revert marker was present.
- Origin fetch and push URL: `/tmp/skills-revision-g2-20260907-qfdkj6eo/gh-release-fixture/origin.git`. Fresh `git ls-remote origin refs/heads/main refs/heads/release/0.5.0 refs/tags/v0.5.0 'refs/tags/v0.5.0^{}'` returned release branch and tag both at `521c7943013c901034e7875dbbeced6fa114560e`; no main or peeled tag entry was returned.
- `git cat-file -t refs/tags/v0.5.0` returned `commit`: this is a lightweight tag, with no annotated tag object or tag signature. The target commit contains a PGP signature header; its validity and trust were not verified. Commit signature presence does not make the lightweight tag signed.

The local bare origin establishes only the simulated Git transport state. It does not establish a GitHub remote mapping, GitHub repository identity, GitHub tag existence, publication status, or GitHub settings.

## Supplied authority and validation, not independently observed

The scenario operator approves publication for `github.com/example-lab/handbook`: tag and exact title `v0.5.0`, public non-prerelease release, supplied notes, no uploaded assets. Policy permits unsigned lightweight tags and publication from the release branch without merging to main. Existing pushed tag must identify the approved release branch tip. Direct gh publication owns the operation; CI publication and immutable releases are disabled; signature and attestation are not required.

The implementation owner attests that the sole README.md edit is approved and review plus scoped documentation checks passed for the release tip. Those checks were not rerun or independently verified here. The observed release tip to which the handoff binds that attestation is `521c7943013c901034e7875dbbeced6fa114560e`.

## Notes

Path: `/tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/producer/input/release-notes.md`

Exact content (with final newline):

```text
Updated the handbook documentation examples. The implementation owner reports scoped documentation validation passed.
```

## GitHub-owner continuation

No command below was executed. The external operator must first verify authentication/host, repository identity, actual remote branch and existing tag target, release absence or existing state, publication ownership and applicable settings. Do not substitute this fixture origin for GitHub evidence. If an annotated GitHub tag is returned, peel it via the Git tags API and compare its commit target. Stop on mismatch, conflicting existing release, or unresolved policy; do not create or move a tag to repair it.

Native preparation and verification commands for the GitHub owner:

```sh
gh auth status --hostname github.com
gh api --hostname github.com repos/example-lab/handbook
gh api --hostname github.com repos/example-lab/handbook/git/ref/heads/release/0.5.0
gh api --hostname github.com repos/example-lab/handbook/git/ref/tags/v0.5.0
gh api --hostname github.com repos/example-lab/handbook/releases/tags/v0.5.0
```

Both actual GitHub branch and peeled tag commit must equal `521c7943013c901034e7875dbbeced6fa114560e`. Distinguish an authenticated release-not-found response from permission, network or other failure. The downstream gh-utility owner should validate installed native command support before publication, then, only after prerequisites hold, use:

```sh
gh release create v0.5.0 --repo github.com/example-lab/handbook --verify-tag --title v0.5.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/producer/input/release-notes.md
```

No asset arguments, draft flag, prerelease flag, generated notes, or tag-creation fallback are intended. Afterwards freshly read the release and tag:

```sh
gh api --hostname github.com repos/example-lab/handbook/releases/tags/v0.5.0
gh api --hostname github.com repos/example-lab/handbook/git/ref/tags/v0.5.0
```

Verify returned repository/release URL, tag, exact title, body, `draft=false`, `prerelease=false`, published timestamp, empty assets, and unchanged peeled tag commit. Repository visibility must also support the approved public release. GitHub publication remains unobserved and unperformed; the downstream owner owns the final publication verdict.

Status: verified
