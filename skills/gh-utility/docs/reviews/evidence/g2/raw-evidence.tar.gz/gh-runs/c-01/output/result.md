# Prepared release decisions — no publication executed

Only local reads and native help/version ran. Observed CLI: gh 2.96.0 (2026-07-02); create, view, and api help confirm the flags and JSON fields below. All GitHub state and source-validation results remain supplied synthetic records, not live observations. The three notes files were read; each contains only the documentation update and attributes validation to its implementation owner.

| Row | Supplied state / decision | Next action | Risk / recovery |
|---|---|---|---|
| A — github.com/example-lab/docs-a v2.0.0 | Matching lightweight commit tag; policy permits unsigned tags; eligible for independent publication after fresh reads | Read ref/release, then exact public non-prerelease create and verify below | High: publication; no rollback/deletion authorized |
| B — github.com/example-lab/docs-b v3.0.0 | BLOCKED: existing lightweight unsigned tag violates this repository's signed annotated tag requirement | Read-only confirmation; return to Git owner for required signed annotated tag evidence and approved resolution | No publication or repair; no rollback authorized |
| C — github.com/example-lab/docs-c v4.0.0 | BLOCKED: GitHub ref dddddddddddddddddddddddddddddddddddddddd conflicts with approved target cccccccccccccccccccccccccccccccccccccccc | Read-only confirmation; return discrepancy to Git owner | No publication or repair; no rollback authorized |

The explicit row policies and no-additional-merge-requirement instruction govern over the skill's generic signed-tag/merged-commit handoff wording. A requires neither a signed tag nor a new merge gate. B has an actual policy blocker; C has an actual identity blocker. Independent per-row progress is expressly permitted, so B/C do not stop A. No new authorization question is needed for A's exact supplied plan. This environment nevertheless forbids external execution; all commands below are proposed for a permitted external session.

## A: actionable sequence

Run from the supplied input directory (where notes-A.md resides). First inspect:

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-a/git/ref/tags/v2.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v2.0.0 --repo github.com/example-lab/docs-a --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

Proceed only if the ref is refs/tags/v2.0.0, type commit, SHA aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, and the release is specifically absent. A generic command failure does not establish absence; unexpected state or errors require investigation before mutation. Then:

```bash
gh release create v2.0.0 --repo github.com/example-lab/docs-a --verify-tag --title v2.0.0 --notes-file notes-A.md --draft=false --prerelease=false
gh release view v2.0.0 --repo github.com/example-lab/docs-a --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
gh api --hostname github.com -X GET repos/example-lab/docs-a/git/ref/tags/v2.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
```

Expected verification: tag/name v2.0.0; isDraft=false; isPrerelease=false; publication timestamp and URL present; body equals notes-A.md; assets empty; ref still equals approved SHA. --verify-tag prevents implicit creation of a missing tag but does not validate its target SHA or signature. No assets, generated notes, attestations, or draft staging are needed under the supplied policy. Do not treat source archive links as uploaded assets. If creation has an uncertain result, inspect before retrying; do not delete or roll back.

## B: next commands and dependency

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-b/git/ref/tags/v3.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v3.0.0 --repo github.com/example-lab/docs-b --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

No create command is runnable under the supplied evidence. Git owner must resolve the policy failure under separately authorized work and provide signed annotated tag verification/push evidence. Then a fresh remote tag object must be resolved to its commit and compared with approved bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb. Merely matching the lightweight ref SHA or using --verify-tag does not meet the signature requirement. No repair is authorized here.

## C: next commands and dependency

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-c/git/ref/tags/v4.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v4.0.0 --repo github.com/example-lab/docs-c --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

No create command is runnable while the identity conflict remains. Git owner must reconcile the authoritative target and remote ref through separately authorized work. A fresh matching ref is required before reevaluating publication. --target cannot fix an existing wrong tag and must not be used as a workaround.

Prepared targets: 3; external targets inspected: 0; changed: 0. A is ready for the proposed live checks and conditional publication; B/C remain blocked for the stated independent reasons. No live release completion is claimed.
