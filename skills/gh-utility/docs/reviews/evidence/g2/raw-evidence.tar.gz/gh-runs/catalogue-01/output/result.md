1. Primary: `gh-utility`; secondary: none — listing Actions runs and retrieving logs through `gh` is GitHub resource access without diagnosis.
2. Primary: `git-engineer`; secondary: none — rebasing, preserving unrelated edits, and safely pushing the authorized branch are Git history operations.
3. Primary: `typescript-test-engineer`; secondary: none — diagnosing and fixing unit-test CI failures belongs to the testing owner, with no GitHub access needed because logs are local (its stated language scope is TypeScript).
4. Primary: `security-reviewer`; secondary: none — assessing token permissions for exploitability is a read-only security audit.
5. Primary: `gh-utility`; secondary: none — publishing an approved GitHub release through `gh` from an already pushed tag is GitHub release management.
6. Primary: `code-reviewer`; secondary: none — reviewing an available PR diff for correctness and regressions is read-only code review, with no specific domain requiring another owner stated.
