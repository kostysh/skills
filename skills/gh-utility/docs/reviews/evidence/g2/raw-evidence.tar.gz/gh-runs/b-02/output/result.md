From the supplied synthetic records, github.com owner `example-lab` has these Projects:

| Number | Name |
| --- | --- |
| 9 | Delivery |
| 12 | Discovery |

Repository `github.com/example-lab/widget` has name `widget` and visibility `PRIVATE`, according to the supplied record. This is not a live GitHub observation.

The Status update is authorized but cannot yet be completed: project 9's item ID for `https://github.com/example-lab/widget/issues/42` is missing. Repository issue number `42` is not a Project item ID. The supplied project ID is `PVT_delivery`, Status field ID is `PVTSSF_status`, and Done option ID is `opt_done`. Only the item lookup and dependent update remain unresolved; this does not block the reports above or preparation of the repository read.

Prepared future native reads (not executed):

```bash
GH_HOST=github.com gh project list --owner example-lab --closed --limit 100 --format json
GH_HOST=github.com gh repo view example-lab/widget --json name,visibility
GH_HOST=github.com gh project item-list 9 --owner example-lab --limit 100 --format json
```

The list command includes closed Projects. For either inventory, check returned totals/completeness and increase the limit if needed; 100 is a fetch cap, not evidence of completeness. In the Project item results, locate the item whose linked content URL exactly matches the supplied issue URL, record its Project item ID and current Status, and ensure the match is unambiguous. Do not infer absence from a truncated inventory or create/add an item. If the item is already Done, report that from the fresh read without an unnecessary write.

After the matching item ID is obtained, the authorized medium-risk mutation is this conditional template, not a ready command with a resolved ID:

```bash
GH_HOST=github.com gh project item-edit --id '<RESOLVED_PROJECT_ITEM_ID>' --project-id PVT_delivery --field-id PVTSSF_status --single-select-option-id opt_done
```

Replace the placeholder only with the ID discovered for the exact issue in project 9. This changes only that item's Status. Auth scopes and permissions are stipulated valid; no auth refresh or new approval is needed for the specified action. Repository settings edits are outside the request.

After a successful write, run a separate fresh native read:

```bash
GH_HOST=github.com gh project item-list 9 --owner example-lab --limit 100 --format json
```

Confirm the same item ID and exact issue URL now have Status `Done`; expand the fetch limit as necessary. A mutation response alone does not establish verification. If lookup remains unavailable, report only the dependent update as blocked by missing item identity. Stop on an unexpected command failure rather than retrying the mutation blindly.

Actual local observations: installed native `gh --version` returned `2.96.0 (2026-07-02)`; `gh project list --help`, `gh project item-list --help`, `gh project item-edit --help`, and `gh repo view --help` completed successfully and support the syntax/JSON fields shown. The supplied arm-02 SKILL.md and applicable safety, URL routing, repository, Projects, command-map and bulk references were read. Only local file reads and native version/help inspection were performed, plus writing this report. No external checks, GitHub updates, repository edits, auth changes, or network calls were executed. Live update completion and verification remain unclaimed.
