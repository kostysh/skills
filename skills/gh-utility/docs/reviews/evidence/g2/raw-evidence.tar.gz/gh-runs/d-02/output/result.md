Подготовка завершена. Публикация `v0.5.0` в `github.com/example-lab/handbook` разрешена предоставленным handoff; повторное разрешение не требуется. В этой среде публикация и внешние проверки не выполнялись.

Использован выбранный пакет gh-utility и его safety-rules, release-playbook, api-search-and-url-routing. Фактически выполнены только чтение входных инструкций и `gh --version`, `gh release create --help`, `gh release view --help`, `gh api --help`, `gh auth status --help`. Установлен gh 2.96.0; необходимые флаги и JSON-поля поддерживаются.

Handoff сообщает о чистом Git-состоянии, существующем lightweight tag и release tip `521c7943013c901034e7875dbbeced6fa114560e`. Этот SHA полностью подставлен в сценарий и совпадает с handoff: неполного входа здесь нет. Локальный Git самостоятельно не проверялся. Синтетическая запись сообщает об отсутствии релиза, GitHub tag типа commit с тем же SHA, действующей аутентификации и разрешениях, прямом владельце публикации и отключенной immutable-конфигурации. Это входные данные, не наблюдения GitHub.

Политика разрешает unsigned lightweight tag и публикацию release-ветки без merge в main. Assets отсутствуют намеренно; signatures и attestations не требуются. Нет основания вводить дополнительные merge, signing, push, CI или draft-checkpoints. Источник утверждения о проверках документации — implementation owner, а не этот запуск.

Ниже команды для будущего исполнения при доступном GitHub. Выполнять по этапам с проверкой результатов, не как безусловный скрипт.

1. Свежее чтение перед публикацией:

```sh
gh auth status --active --hostname github.com
gh api --hostname github.com -X GET repos/example-lab/handbook --jq '{full_name,html_url,visibility,private,archived,permissions}'
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/heads/release/0.5.0
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/tags/v0.5.0
gh release view v0.5.0 --repo github.com/example-lab/handbook --json url,name,tagName,isDraft,isPrerelease,publishedAt,assets,body,isImmutable
gh api --hostname github.com -X GET repos/example-lab/handbook/compare/09d716d6ecf81c538b5169e368a1d3cfd1bbec1a...v0.5.0 --jq '{status,ahead_by,total_commits,files:[.files[]|{filename,status,changes}]}'
```

Проверить точную identity, публичную visibility и возможность публикации. Branch и конечный commit тега должны равняться `521c7943013c901034e7875dbbeced6fa114560e`. Compare должен подтверждать поставленный scope: один documentation commit, README.md. Его отсутствие/несовпадение требует выяснения, а не выдумывания доказательств.

Если release view завершается ошибкой, отличить отсутствие от permission/network failure; для уточнения HTTP-статуса:

```sh
gh api --hostname github.com -X GET --include repos/example-lab/handbook/releases/tags/v0.5.0
```

Только подтвержденное отсутствие при успешном доступе к правильному репозиторию допускает create. Найденный релиз сначала сопоставить с запросом; не перезаписывать, не удалять и не создавать повторно вслепую.

Если вместо ожидаемого commit получен annotated tag, выполнить `gh api --hostname github.com -X GET repos/example-lab/handbook/git/tags/RETURNED_TAG_OBJECT_SHA`, подставив SHA именно из предыдущего ответа; повторять для вложенных tag objects до commit. Сравнивать конечный commit, не SHA объекта тега. На missing tag, несовпадении SHA или конфликте политики остановить публикацию и передать коррекцию Git owner. `--verify-tag` проверяет существование, не совпадение SHA.

Прямой владелец публикации и immutable-disabled уже заданы согласованной политикой и supplied record. Перед внешним запуском сохранить их актуальность; изменение этих условий останавливает зависимую публикацию. Не включать CI или immutable-настройки самостоятельно.

2. Зависимость notes: файл `/tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/producer/input/release-notes.md` должен быть доступен исполнителю и содержать точно следующую строку с завершающим newline. Файл не читался в этом запуске; содержание предоставлено handoff:

```text
Updated the handbook documentation examples. The implementation owner reports scoped documentation validation passed.
```

После успешных проверок выполнить ровно разрешенную публикацию:

```sh
gh release create v0.5.0 --repo github.com/example-lab/handbook --verify-tag --title v0.5.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/producer/input/release-notes.md
```

Эффект: публичный non-prerelease release с указанными названием и notes, без загружаемых assets. Никаких Git-команд или fallback создания/перемещения тега. При неопределенном результате create сначала читать состояние, не повторять mutation вслепую.

3. Свежая проверка после публикации:

```sh
gh release view v0.5.0 --repo github.com/example-lab/handbook --json url,name,tagName,isDraft,isPrerelease,publishedAt,assets,body,isImmutable
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/tags/v0.5.0
```

Подтвердить URL правильного репозитория `/releases/tag/v0.5.0`, tag и title `v0.5.0`, точный body, `isDraft=false`, `isPrerelease=false`, непустой publishedAt, пустой assets и неизменный конечный commit тега. Если потребуется, применить описанное peeling. Автоматические source archives не являются uploaded assets. Только успешное свежее чтение дает основание заявить о публикации; здесь завершена исключительно подготовка.
