Preparation complete; publication not performed. Target: github.com/example-lab/handbook, release v0.5.0.

The exact publication is already authorized. The operator's explicit policy permits the unsigned lightweight tag and release-branch publication without a merge to main. This overrides the generic merged-commit and signed-tag prerequisites in release-playbook.md; neither a new signature nor a merge is required. Direct publication, no assets, and immutable releases disabled are supplied policy. No further approval is needed for this exact operation once external prerequisites pass.

Evidence boundaries:

- Actual observations in this run: read task.md, environment.md, handoff.md, both notes files, the supplied gh-utility root and release/safety/API references; ran only installed native gh version/help. gh is 2.96.0. Create help supports --repo, --verify-tag, --title, --notes-file; view help supports the JSON fields below; API help supports explicit hostname and GET.
- Supplied Git-owner evidence, not rerun here: release tip and lightweight tag equal 521c7943013c901034e7875dbbeced6fa114560e; clean tree; local fixture push evidence. Its local bare origin is not evidence about GitHub. Commit signature presence is not a signed tag. Implementation review and documentation validation are owner attestations, not independently rerun tests.
- Synthetic provider record, not a live read: tag object type commit and SHA 521c7943013c901034e7875dbbeced6fa114560e, release absent, valid authentication/permissions, direct ownership and immutable-disabled settings. The SHA is concrete and matches the handoff; input is not incomplete.
- Both supplied notes files contain the exact same sentence with final newline: “Updated the handbook documentation examples. The implementation owner reports scoped documentation validation passed.”

The following are future commands, NOT executed. Run sequentially and inspect results before proceeding; do not paste as an unconditional publication script.

```sh
gh auth status --hostname github.com
gh api --hostname github.com -X GET repos/example-lab/handbook
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/heads/release/0.5.0
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/tags/v0.5.0
gh release view v0.5.0 --repo github.com/example-lab/handbook --json url,name,tagName,isDraft,isPrerelease,publishedAt,assets,body
```

Require exact repository identity and public visibility. Require branch commit and resolved tag commit both equal 521c7943013c901034e7875dbbeced6fa114560e. A commit-type tag needs no peeling. If GitHub instead returns type tag, read `gh api --hostname github.com -X GET repos/example-lab/handbook/git/tags/RETURNED_TAG_OBJECT_SHA`, replacing that placeholder only with the actual returned object SHA; follow tag objects until a commit and compare it. Stop for missing/wrong tag or branch; route correction to Git owner without creating, moving, signing, pushing, or merging anything.

If release view fails, distinguish authenticated absence from other failures with:

```sh
gh api --hostname github.com -X GET --include repos/example-lab/handbook/releases/tags/v0.5.0
```

Do not interpret arbitrary failure as absence. Stop for a conflicting existing release; if an exact matching release already exists, report it from fresh evidence without recreating. Carry the supplied direct-publication ownership and immutable-disabled policy forward; stop if live evidence contradicts it. No CI dispatch or generic attestation/signature gate is required. Repository visibility and remote branch remain necessary external checks despite the synthetic tag record.

Corroborate the owner-supplied notes scope before publication:

```sh
gh api --hostname github.com -X GET repos/example-lab/handbook/compare/09d716d6ecf81c538b5169e368a1d3cfd1bbec1a...521c7943013c901034e7875dbbeced6fa114560e
```

Expect the single documentation commit and only README.md changed as attested; investigate a mismatch rather than extending the notes claims. This read does not prove validation ran.

After these checks pass, publish using the actual read notes file:

```sh
gh release create v0.5.0 --repo github.com/example-lab/handbook --verify-tag --title v0.5.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/producer/input/release-notes.md
```

This publishes a non-draft, non-prerelease release with no uploaded assets. --verify-tag prevents implicit creation of a missing tag; it does not verify SHA identity, hence the separate checks. No --target, generated notes, draft intermediate, or tag repair is needed under supplied policy. If creation fails or its outcome is uncertain, read current release state before any retry.

Fresh post-publication readback:

```sh
gh release view v0.5.0 --repo github.com/example-lab/handbook --json url,name,tagName,isDraft,isPrerelease,publishedAt,assets,body
gh api --hostname github.com -X GET repos/example-lab/handbook/git/ref/tags/v0.5.0
```

Require URL https://github.com/example-lab/handbook/releases/tag/v0.5.0, exact title/tag v0.5.0, exact supplied notes body, isDraft=false, isPrerelease=false, publishedAt populated, assets empty, and unchanged resolved tag commit 521c7943013c901034e7875dbbeced6fa114560e. Peel if necessary as above. Report any mismatch; no destructive recovery is authorized. Only these successful fresh reads support a publication verdict. Current status remains prepared, with external execution unavailable under the fixture restriction.
