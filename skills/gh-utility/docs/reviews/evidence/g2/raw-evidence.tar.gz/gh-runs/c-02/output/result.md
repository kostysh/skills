Preparation complete; no releases published and no network commands executed.

Used the selected gh-utility package and its safety, bulk, release, API-routing, and command-map references. Actual local observations: gh 2.96.0 (2026-07-02); native `gh release create --help`, `gh release view --help`, and `gh api --help` confirm the commands/fields below. Notes files were read locally. All source validation, permissions, release absence, policy, and remote-tag assertions remain supplied synthetic records, not live verification.

| Row / github.com repository | Supplied state and decision | Next action | Risk / rollback |
|---|---|---|---|
| A / example-lab/docs-a | Lightweight unsigned v2.0.0 points to approved aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa; allowed by policy. Ready for the external preflight and authorized publication. | Inspect, publish exact notes with no assets, fresh readback. | Publication is high risk; no rollback or deletion authorized. |
| B / example-lab/docs-b | v3.0.0 SHA matches bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb, but lightweight unsigned tag fails required signed annotated tag policy. Publication blocked. | Read-only confirmation; obtain compliant Git-owner tag/signature evidence under separately authorized correction scope. | No mutation while blocked; no rollback authorized. |
| C / example-lab/docs-c | v4.0.0 GitHub ref reports dddddddddddddddddddddddddddddddddddddddd, differing from approved cccccccccccccccccccccccccccccccccccccccc. Publication blocked. | Read-only confirmation; return discrepancy to Git owner. | No mutation while blocked; no rollback authorized. |

Independent per-row progress is expressly permitted. B and C do not block A. Existing exact authorization is sufficient for A; no further approval document, merged-only gate, new tag, asset paths, or attestation gate is needed. Direct public creation fits the authorized public state, disabled immutability, and explicitly empty asset plan.

All commands below are FUTURE commands, not commands executed in this environment. Run each stage only after evaluating its preceding output; do not paste as an unconditional batch. Stop mutations on unexpected errors; inspect before retrying and do not roll back or delete.

A: first inspect the current ref and release:

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-a/git/ref/tags/v2.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v2.0.0 --repo github.com/example-lab/docs-a --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

Require refs/tags/v2.0.0, type commit, exact SHA aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa, and specifically confirmed release absence. An arbitrary failed read is not evidence of absence. Unexpected existing release or changed ref stops creation. Then execute the authorized publication:

```bash
gh release create v2.0.0 --repo github.com/example-lab/docs-a --title v2.0.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/c-02/input/notes-A.md --verify-tag
```

No draft/prerelease flag means public non-prerelease; no asset arguments means no uploads. `--verify-tag` prevents implicit tag creation but does not validate the target SHA or signature. Use the preceding ref comparison. Fresh verification:

```bash
gh release view v2.0.0 --repo github.com/example-lab/docs-a --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
gh api --hostname github.com -X GET repos/example-lab/docs-a/git/ref/tags/v2.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
```

Require exact tag/title, isDraft=false, isPrerelease=false, publishedAt set, an actual returned release URL, no uploaded assets, body equal to notes-A.md, and unchanged approved ref SHA. Do not use targetCommitish alone as tag-target proof. No `release verify`, asset verification, or attestation command is required for A.

B: actionable current sequence is read-only:

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-b/git/ref/tags/v3.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v3.0.0 --repo github.com/example-lab/docs-b --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

Matching commit SHA alone cannot satisfy B's signature policy. Do not repair the existing tag. The Git owner must resolve the policy failure with proper separate authority and provide signed annotated-tag verification and approved peeled commit evidence. If a later ref is type tag, inspect its actual returned object SHA using native `gh api --hostname github.com -X GET repos/example-lab/docs-b/git/tags/TAG_OBJECT_SHA`; resolve to the approved commit and correlate with Git-owner signature verification. This is a conditional command template, not a known SHA or proof. Only after that dependency is satisfied and absence rechecked is this publication sequence eligible:

```bash
gh release create v3.0.0 --repo github.com/example-lab/docs-b --title v3.0.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/c-02/input/notes-B.md --verify-tag
gh release view v3.0.0 --repo github.com/example-lab/docs-b --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
gh api --hostname github.com -X GET repos/example-lab/docs-b/git/ref/tags/v3.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
```

Verify exact B title/body, public non-prerelease state, timestamp, empty assets, and unchanged verified annotated tag/peeled commit. Release attestation verification does not substitute for Git tag signature evidence.

C: actionable current sequence is read-only:

```bash
gh api --hostname github.com -X GET repos/example-lab/docs-c/git/ref/tags/v4.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
gh release view v4.0.0 --repo github.com/example-lab/docs-c --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
```

Return expected cccccccccccccccccccccccccccccccccccccccc versus supplied dddddddddddddddddddddddddddddddddddddddd to the Git owner. No tag repair or substitution of the observed SHA as the approved target is authorized. Only after owner reconciliation and a fresh ref comparison establishes the approved target, with absence rechecked, is this sequence eligible:

```bash
gh release create v4.0.0 --repo github.com/example-lab/docs-c --title v4.0.0 --notes-file /tmp/skills-revision-g2-20260907-qfdkj6eo/gh-runs/c-02/input/notes-C.md --verify-tag
gh release view v4.0.0 --repo github.com/example-lab/docs-c --json tagName,name,isDraft,isPrerelease,publishedAt,url,assets,body
gh api --hostname github.com -X GET repos/example-lab/docs-c/git/ref/tags/v4.0.0 --jq '{ref,sha:.object.sha,type:.object.type}'
```

Verify exact C title/body, public non-prerelease state, timestamp, empty assets, and unchanged approved SHA. The notes for every row say only that documentation examples changed and explicitly attribute passed scoped documentation validation to the implementation owner; no runtime behavior claim or fresh validation is inferred.

Environment boundary: all three rows await permitted external execution; A has no additional supplied-policy blocker. B and C have the separate dependencies above. Targets changed: 0. Local help failures: 0. Live targets inspected: 0.
