# Предварительная baseline-ревизия gh-utility

**FAIL — 3 P2; P1 не установлен.** Mode `baseline`, assurance `independent`: аудитор не автор baseline или его исправлений. Это source-grounded предварительная инспекция, не behavioral PASS и не разрешение начать изменения до стабильного Git PASS.

Основание: принятый `docs/plans/implementation-plan-20260907-2.md`, repo AGENTS.md, `docs/skill-standard.md`, полные `skill-reviewer/SKILL.md`, `references/methodology.md` и `references/forward-testing.md`. Цель — решения и handoff агента, работающего с native gh: точный target/action, сохранение полномочий, ограничение недоступного вывода, достоверный GitHub readback. Не подтверждены live GitHub, установленная версия gh, естественная активация, универсальная надёжность или поведение всех API/examples.

## Находки

### F1 — P2: правила отдельных операций заново требуют подтверждение уже разрешённого действия

**Основание conflicting, уверенность высокая.** `references/bulk-operations.md:106` предписывает “Ask first” для rerun/cancel/disable; `references/codespaces-and-dev-envs.md:32` делает то же для stop/delete/rebuild. `references/admin-security-playbook.md:7`, `references/safety-rules.md:11` ограничивают авторизацию “current request”, хотя `safety-rules.md:40` признаёт current conversation; `bulk-operations.md:130` и `safety-rules.md:81` требуют отдельный approval artifact. Root Authorization и `fragments/overview.md:11-12` разрешают точное unambiguous действие без повторного подтверждения. Repo AGENTS прямо требует сохранять ранее выданные полномочия.

**Путь:** оператор уже разрешил отмену перечисленных run IDs, затем просит продолжить; исполнитель следует loaded bulk reference и снова спрашивает разрешение либо требует отдельный артефакт несмотря на достаточный исходный список. Аналогично точный запрос остановить Codespace задерживается дополнительным Ask first. Это ненужная остановка разрешённой операции, а не отсутствие настоящего согласования.

**P1 screen:** подтверждённый эффект ограничен повторным approval/blocking; правило не разрешает новую опасную мутацию, не даёт ложного completion. Поэтому P2.

**Минимальное исправление:** единый owner авторизации с переносом действующих разрешений в их точной границе; conditional ссылки используют его, а не вводят повторный current-message gate. Реальный неизвестный target/опасная область по-прежнему останавливают зависимую операцию. Approval record может быть существующим сообщением/списком, если governing policy не требует отдельный документ.

**Закрывающий falsifier:** парные достаточные случаи: уже разрешённый cancel/stop выполняется после readback без нового вопроса; неизвестный ID или расширение scope не выполняется. Проверить реальную последовательность output/tool events; ничего внешнего не мутировать ради теста.

### F2 — P2: входы более сильного workflow объявлены обязательными для всех операций

**Основание direct, уверенность высокая.** `references/release-playbook.md:29-37` безусловно требует merged commit, signed tag, asset paths и блокирует при отсутствии любого. Но подпись/merge/наличие assets не установлены portable Git owner: frozen `git-engineer` получает history semantics из repository/operator policy; `references/safety-rules.md:71-72` использует signed-tag flow как preference. `references/projects-playbook.md:13-19` требует “Always identify” project/field/option/item IDs даже для чтения списка проектов или создания ещё не существующего проекта.

**Путь:** разрешена публикация release без assets на существующем неподписанном теге по явно supplied repository policy; Git owner предоставил точные remote SHA/ref и validation. GH consumer требует подписать тег/merged commit/asset paths и блокирует корректный handoff. Другой достаточный случай — список проектов известного owner; общий Always identify добавляет несуществующие item/field prerequisites. Не предлагается отказаться от проверки существующего remote tag и его точного target.

**P1 screen:** наблюдаемый по тексту ущерб — отказ принять достаточный owner handoff и ненужные требования, а не доказанная мутация тегов: reference явно запрещает GH делать tag correction. Поэтому P2, не гипотетическое повышение до P1.

**Минимальное исправление:** привязать prerequisite к операции и governing release policy; signature/merged-only/assets нужны только когда принятый workflow этого требует. Для Projects разделить owner/list/create и IDs конкретного update. Missing input блокирует зависимый action/claim; доступное чтение и verified provider result сохраняются.

**Закрывающий falsifier:** достаточный policy-authorized release без assets и обязательной подписи принимается без новых Git требований; при действительно обязательной подписи или несовпадении remote SHA публикация блокируется. Read-only Projects list не требует item IDs; item update без нужного ID не выполняется.

### F3 — P2: условно обязательные ссылки представлены как optional

**Основание direct/conflicting, уверенность высокая.** `skill.yaml` имеет `required: false` для всех 13 references, `surfaces.active.requiredReferences: []`; emitted `SKILL.md:116-129` помещает “Read before” / “Read for” в Optional references. Root Start here говорит “Load only the reference matching the use case”, хотя destructive bulk release одновременно требует safety, bulk и release. Дополнительно safety file собственный trigger охватывает любую mutation, а root safety trigger уже.

**Путь:** исполнитель/consumer инструмента считает optional references необязательными, либо загружает одну совпавшую ссылку и пропускает applicable второй слой. Тогда недоступны operation-specific входы и доказательства, например release-owner handoff либо bulk inventory, хотя стандарт требует конкретный согласованный trigger. Это воспроизводимая неоднозначность retrieval contract, не претензия к числу/длине ссылок.

**P1 screen:** root всё равно требует точный authorized action и fresh read; без отдельного trial нет основания утверждать опасную мутацию или ложное закрытие. Установлен material progressive-disclosure defect P2.

**Минимальное исправление:** сохранить conditional loading, обозначить ссылки как required при их trigger, разрешить загрузку всех применимых ссылок и согласовать safety trigger. Не превращать их в always-read manual и не переписывать содержание исправных playbooks.

**Закрывающий falsifier:** простой repo read загружает только нужные ссылки; bulk release загружает все применимые safety/bulk/release instructions; необязательная история не становится нормативной. Нужна проверка emitted classification, а не только YAML.

## Прочие проверенные границы

CI fallback уже существует в `pr-ci-review-loop.md`: actionable failure передаёт PR/check/run/log/head SHA/current state `gh-fix-ci` **или implementation owner**. Поэтому отсутствие gh-fix-ci не само по себе новый P2; root краткое routing может быть согласовано при F3 без выдумывания установленного skill. Review judgment остаётся у review/remediation owner. Merge transport освежает три dimensions, требует exact strategy/PR, проверяет GitHub PR/remote state; локальная очистка принадлежит Git. Его GitHub readback не означает выполненную локальную cleanup. Handoff создания PR требует pushed refs и source diff. Narrow свежие Git→GH trials из задания не пересматривались и не использовались как доказательство полного GH PASS.

Availability/version facts: root требует installed help для меняющихся syntax/fields; auth/troubleshooting имеют missing-gh и alternate-approved-channel fallback. Platform examples не проверялись по сети/установленному gh: задача запрещает network, и текущий отчёт не делает version-correctness claim. Важные API/security экспертные выводы не заменялись догадками. `gh skill` guide требует fresh installed help, preview не объявлен audit PASS. Отдельные команды/поля не объявляются неправильными без authoritative platform evidence.

## Snapshot, состав и checks

Frozen base `/tmp/skills-revision-g2-20260907-qfdkj6eo/baseline/gh-utility`, версия 1.2.1. Полный inventory с индивидуальными SHA256 находится в `gh-baseline-hashes-before.json` и `gh-baseline-hashes-after.json`. Алгоритм aggregate: SHA256 UTF-8 конкатенации sorted relative-path + NUL + file SHA256 + LF (порядок Python sorted Path). Before/after полностью равны.

| Поверхность | Files | Aggregate SHA256 |
|---|---:|---|
| GH baseline source/full package | 33 | `784b3a8f20091fe3faa0fda42012f0e45630e71b54db88de534edec777a13eec` |
| GH emitted | 29 | `2f4cf6b4288ead55774fc57b9b1d8d1e69bcc4e035661857d703a5dbf7dd6af5` |
| Frozen Git emitted 0.2.1 | 10 | `3f69c56b73bad7b57a4946e3fa28e17365e20e95bfaef7459fd469549154572d` |
| Accepted discipline package | 35 | `f81fef2e39cd00147c32a3a194fe5ba7c089d3d383a381a2edc426226d078184` |

Все 29 emitted files byte-equal source counterpart; все 33 GH worktree files равны baseline. Только source files: `AGENTS.md`, `skill.yaml`, `fragments/overview.md`, `fragments/final-checks.md`. Прочитаны все 13 references, 8 assets, UI metadata, оба fragments, source manifest и root; docs README/research/compile-report/два logs просмотрены как supporting. LICENSE учтён inventory/hash; семантика лицензии не предмет review. Runtime/scripts/src/test/package.json отсутствуют в inventory согласованно с documentation-only maintenance contract; искусственный runtime/test package не нужен.

Reused `gh-utility-baseline-checks.json`: lint/check/isolated compile/emitted check exit0 и 29 parity entries true. Самостоятельно повторены read-only inventory, byte parity и before/after hashing; compiler не запускался заново без причины. Никаких GH/Git/network mutations или delegation. Записаны только этот report и два hash manifests в /tmp.

Следующий owner — автор gh-utility после стабильного Git PASS. Сначала зафиксировать raw cases/criteria против F1–F3, затем минимальные source edits, generation, applicable owning checks и независимый re-audit с proportionate behavioral evidence. Этот FAIL не блокирует независимую работу других пакетов и не расширяет принятый план.
