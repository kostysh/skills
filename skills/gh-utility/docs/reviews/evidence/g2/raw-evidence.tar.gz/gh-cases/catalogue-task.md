Using only the supplied catalogue cards, select the primary skill and any necessary secondary owner for each request. Explain each in one short sentence. Do not load skill bodies or execute tasks.
1. Show GitHub Actions runs for example-lab/widget using gh and fetch the failing run's logs; no diagnosis or fix requested.
2. Rebase my local topic branch onto main, preserve my unrelated local edits, then push the authorized branch.
3. Diagnose and fix a failing unit test from the attached CI logs; the logs are already available locally.
4. Audit whether this repository's token permissions create an exploitable security issue; no settings changes requested.
5. Publish the approved GitHub release from the supplied pushed-tag handoff with gh.
6. Review this PR diff for correctness and regressions; no GitHub writes requested.
