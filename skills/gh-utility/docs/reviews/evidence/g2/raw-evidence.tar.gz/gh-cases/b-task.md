For github.com owner example-lab, list the Projects and report their names and numbers. For project 9, set the item for issue https://github.com/example-lab/widget/issues/42 to Status "Done". Both requests are authorized. Prepare all supported work from these supplied synthetic provider records; no network access is available here.

Projects list: project 9 "Delivery", id PVT_delivery; project 12 "Discovery", id PVT_discovery.
Project 9 field schema: single-select Status, id PVTSSF_status, options {Todo: opt_todo, Done: opt_done}.
The item inventory for project 9 is unavailable. Issue number 42 is a repository issue number; no project item ID has been supplied. Auth scopes and permissions for Project reads/updates are stipulated valid.

Additionally, tell me the name and visibility of github.com/example-lab/widget from the supplied repository record {name: widget, visibility: PRIVATE}. Prepare the native read command that would refresh it. Do not edit repository settings.
