## git-engineer
Use for repository-aware Git staging, commits, branches, worktrees, merge, rebase, cherry-pick, and safe pushes. Preserve unrelated work, apply Conventional Commits with emoji by default, and verify exact refs. Route GitHub resources, code review, and CI remediation to their owning skills.

## typescript-test-engineer
Design, implement, review, and diagnose TypeScript tests for Node, React, and edge projects. Use for test strategy, node:test or Vitest, deterministic fixtures and mocks, coverage, CI failures, hanging tests, and evidence quality; keep review and diagnosis read-only unless fixes are requested.

## security-reviewer
Perform bounded security review of code, CI, permissions, webhooks, secrets, data access, and config. Use for vulnerability review, exploitability triage, or scoped audits. Own threat modeling, confidence gating, attack paths, and findings—not scan orchestration, compliance, pentesting, or fixes.

## code-reviewer
Perform read-only review of PRs, diffs, and local branch changes. Use to find bugs or regressions, assess maintainability, tests, compatibility, or lightweight intent alignment, and provide evidence-backed merge guidance with stable scope, severity, and findings; pair with relevant domain skills.

## skill-creator
Create or update a Codex skill with appropriately scoped instructions and any needed supporting resources.
