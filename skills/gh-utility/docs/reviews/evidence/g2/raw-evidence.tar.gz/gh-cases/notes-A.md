Updated the documentation examples. The implementation owner reports scoped documentation validation passed.
