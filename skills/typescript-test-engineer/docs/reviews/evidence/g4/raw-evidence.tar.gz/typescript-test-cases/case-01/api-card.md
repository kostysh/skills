# Official versioned API input
Синтетическая карточка фактов из официальной страницы, прочитанной 2026-09-07; это не результат runtime trial.
Source: https://nodejs.org/download/release/v22.22.0/docs/api/test.html#mockmodulespecifier-options
Node 22.22.0 mock.module options: cache, defaultExport, namedExports. Default export задаётся defaultExport; named exports задаются namedExports. Флаг --experimental-test-module-mocks требуется. Ранее созданные references не заменяются.
