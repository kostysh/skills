export default function client() { return 'production-value'; }
