export function normalizeSlug(input: string): string {
  if (input === '') throw new Error('Empty slug');
  return input.toLowerCase();
}
