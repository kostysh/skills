# Official versioned API input
Синтетическая карточка официальной документации, прочитанной 2026-09-07, страница идентифицирует Node v26.8.1. Это не runtime trial.
Source: https://nodejs.org/api/test.html#mockmodulespecifier-options
В этом API exports задаёт mocked exports: exports.default — default export, остальные enumerable properties — named exports. Поле нельзя смешивать с defaultExport/namedExports; последние объявлены deprecated. Флаг --experimental-test-module-mocks требуется; test context сбрасывает свои mocks.
