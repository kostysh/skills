# Accepted slug contract — synthetic test fixture
Эти требования установлены оператором данного trial как единственный normative oracle, не реальный продуктовый документ. Version 1, approved для fixture.
R1. normalizeSlug(input) убирает leading/trailing ASCII spaces.
R2. Результат преобразует латинские A-Z в lowercase.
R3. Если после trim строка пуста, функция бросает Error с message Empty slug.
Scope: pure helper; persistence, auth, UI, network и coverage policy отсутствуют.
