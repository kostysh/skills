import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSlug } from './implementation.ts';
test('normalizes slug', () => assert.equal(normalizeSlug(' READY '.trim()), 'ready'));
test('rejects empty', () => assert.throws(() => normalizeSlug(''), /Empty slug/));
