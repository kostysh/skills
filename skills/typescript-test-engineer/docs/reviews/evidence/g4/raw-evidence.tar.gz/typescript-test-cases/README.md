# Frozen G4 trial inputs
Подготовлены до remediation, не исполнены. 2 paired version cases + 1 bounded evidence-handoff control. Другого установленного material finding в baseline нет: case03 проверяет adjacent evidence integrity, не выдуманный defect. Baseline-active копирует только root/UI/references текущего target; source/history/evals/answer keys исключены из executor surface. Full package был проверен отдельно в baseline.

Executor получает только task+inputs своего case и соответствующий active skill snapshot. Catalogue executor получает task+catalogue без body. Consumer получает original case03 sources и actual output report из завершённого run; путь нужно заполнить перед запуском. private/rubric.md остаётся только assessor.

Baseline source HEAD c91d096908aa1419419a5d96031016ef934833d9. Методика взята из .worktrees/skills-revision/skills/skill-reviewer 0.2.5 и implementation-discipline 0.2.7. SHA256 manifest paths relative to this folder. Любое изменение критериев требует explicit comparison invalidation.
