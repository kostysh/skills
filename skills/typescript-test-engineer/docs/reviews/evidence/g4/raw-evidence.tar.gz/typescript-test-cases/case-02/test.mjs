import { test } from 'node:test';
import assert from 'node:assert/strict';
test('returns client result', async (t) => {
  t.mock.module('./client.js', { exports: { default: () => 'ready' } });
  const { handler } = await import('./handler.js');
  assert.equal(await handler(), 'ready');
});
