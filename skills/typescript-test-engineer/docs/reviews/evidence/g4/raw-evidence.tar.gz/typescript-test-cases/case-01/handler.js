import client from './client.js';
export async function handler() { return client(); }
