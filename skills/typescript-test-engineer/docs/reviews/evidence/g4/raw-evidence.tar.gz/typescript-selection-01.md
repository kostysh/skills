- `own-task.md`: основной навык — `typescript-test-engineer`. Запрос касается достаточности assertions в `node:test` и пробелов в доказательствах: это прямой предмет специализированного read-only review тестов. `code-reviewer` охватывает общий обзор изменений, но здесь основная задача ограничена качеством тестовых доказательств; `typescript-engineer` нужен для вопросов языка и системы типов.
- `adjacent-task.md`: основной навык — `typescript-engineer`. Conditional types, вывод `never` и исправление generic signature относятся к системе типов TypeScript. `typescript-test-engineer` не является основным: тесты и runner явно исключены из запроса.

Выбор сделан только по двум запросам и описаниям supplied catalogue. Тела навыков не читались, сами задачи не выполнялись.
