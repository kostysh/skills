Helper сохраняет внешние ASCII-пробелы и не отклоняет строку из одних пробелов; исправления не выполнялись, а вывод ограничен статическим анализом чистой функции в synthetic fixture.

# Независимый conformance review

## Основание и снимок

Owning verdict: **non-compliant**. Применён фиксированный `initial-providers/spec-conformance-reviewer/SKILL.md`, source-version 0.1.7, и обязательные `references/methodology.md`, `references/reporting.md`. Policy/admission reference неприменим: нормативный источник не содержит таких требований.

Все пути ниже относительны к `/tmp/skills-revision-g4-20260907-ZMFe9Zkq/`.

| Источник | SHA256 |
| --- | --- |
| `typescript-test-cases/case-03/normative.md` | `55d07ce134c33578e55bc077d14cd1aaf7e5616390559097b27476705fb190c5` |
| `typescript-test-cases/case-03/implementation.ts` | `2cdaed1d03330691b3f10065f0bbb3c80fb341ad548fa8205fa4152ea7354886` |
| `typescript-test-cases/case-03/test.ts` | `561dd943b7bc12c6098c06bde593b3444f4ad082b583ab1e3cff18ada7a15cfb` |
| Фактический producer: `typescript-runs/03-01/report.md` | `9b87d538d4b02ef49b095eb3710ff350f9510912f6e3ea3a012b9642d537f6ea` |

Оператор fixture установил `normative.md` единственным нормативным oracle: Version 1, approved для fixture, применим к pure helper. Superseding-источников в разрешённом наборе нет. Это synthetic stipulated evidence, не реальная продуктовая спецификация. Тест и producer report — supporting evidence, не источник требований. Producer оценивал достаточность тестов; его отрицательный результат не подменяет самостоятельное решение о соответствии кода.

Read-only scope: весь предоставленный helper и тест, без запуска и исправлений. История/diff не предоставлены: нельзя атрибутировать дефекты конкретному изменению. Материальное изменение нормативного источника или реализации инвалидирует этот вердикт.

## Требования и traceability

Все R1–R3 имеют modality `must`, origin `explicit`, без вывода дополнительных обязательств.

| ID / тип | Нормативное основание и ожидаемое поведение | Код / тест / supporting evidence | Статус |
| --- | --- | --- | --- |
| R1 / functional_behavior | `normative.md:3`: удалять leading/trailing ASCII spaces | `implementation.ts:3` только вызывает `toLowerCase()`. Для `' READY '` статически следует `' ready '`. `test.ts:4` удаляет пробелы до вызова helper. Producer указывает тот же обход. | `not_fulfilled` |
| R2 / output_contract | `normative.md:4`: преобразовывать латинские A-Z в lowercase | `implementation.ts:3` непосредственно выполняет `toLowerCase()`. `test.ts:4` содержит точное сравнение READY → ready. Для локального детерминированного преобразования полный код даёт достаточное статическое основание; это не заявление о запуске тестов. | `fulfilled` |
| R3 / error_handling | `normative.md:5`: при пустой после trim строке бросить Error с точным message `Empty slug` | `implementation.ts:2` правильно обрабатывает `''`, но `'   '` проходит к возврату строки. `test.ts:5` охватывает только `''` и проверяет regexp, не точное сообщение/тип. Producer фиксирует отсутствие сценария пробелов. | `not_fulfilled` |

Обратная трассировка: проверка пустого входа относится к R3, lowercasing — к R2; реализации R1 нет. Unicode-lowercasing сверх A-Z — поведение без отдельного нормативного основания, но контракт не запрещает его, поэтому это не дополнительное нарушение. Новые требования Unicode, coverage или интеграций не вводятся.

## Подтверждённые findings

**F1 — major: отсутствует удаление пробелов, нарушены R1 и обязательная ветка R3.** Основание: `normative.md:3,5`. Полная реализация (`implementation.ts:2–3`) проверяет исходную пустоту и возвращает lowercased исходную строку. Поэтому slug сохраняет внешние пробелы, а ввод из одних пробелов возвращается вместо Error. Это прямое противоречие контракту, не вывод из отсутствия тестов. Уверенность высокая, результаты входов статически предсказаны, не исполнены. Направление исправления для владельца реализации: удалить внешние ASCII spaces, проверить пустоту полученной строки и затем выполнить lowercasing; здесь исправление не внесено.

## Пробелы доказательств и передача

Тест предварительно нормализует вход и потому способен пройти при нарушении R1; negative test пропускает whitespace-only ветку R3. Regexp ошибки слабее точной проверки сообщения. Эти пробелы совпадают с supporting producer report, но сами по себе не являются отдельным нарушением нормативной coverage policy: такой policy нет.

Минимальная последующая проверка владельцу тестов: непосредственный вход `' READY '` с ожидаемым `'ready'`, а также `'   '` с проверкой Error и точного message `Empty slug`; сохранить сценарий `''`. Выполнение потребует отдельной разрешённой работы. Статус тестов, CI, TypeScript execution и версия Node неизвестны; никакого runtime PASS не заявлено.

Persistence, auth, UI, network и production integration вне scope. Полная локальная функция достаточна для подтверждения названных противоречий; отсутствие runtime-прогона не превращает их в неизвестность. Нет блокирующей неоднозначности oracle. По aggregation rule наличие обязательных `not_fulfilled` даёт **non-compliant**, даже при реализованном R2. Владелец дальнейшего исправления — implementation owner, усиления unit evidence — test owner; consumer завершает только read-only review.
