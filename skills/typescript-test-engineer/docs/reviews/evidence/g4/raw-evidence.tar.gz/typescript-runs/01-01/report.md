Режим: read-only test design. Применён typescript-test-engineer; прочитаны root SKILL.md и применимые рекомендации testing.md и testing-anti-patterns.md. Исходники, зависимости и runtime не изменялись.

Предлагается один unit-тест реального handler с изолированным default export клиента. Контракт из task.md: handler вызывает клиент и возвращает его строковый результат. Проверяется наблюдаемый результат handler; дополнительный счётчик подтверждает прямо требуемый вызов. Фальсификатор: возврат production-value, undefined либо иной строки вместо результата клиента; отсутствие вызова клиента тоже должно провалить тест.

В references/testing.md сказано: «Use the exports option. defaultExport and namedExports are deprecated compatibility fields». Это противоречит предоставленной versioned API card для Node 22.22.0: её options — cache, defaultExport, namedExports. Для закреплённой версии использую defaultExport, без exports и без переноса утверждения о deprecated. Основание — заданная карточка [официального API Node 22.22.0](https://nodejs.org/download/release/v22.22.0/docs/api/test.html#mockmodulespecifier-options); страницу самостоятельно не открывал.

Минимальный предлагаемый файл handler.test.mjs рядом с handler.js и client.js (файл теста не создан):

```js
import test from 'node:test';
import assert from 'node:assert/strict';

test('handler возвращает строковый результат клиента', async (t) => {
  // Arrange
  const expected = 'isolated-client-result';
  const client = t.mock.fn(() => expected);
  t.mock.module('./client.js', { defaultExport: client });
  const { handler } = await import('./handler.js');

  // Act
  const actual = await handler();

  // Assert
  assert.equal(actual, expected);
  assert.equal(client.mock.callCount(), 1);
});
```

Mock устанавливается до динамического импорта handler. Статический импорт handler или предварительная загрузка клиента сохраняли бы старые references. t.mock обеспечивает очистку mock по завершении теста; это не обещание очистки ESM-кэша. Предложенный отдельный файл содержит один тест, запускаемый отдельной командой, и не переиспользует ранее импортированный handler. При включении в существующий harness потребуется проверить preload/import order.

Fixture — тестовая строка по заданному строковому контракту client → handler. Она намеренно отличается от production-value. Проверяется реальный handler; выполнение настоящего client обходится. Тест не доказывает production-клиент, внешнюю интеграцию или E2E. По показанным исходникам клиент только возвращает строку: state-changing negative matrix неприменима (нет состояния, записей, retry, replay, конкурентных переходов или внешнего исполнителя). Контракт обработки ошибок не задан; его не добавляю.

Предлагаемые команды после отдельного разрешения на создание теста, из его каталога, на существующем закреплённом runtime:

```bash
node --version
node --experimental-test-module-mocks --test handler.test.mjs
```

Ожидаемая версия — v22.22.0; если она отличается, результат не подтверждает заданный runtime. Пример использует ESM .mjs и предоставленные ESM .js; package/module policy не предоставлена и не проверялась. TypeScript loader, dependencies и конфигурацию менять не требуется для этого JavaScript-примера.

Выполнено: чтение разрешённых входов и skill, сопоставление API card с reference, подготовка дизайна и этого отчёта. Только предложено: создание теста и обе команды. По ограничению задачи проект и runtime не выполнялись; результатов теста, проверки версии, stderr, предупреждений и coverage нет. При будущем запуске нужно проверить успешное завершение, отсутствие skips/failures и фактические warnings, включая предупреждения экспериментального API; предупреждения не следует скрывать. Coverage/CI-команды не предоставлены, новый gate не выдуман. Это завершённый дизайн, а не runtime validation или независимый audit PASS.
