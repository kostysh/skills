# Baseline: typescript-test-engineer

**FAIL — один P2: Node module-mock API предписан без границы версии.** Mode `baseline`, assurance `independent`: автором или исполнителем remediation этого snapshot не являюсь. P1 не установлен.

## База и пределы

Worktree: `/home/kostysh/.codex/skills/custom/.worktrees/skills-revision`; HEAD `c91d096908aa1419419a5d96031016ef934833d9`. Все фактически прочитанные skills взяты из `WORKTREE/skills/`, не из catalog/main checkout. Использованы текущие `skill-reviewer/SKILL.md` source-version `0.2.5`, его `references/methodology.md` и `references/forward-testing.md`; `implementation-discipline/SKILL.md` source-version `0.2.7`; repository `AGENTS.md` и `docs/skill-standard.md`. Целевой source-version `0.1.9`.

Consumer — агент, проектирующий/реализующий TypeScript tests или выдающий read-only test review/diagnosis. Capability — sourced test strategy и честный evidence handoff. Ни green docs-contract tests, ни эта ревизия не доказывают production RLS, browser E2E, provider behavior, универсальную активацию или успешное исполнение всех примеров.

Source of truth: target `AGENTS.md` объявляет `skill.yaml`, fragments, references, assets; SKILL.md/compile report generated. Прочитаны весь root, manifest, fragment, четыре references, UI, package, docs-contract tests, eval/fixture; supporting navigation/latest relevant logs/исторические evidence locators использованы только как история, не повторное подтверждение исторических PASS. Runtime/scripts/assets у target не поставляются; test package существует только для docs-contract. Весь target включён в per-file manifest ниже. Содержимое каждого target file совпало с HEAD: **MATCH**. Рабочий tree имеет чужое изменение `docs/plans/implementation-plan-20260907-2.md`, вне reviewed target.

## TTE-B1 — P2, version-dependent module mocks

Evidence: `skills/typescript-test-engineer/references/testing.md:487-493` требует `exports` и называет `defaultExport`/`namedExports` deprecated без условия по pinned runtime; runnable-looking example на строке 509 использует только новую форму. `test/docs-contract.test.mjs`, тест `Node module mocking uses current exports option and deterministic cleanup`, закрепляет именно эту безусловную строку. Root действительно велит сначала определить pinned Node, но не связывает выбор module-mock option с его версией, оставляя прямую несовместимую инструкцию для поддерживаемого проекта.

Basis `direct` для конфликта API; failure consequence `inferred`, не behavioral observation. Для запроса добавить module-mock test в проект с pinned Node 22.22.0 агент получает instruction перейти на `exports`; versioned Node 22 API принимает `defaultExport`/`namedExports` и не объявляет `exports`. Получается неработающий mock/test вместо изолированного сценария. В новом API `exports` корректен; исправление не должно механически откатывать все проекты на старую форму.

Первичные источники проверены 2026-09-07: [Node 22.22.0 mock.module](https://nodejs.org/download/release/v22.22.0/docs/api/test.html#mockmodulespecifier-options), [текущий Node test API, страница идентифицирована как v26.8.1](https://nodejs.org/api/test.html#mockmodulespecifier-options). Это defect совместимости инструкции, не утверждение об ошибке самого Node.

P1 screen: установленный путь ведёт к неверному API и неработающему test setup. Root требует сообщать failures и не разрешает false closure; опасное действие или ложный security PASS этим конкретным сценарием не доказаны. Поэтому P2, не P1.

Минимальная remediation: выбирать mock API по pinned Node и официальной versioned документации; сохранять рабочую существующую форму для старого runtime; не проводить runner/runtime migration без отдельного scope. Обновить source reference и слишком буквальный docs-contract assertion, регенерировать compiler-owned output. Закрытие: paired blind cases для старого и нового API, package structural checks; никаких новых постоянных harness или зависимостей только для этого изменения.

## Остальные поверхности и interop

Read-only modes, TDD opt-in, запрет искусственного удаления уже написанного кода, реальные границы vs mocks, conditional React lifetime matrix с N/A и unavailable-domain fallback заданы. UI соответствует testing scope. Отсутствие names concept/speccon в каждой строке interop само по себе не дефект: target оставляет product/domain oracle их владельцам и formal diff judgement code-reviewer. Текущий spec-conformance-reviewer (root source authority и read-only scope), concept-conformance-reviewer (claim-relative evidence и ownership), security-reviewer (CI/secrets и real data-access boundary) просмотрены как соседи, не запущены как отдельные formal audits. Противоречащего ownership handoff для данной найденной ошибки не установлено. Новые findings за длину, число секций или отсутствие runtime не создавались.

Замеченные общие формулировки о timeout и optional headings сами по себе не объявлены P2: root содержит явные ограничения, достаточного отдельного wrong-decision пути сейчас не установлено.

## Проверки

- `pnpm --filter @kostysh/typescript-test-engineer test`: exit 1 до tests, `[ERROR] unable to open database file`; это environment/package-manager failure, не defect target.
- Объявленный package script `node --test test/docs-contract.test.mjs`: 21/21 PASS, exit 0.
- По уточнению оператора повтор через `npm run test` из target: 21/21 PASS, exit 0, Node v24.15.0. Tests прочитаны перед исполнением: только reads/assertions.
- SHA256 каждого target файла и сравнение с HEAD: MATCH. Source/emitted inspected separately; compiler drift check в этой baseline не запускался, полный byte parity не заявлен.
- Применимые дальнейшие package checks: `npm run test`; compiler shipped CLI `node scripts/skill-source-compiler.mjs check <skill-dir>` из compiler package после regeneration, а также declared compiler lint/compile по owning workflow. Root-wide build/test здесь не нужен для установленной инструкции.
- Behavioral/selection/consumer trials **не запускались** по заданию. Подготовленные frozen cases — входы будущих прогонов, не evidence PASS. Не установлена универсальная корректность остальных version-sensitive API.

Next owner: author/minimal remediation в разрешённом G4 scope; затем independent re-audit TTE-B1 и original failure path. Этот baseline FAIL относится к записанному snapshot.

## Подготовленные paired trials

До candidate edits записаны `typescript-test-cases/`: два version-dependent случая, достаточный positive control на новом API, третий testing-to-speccon handoff на synthetic original normative/code/test inputs; также отдельные own/adjacent catalogue tasks с actual frozen descriptions. Private rubric изолирован логически от executor inputs; это не hard sandbox. Baseline active copy и все case files имеют SHA256 manifest. Trials и consumer **не исполнены**, actual consumer artifact должен появиться из будущего executor run. Fixed v26.8.1 URL оказался недоступен web tool; карточка нового API использует прочитанную official current страницу, явно идентифицированную v26.8.1, а не выдуманный fetched versioned snapshot.

## SHA256 manifest

Алгоритм SHA256; paths относительно worktree root; sorted lexicographically; 31 файлов. Отдельная копия: `typescript-test-baseline-sha256.txt`.

```text
800f40efdcc1041acc17a8ada7b0c60c4e41f1d19825b626c81cff5378884cbf  skills/typescript-test-engineer/AGENTS.md
9986cb9154d175766a25f92990ed0d6542d7f10fa3600305366902ee8994da8f  skills/typescript-test-engineer/SKILL.md
9fc7def9a8ab00f4acd2d5dfd8c166e5fcd853de375a8d620b24660ea1512a04  skills/typescript-test-engineer/agents/openai.yaml
736116e8b19ebc5630a28dfc90c631939677d2df8c6c9fcca42ef7543943adfe  skills/typescript-test-engineer/docs/README.md
8f9a4365ea74e3cb10580cb331b0c8d0c7761f29294a74edc45c019624fc87d9  skills/typescript-test-engineer/docs/compile-report.md
2118933cf89743f15fefefdbd39fb14af751477600a4a765ffdd09e6f9e6f25b  skills/typescript-test-engineer/docs/forward-tests/forward-test-evidence-20260727-1.md
9b65712a465288358c5048743ac66a12d6d24f5b6657897a8d49bfd45d97b0df  skills/typescript-test-engineer/docs/forward-tests/forward-test-evidence-20260727-2.md
4143352c20562ec2b40f7b286c376dfd598ca064ff610a118d74ce181ef15a6d  skills/typescript-test-engineer/docs/forward-tests/forward-test-evidence-20260727-3.md
e29b59b0a1d78037b61ecedc3aeb74c8f17f69a0e4ef1f11b53b024578c79fdf  skills/typescript-test-engineer/docs/issues/implementation-plan-20260425-1.md
d5a79e997e4b8d0f935afcf4fc388a766c89b0f9f8d4214d453cb105054268b8  skills/typescript-test-engineer/docs/issues/issue-20260425-1.md
fb2c0595e1b70edf83b7236e80dc47f216b5fa740fd77a51813391c98b91a6c2  skills/typescript-test-engineer/docs/logs/forward-tests-20260710.md
a720dd6ac02f65979d5c05de53f863ea69077b4f979592623e01a13ecd85cc92  skills/typescript-test-engineer/docs/logs/implementation-log-20260425-1.md
85248d902f4b9f6f640b74e11fa84ebef1b6628de8d475aca96601cf6ac762b5  skills/typescript-test-engineer/docs/logs/implementation-log-20260429-1.md
54952daaf845b8aa28f1fd884b889e6cf4d58fa9ec4fbf2eaecc76b3638534d8  skills/typescript-test-engineer/docs/logs/implementation-log-20260601-1.md
aa82185892a98328f03a69fca0d38551a3e061d723e05c294ba2b9bd74bf6ad3  skills/typescript-test-engineer/docs/logs/implementation-log-20260611-1.md
7fb16c030cd62db98e707124567951573a15209d327694f522c727015d777ff3  skills/typescript-test-engineer/docs/logs/implementation-log-20260622-1.md
525a2aabc72b54699a08e7bda717badcaad1ff60db16a8e341464ad2bf28f787  skills/typescript-test-engineer/docs/logs/implementation-log-20260708-1.md
f5334e8f30689f2f5388ce6403aed6c2c9e8fe3e36b3a061a82025b78b4c0245  skills/typescript-test-engineer/docs/logs/implementation-log-20260710-1.md
0160daea87aa04f73e70fab4942bafe1a4e4e86f8d04427aa9f0e784dfcf2afa  skills/typescript-test-engineer/docs/logs/implementation-log-20260715-1.md
057b5749ddb4955f04bb188cdca7fc0ba34c1761f7d9a530cd2e828da42cb455  skills/typescript-test-engineer/docs/logs/implementation-log-20260727-1.md
8d0ad79c13ac02185b3d3163ea28f2145383ea020290ce5047913b62a6629c44  skills/typescript-test-engineer/docs/logs/implementation-log-20260820-1.md
0aee966be1c4f622a73c5f76cc4033082d40b1b994ff5b6959dc3a5b27bca548  skills/typescript-test-engineer/evals/evals.json
e77be1de41b434a8e0602a075cadf3c209eb9ca1b7da11d5575b9b898fd3aac4  skills/typescript-test-engineer/evals/fixtures/mutation-lifetime-input.md
032df8361537c030508940ab3e39d5362441262839413aa8548b6c5b55cc8bb1  skills/typescript-test-engineer/fragments/overview.md
d913481eee790ffacc5b3b4eda07a6100aaa2dd302d934796af3c739bc98057a  skills/typescript-test-engineer/package.json
f76b527d1fa2b68c38b4a0a51fd5c4c88e5a2a32ca65ce1ad86fd41fbb8669b5  skills/typescript-test-engineer/references/react-vitest.md
029f55af01dd0a9efb77e71693c3503a89bdd8a75367454e02a93712ed18b957  skills/typescript-test-engineer/references/tdd.md
fa8919e363c264db7d14a3cd0dc56ccf85c114c2080ef5a0c22c6b36bb7dd0b6  skills/typescript-test-engineer/references/testing-anti-patterns.md
57fe6c6e144170fc47446d776ee0b7913b76b4727f6e9af9a8055abaf96709bc  skills/typescript-test-engineer/references/testing.md
e8eae6a641aa8fef38b3d32cbb0407944d81c50b6ee384a55af605c29b2eeea5  skills/typescript-test-engineer/skill.yaml
8902171080b0d71f753f0483ac15427288ee462a109594f585d798ebddd749d4  skills/typescript-test-engineer/test/docs-contract.test.mjs
```
