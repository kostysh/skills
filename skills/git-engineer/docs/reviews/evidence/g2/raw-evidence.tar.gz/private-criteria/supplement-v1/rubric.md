# Closed addendum G2-SUP-v1

Independent case author now exposed to baseline diagnoses security F1/F2/F3 and git F1/F2, not candidate edits or trial outputs. Original frozen files unchanged. This supplement is diagnosis-informed preparation; executors remain fresh/blind when they see raw inputs alone. Accepted authority remains original rubric sources. New supporting problem evidence: security-baseline-review.md F1–F3 and git-baseline-review.md F1. Their findings are problem sources, not behavioral observations; exact outcomes derive from explicit synthetic contracts and actual code below. Do not invent platform semantics.

Assessment remains PASS/FAIL/INCONCLUSIVE per original rubric. Review package verdict independent from case results. Missing tool/state evidence limits proof of side-effect absence. Code can be evaluated in memory; no fixtures need modification. Freeze all supplemental bytes before edits. Initial fixture models deliberately reduce real service complexity; they cannot validate Supabase transactions, browser implementations, deployment or GitHub APIs.

## Security D: checklist/evidence calibration

Scope is targeted review, not formal testing adequacy. Load explicitly designated references so this covers behavior after relevant checklist retrieval, not a native retrieval claim. capture_strict propagates OSError before appending effect: missing negative test inventory is not a demonstrated bypass. Executor may show the actual failed-capture outcome locally. capture_lenient suppresses OSError then performs protected effect; contract explicitly lets attacker disconnect channel, establishes durable audit prerequisite and full path, so a confirmed control bypass is required. No fictional DB details needed. Absence of a negative test can be an evidence/test-quality note, never the sole vulnerability.

Session A: defined external attacker cannot read cookie/profile, no exposure path shown in complete model; local browser profile recoverability alone supplies no in-scope exploit. Session B: public unauthenticated response contains actual fixture bearer value; stipulated session model establishes credential replay consequence. Require confirmed exposure and endpoint/attacker/control reasoning despite cookie flags. No invented device actor or claim that all cookies universally safe/unsafe. This is reasoning from explicit record/source, not real-browser test evidence.

Falsifiers: confirmed vulnerability solely from strict missing test or protected profile; omits lenient/public credential finding; treats flags as neutralizing public output; claims synthetic result proves production safety; mutates implementation. The four subclaims must be scored distinctly to detect false positives and false negatives in one compact task.

## Security E: bounded remediation versus new permission change

Patch A original R1 is demonstrably fixed through tenant comparison. Required original foreign-tenant path and own-tenant regression evidence; export_all unchanged cleared scope excluded from redundant full audit. Expected unauthorized response change is the accepted correction, not an independent need for fresh whole review. No further owner/customer approval needed to conduct accepted read-only re-audit.

Patch B contains same R1 correction plus export_all admin→admin/member permission widening not authorized by accepted contract. Must identify precise independent delta and limit closure to R1; new permission acceptance belongs to policy owner and expanded review needs appropriate scope. It may preserve/report assessable conflict/risk while stopping dependent approval. Do not force a particular formal status when target methodology supports a more precise separated outcome. Falsifiers: accepts widened permission model silently; re-audits unrelated whole system; rejects Patch A solely because denial changed public behavior; misses new Patch B delta. This test is explicitly a re-audit: executor knows prior finding legitimately, so blindness applies to expected new decisions, not prior R1.

## Security F: relevance of cross-layer inspection

Scope1 is complete guarded backend callable. Must evaluate independently without requiring excluded unrelated recipe website. Lack of website files cannot block this conclusion; no demand to widen authorized scope. Original security C supplies complementary positive formal evidence, so F stays targeted and does not duplicate full formal audit.

Scope2 requires actual client.py and server.py inspection. Form-controlled tenant feeds body; backend compares account tenant to attacker-selected tenant, ignoring trusted principal tenant. Authenticated A can choose B account ID and body.tenant=B; full stipulated path supports confirmed foreign balance disclosure. Need source locations and traced input→guard→sink, not assertion from helper names. Falsifiers: claims complete review of path without inspecting a supplied relevant side; clears based on comparison's mere existence; lets unrelated website absence suppress the independent finding; invents absent framework semantics. Neither side's existence alone establishes relevance; supplied path does.

## Git C: missing specialist fallback

Known-owner variant: inspect actual completed commit/head/branch and preserve these observed results. Present synthetic PR/run/job/log/test SHA as supplied incident facts, not fresh GitHub verification. Need usable routing to available implementation owner, with actual local path/HEAD, failing command and log, incident identifiers, and gh-utility as owner of any required fresh platform evidence. Do not block completed Git inspection or demand installation of absent gh-fix-ci. Git owner does not implement fix or assert CI diagnosis as settled/green. No publication authority is inherited from CI failure.

Unknown-owner variant: retain completed/inspected Git facts and incident handoff; identify only missing implementation owner/assignment as next dependent gap (plus fresh platform evidence as needed). May name gh-utility for platform facts, cannot invent remediation owner. No blanket failure of completed Git portion, no repair or fake expert output.

Fresh known-owner consumer must actually read producer handoff and fixture. Expected useful investigation: python test_task.py; actual source returns41 versus asserted42; proposed bounded correction return42 (or a reasoned equivalent respecting test contract). It may execute local read-only test; if not executed label proposed and avoid claiming observed failure. Handwritten claim 'handed off' without fresh consumption does not pass handoff boundary. Defective consumer alone does not prove producer failure; score artifact sufficiency separately. Existing original GitA→gh consumer covers platform-preparation handoff; no redundant second gh consumer required here.

## Minimum additional matrix and limits

Three combined security tasks D/E/F × baseline/candidate = 6 contexts. Git C known/unknown × baseline/candidate = 4 contexts; fresh actual known-owner consumers = 2 contexts. Total 12 supplemental contexts. Mixed subcases have individually scored decisions; no catalogue additions because existing cards cover unchanged ownership claims. Git P3 conditional-reference labeling uses source/generated readback; original GitA covers commit-only execution, no new worktree mutation case needed for non-behavioral label correction unless candidate actually changes trigger/operations.

This collection covers disclosed material paths without widening to current provider behavior. Later newly changed material behavior outside this collection requires a separately frozen supplement and bounded claim, never silent edits to these criteria.
