1. **git-engineer** — owns scoped staging and commits while preserving unrelated staged changes. No collaborator needed.
2. **gh-utility** — owns creating a GitHub draft PR using `gh`. No collaborator needed for the already-pushed branch.
3. **git-engineer** — owns local ancestry inspection and repository-aware history command recommendations. No collaborator needed.