1. **git-engineer** — Owns scoped staging and commit preparation while preserving unrelated staged files. No collaborator needed.
2. **gh-utility** — Owns creating the GitHub draft PR through `gh`. No collaborator needed for an already-pushed branch.
3. **git-engineer** — Owns inspecting local ancestry and recommending repository-approved Git history commands. No collaborator needed.