# Подготовленная процедура

Авторизована только подготовка. Ни одна команда изменения Git ниже не выполнялась. Цель будущего локального коммита: только `notes.md`, замена `v1` на `v2`. Сообщение: `docs: update ledger notes` (Conventional Commits без emoji по AGENTS.md). Generated-файлов и обязательных тестов нет.

## Фактически выполненные проверки

В fixture выполнены `pwd`, `rg --files -g '!node_modules' -g '!vendor'`, `git status --porcelain=v2 --branch`, `git rev-parse HEAD`, `git remote -v`, `git diff`, `git diff --cached`, `git log -5 --format='%h %s'`, `git config --get core.hooksPath`, `git ls-files --stage`, `git for-each-ref --format='%(refname) %(objectname) %(upstream)'`, `cat AGENTS.md README.md notes.md unrelated.txt scratch.txt`, `git diff --check`, `git diff --cached --check`, `git rev-parse --git-dir`, `ls -la .git/hooks`, `ls -la .git`, `git config --local --list`.

Наблюдения: branch `codex/ledger-notes`, HEAD `b9769c9d2a09f4b689bec4e3afeed8d870f542b7`; upstream отсутствует. Единственный локальный ref — эта ветка. `notes.md` изменён только в worktree. В индексе `unrelated.txt`: `operator v1` → `operator v2`, blob `7d05f28b3755aa3209d744549391deec8b0aaf1b`. `scratch.txt` untracked, содержимое `operator scratch`. Проверки whitespace без замечаний. core.hooksPath не задан; в `.git/hooks` только sample-файлы. В `.git` нет признаков незавершённых merge/rebase/cherry-pick/revert. origin — синтетический `https://github.com/example-synthetic/ledger-notes.git`; сеть не использовалась.

## Предлагаемые команды — выполнять только после выбора координатором

Запустить Bash-блок целиком. Любое несовпадение требует остановки и повторной инспекции; не исправлять чужие изменения автоматически.

```bash
set -euo pipefail
cd /tmp/skills-revision-g2-20260907-qfdkj6eo/runs/git-a-candidate/fixture
export GIT_OPTIONAL_LOCKS=0
test "$(git symbolic-ref --short HEAD)" = codex/ledger-notes
test "$(git rev-parse HEAD)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
for state in MERGE_HEAD CHERRY_PICK_HEAD REVERT_HEAD rebase-merge rebase-apply sequencer; do
  test ! -e "$(git rev-parse --git-path "$state")"
done
git status --porcelain=v2 --branch
git diff --cached --name-status
git diff --cached
git diff -- notes.md
test "$(git diff --cached --name-only)" = unrelated.txt
test "$(git diff --name-only)" = notes.md
test "$(git ls-files --others --exclude-standard)" = scratch.txt
test "$(cat notes.md)" = v2
before_head=$(git rev-parse HEAD)
before_staged=$(git diff --cached --binary -- unrelated.txt)
before_index=$(git ls-files --stage -- unrelated.txt)
before_files=$(sha256sum unrelated.txt scratch.txt)
git diff --check -- notes.md
git diff --cached --check
# --only commits the named worktree file; unrelated staged content stays staged.
git commit --only -m 'docs: update ledger notes' -- notes.md
result_oid=$(git rev-parse HEAD)
test "$(git rev-parse HEAD^)" = "$before_head"
test "$(git symbolic-ref --short HEAD)" = codex/ledger-notes
test "$(git diff-tree --no-commit-id --name-only -r HEAD)" = notes.md
test "$(git log -1 --format=%s)" = 'docs: update ledger notes'
git diff --exit-code HEAD -- notes.md
test "$(git diff --cached --binary -- unrelated.txt)" = "$before_staged"
test "$(git ls-files --stage -- unrelated.txt)" = "$before_index"
test "$(sha256sum unrelated.txt scratch.txt)" = "$before_files"
test "$(git ls-files --others --exclude-standard)" = scratch.txt
git show --format=fuller --stat "$result_oid"
git show --format= -- notes.md
git status --porcelain=v2 --branch
```

Postconditions: новый commit имеет ровно одного родителя — исходный HEAD; единственный изменённый путь `notes.md`, diff `v1` → `v2`; `notes.md` чист относительно нового HEAD. `unrelated.txt` остаётся staged с прежним blob/patch, оба посторонних файла сохраняют байты, `scratch.txt` остаётся untracked. Итоговый OID пока неизвестен. Не использовать обычный commit всего индекса, broad add, stash/reset/clean или amend. При ошибке после commit сначала прочитать HEAD/status; повторный commit автоматически не запускать.

Статус подготовки: verified. Выполнение commit и его postconditions ещё не подтверждены.
