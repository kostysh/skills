# Git → GitHub handoff

Подготовка завершена; локальный commit и публикация не выполнялись. GitHub-owner: gh-utility. Будущая задача — подготовить запрос draft PR в master; это не разрешает push, создание PR, запуск CI, review approval или merge сейчас.

Наблюдавшийся локальный snapshot:
- Fixture: `/tmp/skills-revision-g2-20260907-qfdkj6eo/runs/git-a-baseline/fixture`.
- Head branch: `codex/ledger-notes`; исходный OID `b9769c9d2a09f4b689bec4e3afeed8d870f542b7`.
- Origin fetch/push: `https://github.com/example-synthetic/ledger-notes.git`. Это синтетический адрес: не обращаться к нему. Реальный репозиторий GitHub не подтверждён.
- Upstream отсутствует. Remote OID не известен; remote-tracking refs отсутствуют.
- Base по AGENTS.md и заданию: `master`. Наличие и OID base на сервере не проверены.
- История PR по политике: merge commit, никогда squash. Это политика будущего merge, не разрешение его выполнить.
- Изменение: notes.md `v1` → `v2`; предлагаемое сообщение `docs: update notes to v2`.
- Сохранить staged unrelated.txt и untracked scratch.txt; точная процедура в procedure.md.

Предлагаемые поля будущего draft PR request: title `docs: update notes to v2`, head `codex/ledger-notes`, base `master`, draft `true`. Body: «Обновляет notes.md с v1 до v2. Локальные проверки whitespace прошли на исходном diff; политика не требует тестов. Commit и публикация должны быть подтверждены отдельно». Перед использованием обновить body по фактическим результатам.

После выбранного координатором commit нужны фактический новый OID, parent, message, diff с единственным notes.md и подтверждение сохранения чужого индекса/worktree. До этого нельзя подставлять исходный OID как commit изменения.

Перед любой будущей публикацией нужны отдельное разрешение, настоящий целевой repo/remote, его доступность, текущие source/destination OID и согласованный refspec. Синтетический remote не использовать. После отдельно разрешённой публикации нужен свежий remote read, подтверждающий точное совпадение опубликованной ветки с новым локальным OID. Только локальный tracking ref или exit code push этого не доказывает.

Для платформенной операции GitHub-owner должен заново подтвердить repo identity, head/base и их SHA, права, отсутствие конфликтующего существующего PR и требования платформы. После отдельно разрешённого создания PR нужны наблюдавшиеся URL/номер, draft flag, head/base и SHA. Сейчас PR URL, CI status, approval и merge readiness неизвестны и не заявляются; кодовый review принадлежит code-reviewer, диагностика CI — специализированному CI-owner.

Фактически выполнены только локальные read-only проверки, перечисленные в procedure.md, и запись этих двух артефактов. Следующее действие: координатор выбирает/исполняет локальную процедуру и дополняет handoff проверенным новым OID.

Статус подготовки: verified.
