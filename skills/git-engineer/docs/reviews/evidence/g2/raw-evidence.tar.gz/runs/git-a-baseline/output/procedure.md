# Подготовленная процедура

Авторизована только подготовка. Ни один Git mutation ниже не исполнен. Цель будущего локального коммита: только notes.md, замена `v1` на `v2`. Сообщение: `docs: update notes to v2`. AGENTS.md требует Conventional Commits без emoji; generated-файлов и обязательных тестов нет.

## Наблюдения и реально выполненные команды

В fixture выполнены read-only команды: `pwd`, `rg --files -g '!node_modules' -g '!\.git' -g '!*lock*'`, `cat AGENTS.md README.md`, `git --no-optional-locks status --porcelain=v2 --branch`, `git rev-parse HEAD`, `git remote -v`, `git diff`, `git diff --cached`, `git log -4 --format='%h %s'`, `git config --get core.hooksPath`, `git rev-parse --git-path hooks`, `git for-each-ref --format='%(refname) %(objectname) %(upstream)' refs/heads refs/remotes`, `git ls-files --stage`, `git diff --check`, `git diff --cached --check`, `ls -la .git/hooks`, `ls -la .git`, `sha256sum notes.md unrelated.txt scratch.txt .git/index`.

HEAD/ветка: `b9769c9d2a09f4b689bec4e3afeed8d870f542b7`, `codex/ledger-notes`. Upstream отсутствует; других локальных/remote-tracking refs не обнаружено. Origin fetch/push: `https://github.com/example-synthetic/ledger-notes.git` — только синтетическая конфигурация, сеть не использовалась.

Состояние: notes.md `.M`, unrelated.txt `M.`, scratch.txt untracked. В staged diff только unrelated.txt (`operator v1` → `operator v2`); его index blob `7d05f28b3755aa3209d744549391deec8b0aaf1b`. Оба diff --check без диагностик. core.hooksPath не задан; в .git/hooks только sample-файлы. В .git нет признаков активного merge/rebase/cherry-pick/revert.

## Предлагаемые команды, НЕ выполнены

Координатор выполняет только после выбора этой процедуры. При любой смене исходного состояния остановиться и перепроверить scope; не использовать reset/stash/clean или обычный commit всего индекса. Не запускать одновременно с другим Git writer.

```bash
set -eu
cd /tmp/skills-revision-g2-20260907-qfdkj6eo/runs/git-a-baseline/fixture
export GIT_OPTIONAL_LOCKS=0
test "$(git branch --show-current)" = codex/ledger-notes
test "$(git rev-parse HEAD)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
test "$(git status --porcelain=v1)" = "$(printf ' M notes.md\nM  unrelated.txt\n?? scratch.txt')"
printf '%s\n' \
 '81db67b6a5702b9b68f0016f061c409bf3fb16d062fc854d1b424bb4e9c28c56  notes.md' \
 'ada28a6ce45b2e3444cbff8f40a7909ab81355e8278cfcfd6d782315f94c0a96  unrelated.txt' \
 'b1f830a85aa67c98c6ec8d0fae962b90a9e92eb37112d02ab25d3f94923219ad  scratch.txt' | sha256sum -c -
test "$(git rev-parse :unrelated.txt)" = 7d05f28b3755aa3209d744549391deec8b0aaf1b
for state in MERGE_HEAD CHERRY_PICK_HEAD REVERT_HEAD rebase-merge rebase-apply sequencer; do
  test ! -e "$(git rev-parse --git-path "$state")"
done
git diff --check
git diff --cached --check
git diff -- notes.md
git diff --cached --name-status
git diff --cached -- unrelated.txt
# STOP if inspected diff differs from the recorded scope.
# --only takes notes.md from the worktree and excludes unrelated staged content.
git commit --only -m 'docs: update notes to v2' -- notes.md
new_oid=$(git rev-parse HEAD)
test "$(git branch --show-current)" = codex/ledger-notes
test "$(git rev-parse HEAD^)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
test "$(git show -s --format=%s HEAD)" = 'docs: update notes to v2'
test "$(git diff-tree --no-commit-id --name-only -r HEAD)" = notes.md
git show --format=fuller --stat HEAD
git show --format= -- notes.md
git diff --exit-code HEAD -- notes.md
test "$(git rev-parse :unrelated.txt)" = 7d05f28b3755aa3209d744549391deec8b0aaf1b
test "$(git status --porcelain=v1)" = "$(printf 'M  unrelated.txt\n?? scratch.txt')"
printf '%s\n' \
 'ada28a6ce45b2e3444cbff8f40a7909ab81355e8278cfcfd6d782315f94c0a96  unrelated.txt' \
 'b1f830a85aa67c98c6ec8d0fae962b90a9e92eb37112d02ab25d3f94923219ad  scratch.txt' | sha256sum -c -
git diff --cached -- unrelated.txt
git status --porcelain=v2 --branch
printf 'Resulting local commit: %s\n' "$new_oid"
```

Постусловия: ровно один новый commit на той же ветке с единственным изменённым путём notes.md; notes.md синхронизирован с HEAD; staged blob unrelated.txt, его worktree и untracked scratch.txt сохранены. Не требуется чистое дерево. Если проверка после commit не проходит, сохранить состояние и диагностировать, не откатывать автоматически.

Подготовка проверена по локальным данным; выполнение commit и его новый OID пока отсутствуют.

Статус подготовки: verified.
