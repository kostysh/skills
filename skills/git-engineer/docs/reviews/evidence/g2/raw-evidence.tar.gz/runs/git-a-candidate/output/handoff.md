# Git → GitHub

Подготовка завершена; Git не изменён. Наблюдавшийся HEAD: `b9769c9d2a09f4b689bec4e3afeed8d870f542b7`, branch `codex/ledger-notes`, upstream отсутствует. origin fetch/push: `https://github.com/example-synthetic/ledger-notes.git`. Это синтетическая конфигурация, не подтверждённый живой GitHub-репозиторий; remote не контактировался. Локального master и remote-tracking refs нет.

Планируемый commit: `docs: update ledger notes`, только `notes.md`, `v1` → `v2`. Инструкция и выполненные локальные проверки записаны в `procedure.md`. Новый OID ещё не существует в проверенных данных. Остаточное состояние: staged `unrelated.txt` (`operator v1` → `operator v2`), untracked `scratch.txt`; их необходимо сохранить.

Будущая задача для gh-utility: подготовить запрос draft PR с base `master`, head `codex/ledger-notes`. Предлагаемый заголовок: `docs: update ledger notes`. Предлагаемое описание: «Обновляет notes.md с v1 до v2. Изменение документации; обязательных тестов по политике репозитория нет». Политика истории — merge commit, никогда squash. Это требование метода, не разрешение на merge.

Сейчас не разрешены push, создание PR, запуск CI, review approval или merge. Синтетический URL не использовать для живых запросов. Для дальнейшей публикации нужны отдельное явное разрешение и реальная подтверждённая repo identity; наличие origin не является таким разрешением.

После выбранного локального commit передать свежий итоговый OID, parent OID, сообщение, diff/список путей и результаты postconditions сохранности из procedure.md. После отдельно разрешённой публикации получить свежие source/destination ref OIDs и remote readback, затем gh-utility должен подтвердить repository identity, существование base master, опубликованный head и точный diff к base. Локальный tracking ref не доказывает состояние remote. До этих данных нельзя считать PR-подготовку пригодной к исполнению. После отдельно разрешённого создания PR нужны его URL/номер, base/head OIDs и подтверждённый draft-state. Факты о CI/checks и review получать отдельно; никаких выводов о прохождении CI, одобрении или готовности merge здесь нет. Code-reviewer владеет review verdict, gh-utility — платформенными действиями и свежей проверкой GitHub.

Статус подготовки: verified. Commit/publication/PR не выполнены и не подтверждены.
