No mandatory commit format. Mainline master. Scope is task.py/test_task.py. Checks use python test_task.py. No publication without explicit authority.
