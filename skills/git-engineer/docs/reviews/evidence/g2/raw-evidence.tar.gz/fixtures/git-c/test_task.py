from task import answer
assert answer() == 42
