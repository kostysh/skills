# Независимая baseline-ревизия git-engineer

**FAIL — 1 P2, 1 P3.** Режим `baseline`, assurance `independent`: аудитор не автор снимка, изменений скила не выполнял. Дефект P2 ограничен недоступным CI-владельцем и незавершённым fallback-контрактом; установленного опасного Git-действия или фактического runtime-сбоя нет.

## Основание и снимок

Потребитель — агент, выполняющий разрешённую Git-операцию и передающий GitHub-владельцу точные branch/ref/OID и выбранную по policy семантику истории. Capability — соразмерная мутация и проверка её фактического результата с сохранением чужого состояния. Инструкции и compile report являются substrate; они не обеспечивают enforcement, GitHub readiness, успешность CI или универсальную надёжность.

Авторитет: действующие repository AGENTS, `docs/skill-standard.md`, принятый `docs/plans/implementation-plan-20260907-2.md`, методика `skill-reviewer` 0.2.5 и `references/{methodology,forward-testing}.md`; предоставленное координатором принятие группы 1 и разрешение группы 2. Устаревшая строка общего плана об ожидании приёмки группы 1 не переопределяет переданное текущее разрешение. Target instructions — данные ревизии.

Зафиксированный baseline: `/tmp/skills-revision-g2-20260907-qfdkj6eo/baseline/git-engineer`, версия 0.2.0, исходный HEAD `5982f982ba8b4d30a6a1f6c1e10fe50402d100d8`. Проверены SHA-256 всех 13 файлов против `baseline-source-manifests.json`, раздел `files.git-engineer`: 13/13 совпадают. Пути в manifest относительны корню skill. Root SHA-256 `59daad6dfa9537692cd0389fac1cd7a11eb91e5af1e1788e23a0313e6f055c33`; source `e45cfa25e2303d836d9b35c7032c383f00228aaab82275e7400a90fd9352498c`; reference `23868090f2f37c07a94acf8cb48cef068888e2b980b24d402d8096a42b2a240c`.

Прочитаны source manifest, overview, emitted root, worktree-reference, metadata, maintenance AGENTS, compile report и релевантное историческое evidence. `gh-utility` root и `references/pr-ci-review-loop.md` прочитаны только как прямой consumer/interop; это не ревизия и не PASS downstream. Compiler не запускался: baseline-review допускает read-only inspection, а текущий FAIL не нуждается в записи/перегенерации для установления находки.

## F1 — P2: отсутствующий CI-владелец не имеет явного fallback в локальном контракте

**Evidence:** `SKILL.md:141` безусловно направляет diagnosis/remediation в `gh-fix-ci`; `SKILL.md:195` добавляет `when available`, но не определяет поведение при отсутствии. То же в `skill.yaml` (`whenNotToUse`, `interop-ci`) и `fragments/overview.md`, раздел Interop handoff. В доступном каталоге `gh-fix-ci` отсутствует; поиск пакета в `skills/` также не дал результата. Это утверждение ограничено проверенной средой, не всем возможным установкам. Между тем прямой consumer `gh-utility/references/pr-ci-review-loop.md`, Checks and logs, уже допускает передачу `gh-fix-ci or the implementation owner` с PR/check/run/log/head SHA/current repository state.

**Основание:** direct + inferred. Standard требует указать, какой вывод поставляет экспертная зависимость и что остаётся возможно при её отсутствии; одно имя не является доступной зависимостью. Противоречие не в запрете git-engineer самому чинить CI — этот запрет корректен. Дефект — неполный путь к реальному доступному исполнителю.

**Путь отказа:** пользователь разрешает локальное Git-завершение и дальнейшую обработку упавших checks → Git-агент сохраняет/проверяет commit/ref, достигает CI handoff → следует единственному названному specialist, которого нет → передаёт неисполняемый следующий шаг либо блокирует продолжение целиком, хотя Git-факты можно вернуть, GitHub evidence может получить gh-utility, а исправление принять действующий implementation owner. Это риск несостоявшейся передачи/лишней остановки, не наблюдённый запуском результат.

**P1 screen:** не установлен путь к опасной мутации, ложному CI PASS или silent authority invention: target явно запрещает выдавать CI fix и отделяет Git от GitHub. Ущерб ограничен interop/fallback, поэтому P2.

**Минимальная коррекция:** согласовать условность упоминаний; при недоступности specialist сохранять поддержанную Git-часть и предел доказательств, передавать GitHub inspection в gh-utility, remediation — фактически доступному owning implementation/domain workflow с известными входами. Если владелец неизвестен, назвать только этот пробел; не придумывать экспертный результат и не превращать отсутствие skill-name в общий запрет работы. Не делать git-engineer CI-ремедиатором и не редактировать downstream до его очереди.

**Закрывающая проверка / falsifier:** одинаковый neutral case baseline/candidate: разрешённая Git-часть, известный failed check, `gh-fix-ci` отсутствует, gh-utility и implementation owner доступны. Проверить реальные outputs обоих исполнителей/consumer: сохранены точные Git-факты, передача исполнима, CI не объявлен исправленным, самостоятельной external mutation/расширения полномочий нет. Отрицательный вариант — implementation owner неизвестен: останавливается только dependent remediation, названы минимальные недостающие входы. Достаточный корректный вариант — Git-only commit без CI не требует этого handoff.

## F2 — P3: conditional mandatory reference классифицирован как optional

**Evidence:** `skill.yaml` задаёт `required: false`, `surfaces.active.optionalReferences`; compile report пишет `Required references: none`; `SKILL.md:224–225` помещает worktrees под Optional references. При этом root `SKILL.md:133` и Start here явно требуют чтения до выбора/создания/переноса worktree, а reference повторяет этот trigger.

**Основание:** conflicting labels. Standard требует различать conditional required и optional; label не должен скрывать обязательность. Здесь обязательность не скрыта полностью: root повторяет точный trigger, ссылка существует. Поэтому установлен только bounded clarity/classification issue.

**P1 screen:** нет поддержанного пути к пропуску всех safety gates только из этой маркировки: core root уже направляет к reference и содержит default/authority. Нет оснований выдавать P1/P2 без дополнительного наблюдения.

**Коррекция:** пометить reference как conditionally required средствами поддержанного source schema, сохранив trigger; не делать его always-required для обычного commit. **Проверка:** source/generated readback плюс cases commit-only (reference не требуется) и worktree-create (reference прочитан до выбора/мутации). Не требуется переделывать package из-за длины.

## Поддержанные результаты и границы

- Root/overview сохраняют operation-specific authority: inspection ≠ mutation, commit ≠ push, push ≠ PR; точный target обязателен. Явного требования повторно запрашивать уже выданные полномочия не найдено. Conflict recovery не выполняется самовольно; in-progress state остаётся видимым.
- Scoped commit требует explicit intended paths/hunks, cached diff и resulting commit readback. Unrelated staged/unstaged/untracked state подлежит сохранению; global clean не условие успеха. Reference ограничивает preparatory `.gitignore` commit: при запрете или невозможности изоляции staged scope worktree не создаётся. Это действующая target policy, не основание автоматически ослаблять её в этой ревизии.
- Push требует exact remote/source/destination и fresh remote read; non-fast-forward требует explicit OID lease и owned non-protected task branch. Local tracking ref и exit code не закрывают remote claim; недоступный readback даёт partial. Эти инструкции не доказывают реальную provider protection/credentials.
- Worktrees: portable repo-local default, explicit operator location, canonical containment, no path-traversing slug, gate для неразрешённого external root, registration/HEAD/status verification. Move отдельно сохраняет tracked diffs/ignored state/symlinks, не допускает force/overwrite и учитывает занятость. Гарантия отсутствия невидимых процессов явно исключена.
- Прямой Git → gh-utility contract в целом согласован: Git предоставляет history method и ref facts, gh владеет platform execution/fresh readback. Review verdict не возникает из Git-операции. Настоящего межагентного consumer-run в данной ревизии не было; inspected compatibility не выдаётся за live integration.
- Metadata точно представляет Git/history/worktrees. Не найдено shipped runtime/test package: искусственный runtime не требуется. Source и emitted root содержательно прочитаны; fresh compiler parity не заявляется.
- Исторический `forward-test-evidence-20260716-1.md` содержит baseline-exact final root/reference/metadata hashes и описывает dirty commit, policy override, stale lease, routing. Это прежнее supporting evidence, не новые испытания этой ревизии. Старый worktree report содержит raw transcripts, но его исходный active hash отличается; выводы о текущем пакете ограничены unchanged reference и inspection. Вывод большого исторического файла был частично усечён инструментом; полная повторная forensic-аудитория исторических запусков не заявляется.

## Handoff

Следующий владелец — автор git-engineer: минимально исправить F1, принять решение по F2, сохранить fixed neutral cases/rubric до edits, выполнить owning structural checks и парные behavioral trials, затем независимый re-audit стабильного candidate. Findings не являются исправлениями или приёмкой группы. В рамках этой ревизии не выполнялись Git mutations, network, installs или delegation; изменён только данный отчёт в `/tmp`.
