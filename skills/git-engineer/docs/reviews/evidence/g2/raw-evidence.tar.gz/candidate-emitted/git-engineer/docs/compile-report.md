# Compile report
Generated from `skill.yaml`.

## Versions
- Skill source version: `0.2.1`

## Source files
- `agents/openai.yaml`
- `docs/README.md`
- `docs/logs/forward-test-evidence-20260713-1.md`
- `docs/logs/forward-test-evidence-20260716-1.md`
- `docs/logs/implementation-log-20260627-1.md`
- `docs/logs/implementation-log-20260713-1.md`
- `docs/logs/implementation-log-20260716-1.md`
- `docs/logs/implementation-log-20260907-1.md`
- `fragments/overview.md`
- `references/worktrees.md`
- `skill.yaml`

## Required references
- `references/worktrees.md`

## Warnings
- none

## Notes
- This document is supporting output only.
- It does not override `SKILL.md`.