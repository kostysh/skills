def load(form, send):
    return send({"account_id": form["account_id"], "tenant": form["tenant"]})
