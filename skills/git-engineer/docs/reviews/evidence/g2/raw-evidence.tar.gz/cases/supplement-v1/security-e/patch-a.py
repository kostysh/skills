def read(user, account):
    if user["tenant"] != account["tenant"]:
        raise PermissionError("Forbidden")
    return account["balance"]

def export_all(user, accounts):
    if user["role"] != "admin":
        raise PermissionError("Forbidden")
    return [a["balance"] for a in accounts]
