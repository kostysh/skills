from platform_auth import require_user, tenant_client

def lookup(request):
    user = require_user(request)
    client = tenant_client(user)
    return client.get_account(request.params["account_id"])
