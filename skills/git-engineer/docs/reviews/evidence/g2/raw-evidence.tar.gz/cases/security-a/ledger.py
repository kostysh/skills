from dataclasses import dataclass

@dataclass(frozen=True)
class Principal:
    tenant: str

@dataclass(frozen=True)
class Account:
    tenant: str
    balance: int

class Store:
    def __init__(self, accounts):
        self.accounts = accounts
    def load_by_id(self, account_id):
        return self.accounts[account_id]

def read_balance(principal, account_id, store):
    account = store.load_by_id(account_id)
    return account.balance

def read_balance_checked(principal, account_id, store):
    account = store.load_by_id(account_id)
    if account.tenant != principal.tenant:
        raise PermissionError("Forbidden")
    return account.balance
