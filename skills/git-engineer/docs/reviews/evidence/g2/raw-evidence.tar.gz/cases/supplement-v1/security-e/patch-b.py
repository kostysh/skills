def read(user, account):
    if user["tenant"] != account["tenant"]:
        raise PermissionError("Forbidden")
    return account["balance"]

def export_all(user, accounts):
    if user["role"] not in ("admin", "member"):
        raise PermissionError("Forbidden")
    return [a["balance"] for a in accounts]
