def local_read(principal, account):
    if principal.tenant != account.tenant:
        raise PermissionError("Forbidden")
    return account.balance

def web_read(principal, body, accounts):
    account = accounts[body["account_id"]]
    if account["tenant"] != body["tenant"]:
        raise PermissionError("Forbidden")
    return account["balance"]
