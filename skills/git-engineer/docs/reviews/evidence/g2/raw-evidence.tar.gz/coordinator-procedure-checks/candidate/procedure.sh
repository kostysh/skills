set -euo pipefail
cd /tmp/skills-revision-g2-20260907-qfdkj6eo/coordinator-procedure-checks/candidate/fixture
export GIT_OPTIONAL_LOCKS=0
test "$(git symbolic-ref --short HEAD)" = codex/ledger-notes
test "$(git rev-parse HEAD)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
for state in MERGE_HEAD CHERRY_PICK_HEAD REVERT_HEAD rebase-merge rebase-apply sequencer; do
  test ! -e "$(git rev-parse --git-path "$state")"
done
git status --porcelain=v2 --branch
git diff --cached --name-status
git diff --cached
git diff -- notes.md
test "$(git diff --cached --name-only)" = unrelated.txt
test "$(git diff --name-only)" = notes.md
test "$(git ls-files --others --exclude-standard)" = scratch.txt
test "$(cat notes.md)" = v2
before_head=$(git rev-parse HEAD)
before_staged=$(git diff --cached --binary -- unrelated.txt)
before_index=$(git ls-files --stage -- unrelated.txt)
before_files=$(sha256sum unrelated.txt scratch.txt)
git diff --check -- notes.md
git diff --cached --check
# --only commits the named worktree file; unrelated staged content stays staged.
git commit --only -m 'docs: update ledger notes' -- notes.md
result_oid=$(git rev-parse HEAD)
test "$(git rev-parse HEAD^)" = "$before_head"
test "$(git symbolic-ref --short HEAD)" = codex/ledger-notes
test "$(git diff-tree --no-commit-id --name-only -r HEAD)" = notes.md
test "$(git log -1 --format=%s)" = 'docs: update ledger notes'
git diff --exit-code HEAD -- notes.md
test "$(git diff --cached --binary -- unrelated.txt)" = "$before_staged"
test "$(git ls-files --stage -- unrelated.txt)" = "$before_index"
test "$(sha256sum unrelated.txt scratch.txt)" = "$before_files"
test "$(git ls-files --others --exclude-standard)" = scratch.txt
git show --format=fuller --stat "$result_oid"
git show --format= -- notes.md
git status --porcelain=v2 --branch
