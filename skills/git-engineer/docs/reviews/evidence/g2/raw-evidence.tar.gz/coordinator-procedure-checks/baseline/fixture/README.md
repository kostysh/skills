Ledger notes
