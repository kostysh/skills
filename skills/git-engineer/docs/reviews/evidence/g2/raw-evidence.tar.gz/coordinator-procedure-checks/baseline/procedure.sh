set -eu
cd /tmp/skills-revision-g2-20260907-qfdkj6eo/coordinator-procedure-checks/baseline/fixture
export GIT_OPTIONAL_LOCKS=0
test "$(git branch --show-current)" = codex/ledger-notes
test "$(git rev-parse HEAD)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
test "$(git status --porcelain=v1)" = "$(printf ' M notes.md\nM  unrelated.txt\n?? scratch.txt')"
printf '%s\n' \
 '81db67b6a5702b9b68f0016f061c409bf3fb16d062fc854d1b424bb4e9c28c56  notes.md' \
 'ada28a6ce45b2e3444cbff8f40a7909ab81355e8278cfcfd6d782315f94c0a96  unrelated.txt' \
 'b1f830a85aa67c98c6ec8d0fae962b90a9e92eb37112d02ab25d3f94923219ad  scratch.txt' | sha256sum -c -
test "$(git rev-parse :unrelated.txt)" = 7d05f28b3755aa3209d744549391deec8b0aaf1b
for state in MERGE_HEAD CHERRY_PICK_HEAD REVERT_HEAD rebase-merge rebase-apply sequencer; do
  test ! -e "$(git rev-parse --git-path "$state")"
done
git diff --check
git diff --cached --check
git diff -- notes.md
git diff --cached --name-status
git diff --cached -- unrelated.txt
# STOP if inspected diff differs from the recorded scope.
# --only takes notes.md from the worktree and excludes unrelated staged content.
git commit --only -m 'docs: update notes to v2' -- notes.md
new_oid=$(git rev-parse HEAD)
test "$(git branch --show-current)" = codex/ledger-notes
test "$(git rev-parse HEAD^)" = b9769c9d2a09f4b689bec4e3afeed8d870f542b7
test "$(git show -s --format=%s HEAD)" = 'docs: update notes to v2'
test "$(git diff-tree --no-commit-id --name-only -r HEAD)" = notes.md
git show --format=fuller --stat HEAD
git show --format= -- notes.md
git diff --exit-code HEAD -- notes.md
test "$(git rev-parse :unrelated.txt)" = 7d05f28b3755aa3209d744549391deec8b0aaf1b
test "$(git status --porcelain=v1)" = "$(printf 'M  unrelated.txt\n?? scratch.txt')"
printf '%s\n' \
 'ada28a6ce45b2e3444cbff8f40a7909ab81355e8278cfcfd6d782315f94c0a96  unrelated.txt' \
 'b1f830a85aa67c98c6ec8d0fae962b90a9e92eb37112d02ab25d3f94923219ad  scratch.txt' | sha256sum -c -
git diff --cached -- unrelated.txt
git status --porcelain=v2 --branch
printf 'Resulting local commit: %s\n' "$new_oid"
