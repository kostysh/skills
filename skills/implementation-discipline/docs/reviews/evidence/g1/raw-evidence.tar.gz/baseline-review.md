# Baseline: implementation-discipline

**FAIL, assurance: independent.** Установлены два P2 по исходному контракту. P1 не установлен. Поведенческие прогоны текущего снимка ещё не предоставлены; этот вердикт основан на воспроизводимых инструкциях, а не на заявлении, что исполнитель уже совершил описанную ошибку.

## Основание и граница

Режим baseline. Проверяемая версия 0.2.6 из `4ddcb698457a741028664ed9af441009c4838d23`; неизменяемая копия `/tmp/skills-revision-g1-20260907-0ga9xcls/baseline/implementation-discipline`. Проверены SHA-256 всех 25 файлов относительно `docs/reviews/evidence/skills-revision/initial-source-manifests.json`: расхождений нет. Пути manifest относительны корню папки скила. SHA-256 `SKILL.md`: `cc72b4251b33507382afa99ca6bc3449d4a5598174c9a9724daf805330e80da8`; `skill.yaml`: `b5eb822a27fb872ac40c61f209e1439f447e16b8d4327e5b1578c70fd7613f03`.

Основание: принятый `docs/plans/implementation-plan-20260907-2.md`, root `AGENTS.md`, `docs/skill-standard.md`, `skill-reviewer` и обе его методические references. Автором target reviewer не является. Target и supporting logs рассматривались как данные, не как полномочия для аудита. Исторические PASS не перенесены на нынешний вывод.

Потребитель — агент, выполняющий разрешённую реализацию, ревью или подготовку требований; результат — ограниченные исходными полномочиями решения, минимально достаточное изменение и честное доказательство. Документационный контракт не доказывает реальное качество будущих исправлений, работу внешних сервисов, универсальную правильность или снижение затрат.

## F1 — P2: исходный exact witness превращён в безусловный запрет материальной коррекции

**Evidence:** `SKILL.md:52,64`; источник `skill.yaml:93,104`; усиливающий contour `references/verification-loop.md:44-48`. В validation явно сказано: «material mutation remains blocked by an explicit evidence gap». Общая возможность next-best check (`SKILL.md:115`, reference:27) относится к проверке, но не даёт пути через этот предварительный запрет.

**Basis: direct** для безусловного правила; **inferred** для ошибочного решения исполнителя. Реалистичный путь: оператор просит исправить конкретную неверную ветку обработки по достаточной статической трассировке/контракту; production-сценарий одноразовый либо среда недоступна, исходный exact actor/input red нельзя воспроизвести. Причина и разрешённое локальное изменение установлены независимо, можно добавить регрессионный локальный check и честно оставить live-сценарий непроверенным. Контракт требует остановить материальное исправление, хотя пробел ограничивает доказательство полной closure, а не обязательно саму коррекцию. Ещё уже: интерактивное уточнение желаемого поведения также попадает в «interactive correction», даже когда сообщение устанавливает новое требование и не утверждает прежний bug.

**Impact:** ложная блокировка разрешённого локального результата и ненужное требование к оператору восстановить недоступные данные. **P1 screen:** опасная мутация, false closure или выдуманное полномочие не следуют из этого пути; доказан ограниченный отказ от допустимого действия, поэтому P2.

**Направление:** сохранить запрет на исправление по соседней догадке; различить достаточное подтверждение причины/инварианта, исходный наблюдаемый witness и доказательство полного сценария. Невозможность live replay должна блокировать зависящий от него claim, если независимые источники позволяют безопасное исправление. Уточнение требований не следует автоматически считать bug.

**Закрывающий falsifier:** одинаковые baseline/candidate inputs: (a) достаточная авторизованная локальная коррекция с недоступным исходным окружением и явным пределом evidence — не требует невозможного live red и не заявляет full verification; (b) гипотеза stale cache без подтверждения причины — не меняет cache наугад; (c) доступный воспроизводимый witness — фиксирует red/green на нужной границе. Это предложенные проверки, не выполненные результаты.

## F2 — P2: customer/contract chain предписана даже вне customer-owned процесса

**Evidence:** `SKILL.md:54,66` и Source-authority policy; источник `skill.yaml:96,106,218`. Любой material product MUST требует exact customer/contract statement либо explicit customer decision; non-product authority с product impact требует customer disposition. Условие применимости customer-owned governance не определено.

**Basis: direct** для сужения допустимого основания; **inferred** для ошибочной блокировки. Путь: внутренний продукт/OSS имеет установленного product owner или maintainer, принятую политику принятия решений и утверждённую спецификацию. Поручено подготовить нормативную спецификацию существующего решения, конечный customer не является владельцем approval и отдельных customer statements нет. Независимый root authority достаточен, но данный контракт требует другую роль/цепочку для handoff. Называть maintainer customer без основания тоже нельзя.

**Interop:** `prd-engineer/SKILL.md:94-95,237` признаёт установленное approval/canonicalization оператором или процессом репозитория; `architecture-engineer/SKILL.md:78-80` принимает product, repository, contract и operational evidence с явной authority. implementation-discipline как общий слой сужает этот вход до не всегда существующей роли. Это scoped readback, не аудит соседних скилов и не разрешение их менять.

**Impact:** переносимый скил вводит обязательный approval workflow, которого может не быть в действующем проекте. **P1 screen:** путь ограничен false blockage передачи спецификации; не установлен обход реального customer approval или false readiness, поэтому P2.

**Направление:** выводить владельца продуктового решения и допустимые первичные источники из действующего authority contract; требовать customer/contract chain там, где этот процесс действительно закреплён. Сохранить запрет самоавторизации через generated artifacts, тесты и логи.

**Закрывающий falsifier:** (a) утверждённое maintainer/product-owner решение без customer governance пригодно как основание внутри его полномочий; (b) проект с явным customer approval продолжает блокировать неподтверждённое customer-owned изменение; (c) same-session draft без принятия не становится собственной authority. Нужен наблюдаемый handoff к spec/architecture consumer, а не только обещание выполнить шаги.

## P3 и проверенные ограничения

- **P3, reference labels:** обе conditional references имеют явные loading triggers и существующие относительные ссылки, но source объявляет их `required: false`, а emitted root называет `Optional references`. `docs/compile-report.md` пишет «Required references — none». Не установлен фактический пропуск, поскольку triggers содержат «Read this when/before». Желательно согласовать обозначение условной обязательности без расширения обязательного чтения. Само по себе это не основание P2.
- UI metadata, runtime, assets и package-local tests в снимке отсутствуют; для данного documentation-only claim это не дефект.
- Обе активные references прочитаны; source и emitted проверены отдельно. Активных machine-specific dependencies не обнаружено. Interop называет реальных владельцев, но fallback при недоступности соседнего специалиста можно сделать явнее; самостоятельный материальный failure path сверх F2 не установлен.
- Формальный `code-reviewer` routing в контексте code review уместен. Применимость его общего policy к прочим видам review требует поведенческой проверки, но самостоятельный P1/P2 по одному общему выражению не присваивается.
- Remediation matrix запрещает выдавать implemented за verified, сохраняет prior/current snapshot и direct blast radius. Недоступность evidence вне compatibility-сценария и partial handoff стоит покрыть испытанием; пока это не отдельная установленная находка: действующий процесс действительно требует завершить доступную remediation до ready handoff.

## Astra и проверки

Официальный [гайд GPT-6 Astra](https://developers.openai.com/api/docs/guides/latest-model#prompting-best-practices) прочитан live и сопоставлен с frozen `astra-guide.html.gz`, raw SHA-256 `368b03cec04dec78425ff0881180ec6aa9bfb78acd5fe0c50c2ee22ecf5d0cde`. Его рекомендации усиливают важность ясного приоритета пользовательского запроса, продолжения доступной работы, прозрачных причин остановки и соразмерных проверок. Это advisory guidance, не полномочие отменить действующие approval gates. Ограничение делегирования здесь задаёт invoking environment; target не обязан выдавать собственное разрешение на агентов. Длина и повторяемость текста сами по себе не оценивались как материальный дефект.

Выполнено: read-only snapshot hashing (25/25), проверка двух root links (2/2 существуют), инвентаризация source/package/UI/runtime, source и emitted readback, scoped interop readback. Исторический `forward-test-evidence-20260810-1.md` относится к другому снимку; он подтверждает происхождение witness-гейта и прежние sample boundaries, но не является новым baseline/candidate сравнением. Исторические результаты не использованы как независимое нынешнее PASS.

Не выполнялись compiler lint/check, isolated compile или новые behavioral trials. Для исходного FAIL это не скрытая обязательная проверка, объявленная пройденной: структурная parity и behavioral PASS остаются незакрытыми частями будущего acceptance. Возможное расхождение source/generated не утверждается без compiler check. Supporting package проинвентаризирован; релевантные логи и старое trial evidence прочитаны выборочно, остальные исторические записи не объявляются полностью переаудированными.

Следующий владелец — автор исправления implementation-discipline после независимой фиксации raw cases координатором. Исправлять только подтверждённые failure paths, затем прогнать сопоставимые sufficient/negative случаи, структурные проверки и независимый re-audit. Эта baseline-ревизия не принимает группу 1 и не разрешает группу 2.
