# Журнал ревизии implementation-discipline

## Основание и границы

Русский; ID `implementation-log-20260907-1`. Принятый общий [план](../../../../docs/plans/implementation-plan-20260907-2.md), группа 1. Отдельного issue нет. Оператор разрешил реализацию и агентов, отдельный skill commit и остановку на приёмке группы. Дополнение оператора: использовать доступный встроенный планировщик для видимого прогресса и включить это правило в скил. Scope delta: expanded только этим прямым требованием; остальные границы unchanged. Группы 2–4 и публикация сейчас не выполняются.

База `4ddcb698457a741028664ed9af441009c4838d23`, worktree `codex/skills-revision`. Baseline 0.2.6, candidate 0.2.7. Actor — агент, выполняющий разрешённую правку либо авторскую задачу. Capability — обоснованное локальное действие/ограниченный вывод и видимый ход многошаговой работы. Source/generated — substrate; тестовые задачи не доказывают универсальную надёжность или работу недоступного native UI.

## Findings → исправления → доказательство

Независимый baseline reviewer `/root/g1_baseline_review` установил FAIL: два P2 и P3. Полный отчёт и исходный snapshot будут сохранены с evidence до итогового аудита.

| Основание | Прямой путь и исправление | Falsifier / статус |
| --- | --- | --- |
| F1 P2 | Невозможность исходного live witness блокировала даже независимо подтверждённую локальную коррекцию. Разделены достаточное основание изменения, исходный witness и доказательство полного deployed-сценария; соседняя гипотеза не разрешает правку. | Cases01/03/09: реальное red/green, недоказанная причина, bounded fix без production replay; implemented |
| F2 P2 | Универсальная customer chain навязывала отсутствующего владельца внутреннему проекту. Владелец и approval берутся из действующего governance; customer gate сохраняется там, где применим. | Cases04/06/10 и реальный spec consumer, включая отдельный customer-owned вариант; implemented |
| P3 | Условно обязательные references обозначались optional. Согласована required classification при прежних условиях чтения, без требования всегда читать обе. | lint/check, generated/readback и trials; implemented |
| Прямое требование оператора | Native user-visible planner для существенной многошаговой работы, честные transitions; fallback на краткий progress при отсутствии инструмента, без новой блокировки или конкурирующего плана. | Cases07/08 и простой01: available-tool decision exercise, фактический fallback и proportionality; implemented |

## Авторская самопроверка перед генерацией

`ready-to-regenerate`: исходные материалы, baseline и три независимых набора критериев frozen до candidate edits. Изменения ограничены названными решениями в skill.yaml и verification-loop.md; runtime/package/UI не добавлены. Основные новые правила имеют владельца и прямое основание. Приоритет явного operator/project authority не ослабляет реальный approval; локальная проверка не закрывает недоступную production-границу. Планировщик обнаруживается через реальный tool catalogue; фиксированное имя или искусственный вызов не предполагается. Нет нового harness, требования отдельной приёмки плана для обычной правки или отмены существующего checkpoint.

Это author self-check, не independent PASS. После generation нужны parity и trials.

## Evidence и ограничения

Исходный пакет: 25 source files, 9 emitted files побайтно совпали. Собственные baseline lint/check/emitted check проходят. Вспомогательный quick_validate отклоняет существующий compatibility; это его ограничение allowlist, не новый дефект. В текущем host native planner/update_plan отсутствует; available-tool case07 проверяет только решение по заданному контракту, не actual native call/UI. Case08 проверит реальный fallback. Skill histories исключены из trial-копии, active references сохранены; полный emitted package проверяется отдельно. Изоляция по инструкции на shared filesystem не является OS sandbox.

Case author `/root/g1_cases` не видел candidate. Основные35файлов и planner-addendum frozen до получения findings; дополнительные09/10 созданы с раскрытым знанием baseline findings, но до candidate edits. Исполнители fresh/no-fork и рубрики/диагнозы не получают. Настройки наследуются от координатора; назначение не выдаётся за независимое измерение модели.

## Статус

`IMPLEMENTED — verification in progress`. Далее source/generated checks, paired trials, отдельный assessor и independent re-audit; затем отдельный commit этого скила и приёмка группы 1. Соседние скилы не изменены. Откат — восстановить source/generated по Git baseline с сохранением evidence и чужих правок.
