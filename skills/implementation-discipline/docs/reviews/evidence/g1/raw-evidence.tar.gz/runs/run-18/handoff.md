# Handoff to spec-engineer

Mode: design/authoring. Consumer: the specification author, using the existing spec-engineer owner to prepare implementer instructions. This task authorizes only this handoff; implementation is not performed.

## Source and scope

Accepted authority: operator decision **R-1**, `workspace/request.md`. Context: `workspace/context.md`. R-1 owns the requested behavior; this handoff is a derived artifact, not additional scope authority. No separate customer approval process is supplied or needed for this bounded operator decision.

Observable outcome: callers of the existing pure `label(value)` utility receive `Untitled` for null or undefined and receive every string unchanged, including the empty string. The editor uses this utility for document titles, but the claim is limited to the local utility contract.

| Requirement | Authority and applicability | Necessity / removal falsifier |
| --- | --- | --- |
| Null and undefined yield `Untitled`. | Explicit R-1; declared nullish inputs. | Removing either case violates R-1: direct invocation would produce something other than `Untitled`. |
| Every string is preserved exactly, including `''`. | Explicit R-1; all declared string inputs. | Removing preservation permits a changed string; `label('') !== ''` is the critical falsifier. |

Non-string, non-null values are outside the declared input contract; do not invent coercion, validation, or fallback behavior for them. Scope remains the existing pure utility. No persistence, UI, service, or release changes are authorized.

## Smallest solution and evidence handoff

Prefer the existing utility with direct nullish handling; no abstraction, dependency, configuration, or new verification infrastructure is justified. The utility source is not supplied, so its present implementation and any prior failure cause have not been established.

For the later authorized implementation, spec-engineer should map R-1 to focused checks in the available local `node:test` suite: direct calls for null and undefined must equal `Untitled`; empty, ordinary, and whitespace strings must equal their original values exactly. These concrete string cases witness preservation; the contract covers all strings. Use the existing declared package command once located rather than inventing one. These checks are derived verification of R-1, not new product requirements.

No cross-layer round trip is required for this pure utility boundary: persistence, services, projection, and reload are outside scope. Local checks can pass without proving rendered editor behavior; do not claim an editor fix or deployment from them.

## State and next action

This handoff was checked against both supplied workspace sources. No utility code or tests were changed or executed. Available evidence is the accepted requirement and contextual statement only; there is no rendered-editor evidence or runtime reproduction. Next: spec-engineer turns this bounded source/scope/evidence packet into implementer instructions, preserving R-1 and the local claim boundary.
