export function label(value) { return value ?? 'Untitled'; }
