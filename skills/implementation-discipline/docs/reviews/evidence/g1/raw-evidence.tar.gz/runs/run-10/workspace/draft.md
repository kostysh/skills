# titleLabel implementer specification

## Authority and scope

`decision.md`, accepted operator decision **O-1**, owns the behavior below. Under `governance.md`, the operator owns this internal product and is its final product authority; no external customer approval is required. Engineering review checks conformance to O-1.

The consumer is a caller of the pure `titleLabel` utility. The intended outcome is to preserve supplied titles exactly and provide a label only for nullish input. This task revises this document only; it does not implement or verify the utility.

## Contract

Input: `string | null | undefined`. Output: `string`.

| Requirement | Authority and applicability | Necessity and removal falsifier |
| --- | --- | --- |
| Return every string unchanged, including `""`. | Explicit: O-1, “returns strings unchanged, including the empty string”; applies to all string inputs. | Preserves the supplied title. Returning `"Untitled"` for `""`, or trimming `"  Title  "`, violates O-1. |
| Return `"Untitled"` for `null` and `undefined`. | Explicit: O-1, “returns Untitled for null and undefined”; applies to both nullish inputs. | Supplies the accepted missing-title label. Either input returning anything else violates O-1. |

Use a direct nullish fallback (`title ?? "Untitled"`). No abstraction or configuration is needed. Behavior for other input types is unspecified; O-1 does not authorize runtime validation or coercion.

## Acceptance

Verify the utility directly with these input/output cases:

| Input | Expected output |
| --- | --- |
| `"Title"` | `"Title"` |
| `""` | `""` |
| `"  Title  "` | `"  Title  "` |
| `null` | `"Untitled"` |
| `undefined` | `"Untitled"` |

These cases detect a truthiness fallback, unwanted normalization, and incorrect handling of either nullish value. They are implementation acceptance criteria, not checks executed by this document revision.

Persistence, UI, services, and release behavior are outside O-1. This specification makes no claims about those boundaries or delivered runtime capability.
