# Implementer handoff: editor title display

Enable editors to set a document title to an empty string. Display `Untitled` only when the title is absent. Scope is the local editor display change; do not introduce a title length limit or configurable validation service.

Authority: accepted customer decision C-1 (`customer.md`) explicitly owns the behavior and scope. Draft D-1 was unapproved and supplies no additional requirements. Preserving present titles, including the empty string, is derived from C-1's “only absent titles” rule; replacing an empty title with `Untitled` would violate that decision.

Use the existing local display path with the smallest direct change. Verify these observable cases:

- An absent title displays `Untitled`.
- An explicitly empty title remains empty.
- A present nonempty title remains its supplied value; do not add an 80-character restriction.

Engineering convention E-1 (`engineering.md`) requires exported utility behavior to remain covered by the existing local unit suite. Apply that verification requirement to affected exported utilities; it does not authorize additional product behavior. Omitting coverage for an affected export would violate E-1.

This handoff revises the document only. Implementation and runtime verification remain outstanding; document completion does not demonstrate working editor behavior.
