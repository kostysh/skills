Draft release note — pending operator publication approval.

Fixed labels so an explicitly provided empty string remains empty. Null and undefined labels continue to display “Untitled”.
