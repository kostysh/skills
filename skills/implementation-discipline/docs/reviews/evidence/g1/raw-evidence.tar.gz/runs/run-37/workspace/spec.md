# Nullish fallback for `label(value)`

## Scope And Handoff

**Status:** ready for implementer. **Consumer:** the implementer of the existing pure `label()` utility. This authoring task produces only this specification.

The accepted authority is the operator's decision R-1 in [request.md](request.md). [context.md](context.md) establishes document-title use and availability of a local `node:test` suite. [handoff.md](../handoff.md) is a derived input, consistent with R-1; it grants no additional scope. No further approval chain or artifact convention is supplied; the requested output is `workspace/spec.md`.

The utility supports editor document-title handling. Its callers observe the returned value; rendered-editor behavior is outside this specification's claim. Risk is low: the bounded failure is an incorrect returned title. No architecture change is needed.

## Behavior

`value` is an input in the declared domain: strings, `null`, or `undefined`. “Unchanged string” means exactly the input string, including empty content and whitespace. `Untitled` is the literal fallback string.

On a call within that domain, `label(value)` returns the fallback for either nullish value and returns every string unchanged. The existing pure-utility boundary remains the implementation contour. Prefer the direct existing-language nullish operation after inspecting the source; no new abstraction is needed. Current implementation behavior and its cause have not been supplied, so this states the accepted target rather than an observed before/after defect.

## Requirements

All requirements are explicit obligations from R-1, owned and accepted by the operator; applicability is limited to calls to this utility.

| ID | Requirement | Source meaning and removal falsifier | Verification |
| --- | --- | --- | --- |
| SPEC-R1 | For `value === null`, `label(value)` MUST return `Untitled`. | R-1's null fallback; removing this permits a result that violates that fallback. | AC1 |
| SPEC-R2 | For `value === undefined`, `label(value)` MUST return `Untitled`. | R-1's undefined fallback; removing this permits a result that violates that fallback. | AC2 |
| SPEC-R3 | For every string `value`, `label(value)` MUST return that string unchanged. | R-1's preservation of every string, explicitly including empty strings; removing this permits replacement or transformation of valid string input. | AC3 |

These obligations are necessary to express R-1's complete input partition. They do not define behavior for values outside that partition.

## Edge Cases

`''` is a valid string, not a missing value. Whitespace-only strings are also preserved. Ordinary titles retain their exact contents. Non-string, non-null values are outside the declared contract: this work adds no validation, coercion, rejection, or fallback policy for them.

## Acceptance

The implementer owns verification through the available local `node:test` suite, invoking the actual utility rather than a duplicate expression or mock:

- **AC1 → SPEC-R1:** assert `label(null)` equals `Untitled`.
- **AC2 → SPEC-R2:** assert `label(undefined)` equals `Untitled`.
- **AC3 → SPEC-R3:** assert exact input/output equality for `''`, a whitespace-only string such as `'  '`, and an ordinary title such as `'Draft title'`; inspect the bounded implementation to confirm preservation applies to all strings rather than only these examples.

The empty-string assertion is the narrowest negative discriminator: returning `Untitled` for `''` fails acceptance even if ordinary-title and nullish cases pass. Any altered whitespace or ordinary title also fails SPEC-R3. These examples are derived verification choices, not additional product rules. Use existing test conventions and the existing suite command once located; no new runner or instrumentation is needed.

## Anti-Claims / Gaps

No inputs are missing that prevent this specification. Utility source, test paths, implementation language, and the exact test command were not supplied; the implementer must locate them before changing or executing code. The assumed existing utility and local suite are source-provided context, not inspected runtime evidence.

No code or tests have been executed or changed. This document establishes neither implemented behavior nor rendered-editor integration or release readiness. Persistence, public readback, reload, and cross-layer checks are inapplicable to this pure return-value contract. UI, persistence, services, release changes, and new dependencies, configuration, or lifecycle mechanisms are outside scope. No architecture decision is pending for this bounded behavior.
