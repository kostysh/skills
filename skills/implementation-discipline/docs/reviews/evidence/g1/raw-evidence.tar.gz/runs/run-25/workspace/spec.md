# Preserve strings in `label(value)`

## Scope And Handoff

**Status: ready for implementer.** This is specification authoring only; the permitted output is `spec.md` at the requested workspace location. No other artifact convention was supplied.

Accepted authority is [request.md](request.md), operator decision **R-1**. [context.md](context.md) identifies the existing editor title utility, implementer consumer, and available future `node:test` suite. [handoff.md](handoff.md) is a derived input checked against those originals, not authority for extra scope.

Scope is the existing pure `label()` utility. Its parent role is supplying document titles to the editor; the observable claim here ends at the utility's return value. Risk is low: a wrong rule substitutes or changes a caller's title string. No architecture boundary is affected.

## Behavior

The caller supplies `string | null | undefined` and receives a string. “Nullish” means exactly `null` or `undefined`; “preserve” means return a string equal to the input, with no trimming, normalization, or fallback substitution. Calls have no side effects, consistent with R-1's existing pure-utility scope.

Nullish inputs return `'Untitled'`; every string returns unchanged. This deterministic local contract lets callers distinguish an empty title from a missing title. Current implementation behavior was not supplied or observed; these are target requirements, not a claim about a reproduced defect. Prefer the direct existing utility path and language nullish fallback primitive; no new abstraction or dependency is necessary.

## Requirements

All requirements below are explicit in R-1 and apply only to calls within the declared input contract.

| ID | Atomic requirement | Exact authority, necessity, and removal falsifier |
| --- | --- | --- |
| SPEC-R1 | For `value === null`, `label(value)` MUST return `'Untitled'`. | R-1: “only null and undefined map to Untitled.” Required to provide the missing-title fallback; removing it permits `null` to return another result. |
| SPEC-R2 | For `value === undefined`, `label(value)` MUST return `'Untitled'`. | Same R-1 statement; required for the other nullish input; removing it permits `undefined` to return another result. |
| SPEC-R3 | For every string `value`, `label(value)` MUST return that exact string. | R-1: “preserve every string, including empty strings.” Required to avoid changing valid titles; removing it permits `''` to become `'Untitled'` or `'  Title  '` to be altered. |

## Edge Cases

An input string `'Untitled'` remains `'Untitled'` by string preservation, not by substitution. Empty and whitespace-only strings are valid strings. Numbers, booleans, objects, and all other non-string non-null inputs are outside the declared contract; this spec assigns them no result, coercion, rejection, or validation policy.

## Acceptance

The implementer owns verification through direct calls to the actual utility in the existing local `node:test` suite, using its declared package command discovered during implementation.

| Acceptance / requirement | Direct check and failure oracle |
| --- | --- |
| AC1 / SPEC-R1 | `label(null)` equals `'Untitled'`; any other result fails. |
| AC2 / SPEC-R2 | `label(undefined)` equals `'Untitled'`; any other result fails. |
| AC3 / SPEC-R3 | For `''`, `'Title'`, `'   '`, `'  Title  '`, and `'Untitled'`, returned value equals input. Any substitution or alteration fails. |

The empty-string assertion is the narrowest falsifier for an erroneous truthiness fallback. Examples support the universal string rule; inspect the direct implementation to confirm it preserves arbitrary strings rather than special-casing examples. Test-file presence or a mocked replacement of `label()` is insufficient evidence.

Verification ends at input → actual utility → return value. Canonical persistence, public projection, DTO mapping, rendered consumption, and authoritative reload are non-applicable because R-1 restricts this to a pure local utility and excludes those changes.

## Anti-Claims / Gaps

No persistence, UI, service, or release changes are specified. Local acceptance does not prove rendered editor behavior, saved-title continuity, or release readiness. No extra validation mechanism, harness, instrumentation, or configuration is required.

No source-owned decision blocks the specification. Implementation and test files, package command, and current behavior are not supplied; their discovery remains implementation work. The stated test-suite availability is source context, not verified execution. Only the supplied documents were checked for scope, requirement authority, and matching acceptance; no runtime implementation or tests were run.
