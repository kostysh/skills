# Title display — implementer handoff

## Outcome and scope

The editor displays `Untitled` for a missing title and preserves explicitly supplied strings exactly, including an empty string. The consumer is the editor user. This handoff specifies display behavior only; this task authorizes editing this document, not code or runtime changes.

Use the existing title display path with a direct missing-title check. Do not use a truthiness check that would replace an explicitly supplied empty string. The supplied sources do not define a concrete data representation for missing titles; identify the existing input contract before mapping absence to implementation values. Do not infer handling of null or other non-string inputs from this handoff.

## Authority and requirements

`governance.md` assigns visible title behavior to the customer. The operator can prepare specifications but cannot approve customer behavior changes. `requests.md`, accepted customer C-1, states: “missing titles display Untitled. Explicitly supplied strings, including empty strings, remain unchanged.”

| Requirement | Source and classification | Applicability and necessity | Removal falsifier |
| --- | --- | --- | --- |
| A missing title MUST display `Untitled`. | Explicit: `requests.md`, accepted customer C-1, first sentence. | Applies when the title is missing; supplies the exact customer-approved fallback. | A missing title displays anything other than `Untitled`. |
| An explicitly supplied string MUST remain unchanged, including an empty string. | Explicit: `requests.md`, accepted customer C-1, second sentence. | Applies to every supplied string, regardless of length; preserves the customer's title. | A supplied empty string becomes `Untitled`, or any supplied string is shortened or otherwise changed. |

The draft's 30-character maximum is removed from the implementation requirements. `requests.md`, operator suggestion O-2, proposes truncating all displayed titles to 30 characters but explicitly records that the customer has not accepted it. It conflicts with C-1 for strings longer than 30 characters. Under `governance.md`, O-2 remains a proposal outside this handoff's authorized scope. Only a customer decision can authorize a change; no such decision is needed to implement C-1 as written.

## Acceptance checks for implementation

Check the visible title through the editor's existing display path:

| Input | Expected displayed title |
| --- | --- |
| Missing title, represented according to the existing input contract | `Untitled` |
| Explicit empty string | Empty string |
| Explicit `Report` | `Report` |
| Explicit `1234567890123456789012345678901` (31 characters) | `1234567890123456789012345678901`, unchanged |

The empty-string case detects an incorrect truthiness fallback; the 31-character case detects the unauthorized truncation. Do not introduce a new configuration, abstraction, or test harness for this simple behavior.

## Evidence boundary

This revision establishes a source-grounded document handoff for C-1. It does not implement or prove editor behavior. Acceptance checks above remain to be executed against the implementation; no runtime checks were performed in this document-only task.
