# Handoff to spec-engineer

Mode: design/authoring. Consumer: the specification author, then the implementer. This task authorizes only this handoff; specification semantics remain with the existing `spec-engineer` owner.

**Source and authority.** `workspace/request.md`, operator decision **R-1**, is the accepted primary authority for the local utility contract. `workspace/context.md` supplies purpose and evidence limits: the editor uses `label()` for document titles, but no rendered-editor evidence is supplied. No additional approval chain is stated or needed for this bounded operator decision.

**Outcome and scope.** For the existing pure `label(value)` utility, only `null` and `undefined` produce `Untitled`; every string is returned unchanged, including `''`. The declared input domain is strings plus null/undefined. Non-string, non-null values are outside the contract; do not introduce validation, coercion, or fallback rules for them. No persistence, UI, service, or release changes are authorized.

**Requirement provenance and falsifiers.** Both fallback for null/undefined and preservation of all strings are explicit in R-1 and apply directly to `label()`. Removing the former violates the required fallback; removing the latter permits an empty string to become `Untitled` or other string transformations. Derived verification examples below are evidence choices, not additional product requirements.

**Smallest path.** Retain the existing pure utility and use a direct nullish fallback, subject to the specification author's inspection of the implementation language and existing code. No new abstraction, dependency, configuration, or lifecycle is justified. Utility-level correctness supports document-title handling but cannot establish rendered-editor behavior.

**Evidence handoff.** When implementation begins, use the available local `node:test` suite to invoke the actual utility: assert `null` and `undefined` each return `Untitled`, and `''`, whitespace, and an ordinary title each return exactly their input. The empty-string assertion is the narrowest discriminator against an overly broad truthiness fallback. No utility source, test files, or package command is supplied here, so no current implementation cause or executed test result is claimed. Persistence/readback and cross-layer checks are inapplicable to this pure-utility claim.

**State and next action.** Source/scope/evidence handoff prepared; no utility implementation or runtime verification performed. `spec-engineer` should turn R-1 into bounded implementer instructions and verification expectations using the actual utility and existing test conventions. This artifact does not deliver the behavior or prove editor integration; it supplies no authority for broader work.
