# Heading utility

Call heading('  Notes  ') to obtain '# Notes'. The utility trims outer whitespace from the title and formats a Markdown heading in memory.
