# Implementer handoff: editor title display

Scope: local editor display only. Editors may set a document title to an empty string. This document authorizes no title length limit or configurable validation service.

| Requirement | Authority and rationale | Falsifying check |
| --- | --- | --- |
| Display `Untitled` only when the title is absent; preserve an explicitly empty string and display supplied titles unchanged. | Explicit: accepted customer decision C-1 (`customer.md`), owned by the customer. Applies to editor title display; removing the absence/empty distinction contradicts C-1. | An absent title displays `Untitled`; `""` stays empty; a supplied title displays unchanged, including one longer than 80 characters. Any mismatch fails. |
| Keep exported utility behavior covered by the existing local unit suite. | Explicit: engineering convention E-1 (`engineering.md`), an engineering verification requirement. Applies to exported utilities affected by the change; removing their coverage violates E-1. It adds no customer behavior. | Run the existing local unit suite with cases covering the display distinction wherever an exported utility owns it; failures or missing coverage leave verification incomplete. |

Use the existing local display path and a direct absence check that preserves empty strings. Do not introduce a configurable service or impose the unapproved draft's 80-character limit.

Before implementation, locate the editor display path and existing unit suite. The supplied workspace contains only a version export in `app.mjs`; it supplies neither that path nor a runnable suite. Those implementation and verification details remain unresolved, without changing C-1 or E-1.

Completion evidence for implementation must include observed editor display for absent, empty, and supplied titles, plus applicable E-1 suite results. Document revision alone proves no runtime capability. This handoff revision changes only `draft.md`; no implementation or tests have been performed.
