Draft release note — pending operator publication decision.

Fixed label fallback handling so an explicitly supplied empty string stays empty. Missing labels (`null` or `undefined`) still display `Untitled`.
