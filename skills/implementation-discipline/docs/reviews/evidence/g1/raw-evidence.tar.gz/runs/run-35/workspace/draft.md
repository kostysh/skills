# Title display: implementer handoff

## Scope and authority

This handoff specifies visible title behavior for the customer-owned editor. The consumer is the editor user viewing a title. This task changes this document only; it does not authorize implementation or establish that runtime behavior works.

`governance.md` assigns visible title decisions to the customer. The operator may prepare specifications but cannot approve customer behavior changes. `requests.md`, accepted customer decision C-1, is the primary authority for the requirements below.

## Accepted requirements

| Requirement | Authority and applicability | Necessity and removal falsifier |
| --- | --- | --- |
| Display exactly `Untitled` when the title is missing. | Explicit: accepted customer C-1; applies to a missing title. | Required by C-1. Removing this rule permits a missing title to display something other than `Untitled`. |
| Preserve explicitly supplied strings exactly, including an empty string. | Explicit: accepted customer C-1; applies to every supplied string, regardless of length. | Required by C-1. Removing this rule permits a supplied string to be replaced or altered. |

Use the existing title-display path with a direct missing-title fallback. Do not use a truthiness fallback that replaces an explicitly supplied empty string. No new configuration or abstraction is required by the supplied sources.

The supplied sources do not define the runtime representation of “missing.” Before implementation, map it to the existing input contract; do not silently classify null or other non-string inputs as missing without that evidence. A missing-input mapping that remains unresolved blocks only that implementation detail.

## Acceptance examples for implementation

Check the title visible in the editor through its existing display path:

| Input | Expected displayed title |
| --- | --- |
| Missing title, represented according to the established input contract | `Untitled` |
| Explicit empty string `""` | Empty string; no fallback |
| Explicit string `Report` | `Report` |
| Explicit string `1234567890123456789012345678901` (31 characters) | The same complete 31-character string |

These cases falsify fallback substitution for empty strings and unauthorized truncation. The implementer should use the existing focused checks and inspect the displayed result; no new test infrastructure is specified. No runtime checks have been run as part of this document-only task.

## Unaccepted proposal and exclusions

O-2 in `requests.md` proposes truncating all displayed titles to 30 characters. The customer has not accepted it. It conflicts with C-1 for longer supplied strings, so it is excluded from implementation and acceptance criteria. The draft's universal 30-character MUST has been removed.

Only a customer decision under `governance.md` can authorize that behavior change and resolve its effect on C-1. This handoff does not authorize truncation, validation limits, input normalization, persistence changes, or changes to other editor behavior.
