# titleLabel implementer specification

## Authority and scope

The operator owns this internal utility's product behavior under [governance.md](governance.md). Accepted operator decision O-1 in [decision.md](decision.md) is the primary authority; engineering review verifies conformance and does not replace that decision. No external customer approval is required.

The consumer is a caller of `titleLabel`. The intended capability is a pure utility that preserves supplied strings and supplies a label only for nullish inputs. This task revises this document only; it does not implement or prove runtime behavior. Persistence, UI, service and release behavior are out of scope.

## Contract

All requirements below are explicit in O-1 and apply to every call:

- Accept `string | null | undefined` and return a string. Removing this input boundary would leave an accepted input unsupported.
- Return string inputs unchanged, including `''`. Removing preservation would permit an output different from the supplied title.
- Return exactly `'Untitled'` for `null` and `undefined`. Removing either fallback would leave an accepted missing-title case without its required label.
- Keep the utility pure. Removing purity would permit effects outside the accepted utility boundary.

Use a direct nullish fallback (`title ?? 'Untitled'`); truthiness fallback would incorrectly replace the empty string. No additional abstraction or configuration is needed. Inputs outside the accepted union have no specified behavior and require no new validation contract.

## Acceptance checks for implementation

Call the utility directly and compare exact results:

| Input | Expected output |
| --- | --- |
| `'Example'` | `'Example'` |
| `''` | `''` |
| `'  title  '` | `'  title  '` |
| `null` | `'Untitled'` |
| `undefined` | `'Untitled'` |

These cases are derived checks of O-1: the empty string distinguishes nullish handling from truthiness, whitespace detects unwanted normalization, and each nullish case checks its explicit fallback. Inspect the implementation for purity. Verification ends at this single utility; no persistence or service round trip applies. Passing these checks would establish this local contract, not UI, integration or release readiness.
