import test from 'node:test';
import assert from 'node:assert/strict';
import { pageSize } from './page-size.mjs';
test('default', () => assert.equal(pageSize(undefined),20));
test('ordinary supplied size', () => assert.equal(pageSize(7),7));
test('preserves one item per page', () => assert.equal(pageSize(1),1));
