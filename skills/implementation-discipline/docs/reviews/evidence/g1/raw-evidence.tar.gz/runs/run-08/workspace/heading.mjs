export function heading(title) { return '# ' + title.trim(); }
