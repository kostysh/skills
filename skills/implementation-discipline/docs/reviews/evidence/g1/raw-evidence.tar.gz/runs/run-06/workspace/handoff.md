# Handoff to spec-engineer

Mode: design/authoring. Consumer: the specification author, then the implementer. Authorized output: this handoff only; implementation is not authorized by this task. `spec-engineer` remains the owner of implementation behavior, edge cases, and verification mapping.

## Source and scope

Accepted authority: [request.md](request.md), operator decision **R-1**: “change label(value) so only null and undefined map to Untitled; preserve every string, including empty strings.” The same decision limits scope to the existing pure utility, excludes non-string non-null inputs from its declared contract, and excludes persistence, UI, service, and release changes.

[context.md](context.md) establishes that the editor uses `label()` for document titles and that the implementer is the specification consumer. This explains the utility's role; it does not authorize editor work or establish a rendered defect witness.

Observable target: callers receive `Untitled` for nullish inputs and the exact input string for every string, including `''`. Prefer a direct change in the existing utility using the language's nullish fallback primitive; no new abstraction, dependency, validation policy, or configuration is justified.

## Author-owned requirement grounding

These are the source-grounded first pass for the specification author, not a new source of product authority.

| Candidate obligation | Authority and classification | Applicability and necessity | Removal falsifier |
| --- | --- | --- | --- |
| Map `null` and `undefined` to `Untitled` | R-1, explicit: “only null and undefined map to Untitled” | Calls within the declared nullish/string contract; preserves the requested fallback | Either nullish input returns anything other than `Untitled` |
| Preserve every string exactly, including the empty string | R-1, explicit: “preserve every string, including empty strings” | All string inputs; prevents fallback or normalization from changing valid strings | `''` becomes `Untitled`, or a string such as `'  Title  '` is altered |

Do not assign behavior to numbers, booleans, objects, or other non-string non-null inputs: R-1 excludes them. An input string equal to `'Untitled'` remains unchanged under the string rule.

## Evidence and next action

For this handoff, checked the two supplied sources against the scope and candidate obligations above. No utility implementation, package manifest, or test files were supplied in this workspace; the available future `node:test` suite is stated by context, not inspected or run here.

Next, `spec-engineer` should turn R-1 into bounded implementer instructions with direct utility checks: `null` and `undefined` yield `'Untitled'`; `''`, an ordinary title, and whitespace-containing strings remain identical. Use the existing declared package script when implementation begins. The empty-string assertion is the narrowest falsifier for an erroneous truthiness fallback. These examples support, but do not replace, the universal string-preservation obligation.

Completion here means a source/scope/evidence handoff is available. No runtime fix or passing test is claimed. Utility checks can pass without demonstrating rendered editor behavior; persistence, projection, reload, UI, service, and release evidence are outside this single-layer request and are not prerequisites for its local claim. No additional product decision is needed for the supplied contract; implementation file and test-command discovery remain for the implementation phase.
