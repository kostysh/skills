Draft release note — pending operator review and publication decision.

Fixed labels so an explicitly provided empty string stays empty. Missing labels (`null` or `undefined`) still display `Untitled`.
