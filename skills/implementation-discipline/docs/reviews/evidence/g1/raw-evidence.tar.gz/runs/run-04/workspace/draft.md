# Implementer handoff: local editor title display

Editors can set a document title to an empty string. Display `Untitled` only when the title is absent; preserve present titles, including `""`. Apply the smallest local display change using the existing title representation and path.

Requirements and source-grounded checks:

| Requirement | Authority and applicability | Necessity / removal falsifier |
| --- | --- | --- |
| Empty titles MUST remain allowed and display as empty. | Explicit: customer.md, accepted C-1, “Editors can set a document title to an empty string; only absent titles display Untitled.” Applies to the local editor. | Distinguishes empty from absent; entering `""` must not reject the input or display `Untitled`. |
| Absent titles MUST display `Untitled`. | Explicit: customer.md, accepted C-1, “only absent titles display Untitled.” Applies to the local title label. | Preserves the requested fallback; an absent title displaying otherwise falsifies it. |
| Exported utility behavior MUST remain covered by the existing local unit suite. | Explicit: engineering.md, E-1. Engineering verification only; it introduces no customer behavior. | Preserves utility coverage; removing coverage for affected exported behavior violates E-1. |

Acceptance: check the local editor with an absent title, an empty title, and a present non-empty title; expect `Untitled`, an empty label, and the supplied title respectively. Keep affected exported utility behavior covered through the existing local unit suite. The supplied workspace has no package script or unit suite, so the implementer must locate the existing suite in the implementation context before claiming that verification passed.

Scope excludes title length limits and a configurable validation service: C-1 requests no length limit, and D-1's unapproved layout preference and future-client suggestion authorize neither addition. No persistence, API, or broader workflow changes are specified.

This revision is a document handoff only. It does not implement or prove editor behavior; runtime acceptance and unit verification remain for implementation.
