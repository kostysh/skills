# Compile report
Generated from `skill.yaml`.

## Versions
- Skill source version: `0.2.7`

## Source files
- `docs/README.md`
- `docs/logs/implementation-log-20260817-1.md`
- `docs/logs/implementation-log-20260818-1.md`
- `docs/logs/implementation-log-20260820-1.md`
- `docs/logs/implementation-log-20260822-1.md`
- `references/core-principles.md`
- `references/verification-loop.md`
- `skill.yaml`

## Required references
- `references/core-principles.md`
- `references/verification-loop.md`

## Warnings
- Generated SKILL.md is 19616 bytes, above the recommended maximum 18500 bytes. Move detailed guidance into references/* and keep SKILL.md focused on activation, workflow, and navigation. Raise skill.recommended-skill-md-max-bytes only when references cannot reasonably reduce the size.

## Notes
- This document is supporting output only.
- It does not override `SKILL.md`.