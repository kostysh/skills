Export is not yet available to editors. The change defines a schema and returns `status: 'queued'`; it does not read the document or produce a downloadable file. No export UI or download integration is supplied.

The reported schema test proves only structure. Completion requires an editor selecting Export and receiving a file containing the current document text. That flow has not been demonstrated. Inspection only; no files changed.
