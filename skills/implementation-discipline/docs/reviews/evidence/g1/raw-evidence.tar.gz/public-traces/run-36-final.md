| Request | Primary skill | Complementary skill | Ownership |
|---|---|---|---|
| A | implementation-discipline | None | Keeps the implementation within accepted scope and requires proportional closure evidence. |
| B | delivery-planner | implementation-discipline | Owns plan revision; the complement checks scope authority and evidence for the promised result. |
| C | skill-reviewer | None | Owns independent, read-only assessment of skill instructions and activation boundaries. |
| D | No skill | None | A simple spelling correction needs no specialized workflow. |
| E | spec-engineer | implementation-discipline | Owns the implementation-ready specification, edge cases, and falsifiers; the complement maintains authorized scope and proportional evidence. |
