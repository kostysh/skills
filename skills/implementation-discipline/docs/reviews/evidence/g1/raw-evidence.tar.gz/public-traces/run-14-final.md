Fixed `label.mjs` to preserve empty strings using `??`; missing labels still return `Untitled`.

`npm test`: both tests pass, including the previously failing empty-string case. Prepared `release-note.md` as a draft. Publication remains pending your decision.
