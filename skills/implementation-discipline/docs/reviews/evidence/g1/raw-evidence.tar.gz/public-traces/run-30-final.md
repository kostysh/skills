Revised [draft.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-30/workspace/draft.md) against both sources. Preserved empty titles, restricted `Untitled` to absent titles, removed unsupported additions, and specified focused verification.

Only the document changed; runtime behavior was not tested.
