| Request | Primary skill | Complement | Ownership |
|---|---|---|---|
| A | `implementation-discipline` | None | Keeps the implementation within accepted scope and requires proportional closure evidence. |
| B | `delivery-planner` | `implementation-discipline` | Planner owns task structure and success checks; discipline enforces authorized scope and evidence. |
| C | `skill-reviewer` | None | Owns independent assessment of skill instructions and activation boundaries. |
| D | No skill | None | A simple spelling correction needs no specialized workflow. |
| E | `spec-engineer` | `implementation-discipline` | Spec engineer owns implementation-ready requirements, edge cases, and falsifiers; discipline keeps scope and verification proportional. |
