Created [handoff.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-32/handoff.md) for `spec-engineer`, covering R-1 authority, utility-only scope, direct implementation direction, and focused verification expectations.

Checked the handoff against supplied sources. No utility code changed or runtime tests run; editor integration remains unproven.
