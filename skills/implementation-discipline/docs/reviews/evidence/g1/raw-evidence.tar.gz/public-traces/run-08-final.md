Updated the heading renderer to trim outer title whitespace and revised the README example to demonstrate it.

`npm test` reproduced the failure before the fix and passed afterward: 1 test, 0 failures. Changes were limited to the renderer and README; nothing was published.
