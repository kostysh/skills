Revised `workspace/draft.md` into a concise implementer specification grounded in operator decision O-1 and governance. It defines exact nullish fallback behavior, string preservation, purity, scope exclusions and focused acceptance cases.

Checked the document against both sources. Only the draft changed; runtime behavior was not implemented or tested.
