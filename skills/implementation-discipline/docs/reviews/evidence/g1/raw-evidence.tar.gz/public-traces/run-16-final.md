Revised `workspace/draft.md` into an implementer handoff grounded in C-1 and E-1. Preserved empty titles, removed the unsupported length limit and validation service, and specified verification expectations.

Checked against both sources. Only the document changed; implementation and runtime tests were not performed.
