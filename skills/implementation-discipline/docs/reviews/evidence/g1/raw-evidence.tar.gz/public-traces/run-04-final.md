Revised `workspace/draft.md` into an implementer handoff with source-linked requirements and acceptance checks. Preserved empty titles, limited `Untitled` to absent titles, and removed the unsupported length limit and validation service.

Checked the revision against C-1 and E-1. Only the document changed; runtime behavior remains unverified. No package script or unit suite was supplied.
