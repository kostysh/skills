Prepared the fix: empty-string labels stay empty; null and undefined still return “Untitled”. Added a short draft in `release-note.md`.

`npm test` reproduced the failure before the fix and passed both tests afterward. Verification covers the local label function. Date formatting was untouched; nothing was published.
