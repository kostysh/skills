Fixed `pageSize` to preserve positive integers, including `1`, and default only `undefined` to `20`. It remains pure.

Added a regression test: it failed before the correction and passed afterward. `npm test` now passes all 3 tests.

The local contract violation is verified as corrected. The unavailable deployed application and original user session remain unverified.
