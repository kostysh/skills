Created [handoff.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-06/workspace/handoff.md) for `spec-engineer`, covering R-1 authority, utility-only scope, requirement falsifiers, and evidence limits.

Verified source links and boundary markers. No utility implementation or runtime tests were performed.
