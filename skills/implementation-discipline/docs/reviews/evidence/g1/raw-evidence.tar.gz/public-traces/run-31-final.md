Export is not yet available to editors. The change defines a schema and returns `status: 'queued'`; it does not read the current document, create a file, or provide a download.

The supplied schema-test result proves only structure. Completion requires evidence that an editor selects Export and downloads a file containing the current document text. Inspection only; no changes made.
