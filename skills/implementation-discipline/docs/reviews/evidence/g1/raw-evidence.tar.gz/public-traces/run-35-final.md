Revised `workspace/draft.md` into an implementer handoff grounded in C-1.

- Missing titles display `Untitled`; supplied strings remain unchanged, including empty and long strings.
- Removed the unauthorized 30-character requirement; retained O-2 as an unaccepted proposal.
- Added acceptance examples and flagged the undefined runtime representation of “missing.”

Checked the document against both supplied sources. Only the document changed; runtime behavior remains unverified.
