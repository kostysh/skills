The excerpt permits a stale-response race: if document A is selected, then B, B’s request can finish first and display B; when A finishes later, `show(result)` displays A.

That is a plausible cause, not a confirmed diagnosis. The unavailable caller may already prevent overlapping requests or reject stale results. The excerpt also cannot establish whether the remote API returns the correct document.

To resolve it, inspect the caller’s selection handling and reproduce A → B with A’s response delayed. Check the requested IDs, response document identities, completion order, and displayed document.

If the race is confirmed, the caller should allow only the latest selection’s response to update the preview, using a request identity or generation check scoped to that preview instance. If responses themselves contain the wrong document, investigate the API or cache instead.

No files changed. The live failure could not be reproduced with the supplied excerpt alone.
