Revised [draft.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-11/workspace/draft.md) into an implementer handoff.

- Preserved accepted C-1, including empty strings.
- Removed unauthorized truncation; O-2 remains a customer decision.
- Added source traceability, falsifiers, and acceptance cases.
- Flagged unspecified missing-title representation.

Checked the document against supplied sources. No code changed or runtime behavior tested.
