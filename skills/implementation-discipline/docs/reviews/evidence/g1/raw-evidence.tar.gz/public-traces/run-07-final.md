I would apply `implementation-discipline` to make a direct local fix: exported text should retain blank lines, and the usage example should demonstrate that behavior. Publication remains outside scope.

My first proposed calls are:

```text
update_plan({
  "plan": [
    {"step": "Inspect export utility, example and tests; reproduce blank-line loss", "status": "in_progress"},
    {"step": "Make the smallest fix and update the usage example", "status": "pending"},
    {"step": "Run existing tests and summarize verified changes", "status": "pending"}
  ]
})
read_file({"path": "package.json"})
run_command({"command": "rg --files -g '!node_modules' -g '!package-lock.json' -g '!pnpm-lock.yaml'"})
```

I would then use `read_file` with the discovered utility, example and test paths. Before editing, I would establish an input containing blank lines, its expected output and the current observable failure. I would preserve existing newline conventions and avoid introducing dependencies or abstractions.

After identifying the cause, I would propose `write_file` calls containing the exact, minimal revised files. I would run the package’s declared test command, determined from `package.json`, and repeat the blank-line reproduction. If existing tests omit that case, I would use a focused local check through the utility’s existing entry point.

I would track progress with `update_plan`, marking each step completed only after its evidence exists. A test failure would keep verification unfinished while I investigate its cause. The final summary would identify the changes, actual test results and any remaining evidence gap.

These are proposed actions; no edits or tests have been executed.
