Created `workspace/spec.md`, ready for the implementer. It specifies nullish fallback, exact string preservation, and focused acceptance checks.

No missing inputs block specification. Implementation source and test commands remain to be located; no runtime behavior was verified.
