Обновлён [draft.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-10/workspace/draft.md): контракт `titleLabel`, источник полномочий O-1, границы и пять проверочных примеров.

Сверено с `governance.md` и `decision.md`. Изменён только документ; реализация и runtime-проверки не выполнялись.
