Fixed `pageSize` to preserve positive integers, including `1`, and default only `undefined` to `20`.

Added a regression test that failed before the correction; `npm test` now passes all 3 tests.

This verifies the local utility contract. The reported deployed application issue remains unverified because its session and runtime are unavailable.
