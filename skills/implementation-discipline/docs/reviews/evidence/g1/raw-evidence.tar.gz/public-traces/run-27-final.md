Fixed `label()` by replacing `||` with `??`. Empty strings stay empty; null and undefined still return `Untitled`.

Verified with `npm test`: reproduced the failure before the change; both existing tests pass afterward. Only `label.mjs` changed locally.
