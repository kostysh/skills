The excerpt permits a stale-response race: select A, then B; if B finishes first and A finishes later, `show` displays B followed by A. A local Node check reproduced that ordering. No files changed; no package script was supplied.

This is a plausible cause, not a confirmed diagnosis of the remote UI: the caller may already prevent overlapping requests or reject stale results.

To resolve it, we need the caller’s selection/loading code, `fetchPreview` and `show`, plus a failing sequence showing selected document IDs, request completion order, returned document identity, and displayed result. That distinguishes a client race from incorrect remote responses.

If confirmed, the smallest fix is typically a caller-owned request generation check before displaying a result, scoped to that preview instance. Verify by selecting A then B, completing B before A, and confirming B remains displayed.
