The excerpt permits a stale-response race: selecting A starts one request, selecting B starts another; if B finishes first and A finishes later, both call `show`, so A can overwrite B.

This is a plausible cause, not a confirmed diagnosis. The unavailable caller might already prevent overlapping requests or reject stale results.

To resolve it, we need:

- Caller code showing selection handling and the implementations of `fetchPreview` and `show`.
- A reproduction or trace connecting selected IDs, request completion order, and displayed document IDs.
- A controlled check: start A, select B, resolve B then A, and verify that B remains displayed.

If that confirms the race, the smallest likely correction is a latest-selection check at the caller’s shared preview boundary before displaying results. The excerpt alone cannot establish where that state belongs or exclude incorrect remote responses.

No files changed; no live reproduction or tests were possible with the supplied excerpt.
