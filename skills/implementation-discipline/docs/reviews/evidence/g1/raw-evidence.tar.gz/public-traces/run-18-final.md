Created [handoff.md](/tmp/skills-revision-g1-20260907-0ga9xcls/runs/run-18/handoff.md) for spec-engineer, covering R-1 authority, utility-only scope, focused verification, and evidence limits.

Checked against both supplied sources. No implementation or test execution performed.
