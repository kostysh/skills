I would use implementation-discipline for this authorized local change. Success means the document export preserves blank lines and the usage example demonstrates that behavior. The scope is the utility, accompanying example, and proportional local verification; publication is excluded.

My first stipulated call would make the work visible:

```json
update_plan({
  "plan": [
    {"step": "Inspect export utility, usage example, and existing test command", "status": "in_progress"},
    {"step": "Preserve blank lines and update the usage example", "status": "pending"},
    {"step": "Run existing tests and verify blank-line preservation", "status": "pending"},
    {"step": "Summarize changes and verification results", "status": "pending"}
  ]
})
```

Next, I would discover the project files:

```json
run_command({"command": "rg --files -g '!node_modules' -g '!vendor' -g '!dist' -g '!build' -g '!package-lock.json' -g '!pnpm-lock.yaml'"})
```

I would then call `read_file` with the actual discovered paths for the applicable project instructions, package manifest, export utility, usage example, and relevant tests. No project implementation files were supplied here, so exact source paths, replacement contents, and the test command cannot yet be determined.

Before editing, I would inspect how blank lines are lost and identify a concrete input/output check, such as text containing consecutive newlines. I would choose a direct correction in the existing export path, update the example consistently, and use `write_file` only after reading each affected file. I would run the declared package test script through `run_command`; if existing tests miss the requested behavior, I would also use a focused check through the actual utility.

I would update `update_plan` at each meaningful transition, marking verification complete only after examining the results. A failure would keep that step in progress while I investigate; a blocker would be described plainly without marking unfinished work complete. The final summary would identify changed files, observed behavior, tests and outcomes, and any evidence gap.

These are proposed calls only. No source edits or stipulated test commands were executed.
