# Авторская самопроверка группы 1

Changed surface: skill.yaml, verification-loop.md и generated SKILL.md. Capability — поддержанное источниками разрешённое действие или честный ограниченный вывод; actor — исполнитель/автор, downstream — реальный spec-engineer. Основные входы и границы остаются прежними. F1 меняет достаточность основания локальной коррекции, F2 выводит владельца из действующего governance, P3 согласует включение conditional references с прежними triggers. Никакой новый runtime, API, режим или инструмент не вводится.

До первой генерации записан ready-to-regenerate в implementation log. После явной отмены planner удалены только новый policy и start-here entry; затем выполнены повторная генерация и свежие прогоны итогового пакета. Одно предложение сокращено без изменения основания или лимитов. Advisory ceiling не повышался; итоговый root 18492 bytes.

Разделены основания изменения и сила closure: локальная проверка не доказывает недоступную production-цепочку, unsupported hypothesis не разрешает правку. Право owner не отменяет существующий customer gate. Derived artifact не создаёт свою authority. Root и reference согласованы; сохранены read-only, side effects, partial blocks, domain ownership и независимый audit gate. Новых обязательных внешних файлов нет.

Structural checks: final-structural-checks.json и final-parity.json — lint, source check, isolated compile, emitted check, 9 emitted файлов побайтно совпали. author-readback.json — active links, portability, отсутствие planner и drift. Source/runtime compiler не менялся; package-local runtime/tests/UI отсутствуют у target, поэтому выдуманный test runner не добавлялся. Вспомогательный quick_validate на baseline отклоняет существующее compatibility; собственный compiler принимает контракт. Этот сторонний allowlist не менялся и не объявляется пройденным.

Это author evidence, не independent PASS. Финальная поведенческая оценка и re-audit выполняются отдельными агентами по закрытым критериям. Выполненные intermediate trials сохранены как superseded после отмены требования; не смешиваются с итоговой версией.

