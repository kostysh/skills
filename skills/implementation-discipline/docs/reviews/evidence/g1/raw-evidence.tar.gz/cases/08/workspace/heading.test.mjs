import test from 'node:test';
import assert from 'node:assert/strict';
import { heading } from './heading.mjs';
test('heading titles', () => { assert.equal(heading('  Notes  '), '# Notes'); assert.equal(heading('Notes'), '# Notes'); assert.equal(heading(''), '# '); });
