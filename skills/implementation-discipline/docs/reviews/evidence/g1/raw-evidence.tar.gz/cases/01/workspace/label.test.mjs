import test from 'node:test';
import assert from 'node:assert/strict';
import {label} from './label.mjs';
test('missing labels',()=>{assert.equal(label(null),'Untitled');assert.equal(label(undefined),'Untitled');});
test('provided labels',()=>{assert.equal(label('Alpha'),'Alpha');assert.equal(label(''),'');});
