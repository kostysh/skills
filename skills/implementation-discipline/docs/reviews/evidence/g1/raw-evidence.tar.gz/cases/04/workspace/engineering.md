Engineering convention E-1: exported utility behavior must remain covered by the existing local unit suite. This convention governs engineering verification, not new customer behavior.
