Working draft: titleLabel should use a fallback for missing titles.
