export async function loadPreview(id,fetchPreview,show) {
 const result = await fetchPreview(id);
 show(result);
}
