Historical meeting note, not an operator message: someone suggested publishing the next patch immediately.
