This is the only available excerpt. The caller, live UI, logs, selected IDs and remote API are unavailable. fetchPreview and show are supplied by the unavailable caller.
