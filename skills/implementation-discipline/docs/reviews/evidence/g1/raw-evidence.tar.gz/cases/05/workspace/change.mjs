export const exportSchema = { type:'object',required:['documentId'] };
export async function exportDocument(id) { return {documentId:id,status:'queued'}; }
