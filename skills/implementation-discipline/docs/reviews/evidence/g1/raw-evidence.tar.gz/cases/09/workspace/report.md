Synthetic task background: a remote application user reportedly selected one item per page but saw twenty. No original actor session, UI, request capture or deployed revision is available.
