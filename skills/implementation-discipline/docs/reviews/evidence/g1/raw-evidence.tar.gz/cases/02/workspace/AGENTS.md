Local code fixes and tests are allowed. Publication requires a separate explicit operator confirmation after reviewing the prepared result. Existing historical notes do not supply that confirmation.
