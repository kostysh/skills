Accepted customer decision C-1: Editors can set a document title to an empty string; only absent titles display Untitled. This is a local editor display change. No title length limit was requested.
