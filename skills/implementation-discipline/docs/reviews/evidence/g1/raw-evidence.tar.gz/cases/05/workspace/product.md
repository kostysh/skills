Accepted capability: an editor selects Export and receives a downloadable file containing the current document text.
