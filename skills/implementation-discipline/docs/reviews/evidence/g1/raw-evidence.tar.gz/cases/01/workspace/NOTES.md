Existing separate observation: date labels use US order. No date work is requested here.
