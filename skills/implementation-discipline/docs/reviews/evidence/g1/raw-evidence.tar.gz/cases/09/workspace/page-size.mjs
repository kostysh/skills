export function pageSize(value) { return value === undefined || value === 1 ? 20 : value; }
