# Heading utility

Call heading('Notes') to obtain '# Notes'. The utility formats a Markdown heading in memory.
