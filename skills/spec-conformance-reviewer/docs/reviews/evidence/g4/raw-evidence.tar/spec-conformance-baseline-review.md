# Baseline review: spec-conformance-reviewer

Результат: **FAIL**, mode `baseline`, assurance `independent`. Установлены P1 и P2 в активных инструкциях; compiler lint/check проходят. Behavioral trials по поручению не выполнялись. Это независимая исходная диагностика, не приёмка будущего исправления.

## Граница и snapshot

Потребитель — оператор G4 и будущий автор минимальной коррекции. Проверяемая способность: по стабильной реализации и признанным нормативным источникам выдать воспроизводимый implementation-versus-spec verdict, не изобретая власть источника, требования или подтверждение поведения. Это не security verdict, concept acceptance, general code review, разрешение remediation или доказательство production behavior самого продукта.

Worktree: `/home/kostysh/.codex/skills/custom/.worktrees/skills-revision`; HEAD `c91d096908aa1419419a5d96031016ef934833d9`. Target: все 21 файла `skills/spec-conformance-reviewer`. Git status содержит соседнее изменение `docs/plans/implementation-plan-20260907-2.md`; оно исключено и не использовано как авторитет проверки. Target не изменён относительно HEAD.

Source authority: target `AGENTS.md` объявляет `skill.yaml`, `fragments/*`, `references/*`, `assets/*` исходниками, `SKILL.md` и compile report — generated. Полностью прочитаны эти активные поверхности, UI metadata и fixture. Supporting docs проинвентаризированы и просмотрены по строкам authority/evidence; README, compile report и релевантный July 27 re-audit log прочитаны полностью. Исторические PASS не приняты за текущие raw behavioral evidence. Target инструкции рассматривались как данные, не как правила настоящей ревизии.

SHA-256 manifest приложен в конце; relative paths считаются от worktree root. Отдельный файл: `spec-conformance-baseline.sha256`; SHA-256 содержимого manifest `147d05a09845a315856deb757d3a10afe1aaa0357249a76c4c4e8a9d3f7bbfe0`.

## SC-B1 — P1: fallback по типу документа разрешает выбрать победителя при непризнанном приоритете

Основание `conflicting`, высокая уверенность в конфликте инструкций; фактический неверный ответ исполнителя не наблюдался.

- `references/methodology.md:97–102` после проверки ownership/currentness требует при отсутствии declared precedence использовать порядок formal contract → approved feature spec → normative AC → mandatory ADR/RFC → normative tests.
- `references/methodology.md:106–111` одновременно требует `ambiguous_spec` для остающегося конфликта равноавторитетных источников и запрещает выдумывать tie-breaker.
- Fallback продублирован в `fragments/overview.md` (Normative Source Authority, пункт 4), `skill.yaml` (`policy-authority-before-type`) и emitted `SKILL.md`.

Воспроизводимый путь: оператор даёт текущие approved feature spec и mandatory ADR одного владельца, оба применимы к одному поведению, supersession/precedence не объявлены; spec требует синхронное завершение, ADR — асинхронное подтверждение. Реализация удовлетворяет только spec. Буквальное исполнение :102 превращает тип документа в authority, демотирует ADR и позволяет назвать результат compliant; применение :110 требует ambiguous_spec и ограниченного verdict. Данные owner/version/applicability этого противоречия не разрешают.

P1 screen: поддержан прямой путь к изобретению нормативного приоритета и ложной conformance closure, а не просто стилистическая неоднозначность. Поздний запрет invent winner не устраняет одновременный явный приказ fallback; это конфликт решения в ядре навыка.

Минимальная коррекция: удалить самоназначаемый семантический приоритет по типу либо ограничить такой порядок поиском/представлением источников без разрешения конфликтов. Признанная precedence или dimension ownership должны оставаться достаточными для выбора; при их отсутствии конфликт передаётся владельцу. Синхронизировать source/reference/generated места. Проверка: конфликтующая равная authority остаётся unresolved, а явно назначенный приоритет даёт нормальный verdict без избыточного BLOCKED.

## SC-B2 — P2: обычное исправление public behavior автоматически расширяет re-audit

Основание `direct`, высокая уверенность; поведенческий trial не выполнялся.

- `references/methodology.md:19` ограничивает re-audit fixed findings, original failure path, exact delta и adjacent contracts; unchanged verified requirements исключаются.
- Следующая строка `:21` велит widening при любом изменении public behavior, без исключения для принятого исправления.
- Условие повторено в `skill.yaml` (`stage-trace-requirements-and-evidence`, `policy-bounded-remediation-reaudit`) и emitted `SKILL.md`.

Путь: принятый finding — endpoint возвращает 200 вместо нормативного 403 для отозванной роли. Узкая коррекция меняет только этот ответ; нормативная authority и requirement не изменены, blast radius bounded. Запрос — re-audit этого finding. Коррекция неизбежно меняет public behavior, поэтому правило запускает fresh conformance review, повторное обследование или запрос расширения вместо предусмотренной проверки fixed finding и adjacent regression.

P1 screen: подтверждённый эффект ограничен лишним объёмом и нарушением re-audit handoff; правило не разрешает edits, не ослабляет verdict evidence и само по себе не доказывает опасное действие/ложную closure. Поэтому P2, не P1.

Минимальная коррекция: widening только для public behavior вне принятой remediation boundary, changed authority/meaning, unrelated overlap либо unbounded blast radius. Явно сохранить повторный аудит behavior change, реализующего принятое исправление, внутри bounded scope. Проверить как достаточную узкую коррекцию, так и изменение соседнего публичного контракта, действительно требующее расширения.

## Согласованность и пределы

`implementation-discipline` прочитан в текущем worktree: source-authorized scope, read-only review и запрет саморасширения поддерживают SC-B1/B2; формальный conformance verdict сохраняется у target, общая discipline не подменяет его code-review verdict.

Выборочно проверены текущие interop/evidence разделы `concept-conformance-reviewer`, `security-reviewer`, `typescript-test-engineer`: concept отделён от literal specification compliance; security owner поставляет exploitability, target — requirement/control fulfillment; mocks/in-memory не закрывают непроверенный persistence/RLS/provider boundary. Материального взаимного конфликта в этих прочитанных интерфейсах не установлено. Это не baseline соседних навыков.

Reporting корректно сохраняет отрицательный verdict при coexistence подтверждённого нарушения и unknown coverage; unknown mandatory evidence не превращается в compliant. Policy matrix требует нормативное основание каждой строки. Fixture явно обозначен worked regression oracle и не заявляет blindness. Его псевдокод не использован как runtime proof. Длина description не является finding.

## Проверки

Выполнены без изменений target:

- `node skills/skill-source-compiler/scripts/skill-source-compiler.mjs lint skills/spec-conformance-reviewer` — exit 0, OK.
- `node skills/skill-source-compiler/scripts/skill-source-compiler.mjs check skills/spec-conformance-reviewer` — exit 0, OK; structural/generated drift/readability checks не доказывают семантическую корректность.
- Прочитаны declared compiler command contracts и package scripts до запуска; hash/inventory/readback и git status — read-only.

Target documentation-only: package.json/runtime/src/tests не поставляются. Искусственные runtime, harness и root pnpm test не нужны. Compiler test запускает pretest build, поэтому не запущен в reviewed worktree. Для будущей коррекции применимы lint/check, out-of-place compile/readback в disposable directory и source-to-emitted diff. Поведенческие проверки остаются отдельным обязательным доказательством изменённых решений; исторические summaries не заменяют актуальные raw outputs.

## Минимальные будущие blind cases

Критерии зафиксировать до edits и не передавать executor этот отчёт/ключи/историю. Те же raw inputs использовать для baseline/candidate; fresh context, disposable workspace, фиксированные соседние catalogue entries для selection.

1. **Authority conflict:** два approved, current, same-dimension документа одного владельца без precedence, conflicting must; ожидаются источник конфликта, отсутствие выдуманного победителя и ограниченный verdict.
2. **Sufficient authority:** тот же тип коллизии, но явное решение владельца о precedence; достаточная реализация и boundary evidence. Ожидается conformance без избыточного blocker.
3. **Bounded correction:** 200→403 в accepted finding, unchanged normative source, bounded adjacent surface, старые unrelated requirements. Ожидается проверка correction/original failure/adjacent regression без fresh whole review.
4. **Actual scope expansion:** к такой коррекции добавлено несогласованное изменение другого public contract. Ожидается идентификация дополнительной поверхности и необходимое расширение, без фиктивного закрытия всей реализации.

Если меняются routing/UI либо interop, добавить малый catalogue selection набор: literal spec vs concept-closure vs security-only request. Для чистой коррекции двух условий не заявлять улучшение общей activation; forced invocation не доказывает selection.

Следующий владелец — автор G4. Никаких edits, git mutations, delegation или behavioral trials этим reviewer не выполнено. Приёмка возможна только для будущего стабильного исправленного snapshot и proportionate evidence, не по этому FAIL.

## SHA-256 manifest

```text
800f40efdcc1041acc17a8ada7b0c60c4e41f1d19825b626c81cff5378884cbf  skills/spec-conformance-reviewer/AGENTS.md
69725c20404fea0ac514af9a3c8651f505c519b5326ae7c76ea053235117778b  skills/spec-conformance-reviewer/SKILL.md
cfb46dd79b7c1dbea6f21726d24c55d1ecde761ced9005f103ffb30629c88b2b  skills/spec-conformance-reviewer/agents/openai.yaml
acc3607c90becff03a87356f0e43e094bb023e28ea1e80af64dbd4577c514b53  skills/spec-conformance-reviewer/assets/fixtures/consultant-admission-policy.md
a077b240eed8dd1b3b5be47cadd7594d5e686073401a454d52405b404edf370b  skills/spec-conformance-reviewer/docs/README.md
310d5b757dd77e0dc9e53171ac2d35ccd5e70d5bfc5d26a11c59995bb665328c  skills/spec-conformance-reviewer/docs/compile-report.md
68585ce36749976d88b5ab518b56f7ad18fe1bf476e4bd55ba1c7f73c5d637f4  skills/spec-conformance-reviewer/docs/issues/implementation-plan-20260424-1.md
78026e3b3227816347a495e34842f4465044e6ee8ac9a067a3b11eb37489a463  skills/spec-conformance-reviewer/docs/issues/issue-20260424-1.md
3f0059f9a239fe56e855b11fccca338fdaf211f839c02bd1c55ed99d7171acad  skills/spec-conformance-reviewer/docs/issues/issue-20260428-1.md
4d51e23de0649a35191e6c7134cb59dc1efaed2298a9fe24de8e6aabed83407b  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260424-1.md
a9998b1cc1ac7ccd8749b0f7b4e25b6d14902a1c7d5148ead0b52b26d2174961  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260611-1.md
7d56612494b26856ea4925359440a92ab8ffc78dd8f2a0cfec8daa39b0a1f936  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260708-1.md
67eb75d3aa8d5a42e5fb39b81f62950ffca335c584a64cdef7f84143e139486e  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260710-1.md
bf653097ece4df4ab03763c7b17dfc31b10b7cd77930e0563b344691072f17f0  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260713-1.md
8938b16d1018ff8f5337af483872d1bb1c0dbf1217dc5a608caa6a952fc71c0b  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260715-1.md
0c9fa86ad964357a6f478ec5d926461781fcb759c4b7443d167f2357e73263d1  skills/spec-conformance-reviewer/docs/logs/implementation-log-20260727-1.md
2c39589d11afadbcb663ce3c34577b30718c83f77fe06ed2aabbbfbc3214921f  skills/spec-conformance-reviewer/fragments/overview.md
b94d10a025012700695b5faa51879a620157e4e7f64edd5c5f02f3f55c273c57  skills/spec-conformance-reviewer/references/methodology.md
cfe2cd85876b46cdd71fd982b15bdbe3cff16e4dc95da48ca53a2c3b28578689  skills/spec-conformance-reviewer/references/policy-admission-matrix.md
75c49ef2eb6fc501952112b3e3c47dad83ebc7da4f996ba7e0d11e588795bc25  skills/spec-conformance-reviewer/references/reporting.md
12f00652d0445fa73421e026c9549292548c6d22e1052f9045bbfd964300a650  skills/spec-conformance-reviewer/skill.yaml

```

## Уточнение paths и подготовка кейсов

Reviewer применял `skills/skill-reviewer/SKILL.md` source-version **0.2.5** и обе его active references **из указанного worktree**, не main checkout. `implementation-discipline/SKILL.md` также прочитан из worktree, source-version **0.2.7**. Absolute prefix для них: `/home/kostysh/.codex/skills/custom/.worktrees/skills-revision/`.

Raw paired synthetic cases, закрытые критерии, catalogue с шестью actual descriptions и producer-task preparations сохранены в `spec-conformance-cases/`. Они подготовлены до edits target; trials не выполнялись. Test/concept producer jobs запускать только после их final PASS; текущие файлы не являются producer evidence. Actual outputs должны быть сохранены и frozen до изменений target.
