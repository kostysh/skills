# Fixed actual worktree descriptions
## spec-conformance-reviewer
```yaml
description: Review code against authoritative specs, contracts, ADRs, tickets,
  PRDs, RFCs, migrations, and acceptance criteria. Build requirement-to-code
  traceability, identify compliance gaps or ambiguities, and issue an
  implementation-versus-spec verdict limited by source authority and evidence.
```

## concept-conformance-reviewer
```yaml
description: Review features, specs, plans, acceptance criteria,
  implementations, and closure claims against an established product or system
  concept. Use when scaffolding, APIs, mocks, tests, evidence, or docs may be
  mistaken for observable capability; not for ordinary spec, code, security, or
  domain review.
```

## security-reviewer
```yaml
description: Perform bounded security review of code, CI, permissions, webhooks,
  secrets, data access, and config. Use for vulnerability review, exploitability
  triage, or scoped audits. Own threat modeling, confidence gating, attack
  paths, and findings—not scan orchestration, compliance, pentesting, or fixes.
```

## typescript-test-engineer
```yaml
description: Design, implement, review, and diagnose TypeScript tests for Node,
  React, and edge projects. Use for test strategy, node:test or Vitest,
  deterministic fixtures and mocks, coverage, CI failures, hanging tests, and
  evidence quality; keep review and diagnosis read-only unless fixes are
  requested.
```

## code-reviewer
```yaml
description: Perform read-only review of PRs, diffs, and local branch changes.
  Use to find bugs or regressions, assess maintainability, tests, compatibility,
  or lightweight intent alignment, and provide evidence-backed merge guidance
  with stable scope, severity, and findings; pair with relevant domain skills.
```

## spec-engineer
```yaml
description: Create concise, falsifiable software specs for AI coding agents.
  Use to turn ideas, tickets, APIs, domain rules, migrations, workflows, or
  function behavior into implementation-ready Markdown with observable
  requirements, acceptance evidence, anti-claims, source authority, and handoff
  readiness.
```
