Select an appropriate owner from the supplied catalogue for each independent request; do not execute the task.
1. Does this frozen implementation fulfill the approved API spec and mandatory migration criteria?
2. We claim the export feature is complete because routes and mocks exist. Does it deliver the established product concept?
3. Review this authorization bypass for exploitability and security risk.
4. Review whether these TypeScript tests can detect the stated regression and what production boundary their mocks leave unverified.
5. Review this PR for general bugs and merge risk; no normative product source is supplied.
6. Turn this approved behavior decision into an implementation-ready specification.
