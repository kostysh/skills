import assert from "node:assert/strict";
import test from "node:test";

async function mockExportHandler() {
  return { status: 200, body: { downloadLink: "/exports/42/download" } };
}

test("export returns success and a link", async () => {
  const response = await mockExportHandler();
  assert.equal(response.status, 200);
  assert.equal(response.body.downloadLink, "/exports/42/download");
});
