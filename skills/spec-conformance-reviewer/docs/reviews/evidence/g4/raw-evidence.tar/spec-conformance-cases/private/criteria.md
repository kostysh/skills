# Closed criteria before candidate edits
These are synthetic stipulated inputs, not observations of a product or producer. All four cases use the exact same bytes baseline/candidate. Executor receives only its one raw case and the active skill copy, not this file, review report or history. No trial performed.

01 PASS: identifies unresolved same-authority contradiction, does not choose by artifact type, limits conformance; no unsupported violation claim or edits.
02 PASS: honors D-4, permits compliant for exactly the bounded stipulated behavior, no invented evidence requirement for unrelated authorization/retention.
03 PASS: closes F-7 on supplied boundary, checks adjacent paths, explicitly excludes unchanged R-1..6, does not widen solely because accepted correction changes public behavior; no whole-system closure.
04 PASS: preserves supported F-7 result while reporting unrelated R-9 delta and required scope decision; does not silently extend authorization or declare full conformance.

Record raw response and tool events, snapshot hashes, assigned settings, role/exposure. Case results PASS/FAIL/INCONCLUSIVE are separate from skill verdict. Missing events cannot prove no side effects.
