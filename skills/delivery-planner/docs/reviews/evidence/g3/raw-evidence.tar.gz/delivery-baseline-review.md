# Предварительная baseline-ревизия delivery-planner

**FAIL — 2 P2, 1 P3.** Независимая read-only инспекция полного пакета выявила два пути к лишним prerequisites. Это исходный snapshot, не заключение о будущей совместимости после изменений architecture-engineer/spec-engineer.

## Основание и границы

Mode `baseline`; assurance `independent`: аудитор не автор пакета и не исправлял его. Scope: source `skill.yaml`, fragments, generated `SKILL.md`, все references, оба templates, UI metadata, все supporting docs/logs. Runtime/package.json/tests не поставляются. Применены AGENTS.md, Skill standard, принятый implementation-plan-20260907-2, skill-reviewer с methodology/forward-testing, implementation-discipline. Для нормативной совместимости использована текущая принятая implementation-discipline из worktree, не старая версия основного checkout.

Snapshot: `/tmp/skills-revision-g3-20260907-idvgqdrf/baseline/delivery-planner`; source-version 0.2.12; baseCommit `be557e915b03267df650b9ca5906ac59078110e9`. Все 24 SHA-256 из baseline-source-manifests.json проверены до и после инспекции: совпадают. Чтение исходников выполнялось частями; усечённый объединённый вывод source/root повторно прочитан ограниченными частями.

Consumer — агент, принимающий план для координации или следующий task owner. Capability — исполнимая декомпозиция с достаточным основанием, честной readiness, источниками и evidence-return. План и compiler output не доказывают runtime, release, empirical spike evidence или универсальную надёжность исполнения.

## Findings

### DP-B1 — P2: customer chain требуется вне customer-owned governance

Basis `direct` для правила, `conflicting` для межскильного контракта; прогноз поведения `inferred` из инструкции, новый trial не запускался.

`references/methodology.md:90-102` требует для **каждого** material product requirement exact customer/contract statement либо customer decision, не принимает accepted derived artifact как достаточное coordination и блокирует dependent planning при отсутствующей chain. Условие повторено в `SKILL.md:25`, Source and handoff readiness policy, final checks, source и обоих templates. При этом принятый владелец source-authority `implementation-discipline/SKILL.md:54,66` требует legitimate owner's accepted decision и customer chain только когда соответствующее governance действительно действует.

Failure path: maintainer-owned продукт с явным принятым решением владельца, достаточными architecture/spec inputs и без customer approval process → delivery intake ищет отсутствующий customer/contract → задача остаётся blocked и возвращается product/customer owner вместо пригодного handoff. Пакет не содержит исключения для этого достаточного входа. Наличие общей ссылки на implementation-discipline не устраняет собственный обязательный противоположный gate.

Impact: потребитель не может получить готовый локальный план по достаточному действующему основанию. P1 screen: установлен лишний dependent blocker, не обход действующего customer approval, не ложная product/runtime closure и не опасная mutation; поэтому P2. Реальное customer governance следует сохранить без ослабления.

Bounded correction: сделать установленного decision owner и применимые approval rules каноническим основанием; customer chain — условным требованием. Согласовать source, methodology, final checks и templates, не менять владельца product intent и не разрешать самогенерируемые требования.

Closure evidence: одинаковые baseline/candidate inputs для достаточного maintainer-owned решения, достаточного customer-owned пакета и недостающего customer approval; в первом нет выдуманного customer prerequisite, в последнем blocked только зависимое. Реальный upstream output должен пройти consumer, не только переписанный координатором fixture.

### DP-B2 — P2: любой docs/tooling/skills task обязан иметь следующий slice

Basis `direct` для правила и внутреннего противоречия; request-to-output path — `inferred`.

`SKILL.md:195-196`, source policy `policy-support-task-contract`: “A remediation, tooling, documentation, or skills task must name ... the effectiveness check for the next slice.” Это применяется к любому такому task. В то же время Capability or verifiability policy и `references/methodology.md` разрешают самостоятельную explicit developer-experience goal; Skill standard различает capability непосредственного consumer и substrate более широкого workflow.

Failure path: принят самостоятельный task по исправлению onboarding instructions или локального developer tool с непосредственным пользователем, проверяемым текущим результатом и без следующего product slice → planner должен потребовать неназванный next slice/effectiveness check либо переоформить готовую самостоятельную работу как dependent support. Даже source-authorized задача не может буквально удовлетворить все обязательные условия без лишнего будущего владельца. Общий совет “compactness” не даёт исключения из `must`.

Impact: искусственная зависимость/неполный handoff для валидной docs/DX scope. P1 screen: подтверждённый исход ограничен избыточным planning prerequisite; запреты на самостоятельное расширение scope остаются, поэтому не заявляется, что агент обязательно выдумает новый product slice или ложно закроет capability. P2.

Bounded correction: применить dependency/effectiveness-for-next-slice к работе, действительно поддерживающей такой slice. Для самостоятельного docs/tooling/skills результата достаточно текущего consumer/outcome, source и соразмерной проверки; сохранить запрет считать его product runtime delivery. Не удалять support traceability целиком.

Closure evidence: одна самостоятельная docs/DX задача без будущего slice получает достаточный task contract; реальный support для известного increment сохраняет связь/evidence; future-only scaffold без текущей обязанности отвергается.

### DP-B3 — P3: условное чтение обозначено optional

`SKILL.md:225-227` и source `required: false` помещают imperative “Read this when producing ...” под Optional references. `output-templates` условно обязателен при создании плана; patterns также имеет явный loading trigger. Это расходится с Skill standard об явной conditional classification. В этом пакете уникальный материальный safety gate, отсутствующий в root/methodology, не установлен: большинство правил templates дублирует основные. Поэтому P3, а не вывод о доказанной неверной readiness. Уточнить классификацию без обязательного чтения всех references на любом запросе.

## Поддержанные свойства и проверки

Продуктовые/архитектурные/spec gaps роутятся владельцам; план может быть complete при blocked tasks. Typed start/merge/acceptance/future-owner и shared-race evidence явно отделяют параллельную реализацию от независимой приёмки. Substrate не выдаётся за runtime; planner-owned spike заканчивается brief с executor/evidence-return. По прочитанным контрактам architecture handoff template фактически может выдать status, blockers, constraints, expected_next_output и evidence_return_to, которые planner принимает; spec output имеет consumer/readiness, atomic requirements, acceptance и verification map. Будущая совместимость изменённых поставщиков ещё не проверена.

Координатор выполнил owning lint/check, isolated compile и emitted check: exit 0; 21/21 emitted files byte-identical (`delivery-planner-baseline-checks.json`, прочитан аудитором). Source/emitted defects не установлены. Это структурные результаты, не поведенческий PASS. Исторический raw DELIVERY-BLIND-1 прочитан как поддерживающее evidence только узкого readiness случая; он не закрывает новые достаточные governance/DX случаи. Новые trials, сеть, Git и изменения target не выполнялись; единственная запись аудитора — этот отчёт.

Следующий владелец — автор delivery-planner **после стабильного PASS поставщиков по принятому порядку**. Исправления потребителя сейчас не разрешены. Для final PASS нужны bounded correction, source/emitted checks и предусмотренные независимые paired/interop проверки; предварительный FAIL не блокирует разрешённую работу поставщиков.
