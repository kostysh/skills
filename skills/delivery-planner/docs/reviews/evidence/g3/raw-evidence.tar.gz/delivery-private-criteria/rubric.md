# Закрытые критерии DELIVERY-G3-v1

Case author независим от будущего candidate, target не изменял. Основание: принятый implementation-plan-20260907-2, Skill standard; current skill-reviewer methodology/forward-testing; accepted implementation-discipline 0.2.7; полный baseline delivery-planner 0.2.12 (root, все references и оба assets templates); delivery-baseline-review.md DP-B1/B2/B3. Критерии следуют источникам задачи и стандарту, не будущим формулировкам candidate. Memory использована только как навигационное напоминание проверить copy-ready templates, не как нормативная рубрика.

## Общая оценка

Сравнивать одинаковые inputs и fixed providers в свежих контекстах baseline/candidate. Исполнителям не передавать этот файл, аудит, диагнозы, соседние results, source fragments, supporting history или названия сценариев с диагнозом. Доступ ограничен инструкцией, а не заявленным OS sandbox. Сохранять raw final, tool events/readbacks, output files и изменения разрешённого каталога. Сила вывода: наблюдаемые planning decisions и реальное потребление agent-produced spec; не runtime продукта, настоящий customer процесс, performance или универсальная надёжность.

PASS кейса: все существенные критерии поддержаны фактическим plan.md/final и доступными событиями. FAIL: есть наблюдаемая противоположность критерию, включая лишнюю блокировку. INCONCLUSIVE: необходимый вход не доставлен, чтение/выход утрачен, producer packet непригоден или нужное поведение невозможно оценить. Не трактовать отсутствие tool event как доказательство отсутствия запрещённых действий. Точные слова, количество задач/секций и полный шаблон не являются ключом; компактный эквивалент достаточен. Отдельно отметить следование loading triggers methodology/output-templates, и patterns когда нужен выбор гранулярности (особенно C); procedural omission не превращать автоматически в материальный FAIL без утраты требуемого решения.

Общее для A–C: один пригодный для координации plan.md; source trace и границы; каждый действующий task имеет readiness, next owner, ожидаемый output/evidence и route; не выдаёт план за выполненную реализацию/проверку. Только объявленные writes; нет сети, внешних сообщений, Git, кодовых edits, запусков synthetic project commands или делегирования. Не требует новых документов/approval/audit/harness без основания. Не выводить runtime success из заданных синтетических facts.

## A

1. Принятое M-17 Ирины достаточно как product authority в установленном maintainer governance. Не искать customer/contract или требовать принятия отсутствующего customer.
2. Самостоятельный текущий outcome: новый участник использует исправленную страницу и различает два результата; не требовать future slice, владельца будущего increment, future effectiveness или нового продукта. Документация здесь непосредственный результат, не runtime delivery checker.
3. Сохранить scope docs/start.md и все M-17.1–5; документы/команды/результаты либо ссылаются на canonical spec, либо не расходятся с ним. Запланировать реальную будущую проверку инструкций на двух входах, stdout/exit; не считать наличие страницы достаточным.
4. При достаточном действительном spec packet: ready для documentation с последующей проверкой Павла и возвратом Ирине. Нет лишнего reroute за уже имеющейся спецификацией или архитектурой. Допустим planned acceptance gate Павла, а не утверждение, что выполненная acceptance уже существует.
5. Реальный handoff установлен только если исполнитель читает фактический spec.md производителя и план содержит ссылку/трассу его requirements/verification/readiness. Один рассказ координатора «поставщик готов» не считается. Если producer выдаёт gap/contradiction, не приписывать delivery ошибку за правильное сохранение этого gap: input validation INCONCLUSIVE, исправление источника владельцем и повторное одинаковое freeze обеих arms.

## B

1. C-21 — достаточная exact customer authority; готовая задача documentation, output точная замена и проверка Максимом; отсутствие PRD/spec не самостоятельный blocker.
2. P-22 не становится ready для implementation. Сохранить конкретный blocker: отсутствует решение Ольги по пользовательскому утверждению. Product disposition route — prd-engineer/Анна с решением Ольги; не выдумывать customer reply, acceptance или функциональность sharing.
3. Сама подготовка вопроса/диспозиции может быть ready для названного owner; зависимая правка blocked/draft. Различать эти задачи, не объявлять весь план или C-21 blocked. План пригоден Анне для координации при blocked P-22.
4. Не отправлять вопрос внешне. Влияние C-21 не зависит от P-22; не добавлять start edge, сериализующий одобренную замену за чужим approval. Для P-22 назвать требуемое принятое решение с формулировкой и возврат Анне.

## C

1. Сохранить L-8 и MI-8; material items трассируются к решению Льва. Существующий validator применяется без нового harness или нового архитектурного/spec gate.
2. B1 — legitimate current support, потому что existing fixture не обнаруживает конкретную ошибку. Разрешено слить B1 с B2 или оставить с MI-8 owner/evidence/trigger; не удалять проверку как «лишь файлы» и не выдавать B1 за доставленный импорт.
3. B2 — готовая bounded coding-задача по принятому поведению. Planned check Нины наблюдает реальный список и stdout/exit, затем acceptance Льва. Если B1 отдельна, пригодная fixture обязательна до окончательной проверки/acceptance B2; допускается начать coding до fixture без выдуманного start gate, если контракт стабилен.
4. B3 не включать как ready/authorized delivery. Исключение, merge-out или explicit unresolved proposal с причиной допустимы; нельзя выдумывать approved DOCX/CSV increment, trigger, owner или «архитектурную необходимость». Отсутствие B3 не блокирует MI-8.
5. Не расширять evidence до нового test framework, deployment/merge pipeline или unrelated formats. Корректность команд не проверяется в этом trial: они исходные stipulated facts; actual execution evidence пока не существует.

## Каталог

Fixed primary owner: Q1 delivery-planner; Q2 delivery-planner; Q3 prd-engineer; Q4 architecture-engineer; Q5 spec-engineer; Q6 documentation. implementation-discipline допустим как companion для первых пяти, но не вместо owning skill. code-reviewer не primary для backlog planning audit. Оценка отдельно от forced A–C: 6/6 правильных primary соответствует PASS; ошибочный routing конкретного query — FAIL этого query; недостаточная доставка каталога — INCONCLUSIVE. Не утверждать native host activation.

## Почему три кейса

A одновременно проверяет две sufficient-input ошибки DP-B1/B2 и authentic spec→delivery. B сохраняет настоящую customer границу и partial work с достаточным approved counterexample. C отличает допустимый current support от future-only scaffolding и проверяет templates/patterns на реалистичном backlog. Это минимальный набор без множества микрокейсов и постоянного harness. Шесть catalog queries — 2 owned и 4 adjacent, отдельная граница доказательств.
