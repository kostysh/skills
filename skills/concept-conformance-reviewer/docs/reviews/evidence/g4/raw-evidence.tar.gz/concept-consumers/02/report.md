Реализация нарушает R3: для существующей чужой job отсутствует tenant-проверка; работоспособность HTTP handler и выполнение Acceptance не подтверждены.

## Основание и идентичности

Вердикт: `non-compliant`. Read-only проверка полного предоставленного implementation.py:1–10. Реализация не запускалась и не изменялась. История изменений отсутствует: отделить внесённое нарушение от ранее существовавшего невозможно.

Единственный нормативный источник — утверждённая владельцем API spec v1, явно назначенная заданием consumer-task.md. Concept v1 утверждён владельцем продукта, но в этом задании задаёт только контекст. Данных о supersession нет. Прочитанный upstream report имеет design-time scope, не исследовал реализацию и не устанавливает новые требования. Его `design-ready` и `proceed` не являются conformance verdict или разрешением публикации.

SHA-256 источников; пути относительно `/tmp/skills-revision-g4-20260907-ZMFe9Zkq`:

- `concept-cases/01/concept.md`: `7d74ca62488b8cc231d92d256373c910acf5a435ad081a05877957af3e18b6ed`.
- `concept-cases/01/spec.md`: `1be2e50e11bd5e5ca74376db20c347e1c62449f61ac4454cda2f6b7127bfabcb`.
- `concept-cases/01/implementation.py`: `4492f0b297d81577bed61f8bdf21f0d0260cdeffebb8c36705ad922c218c7d33`.
- `concept-runs/01-02/report.md`: `3a734d4a36e123ef638ac47737913b33c639fcc804e7fdce1c29f7fb8cd7798f`.

Последняя запись — hash фактического прочитанного upstream review. Все четыре хеша повторно проверены перед записью; изменение snapshot инвалидирует вердикт.

## Требования и evidence

Источник всех требований — spec.md:1, R1–R4 и Acceptance; modality для каждой строки `must`, origin `explicit`. Производных обязательств не добавлено. В колонке evidence описано статическое чтение, не результаты исполнения. Test evidence отсутствует для всех строк.

| ID / тип | Условие и требование | Evidence | Статус |
|---|---|---|---|
| R1a / functional_behavior | Authenticated GET для своей job возвращает HTTP 200 | Стр. 10 возвращает tuple 200; route/authentication/HTTP boundary не предоставлены | `cannot_determine` |
| R1b / output_contract | Ответ содержит id/state выбранной своей job | Стр. 4,7 формируют словарь; реальный полный JSON не показан | `cannot_determine` |
| R2a / output_contract | Ready дополнительно содержит downloadUrl | Стр. 8–9 добавляют URL из job; HTTP evidence отсутствует | `cannot_determine` |
| R2b / output_contract | Прочие state не содержат downloadUrl | Стр. 7–9 не добавляют поле в не-ready; HTTP evidence отсутствует | `cannot_determine` |
| R3a / authorization_or_policy | Чужая job возвращает 404 | Actor используется только в проверке None; для любой найденной job стр. 10 возвращает 200 | `not_fulfilled` |
| R3b / output_contract | Ответ чужому tenant не раскрывает поля job | Стр. 7–9 возвращают id/state и URL при ready без проверки tenant | `not_fulfilled` |
| R3c / error_handling | Unknown id возвращает 404 без полей job | Стр. 5–6 возвращают 404, {}; HTTP surface отсутствует | `cannot_determine` |
| R3d / consistency_or_invariant | Чужая job и unknown id дают одинаковый ответ | Ветки стр. 5–6 и 7–10 отличаются status и полями | `not_fulfilled` |
| R4 / authorization_or_policy | Без authentication — 401 | Стр. 2–3: actor=None даёт 401; mapping реального authentication в actor неизвестен | `cannot_determine` |
| A1 / functional_behavior | Реальные запросы handler охватывают четыре state | Нет фактических результатов queued/running/ready/failed | `cannot_determine` |
| A2 / authorization_or_policy | Реальные запросы охватывают чужой tenant, unknown id и отсутствие authentication | Результаты не предоставлены | `cannot_determine` |
| A3 / output_contract | В Acceptance проверяются HTTP status и полный JSON | Нет соответствующих проверок/результатов | `cannot_determine` |

Статические положительные свойства функции сохранены в таблице, но не выданы за выполнение HTTP контракта. Отсутствие доказательства не является partial fulfillment.

## F-1 — обязательная изоляция tenant отсутствует

Severity: `major`. Основание: spec R3, атомарные R3a/R3b/R3d. При actor != None и существующем job_id функция получает job из jobs и возвращает 200 с её полями (implementation.py:2–10). При неизвестном id возвращает 404, {} (стр. 5–6). Проверки владельца нет вообще. Это прослеженный статический путь, не выполненный тест.

Влияние: если jobs содержит чужую job, вызывающий получает её сведения и может отличить существующую чужую job от неизвестной. Полнота предоставленной функции позволяет подтвердить отсутствие обязательной проверки здесь. Внешняя tenant-фильтрация не показана; её нельзя предположить как оправдание или объявить отсутствующей в неизвестном deployment. Production exploitability этим отчётом не доказана.

Направление исправления: владелец API-реализации обеспечивает tenant-aware lookup либо проверку принадлежности до сериализации; отказ должен совпасть с unknown 404 без полей job. Если защита задумана выше функции, представить обязательный enforcement contract и его реализацию для проверки полного пути. Уверенность в отсутствии проверки внутри функции высокая.

## Условная policy/admission matrix

Триггер: R3/R4 требуют отказ клиенту чужого tenant и без authentication. Субъект — partner client; ресурс — export job. Дополнительный durable/audit side effect не задан.

| Row | Нормативное условие | Ожидаемый результат | Evidence / статус |
|---|---|---|---|
| P1 allow | R1: authentication и своя job | 200 с полями R1/R2 | Стр. 7–10; HTTP/auth boundary отсутствует: `cannot_determine` |
| P2 deny | R3: чужая job | 404 без полей job, как unknown | Стр. 7–10: `not_fulfilled` |
| P3 resource absent | R3: unknown id | 404 без полей job | Стр. 5–6; HTTP boundary отсутствует: `cannot_determine` |
| P4 missing admission evidence | R4: без authentication | 401 | Стр. 2–3; authentication mapping неизвестен: `cannot_determine` |

Test evidence отсутствует во всех rows. Freshness, replay, activation, downstream health, persistence failure и audit durability нормативно не требуются и не превращены в findings.

## Пробелы и следующий владелец

Обратная трассировка: actor=None относится к R4, missing job — R3, id/state и ready-ветка — R1/R2. Безусловный успех для любой найденной job расходится с R3. Тело ответа 401 и malformed job не специфицированы; новые обязательства на них не изобретены.

Владелец реализации исправляет F-1 либо представляет обязательную внешнюю границу изоляции. Затем исполнитель Acceptance проводит реальные запросы handler для всех четырёх state, чужого tenant, unknown id и отсутствия authentication с проверкой HTTP status и полного JSON. Reviewer повторно оценивает новую идентичность с этими результатами. В текущем review запуск запрещён и ни один тест не заявлен выполненным.

Upstream design-time handoff принят только как концептуальная оценка: partner API является полноценной capability для прямого клиента, UI не нужен. Web UI, доступность скачивания, создание/исполнение export job, deployment, durable effect GET и полная security assurance находятся вне вывода. Спецификацию меняет её владелец; обязательной концептуальной переделки upstream не требует.

Итог: `non-compliant` из-за подтверждённого нарушения R3; остальные `cannot_determine` сохраняются как границы покрытия. Этот отчёт не является независимым аудитом качества skill и не присваивает skill audit PASS.
