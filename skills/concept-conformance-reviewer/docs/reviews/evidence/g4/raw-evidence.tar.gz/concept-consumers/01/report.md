# Соответствие реализации спецификации

Реализация нарушает обязательную tenant-изоляцию R3; локальные ветви ответа видны в коде, но реальная HTTP-приёмка не подтверждена.

## Основание и snapshot

Read-only проверка полного `implementation.py:1–10` против утверждённой владельцем API `spec.md` v1. По заданию именно spec нормативна; утверждённая владельцем продукта concept v1 — только контекст. Замена версий не указана. Отсутствуют diff/base, поэтому происхождение нарушения по изменениям не определено. Реализация и тесты не запускались и не менялись.

Actual upstream review прочитан как design-time handoff: design-ready/proceed относятся к спецификации, а строки 23–25 исключают доказательство работающей реализации. Upstream не становится новой спецификацией и не передаёт свой verdict реализации. Собственный итог ниже получен по коду и spec.

Корень идентификаторов: `/tmp/skills-revision-g4-20260907-ZMFe9Zkq`. SHA-256:

- `concept-cases/01/concept.md`: `7d74ca62488b8cc231d92d256373c910acf5a435ad081a05877957af3e18b6ed`
- `concept-cases/01/spec.md`: `1be2e50e11bd5e5ca74376db20c347e1c62449f61ac4454cda2f6b7127bfabcb`
- `concept-cases/01/implementation.py`: `4492f0b297d81577bed61f8bdf21f0d0260cdeffebb8c36705ad922c218c7d33`
- `concept-runs/01-01/report.md`: `9d885081ae562aa83b58a86c9969fbcd644dc8941048c7d963ee2eb06d0cef8e`

Хеши повторно сверены при записи; изменение реализации или нормативного источника инвалидирует verdict. Применён указанный skill spec-conformance-reviewer 0.1.7 и полностью прочитаны methodology, reporting, conditional policy-admission-matrix. Последний применим по R3/R4 (tenant denial/authentication).

## Требования и трассировка

Все строки: modality `must`, origin `explicit`; источник — единственная строка spec.md, соответствующий R или Acceptance. Выведенные требования не добавлялись. Тестовое evidence отсутствует для всех строк.

| ID | Тип и ожидаемое поведение | Evidence | Статус |
| --- | --- | --- | --- |
| R1.a | output_contract: свой существующий job — 200, id,state | строки 4–10 возвращают tuple и новый dict | fulfilled в границе функции |
| R1.b | functional_behavior: authenticated GET /exports/{id} возвращает HTTP/JSON | route, auth adapter, сериализация не предоставлены | cannot_determine |
| R2.a | output_contract: ready содержит downloadUrl | строки 8–9 копируют поле | fulfilled в границе функции |
| R2.b | output_contract: остальные state без downloadUrl | новый dict строки 7, добавление только при ready | fulfilled в границе функции |
| R3.a | authorization_or_policy: чужой tenant — 404 без полей job | строки 4–10 не проверяют tenant и возвращают найденный job | not_fulfilled |
| R3.b | output_contract: unknown id — 404 без job | строки 4–6 возвращают 404, {} | fulfilled в границе функции |
| R3.c | consistency_or_invariant: чужой и unknown получают одинаковый ответ | чужой найденный job идёт в 200, unknown в 404 | not_fulfilled |
| R4 | authorization_or_policy: без authentication — 401 | строки 2–3 реализуют actor=None; реальное отображение authentication в actor неизвестно | cannot_determine на HTTP-границе |
| A1 | functional_behavior: реальные запросы handler для всех четырёх state, чужого tenant, unknown и отсутствующей auth; status и полный JSON | тесты, результаты и HTTP wiring отсутствуют в предоставленной поверхности | cannot_determine |

Локальные fulfilled основаны на прямом статическом анализе алгоритма, а не существовании функции, комментариях или фиктивном test pass. Они не закрывают HTTP-границу R1.b/R4/A1. Для R4 локальная None-ветвь подтверждена кодом, реальный запрос не наблюдался.

## F1 — major: отсутствует tenant-проверка

Основание: R3.a/R3.c (spec R3). `implementation.py:4` ищет только по job_id. После проверки actor на None (строка 2) actor больше не используется. Строки 7–10 возвращают id/state любого найденного job, а ready — также URL. Статический контрпример: actor tenant A и существующий job tenant B в jobs проходят в 200, тогда как неизвестный id получает 404 и {}. Это выведенный путь кода, не результат исполнения.

Воздействие: сведения чужого job раскрываются на предоставленной границе функции, нарушается равенство отказов. Предварительная фильтрация jobs не показана и не засчитывается как доказанная защита. Уверенность высокая для функции; exploitability реального сервиса не оценивалась. Направление исправления владельцу реализации: проверить принадлежность до формирования ответа, обеспечить одинаковый 404 без job для чужого и unknown; затем получить реальные acceptance-запросы. Историческую новизну F1 установить нельзя без diff/base.

## Ограниченная policy-матрица

| Row | Основание / условие | Ожидаемое решение | Evidence / статус |
| --- | --- | --- | --- |
| P1 allow | R1: authenticated, свой job | 200 id/state | строки 7–10: локально fulfilled, HTTP unknown |
| P2 deny | R3: чужой tenant | 404 без job | tenant-проверка отсутствует: not_fulfilled |
| P3 unknown | R3: неизвестный id | 404 без job | строки 4–6: локально fulfilled |
| P4 missing admission | R4: нет authentication | 401 | строки 2–3 для None, auth adapter неизвестен: cannot_determine |

Тестового evidence нет. Дополнительные side effects не предписаны. Freshness, replay, activation, audit/persistence failure не имеют нормативного основания и не добавлены. Прямой persistence/RLS путь не представлен и не заявлен; его наличие или защиту не предполагаю.

## Границы и handoff

Обратная трассировка: статусы 401/404/200 и поля id,state,downloadUrl имеют основание R1–R4. Успешный ответ для чужого tenant — контрактное отклонение F1. Некорректная структура job и неизвестные state отдельно не определены; новых обязанностей не извлечено.

Нет доказательств HTTP wiring, реальной authentication, сериализации и выполнения Acceptance. Непредоставленные компоненты не названы подтверждённо отсутствующими. Download availability, исполнение export job и user UI не оценивались; отсутствие UI не является нарушением. API является самостоятельной возможностью partner client в заданной концепции.

Итог: **non-compliant**, так как обязательные R3.a/R3.c — not_fulfilled. Неопределённость других границ остаётся видимой и не смягчает отрицательный verdict. Владелец реализации исправляет F1 и предоставляет реальные запросы с полным JSON; spec-conformance-reviewer проверяет новый snapshot и evidence. Изменение смысла spec владельцем API для исправления не требуется. Это conformance report реализации, не независимый skill audit PASS.
