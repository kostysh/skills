def get_export(job_id, actor, jobs):
    if actor is None:
        return 401, {}
    job = jobs.get(job_id)
    if job is None:
        return 404, {}
    result = {"id": job_id, "state": job["state"]}
    if job["state"] == "ready":
        result["downloadUrl"] = job["downloadUrl"]
    return 200, result
