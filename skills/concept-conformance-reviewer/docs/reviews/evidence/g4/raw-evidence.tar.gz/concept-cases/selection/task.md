Для каждого запроса выбери основной skill из catalog.json и кратко укажи границу его задачи. Не открывай тела skills до выбора.
1. У команды есть approved product concept и план, но acceptance проверяет только наличие endpoint. Оцени, обеспечивает ли план заявленную capability.
2. Сравни реализацию endpoint с утверждённой спецификацией и перечисли несовпадения.
3. Исследуй exploitability tenant access в API; нужна vulnerability severity.
