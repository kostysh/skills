# Baseline architecture-engineer: FAIL

Режим `baseline`, assurance `independent`. Установлена одна P2: условие остановки в root требует повторного решения человека даже при достаточных и уже принятых входных данных. Одна P3 относится к неоднозначному обозначению условных references. P1 не установлены. Исправлений не выполнено.

## Основание и граница

Проверен architecture-engineer 0.1.8 в worktree `skills-revision`, base commit `be557e915b03267df650b9ca5906ac59078110e9`. Все 28 файлов совпали с `baseline-source-manifests.json` до и после проверки. SHA-256 канонического JSON словаря architecture-engineer (ключи отсортированы, separators `(',', ':')`, относительные пути от папки скилла): `30aa82c8dba34743808843247ffd1b8af04b992e96a4d3a8b779f50456618c08`.

Применены AGENTS.md, docs/skill-standard.md, принятый implementation-plan-20260907-2, текущие skill-reviewer с methodology и implementation-discipline. Скилл-мишень — данные аудита, не источник полномочий аудитора. Полностью прочитаны skill.yaml, SKILL.md, оба fragments, все три references, десять templates, UI metadata. Supporting README/compile-report и актуальный authority-gate log рассмотрены как навигация/история; прежние PASS не переносятся на настоящий вывод. Соседние spec-engineer/delivery-planner читались только в частях входа, ownership, readiness и spike handoff. Их исправления и полный аудит исключены.

Capability для архитектурного агента — вывести обоснованное решение/ограничение и пригодный named-owner handoff из разрешённых входов. Для спецификатора и планировщика это входные ограничения, а не реализованное поведение. Архив, шаблоны, compiler и этот аудит не доказывают runtime, общую надёжность агента, live-интеграцию или фактическое исполнение будущего handoff.

## F1 — P2: изменение архитектурной поверхности само по себе требует нового human review

**Evidence:** `skill.yaml:371-383`, emitted `SKILL.md:282-292`: “Ask one focused question or mark human review required when” и далее “a public API, identity model, tenant isolation model, data model, migration strategy, secrets handling, or deployment topology would change”. В required `references/methodology.md:534-538` то же правило названо reminder, но применено только “when the missing or conflicting input would change architecture”. Root не сохраняет это условие и не исключает ранее полученное разрешение.

**Basis: conflicting**, непосредственно подтверждено двумя активными формулировками одного stop decision. Применимые AGENTS.md требуют сохранять полномочия текущей задачи и останавливать только зависимую часть; standard требует одного canonical owner для нормативного решения.

**Failure path:** оператор просит подготовить архитектурную delta уже согласованного изменения публичного контракта, передаёт принятую authority, constraints и достаточно фактов, не запрашивает реализацию. Агент применяет root predicate “public API ... would change” и вместо завершённой разрешённой delta/handoff требует ещё один ответ или помечает результат `human review required`. Этот дополнительный gate не обусловлен отсутствующим фактом или действующим approval boundary. Методика допускает продолжение, root требует иной вывод.

**Impact:** необоснованное прерывание архитектурной подготовки/ложное впечатление неподготовленного handoff для spec-engineer. **P1 screen:** поддержанный исход — лишняя остановка/маркер review, а не опасная мутация, выдуманное нормативное требование или ложная успешная capability. Поэтому P2, несмотря на активное противоречие; оно ограничено escalation predicate, а не разрушает весь authority contract.

**Минимальная коррекция:** назначить одно canonical stop rule с условием реально недостающего/конфликтующего входа либо действующего неисполненного approval boundary, сохранить уже выданные полномочия и продолжение независимой работы. Root/reminder должны ссылаться на одинаковое условие. Редактировать source и регенерировать, не чинить только emitted файл.

**Закрывающая проверка:** одинаковый достаточный случай с принятым изменением API должен дать разрешённую architecture delta без нового обязательного вопроса; контрольный случай с неизвестным authority/взаимоисключающими требованиями должен остановить только зависимый выбор и назвать нужный вход. Это критерии будущей проверки, не выполненные trials.

## F2 — P3: Optional references одновременно предписывают условное чтение

**Evidence:** `skill.yaml:27-39` задаёт `required: false` для artifact-templates и pattern-catalog, тогда как оба triggers говорят “Read this when”; emitted `SKILL.md:300-302` помещает их в `Optional references`. Methodology дополнительно требует catalog для component-specific comparison; catalog заканчивается правилом загрузить domain skill для runtime/framework-specific validation.

**Basis: direct.** Неясно, рекомендованы ли эти материалы или обязательны при совпадении условия. Standard требует не скрывать обязательное условие ярлыком optional.

**Failure path и предел:** при совпадающей задаче executor может трактовать заголовок как разрешение не читать материал, тогда как другой executor трактует trigger как обязанность. На прочитанной поверхности не установлен самостоятельный материально неверный архитектурный вывод: root и required methodology уже несут authority, risk, owner-producibility, evidence и handoff guards. Поэтому это P3 clarity, а не P2 только за классификацию references. **P1 screen:** пропуск сам по себе не разрешает опасное действие, выдуманный факт или ложную готовность; такой исход не доказан.

**Коррекция:** выбрать намерение автора: conditionally required с существующим узким trigger либо действительно optional формулировка без императивной обязательности. Не делать все материалы безусловными. Для closure достаточен согласованный source/emitted readback и соразмерная проверка выбора reference при соответствующей/несоответствующей задаче, если меняется контракт.

## Поддержанные результаты и проверки

Authority gate ASR различает accepted source, accepted non-product authority и unresolved assumption; наблюдаемая реализация не превращается в новое требование. Готовность handoff привязана к конкретному next owner; unresolved decision может породить ready spike для его разрешения, но не обычную ready implementation handoff. Planner получает только executable brief, empirical evidence возвращает executor. Эти правила согласованы с прочитанными потребительскими контрактами. Spec получает constraints/verification obligations и не должен выбирать архитектуру повторно.

Root, methodology и templates покрывают capability/substrate, риск, rollback/validation и intentionally not_prescribed детали. UI metadata соответствует архитектурному scope. Runtime/package/test harness в скилле нет; искусственные тесты не добавлялись. Материальных parity, локальных ссылок или machine-path зависимостей на проверенных активных поверхностях не установлено.

Повторно прочитан coordinator evidence `architecture-engineer-baseline-checks.json`: lint, source check, isolated compile и emitted check имеют exit 0; emitted parity 25/25. Это структурное evidence, не поведенческий PASS. Я не запускал эти команды повторно и не изменял target. Исторические behavioral summaries не использованы как текущие trials. Настоящее задание — baseline inspection; blind execution и activation/generalization не проводились и не заявлены. Forward-testing не активирован для сбора/оценки trials, поскольку таких claims здесь нет.

Итоговый **FAIL** обусловлен F1 на стабильной воспроизводимой поверхности. Следующий владелец — автор architecture-engineer: минимальная source-коррекция, решение по P3, затем проверки по принятому плану и независимый re-audit. Независимый baseline не является приёмкой группы 3.
