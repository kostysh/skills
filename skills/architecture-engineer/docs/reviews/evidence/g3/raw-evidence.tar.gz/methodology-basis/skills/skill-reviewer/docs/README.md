# `skill-reviewer` docs

Эта папка содержит supporting и historical surface. Активные инструкции находятся в `SKILL.md` и явно подключённых `references/*`.

## Implementation Logs

- `docs/logs/implementation-log-20260710-1.md` — создание `skill-reviewer` и формализация методики независимого ревью скилов.
- `docs/logs/implementation-log-20260713-1.md` — сокращение prompt surface, явная read-only автономия reviewer-а и grounded evidence contract.
- `docs/logs/implementation-log-20260713-2.md` — escalation от повторного blocking finding к root-cause investigation.
- `docs/logs/implementation-log-20260715-1.md` — правило проверки рекомендуемой длины описания скила и сокращение собственного trigger surface.
- `docs/logs/implementation-log-20260727-1.md` — bounded remediation re-audit contract и evidence реализации #226; independent PASS.

## Generated Reports

- `docs/compile-report.md` — generated отчёт о текущей compiled surface.

## Текущая ревизия методики

Source-only запись `docs/logs/implementation-log-20260907-1.md` содержит реализацию CP3, актуальный статус, проверки и независимый аудит. Она доступна в исходном репозитории и не входит в emitted package; активные инструкции от неё не зависят.
