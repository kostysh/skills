1. **architecture-engineer** — The request requires settling architectural boundaries, evaluating a storage-strategy spike, and handing off architectural constraints.
2. **spec-engineer** — The request translates accepted behavior and architecture into atomic, falsifiable requirements for a bounded API extension.
3. **delivery-planner** — The request decomposes accepted specifications and architecture into executable tasks, dependencies, and verification evidence.
4. **none** — A static caption typo correction with unchanged behavior and boundaries does not require any of the catalogued architecture, specification, planning, or product-requirements skills.
