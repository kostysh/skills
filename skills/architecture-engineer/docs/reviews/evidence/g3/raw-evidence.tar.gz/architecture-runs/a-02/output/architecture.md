# AD-001: Job status display label response extension

Status: decided within ARCH-A authorization; handoff ready. Scope: component-level API response contract. Risk: medium because the public success shape changes; existing access and error behavior are protected invariants. A compact architecture delta is sufficient; no separate ADR, pattern comparison, or feasibility spike is needed for the direct mapping.

## Sources and claim boundary

- **PRD-A/A1–A4**, [task.md, Accepted product requirements](../input/task.md): operator-owned accepted product authority.
- **ARCH-A**, [task.md, Accepted architecture](../input/task.md): accepted API assembly/repository boundary and explicit delegation to select this mapping now.
- **STATE-A**, [task.md, Current-state contract](../input/task.md): stipulated existing design, including an already-available optional saved label and opaque state/error behavior; not executed evidence.
- **GOV-A**, [context.md, Project governance](../input/context.md): architecture decisions within accepted requirements need no additional product approval; output goes to the specification agent.

This is design/authoring only. The sole deliverable is this handoff. The enabled capability is an authenticated workspace member seeing the existing job's saved label in an actual status response, including an empty string or legacy null. The immediate consumer is `spec-engineer`. This document and a future specification are substrate: neither demonstrates that the public operation works. No implementation, deployment, or publication is authorized here.

## Existing boundary and scope

STATE-A supplies the complete current-state facts for this decision: the single read-status operation receives an opaque identifier plus authentication context; the API service assembles `{id, state}` from the existing workspace-scoped job repository. The authorized job already contains the optional saved label. ARCH-A requires preserving that ownership.

The change is confined to successful public-response assembly in the API service. Repository, persistence, authentication, workspace scoping, endpoint, job states, data writes, background processing, deployment units, and logging obligations remain outside this delta (PRD-A/A2–A3; ARCH-A; STATE-A). No latency or throughput target is introduced; targets are unspecified/TBD and do not block this bounded mapping.

## Architecture-shaping requirements

### ASR-001 — Additive public projection with legacy compatibility

- Requirement: The successful response exposes `displayLabel` as the saved string without normalization, preserving an empty saved string; absence of a saved label produces JSON null. Existing `id` and `state` semantics remain intact and no migration or user action is needed.
- Authority: `source_statement`; locators PRD-A/A1–A2; owner operator/product; derivation explicit. Normative statements: A1 requires the saved label, including empty string and legacy null; A2 requires existing values and migration-free legacy behavior.
- Applicability: authorized members reading existing jobs through this operation.
- Necessity/removal falsifier: Omitting this constraint permits a missing `displayLabel`, an empty string converted to null, or a legacy job needing a write, each violating A1 or A2.
- Forces: additive client compatibility and reuse of available repository data. Medium risk, high confidence in the stipulated facts. Validation: V-001.

### ASR-002 — Preserve scoped ownership and denial behavior

- Requirement: API-owned assembly continues to consume the existing workspace-scoped repository; the extension provides no job data to foreign-workspace or unauthenticated callers and preserves all current error responses.
- Authority: `accepted_non_product_authority` for ARCH-A's explicit boundary preservation, combined with `source_statement` PRD-A/A2–A3 for unchanged errors and access. Owners: accepted architecture/operator and operator/product respectively. Derivation explicit; STATE-A supplies the existing-operation preservation detail, not authority for a new access rule.
- Applicability: every invocation, including denied, malformed, and missing-job paths.
- Necessity/removal falsifier: Bypassing scoped access or changing an error response violates A2/A3; moving response ownership violates ARCH-A.
- Forces: tenant isolation and compatibility through an unchanged existing path. The mapping is medium risk; access regressions have serious consequences and require real-operation validation. High confidence in stipulated facts, no runtime proof. Validation: V-002 and V-003.

## D-001 — Direct API success-response mapping

Selected under ARCH-A's explicit delegated authority, linked to ASR-001 and ASR-002. Extend the existing successful response with `displayLabel`. Map the repository-returned saved label unchanged when present, including `""`; use explicit JSON null for an absent saved label. Do not omit the property or use truthiness to decide whether a label exists. Keep `id` and opaque `state` unchanged.

Apply this projection only to the already-authorized successful result. Preserve the existing operation's authentication, missing-job, foreign-workspace, and malformed-identifier responses byte-for-byte, without specifying new status codes or bodies. The same service/repository boundary remains responsible for access.

The direct path satisfies all accepted forces; there is no unmet obligation justifying an abstraction, new DTO layer, registry, storage default/backfill, queue, instrumentation, or test seam. No alternatives exercise is warranted. Consequence: clients gain one success property and can distinguish empty labels from absent labels. There is no data migration, new operational lifecycle, or new dependency. Local code reversal does not require data rollback, but removing the property after delivery would violate A1 and cannot be presented as successful delivery. No rollback automation or rollout mechanism is prescribed.

## Validation obligations

- **V-001 (A1, A2, A4):** Exercise the actual existing read-status operation as an authorized workspace member against jobs with a saved non-empty label, a saved empty string, and no saved label. Inspect public JSON for exact string preservation, `""`, and explicit null respectively, with unchanged `id` and state. Include a string whose whitespace would reveal accidental normalization. These checks can falsify D-001 directly.
- **V-002 (A2, A3, A4):** Exercise foreign-workspace and unauthenticated access through the same operation. Confirm no job data, including label, is disclosed and compare the existing response status/body with its pre-change baseline byte-for-byte.
- **V-003 (A2, STATE-A):** Compare missing-job and malformed-identifier responses against the existing baseline byte-for-byte. Retain existing opaque state values on success. Obtain the baseline from the operation during downstream implementation verification; do not invent concrete errors or states in the specification.

Use existing verification facilities at this operation's boundary. Mapping-only or mocked tests can support verification but cannot satisfy A4 alone. New label-writing, migration, or producer-to-storage flows are not part of this single response-projection change and are not prerequisites for acceptance. Actual operation execution and code inspection were unavailable under the fixture limits; all V-items remain unexecuted.

## Architecture handoff

```yaml
architecture_handoff_item:
  id: AHI-001
  kind: spec_candidate
  status: ready
  blockers: []
  title: Job status display label projection
  linked_prd: [PRD-A/A1, PRD-A/A2, PRD-A/A3, PRD-A/A4]
  linked_asr: [ASR-001, ASR-002]
  linked_decision: [D-001]
  architectural_intent: Extend only the successful API projection using the existing scoped repository result.
  constraints:
    - Preserve D-001 mapping and existing API/repository ownership.
    - Preserve opaque id/state and current errors byte-for-byte.
    - No access, persistence, endpoint, state, logging, async, or deployment expansion.
  acceptance_constraints:
    - Actual authorized response must show saved string, empty string, or explicit null as applicable.
    - Existing access and state behavior must remain correct.
    - Documentation or mapper-only evidence cannot close runtime acceptance.
  required_validation: [V-001, V-002, V-003]
  next_stage_owner: spec-engineer
  expected_next_output:
    - specification.md containing bounded behavior requirements and an operation-level verification map
  not_prescribed:
    - Exact source file, class, function, and test framework.
    - Internal mapping syntax and error/state values already owned by the existing operation.
```

No source conflict or missing architecture decision blocks specification. Readiness authorizes the next design stage only. Revisit D-001 with `architecture-engineer` if downstream evidence contradicts label availability, requires another boundary or storage change, or shows that existing access/error semantics cannot be preserved. Changed product semantics return to the operator. Otherwise retain this decision without adding architecture work.
