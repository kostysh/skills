# ARCH-B: Archive preview architecture and routed handoff

Preview is ready for specification using the existing API and workspace-scoped repository. Retention architecture is blocked by contradictory product obligations. A bounded local storage investigation is ready for delivery framing; no storage change is selected.

## Scope, authority, and evidence

This is design/authoring substrate for a member-visible preview, not an implemented capability. Only this architecture artifact is produced. No experiment, runtime validation, implementation, deployment, or publication has occurred.

Source locators below refer to [task.md](../input/task.md), its named requirement statements and sections, and [context.md](../input/context.md), Project governance. Product owner/operator owns product decisions; ARCH-B1 and ARCH-B2 are accepted architecture authority. Current-state statements are stipulated design facts, not execution evidence or new normative authority. Confidence in source interpretation is high; operational correctness remains unverified.

Scope is component-level API/repository behavior. Preview has medium change complexity with a high-criticality tenant isolation invariant. Retention is high risk because irreversible deletion conflicts with recovery. Future storage selection has unproven feasibility. The smallest sufficient design is a read through the existing workspace partition in saved order, limited to the first 20 titles. No infrastructure, persistence, new auth mode, cache, queue, vendor, or generic storage layer is justified.

The downstream consumer is a fresh spec-engineer; the eventual actor is a member viewing their own workspace. The narrowest capability falsifier is a member preview returning any foreign-workspace title, changed spelling/order, or a sequence other than the first up-to-20 saved titles. Documentation completeness cannot pass as that runtime evidence.

## Architecturally significant requirements

| ID / status | Requirement and authority | Applicability, necessity, forces | Validation |
| --- | --- | --- | --- |
| ASR-B1 / accepted | Exact own-workspace title preview. `source_statement`; task.md PRD-B1, product owner; explicit: “Members can preview the first 20 saved archive titles for their own workspace; preserve title order and spelling. No cross-workspace reads.” | Member preview. Removing this violates the accepted capability and tenant boundary. Forces: partition-scoped reads, exact ordered projection; isolation high risk. | QS-B1; H-B1 |
| ASR-B2 / accepted | Existing boundary and retention independence. `accepted_non_product_authority`; task.md ARCH-B1, accepted architecture owner; explicit existing API/repository and no new infrastructure or persistence. Independence additionally explicit in PRD-B1, product owner. | Preview only. Removing these constraints silently expands architecture or blocks an explicitly independent slice. Forces: direct existing read, minimal coupling. | Boundary review in H-B1 |
| ASR-B3 / blocked | `source_statement`; task.md PRD-B2, product owner; explicit permanent erasure at day 30 with no recoverable copy. | All archive data. Removing it loses a stated obligation; accepting it alone violates ASR-B4. Forces: irreversible data lifecycle. | Product reconciliation, then QS-B2; H-B3 |
| ASR-B4 / blocked | `source_statement`; task.md PRD-B3, same product owner authority; explicit recoverability through day 90. | All archive data. Removing it loses a stated obligation; accepting it alone violates ASR-B3. Forces: recovery lifecycle. | Product reconciliation, then QS-B2; H-B3 |
| ASR-B5 / accepted investigation constraint | `accepted_non_product_authority`; task.md ARCH-B2, accepted architecture owner; explicit bounded comparison of ordered-list and indexed representations for 10,000 synthetic titles, first 20 exactly ordered, existing partition preserved. | Offline feasibility only. Removing the bound, correctness checks, or evidence return violates investigation authority. Forces: reversible experiment, no production commitment. Duration and memory are exploratory. | SP-B1; H-B2 |

PRD-B4 is a scope exclusion: download need, size ceiling and performance target are unaccepted. It creates no download ASR. No performance threshold exists for preview or the investigation; neither a maximum production archive size nor a latency SLO may be invented.

## Decisions and constraints

**D-B1 — accepted preview frame.** Sources: PRD-B1, ARCH-B1 → ASR-B1/B2 → H-B1. Use the existing API and workspace-scoped repository to expose the first up-to-20 saved titles, preserving sequence, duplicates, and spelling; fewer records yield only available titles. The up-to-20 interpretation follows a prefix of existing saved records and introduces no fabricated titles. Workspace authorization must constrain the read itself; do not read other partitions and merely filter the response. Exact routes, DTO names, functions and query syntax are `not_prescribed` for the specification owner.

This direct existing path needs no alternatives exercise: a new store or service would violate ARCH-B1 without improving the accepted scope. No persistence migration is required. Preview is read-only and introduces no deletion or recovery action; rollback of its exposure must not mutate archive records. Revisit if implementation cannot preserve the existing boundary or partition/order invariant. Confidence: high in architectural fit from stipulated facts, no runtime proof.

**D-B2 — retention blocked, no policy selected.** PRD-B2 and PRD-B3 apply to the same archive data and interval: immediately after day 30, no copy may be recoverable under B2 while recovery must remain possible under B3. Neither date order nor architecture discretion resolves equal-authority conflict. The product owner must supply one reconciled authoritative lifecycle rule before retention specifications, deletion mechanisms, recovery guarantees, migration or rollback policy can be committed. No vendor or specialist is available to supply this missing product decision, and neither would replace the product owner's authority.

The old `retentionOverride` field and maintenance script (task.md, Current-state evidence) establish only existing mechanics. They authorize no member/admin exception, toggle, prerequisite, or bypass and cannot reconcile B2/B3. This work neither exposes nor removes them. Their treatment depends on the reconciled lifecycle; no assumption of compatibility or compliance is made.

**D-B3 — proposed storage choice, commitment withheld.** ARCH-B2 → ASR-B5 → SP-B1/H-B2. Compare the existing ordered-list baseline with an indexed representation only inside the disposable experiment. The baseline has strongest stipulated codebase fit and lowest new conceptual cost; an index may offer different retrieval/memory behavior but adds representation and index construction cost. ASR fit, duration, memory, diagnostic visibility and partition safety are unmeasured for both. Both are locally reversible; production migration, operational fit and cost remain unknown. Numerical scoring would invent evidence. Retain the accepted current preview frame; return experiment evidence before selecting any future storage change. No final storage ADR or production migration is authorized.

## Validation scenarios

**QS-B1 — preview sequence and tenant boundary.** Source: member in workspace A. Stimulus: request preview while A has ordered titles and B has distinct sentinel titles. Environment: eventual production-equivalent existing API/repository path. Artifact: authorized scoped read and consumer-visible result. Required response: exact A prefix of length min(20, A count), unchanged spelling and duplicates, zero B reads and titles. Validate empty, fewer-than-20, exactly-20 and more-than-20 sets and a foreign-workspace request attempt. Compare saved authoritative order with API output and visible preview; inspect read scoping as well as output. No write path is changed here. Fixture-only checks cannot establish runtime authorization correctness. H-B1 must carry these obligations into the verification map.

**QS-B2 — retention, blocked until reconciliation.** Source: lifecycle time progression. Stimulus: archive reaches days 30 and 90. Artifact: archive and every recoverable copy. The two current response measures contradict: no recoverable copy after day 30 versus successful recovery through day 90. No combined passing test exists. After the product owner reconciles them, architecture must identify relevant copy boundaries and lifecycle evidence, including irreversible deletion and recovery behavior; current facts cannot support a universal no-copy guarantee or safe rollback. This validation gap does not block QS-B1.

## SP-B1 — bounded ordered-title feasibility investigation

Question: for the stipulated 10,000 synthetic titles, can either current ordered-list or indexed representation return the first 20 titles in exact saved order while preserving the existing workspace partition?

Scope: a small offline experiment in a disposable directory, two representations only, no production/external service access. Use a reproducible synthetic sequence with known order/spelling and a separate foreign partition containing identifiable sentinels. State how the 10,000-title target dataset and isolation fixture are assigned. Represent indexing within the existing partition; do not compare a different tenancy topology. The implementation executor may select a minimal local representation and measurement tool, recording those choices and their limits.

Success criteria: exact equality to the target's first 20 titles and no other partition's titles for each candidate. A failing candidate is a useful negative result; never report the investigation successful merely because timings exist. Record duration and memory with units, measurement method, environment and run context; distinguish construction/indexing from read measurements where measured. These are exploratory observations, not pass/fail performance thresholds or production scale evidence.

Eventual executor evidence contract: reproducible experiment source, synthetic dataset or deterministic generator, invocation instructions, observed and expected sequences, correctness/isolation results per representation, raw duration/memory measurements, failures and caveats. Return artifacts and measurements to architecture-engineer before storage commitment. No permanent benchmark framework, production seam, or download experiment is needed. Revisit D-B3 using actual evidence; a passing local experiment alone does not authorize a production change or establish runtime tenancy security.

## Architecture handoff register

### H-B1 — preview specification

- kind: `spec_candidate`
- status: `ready`
- blockers: []
- linked_prd: PRD-B1; linked_asr: ASR-B1, ASR-B2; linked_decision: D-B1
- next_stage_owner: `spec-engineer`
- expected_next_output: preview behavior specification and verification map, using the context's `specification.md` convention in that owner's assigned output directory.
- constraints: existing API/repository, workspace-scoped reads, first up-to-20 exact saved titles, independent of retention, no download, no override mode, no new persistence or infrastructure.
- required_validation: QS-B1 and source-to-spec boundary review; carry unexecuted runtime obligations explicitly.
- rollback_constraints: no archive data mutation from preview enablement or rollback.
- not_prescribed: endpoint names, data structure implementation, DTO names, local function organization, exact UI presentation.
- return path: architecture-engineer if a spec or implementation finding requires a boundary change. Specification can be written now without waiting for retention or SP-B1.

### H-B2 — investigation delivery framing

- kind: `spike`
- status: `ready`
- blockers: []
- linked_prd: none; accepted authority: ARCH-B2; linked_asr: ASR-B5; linked_decision: D-B3
- next_stage_owner: `delivery-planner`
- expected_next_output: bounded executable investigation brief carrying SP-B1, its correctness criteria, evidence contract and return route, naming the available repository implementation agent with local shell/filesystem as execution owner.
- constraints: offline disposable experiment; 10,000 synthetic titles; ordered-list versus indexed only; existing tenant partition; no production change, external service or download capability.
- required_validation: brief contains an executor capable of producing SP-B1 evidence and separates exploratory measurements from correctness gates.
- evidence_return_to: `architecture-engineer`
- not_prescribed: exact experiment source filenames, local language, memory measurement utility.
- Evidence production belongs to the implementation executor after the brief, not to delivery-planner. The planner's completion is only a brief; actual execution and returned artifacts remain future work. This architecture artifact performs no execution or delegation.

### H-B3 — reconcile lifecycle authority

- kind: `architecture_revisit_trigger`
- status: `ready`
- blockers: []
- linked_prd: PRD-B2, PRD-B3; linked_asr: ASR-B3, ASR-B4; linked_decision: D-B2
- next_stage_owner: `product owner/operator`
- expected_next_output: authoritative reconciliation of permanent erasure at 30 days and recoverability through 90 days, explicitly replacing or qualifying the conflicting statements.
- constraints: no implicit precedence, no inferred override or exception.
- required_validation: accepted rule no longer demands mutually exclusive outcomes for the same data and interval.
- evidence_return_to: `architecture-engineer`
- Readiness here means the owner can resolve the question; retention design/specification remains blocked by the absent reconciliation. No retention-ready handoff is issued.

## Completion and limits

The handoff was checked for source traceability, per-owner executable outputs, independent preview readiness, retention conflict containment, and absence of unsupported override/download/performance commitments. This is an author consistency check only. No code, experiment, security validation or runtime capability is evidenced. Preview specification and investigation framing can proceed now; retention-dependent work waits only for the identified product decision. This output adds no approval gate for those independent artifacts.
