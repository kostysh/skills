# Architecture: archive preview and retention

Document ID: ARCH-NOTE-B. Mode: design/authoring. Documentation only.

Preview specification is ready now. Retention architecture is blocked by incompatible accepted requirements. The local storage investigation is ready for a delivery-planner brief; storage selection remains pending actual experiment evidence. No runtime, benchmark, security validation, implementation, or production change has been performed.

## Authority and scope

Source locators below refer to the supplied `../input/task.md` headings and stable statement IDs. Governance is `../input/context.md`, “Project governance”; evidence limitations are its “Fixture environment”. These are stipulated facts, not inspected software. The product owner owns product decisions; accepted architecture grants bounded architecture choice and investigation authority. Equal-authority requirements have no date precedence.

The outcome for members is an own-workspace preview of the first 20 saved archive titles, preserving their saved sequence and spelling. This note enables a fresh specification agent to constrain that behavior; the note itself does not deliver preview or establish tenant safety. Source-authorized outputs are this architecture artifact and downstream handoffs. The direct path is the existing API and workspace-scoped archive repository. The narrowest behavioral falsifier is a member preview response that differs from their workspace's first 20 saved titles or includes a title read from another workspace.

Scope is component-level API/repository architecture. Tenant isolation has high security criticality; preview introduces no new boundary. Retention has high data-loss/recoverability risk. The offline investigation is bounded feasibility work, not a migration. Full-workspace download, new infrastructure, new persistence, override modes, implementation, deployment, external services and publication are excluded.

## ASR register

| ID / status | Authority, owner and derivation | Applicability and requirement | Necessity / removal falsifier | Forces, risk, confidence, validation |
| --- | --- | --- | --- | --- |
| ASR-B-P / accepted | `task.md`, Accepted product requirements, PRD-B1; source_statement; product owner; explicit | Members preview the first 20 saved titles of their own workspace, in saved order and spelling; no cross-workspace reads | Removing sequence or tenancy constraints permits the response to violate PRD-B1 | Ordered projection and tenant confinement; high isolation risk; high source confidence, runtime unverified; QS-B-P |
| ASR-B-E / accepted | `task.md`, Accepted architecture and investigation authority, ARCH-B1; accepted_non_product_authority; accepted architecture; explicit | Preview stays in existing API and workspace-scoped repository with existing ordered titles; no new infrastructure or persistence | Removing this constraint permits an unauthorized new persistence or service boundary | Existing-system fit and minimal surface; medium component risk; high stipulated confidence; PD-B-P and specification boundary check |
| ASR-B-R / blocked | `task.md`, PRD-B2 and PRD-B3; source_statement; product owner; explicit conflicting obligations | All archive data permanently erased after 30 days with no recoverable copy AND recoverable through 90 days | Between days 30 and 90 either permanent erasure defeats B3 or a recoverable copy defeats B2 | Irreversible deletion versus recovery; high risk; conflict certain; product reconciliation required before retention design or validation criteria |
| ASR-B-I / accepted for investigation only | `task.md`, ARCH-B2; accepted_non_product_authority; accepted architecture; explicit | Compare ordered-list and indexed representations on 10,000 synthetic titles, preserving partition and exact first-20 sequence; exploratory duration and memory | Without this bounded evidence, a storage commitment violates ARCH-B2's return-before-commit requirement | Evidence before storage choice; no performance threshold; experiment unexecuted; SPIKE-B-I |

Current-state evidence (`task.md`, “Current-state evidence”) says storage is workspace-partitioned and titles are saved in order. The existing `retentionOverride` belongs to an old internal maintenance script. It grants no member or administrator entitlement, prerequisite, retention exception or configuration mode. Its modification or removal is not authorized here.

## Decisions

### PD-B-P — Preserve existing preview boundary

Status: accepted within ARCH-B1 authority. Select direct ordered-title projection through the existing API and workspace-scoped repository. Preserve membership/own-workspace confinement from request through repository access and response; no cross-workspace fetch followed by filtering. This is a derived constraint of PRD-B1's prohibition on reads, not a new identity model.

No architecture alternative exercise is needed: ARCH-B1 already selects the sufficient existing boundary. No cache, worker, index, wrapper or persistence layer is needed for preview. Exact routes, schemas, classes and functions are `not_prescribed`. A future spec may refine ordinary behavior within this frame without reopening storage design.

Consequences: preview can proceed independently of retention or investigation; this makes no production performance claim. Confidence is high in source fit, with runtime conformance unverified. Preview has no migration or data rollback requirement because it adds no persistence change. Revisit if implementation cannot preserve ordering or tenancy on the existing boundary, or if accepted scope changes.

### DEC-B-R — Retention decision withheld

Status: blocked; human product decision required. PRD-B2 and PRD-B3 are incompatible at equal authority. Neither overrides the other. No soft-delete, backup tier, encryption trick, override mode, or alternative time rule is selected as a reconciliation. Blocking dependency is only retention policy and its downstream architecture/specification.

The product owner must supply a single accepted reconciled obligation or explicit precedence, including whether recoverable copies may exist after day 30. No specialist or vendor is available to replace that ownership. After reconciliation, architecture must derive deletion/recovery boundary scenarios from the accepted rule, assess irreversible effects and any migration/rollback limits, and route a ready retention spec. No retention compliance is claimed today.

### DEC-B-S — Storage selection pending

Status: proposed/unselected pending SPIKE-B-I evidence. Current ordered-list and indexed representations are investigation candidates, not selected production designs. Their runtime fit, resource costs and relative benefit remain unknown; numeric scores or a winner would fabricate evidence. Even a correct faster candidate does not automatically authorize production change. ARCH-B2 requires evidence return before commitment, and no performance target exists.

## QS-B-P — Preview sequence and tenant isolation

Source: member; stimulus: request own-workspace preview with distinguishable titles saved in different orders in two partitions. Environment: future production-equivalent existing API/repository boundary. Artifact: preview read path and member-visible response. Required response: exactly the first 20 saved titles for that workspace in original spelling and order, with no other-partition read or response content.

Verification obligation: exercise the real member/API/repository/response path with more than 20 ordered titles, spelling-sensitive and duplicate titles; cover fewer than 20 and empty saved lists in the specification. A forged other-workspace request must not cause that partition to be read or its titles disclosed. Exact rejection presentation remains for the specification within existing conventions. Compare response against the saved sequence and observe repository access scope; response-only filtering is insufficient proof of no reads. These are future checks, not executed evidence.

## SPIKE-B-I — Ordered-title feasibility

Question: do the current ordered-list and an indexed representation each return the exact first 20 saved titles for the stipulated 10,000-title dataset while preserving the existing tenant partition?

Scope: a small offline experiment in a disposable directory, with only synthetic data and local shell/filesystem access. Reproducibly generate 10,000 titles with known saved ordering and spelling; record the dataset definition and partition allocation. Include distinct other-partition sentinel titles so cross-partition leakage is detectable, documenting any sentinel data separately from the stipulated dataset. Both representations receive equivalent records and ordering. No network, production data, external service, infrastructure, or production modification.

Correctness criteria: exact expected first-20 sequence for the selected partition; no other-partition title or read. Record each representation's result and failure details. Preserve repeated/spelling-sensitive titles in the expected sequence. Capture duration and memory with units, measurement method, runtime/environment, command, and repetition details sufficient to interpret and reproduce them. Duration and memory are exploratory observations, never pass/fail thresholds. Dataset-limited success does not prove arbitrary-scale performance, production tenant enforcement, or download viability.

Eventual executor evidence contract: local experiment source and dataset generation/reproduction instructions; expected and actual sequences; isolation observations; terminal results and exit status; raw duration/memory measurements and measurement limitations; bounded comparison and recommendation. Return all to architecture-engineer before any storage selection. No experiment or measurements exist in the supplied inputs or this output.

## Architecture handoff register

### AHI-B-P

- kind: spec_candidate
- status: ready
- blockers: []
- next_stage_owner: spec-engineer
- linked_prd: PRD-B1, PRD-B4
- linked_asr: ASR-B-P, ASR-B-E
- linked_decision: PD-B-P
- expected_next_output: `specification.md`, containing preview behavior and verification map from the original inputs and this note.
- constraints: own-workspace member preview; exact saved first-20 sequence and spelling; existing API/repository; no cross-workspace reads; independent of retention and storage investigation; no download or override mode.
- acceptance_constraints / required_validation: QS-B-P, including saved-state-to-response sequence and actual read-scope checks; document unavailable runtime evidence honestly.
- not_prescribed: exact API route, schema, function/class names, UI arrangement and test framework.
- return path: architecture-engineer only if specification or implementation needs to change these boundaries or reveals an invariant failure.

### AHI-B-I

- kind: spike
- status: ready
- blockers: []
- next_stage_owner: delivery-planner
- linked_asr: ASR-B-I
- linked_decision: DEC-B-S
- expected_next_output: a bounded executable investigation brief based on SPIKE-B-I, naming the repository implementation agent as executor, correctness criteria, evidence contract and return route. The planner supplies a brief only, not measurements or experiment artifacts.
- constraints: offline disposable experiment; 10,000 synthetic titles; ordered-list versus indexed; preserve partition; exploratory memory/duration only; no production change.
- required_validation: executor must return SPIKE-B-I's artifact and measurement package before commitment.
- evidence_return_to: architecture-engineer
- not_prescribed: exact experimental file names, language, index implementation or measurement utility, provided the question and partition boundary are preserved and methods recorded.

The known repository implementation agent can implement and run that small offline experiment after receiving the planner's brief. This architecture author does not execute it. Evidence return enables architecture review, not automatic promotion to production.

### AHI-B-R

- kind: spec_candidate
- status: blocked
- blockers: unresolved PRD-B2 versus PRD-B3 product conflict; no reconciled retention architecture.
- next_stage_owner: spec-engineer
- linked_asr: ASR-B-R
- linked_decision: DEC-B-R
- expected_next_output: retention behavior specification only after product reconciliation and subsequent architecture constraints.
- constraints: do not select either deadline, invent exceptions, or use `retentionOverride` as requirement authority.
- required_validation: eventual deletion/recovery scenarios follow the reconciled policy; none can currently demonstrate both conflicting obligations.
- unblock owner and return path: product owner resolves conflict; architecture-engineer revisits DEC-B-R and supplies accepted constraints before this handoff becomes ready.

## Deferred scope and evidence limits

PRD-B4's full-workspace download remains under consideration. Need, maximum archive size and performance targets are unaccepted; there is no ready download handoff, fabricated target, or hidden download requirement in preview. Reopen only with product-owner accepted scope.

Completed verification is source-to-decision and handoff consistency inspection: preview has sufficient accepted authority; retention remains isolated and blocked; investigation routes planning separately from empirical execution; no current-state mechanism became a product entitlement. All system facts remain stipulated. No runtime, benchmark, security test, external contract check or independent review was executed. Artifact existence proves only the architecture handoff, not preview, erasure, recoverability, storage performance or tenant isolation in deployed software.
