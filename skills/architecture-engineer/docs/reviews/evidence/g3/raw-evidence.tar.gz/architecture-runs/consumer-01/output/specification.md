# Job status display label

## Scope and handoff

**Status: ready for the repository implementation agent.** No blocking product or architecture decision is missing. This artifact specifies one additive response mapping; implementation and executed acceptance remain outstanding.

Sources: [case-a.md](../input/case-a.md), accepted operator PRD-A A1–A4 and accepted ARCH-A; STATE-A describes the stipulated current contract. The inherited [architecture.md](../../a-01/output/architecture.md), ASR-001, ASR-002, D-001 and AHI-001, selects the mapping within ARCH-A's delegated authority. It does not authorize additional product scope. [Task](../input/task.md) names the downstream consumer; [context](../input/context.md) establishes English and this artifact location, with no further indexing convention.

Parent intent: an authenticated workspace member can read a job's saved label through the existing status operation while existing job identity, state and access behavior continue unchanged. The direct implementation contour is the existing API success-response assembly using the label already returned by the workspace-scoped repository. Risk is medium for the public contract delta; access isolation is a critical preserved invariant, covered by negative actual-response checks.

## Behavior

“Status operation” means the one existing public read-status operation, receiving an opaque job identifier and current authentication context. “Authorized member” means an authenticated member of the job's workspace under the existing operation. “Saved label” is the optional string already supplied by that operation's repository; an empty string is a saved value. “Legacy absence” means no saved label exists.

For an existing job visible to the authorized member, reading status changes the successful JSON object from `{id, state}` to `{id, state, displayLabel}`. The added value is the saved string verbatim, or JSON null for legacy absence. This is an immediate response projection with no persistent effect or repair prerequisite. No new state enumeration is defined.

## Requirements

All rows are explicit obligations from the cited accepted statements; D-001 supplies the inherited placement decision. Each necessity also identifies the accepted obligation that removal would permit to fail.

| ID | Atomic requirement and applicability | Authority; necessity/removal falsifier | Acceptance |
| --- | --- | --- | --- |
| SPEC-R1 | On every authorized successful status read, the API MUST include `displayLabel`. | A1; omitting it loses the accepted response extension. | AC1 |
| SPEC-R2 | When a saved label exists, the API MUST return that string unchanged as `displayLabel`, including an empty string. | A1; transformation or empty-to-null conversion loses the saved value. | AC1 |
| SPEC-R3 | When no saved label exists, the API MUST return JSON null as `displayLabel`. | A1; omission or another value violates legacy representation. | AC1 |
| INV1 | For successful status reads, the API MUST retain the existing `id` value. | A2; an identity change violates compatibility. | AC2 |
| INV2 | For successful status reads, the API MUST retain the existing opaque `state` value. | A2; a state change violates compatibility. | AC2 |
| INV3 | The status operation MUST preserve its existing authentication, missing-job, foreign-workspace and malformed-identifier error responses byte-for-byte. | A2 and STATE-A; any changed error violates the expressly preserved contract. | AC3 |
| INV4 | The status operation MUST NOT return job data to an unauthenticated caller or a member of another workspace. | A3; either disclosure violates access isolation. | AC3 |
| SPEC-R4 | For legacy jobs, the extension MUST work without migration or user action. | A2; requiring repair excludes accepted legacy behavior. | AC1, AC4 |
| SPEC-R5 | The API service MUST assemble the extension on its existing success path using the existing workspace-scoped repository. | ARCH-A and D-001; bypassing that ownership violates the accepted architecture boundary. | AC4 |

## Edge cases and preserved boundary

Illustrative saved-value examples: `"Job title"` returns `"Job title"`; `"  Job title  "` returns the same whitespace; `""` returns `""`; absence returns `null`, with the property present in every successful case. These examples do not introduce new allowed-state or identifier rules.

Authentication, identifier validity, missing-job handling and workspace visibility continue to be decided by the existing operation before its success mapping. Its concrete route, error status/body bytes, state vocabulary and code layout remain owned by the existing contract; discover them in the repository, rather than replacing them with values from this specification. Existing clients are stipulated to tolerate additive properties. No concurrency, retry, write, latency or throughput behavior changes are specified.

## Acceptance and verification map

The repository implementation agent owns all future checks below, corresponding to inherited V-001–V-003. No check has been executed here.

- **AC1 (SPEC-R1–SPEC-R4; V-001):** Exercise the actual public operation as an authorized member against jobs with non-empty text, whitespace-bearing text, empty text, and legacy absence. Observe `displayLabel` present with exactly the corresponding saved string or JSON null. Legacy success requires no migration or user repair. Falsifiers include property omission, altered text, and empty string becoming null.
- **AC2 (INV1–INV2; V-001):** In those successful responses, compare `id` and `state` with their existing expected values. Either value changing is failure.
- **AC3 (INV3–INV4; V-002):** Exercise unauthenticated, foreign-workspace, missing-job and malformed-identifier requests. Compare the operation's pre-change error status/body bytes with post-change responses and check that unauthorized callers receive no job data. Any error-byte difference or disclosure fails acceptance. Capture concrete baseline expectations from the existing operation before changing it; do not invent them.
- **AC4 (SPEC-R4–SPEC-R5; V-003):** Inspect the change to confirm the existing repository/access boundary and API success assembly remain in use and that no storage, migration or additional-package change was introduced. Inspection supports, but cannot replace, AC1–AC3.

Shortest observation path: existing saved job (string/empty/absent) → existing workspace-scoped repository read (authorized/foreign/unauthenticated context governed by the operation) → API response projection → public JSON observed by the caller. The repository owns read visibility; the API owns projection. AC1–AC3 falsify value corruption or access/error regressions along this path. Label production, normalization and persistence writes are outside the delta; no write-round-trip or new test infrastructure is required. Mapper-only, mock-only or schema-only success does not satisfy A4's actual-response acceptance.

## Anti-claims and gaps

Only the specification was authored. No software, runtime test, deployment, publication or independent review is claimed. The slice introduces no endpoint, role, job state, write, logging obligation, asynchronous process, deployment unit or label normalization. No new architecture decision, ADR, approval gate or implementation harness is required.

No blocking input gap was identified. Repository paths, concrete error baselines and existing verification commands are discovery items for the implementation agent, not missing product decisions. Runtime access and response captures are outstanding validation evidence. If repository evidence contradicts STATE-A or requires a new boundary, route that specific discrepancy to the architecture owner; route changed product behavior to the operator. Specification readiness is not product acceptance or release readiness.
