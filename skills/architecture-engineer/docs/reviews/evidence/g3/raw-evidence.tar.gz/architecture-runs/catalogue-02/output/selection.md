1. **architecture-engineer** — The request concerns architectural boundaries, storage trade-offs, spike decisions, and routing architectural constraints from accepted product scope.
2. **spec-engineer** — The request turns accepted behavior and architecture into atomic, falsifiable software requirements for a specific extension.
3. **delivery-planner** — The request decomposes accepted specifications and architecture into executable tasks, dependencies, and verification evidence.
4. **none** — Correcting a static caption without behavioral or boundary changes does not require any of the catalogued architecture, specification, delivery-planning, or product-requirements skills.
