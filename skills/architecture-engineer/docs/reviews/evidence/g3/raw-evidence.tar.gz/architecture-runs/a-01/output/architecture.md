# AD-001: Job status display label response extension

Status: architecture decision selected; handoff ready. Scope: component-level API public response change. Risk: medium because the public contract changes and existing access/error behavior must remain intact. A bounded architecture delta is sufficient; no new topology or significant pattern choice requires an ADR or spike.

## Sources and claim boundary

- S-01: [task.md, PRD-A A1–A4](../input/task.md#accepted-product-requirements-operator-prd-a), accepted operator requirements: label/null response, compatibility, access invariants, and actual-response acceptance.
- S-02: [task.md, ARCH-A](../input/task.md#accepted-architecture-arch-a), accepted API service ownership and existing workspace-scoped repository boundary; expressly authorizes this mapping decision without renewed product approval.
- S-03: [task.md, STATE-A](../input/task.md#current-state-contract-state-a), stipulated current design: `{id, state}` success, optional label already available, opaque states and existing error responses.
- S-04: [context.md, Project governance](../input/context.md#project-governance), architecture artifact authority and output convention.

All system facts above are supplied scenario facts, not executed evidence. This design enables an authenticated workspace member to see a saved job label through the existing public status read. This artifact is handoff substrate: neither its completion nor a later specification proves that any actual response behaves correctly. Only this architecture artifact is authored; implementation, services, deployment and publication are outside authority.

## Architecture-shaping requirements

| ID | Requirement, authority and necessity | Forces and validation |
| --- | --- | --- |
| ASR-001 | Explicit source statement, operator S-01/A1–A2: existing authorized successful reads add the saved label verbatim, including empty string; absence produces JSON null without migration or user action. Applies to existing and legacy jobs. Removing this requirement loses the accepted visible label or legacy compatibility. | Additive public projection; retain optional storage representation. Medium risk; high design confidence from supplied facts. Verify V-001. |
| ASR-002 | Explicit source statement, operator S-01/A2–A3: retain `id`, opaque `state`, existing errors and no-data access outcomes. Applies to authorized, foreign-workspace, unauthenticated, missing-job and malformed-identifier paths. Removing it permits a compatibility or access regression. S-02 also explicitly requires API assembly through the existing workspace-scoped repository, owned by accepted architecture authority. | Existing ownership and tenant boundary; no alternate lookup path. Medium change risk with access-critical invariants. Verify V-002. |

These requirements derive no additional product modes, actor prerequisites or storage obligations. No latency or throughput target has been accepted (S-03); targets remain unspecified and do not block the bounded mapping decision.

## D-001: Selected response mapping

Within the existing API service success-response assembly, add `displayLabel` using the label already returned by the existing authorized workspace-scoped repository. Emit the saved string unchanged; when no saved label exists, emit explicit JSON null. In particular, an empty string remains an empty string. Leave existing `id` and `state` values intact.

The existing operation continues to determine authentication, identifier validity, workspace visibility and missing-job outcomes. Apply the extension only on its successful response path. Preserve its error responses byte-for-byte; do not select or restate concrete status codes, error bodies or state enumerations, which this slice intentionally leaves with the existing operation.

This directly satisfies ASR-001 and ASR-002 under S-02's delegated decision authority. The saved optional value is already available (S-03), so repository, persistence, migration, data-write and job-lifecycle changes are unnecessary. No new endpoint, role, asynchronous process, deployment unit, normalization, logging or instrumentation obligation is introduced (S-01/A3). Labels are stipulated ordinary user-visible strings (S-03).

Alternatives exercise: unnecessary; the existing response assembly is sufficient. Additional layers or a new read mechanism have no accepted requirement and would enlarge the change without solving a current gap. Exact functions, files, language constructs and validation tooling are `not_prescribed`.

Consequence: the successful public JSON contract gains one property, tolerated by existing clients per S-01/A2. The change has no persistent side effect. Code reversal is locally simple, but removing the property would cease satisfying A1 and must not be described as accepted product behavior. No migration or data rollback procedure is required. Confidence is high for this architecture selection based on the stipulated inputs; runtime correctness is unverified.

## Validation obligations

- V-001 (A1, A2, A4; ASR-001): exercise the actual public operation as an authenticated member of the owning workspace for saved non-empty text, saved empty string, and a legacy job without a saved label. Observe the successful JSON response: `displayLabel` equals the saved value verbatim or is present with JSON null for absence, with original `id` and `state` values retained. Include a label with whitespace to detect unintended normalization. No migration or user repair step may be needed. The narrow falsifier is any actual response that omits the property, converts empty string to null, changes text, or changes `id`/`state`.
- V-002 (A2, A3, A4; ASR-002): exercise unauthenticated, foreign-workspace, missing-job and malformed-identifier paths through the existing operation. Compare existing status/body bytes against the unchanged baseline and verify that unauthorized responses contain no job data. Obtain concrete baselines from the operation when implementation access is available; do not invent them in the specification.
- V-003 (S-02, S-03): inspect the eventual change to confirm the existing repository/access boundary and success assembly are retained and no storage or additional-package change was introduced. Static inspection supplements V-001/V-002; it cannot replace actual-response evidence.

The applicable observation path is existing saved job → authorized workspace repository read → API success assembly → public JSON. This slice does not modify label creation, persistence or normalization; it requires no new write-flow test infrastructure. Mapper-only tests or schema checks cannot close A4. No checks against software were executed here because no runtime was supplied or authorized.

## Architecture handoff

- `id`: AHI-001
- `kind`: spec_candidate
- `status`: ready
- `blockers`: []
- `linked_prd`: S-01/A1–A4
- `linked_asr`: ASR-001, ASR-002
- `linked_decision`: D-001
- `next_stage_owner`: spec-engineer
- `expected_next_output`: `specification.md`, an implementation-ready specification and verification map for this single existing status operation.
- `architectural_intent`: extend its successful response locally while preserving the API/repository boundary and compatibility/access invariants.
- `constraints`: D-001, including explicit null for absence, exact saved text, unchanged opaque fields, existing error bytes, and no expanded runtime scope.
- `acceptance_constraints`: actual-response evidence required by S-01/A4; spec completion is not product acceptance.
- `required_validation`: carry V-001–V-003 into the verification map, clearly marking future executed evidence as outstanding.
- `not_prescribed`: code layout, mapper syntax, existing operation path, concrete error values, opaque state enumeration, and test tooling.

No missing product or architecture decision blocks the specification. Runtime access and baseline captures are implementation-validation gaps, not reasons to reopen the authorized mapping decision. Return to architecture-engineer only if implementation evidence contradicts S-03 or fulfilling the requirement would require a new boundary; route any changed product semantics to the operator. Otherwise retain D-001 without additional architecture ceremony.

## Artifact verification

Performed a source-to-decision and handoff review against S-01–S-04: scope stays within response mapping, every accepted requirement has a constraint or validation obligation, and no additional authority gate was introduced. No runtime, integration, deployment or independent review result is claimed.
