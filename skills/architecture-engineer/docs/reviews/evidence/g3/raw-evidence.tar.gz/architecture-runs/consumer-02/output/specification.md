# Job status display label

## Scope and handoff

**Status: ready for repository implementation agent.** No blocking input gap. This is a design-only handoff, not authorization to implement or evidence of runtime acceptance.

Scope is the existing public read-status operation's successful response mapping in the API service. Parent intent: let an authenticated workspace member obtain the saved job label while preserving existing status and access behavior. The simplest contour is the producer's direct mapping of the already-authorized repository result; no new component is needed.

Sources:
- [Original accepted product PRD-A/A1–A4 and architecture ARCH-A](../../a-02/input/task.md) own behavior and service/repository boundaries. [Assigned case](../input/case-a.md) supplies the same statements.
- STATE-A in those inputs supplies stipulated existing behavior, not executed evidence. Concrete error responses and opaque state values remain owned by the existing operation.
- [Producer architecture](../../a-02/output/architecture.md), ASR-001, ASR-002, D-001 and AHI-001: inherited, ready architecture input. ARCH-A explicitly authorizes its bounded mapping decision; this artifact does not independently authorize product expansion.
- [Task](../input/task.md) and [governance](../input/context.md) authorize this specification and its path. No additional naming or indexing convention applies.

Risk is medium for additive public-contract compatibility; an access regression would have serious consequences, so explicit denial invariants and actual-operation negative checks accompany the small mapping change. This is neither a new authorization design nor multi-package/provider work; a full high-risk backend matrix is not triggered.

## Behavior

A **saved label** is the optional string already available on the authorized repository result. An **authorized member** is an authenticated member of the job's workspace, as determined by existing operation behavior. A **legacy job** has no saved label. `id` and `state` are opaque existing response values.

Given an existing job, when an authorized member reads its status through the existing operation, the API returns the existing `id` and `state` plus `displayLabel`: exactly the saved string, or JSON null when absent. The operation remains read-only and usable for legacy jobs without preparatory action.

Inherited architecture: API-owned assembly continues to use the existing workspace-scoped repository. D-001 applies only after the operation has produced an authorized successful result.

## Requirements

All rows are explicit derivations within the stated applicability. PRD-A is operator-owned; ARCH-A owns the accepted boundary. The last column states why removal would violate that authority, rather than relying on the producer's readiness label.

| ID | Applicability and atomic obligation | Authority | Necessity / removal falsifier |
| --- | --- | --- | --- |
| SPEC-R1 | Every successful status response MUST contain the additional `displayLabel` property. | A1; D-001 | Property omission loses the accepted response extension. |
| SPEC-R2 | For a saved string, the API MUST return that exact string as `displayLabel`, including empty string and whitespace. | A1; D-001 | Normalization or truthiness fallback changes the saved label. |
| SPEC-R3 | For no saved label, the API MUST return JSON null as `displayLabel`. | A1; D-001 | Omission, an empty string, or a manufactured default violates legacy null behavior. |
| SPEC-R4 | On success, the API MUST preserve the existing `id` value. | A2 | An altered identifier violates existing-value preservation. |
| SPEC-R5 | On success, the API MUST preserve the existing opaque `state` value. | A2 | Remapped states violate existing-value preservation. |
| SPEC-R6 | The extension MUST work for legacy jobs without migration. | A2 | A backfill prerequisite prevents migration-free use. |
| SPEC-R7 | The extension MUST work for legacy jobs without user action. | A2 | A repair or label-edit prerequisite violates immediate legacy support. |
| INV1 | For foreign-workspace and unauthenticated callers, the operation MUST NOT disclose job data, including the added label. | A3 | Disclosure breaks the accepted access invariant. |
| INV2 | All existing error responses MUST remain byte-for-byte unchanged, including authentication, missing-job, foreign-workspace, and malformed-identifier paths. | A2 preservation; STATE-A identifies the existing contract; D-001 | Rewriting an error changes the preserved operation contract. |
| INV3 | Status response assembly MUST remain API-owned using the existing workspace-scoped job repository. | ARCH-A; D-001 | Moving assembly or bypassing scoped retrieval violates accepted architecture. |
| INV4 | The extension MUST NOT introduce a data write. | A3; D-001 | Saving defaults or labels expands the accepted read-only change. |

## Edge cases

Illustrative success projection, retaining the operation's actual opaque `id` and `state`:

| Existing saved label | New `displayLabel` |
| --- | --- |
| `" Example "` | `" Example "` |
| `""` | `""` |
| Absent | `null` |

Do not use truthiness to equate empty with absent. Existing errors are deliberately not assigned new HTTP codes, body schemas, identifier-validation rules, or precedence here. New latency, throughput, retry, concurrency, persistence, or normalization guarantees are not introduced.

## Acceptance and verification

The repository implementation agent owns execution and evidence. Use existing operation-boundary facilities; obtain the existing response baseline before changing its mapping. Source-file names and test commands are repository discovery details, not missing product decisions.

| ID | Required observation / narrow falsifier | Requirements |
| --- | --- | --- |
| AC1 | Exercise the actual public status operation as an authorized member for saved non-empty (including whitespace), empty, and absent labels. Inspect JSON for the property and exact values above. Missing property, trimming, or empty-to-null conversion fails. Compare returned `id` and `state` with existing behavior for these jobs. | R1–R5 |
| AC2 | Exercise the existing legacy job's status without migration or user repair. Needing either before it returns explicit null fails. Inspect the bounded change for absence of new write/migration paths. | R3, R6, R7, INV4 |
| AC3 | Exercise foreign-workspace and unauthenticated requests against the same operation. Any job data disclosure fails; compare their existing error responses byte-for-byte against baseline. | INV1, INV2 |
| AC4 | Exercise missing-job and malformed-identifier paths; compare errors byte-for-byte against baseline. Inspect the change to confirm other existing errors remain untouched. | INV2 |
| AC5 | Inspect the change for API-only success mapping through the existing scoped repository, with no new writes. Boundary bypass or added writes fails. | INV3, INV4 |

These checks derive from A1–A4 and producer V-001–V-003. Actual status-response observation is necessary for A4: mapper tests, mocked repository results, schemas, or this document alone cannot close acceptance.

Applicable value path is the existing scoped repository result -> API public projection -> caller's JSON response. The API service owns the changed projection; label presence/empty/whitespace and caller workspace/authentication are the varying dimensions. Changed or leaked values are falsifiers. Label production, normalization, persistence changes and a write/reload lifecycle are outside this single response-mapping claim; no new upstream round trip or harness is required.

## Anti-claims and gaps

No new role, endpoint, job state, storage change, package, logging obligation, asynchronous process, deployment unit, or operational target is specified. No implementation, runtime test, deployment, or publication was performed. Acceptance checks above remain unexecuted because the task permits document authoring only.

Assumptions are the stipulated STATE-A facts, including optional-label availability and tolerant existing clients. Concrete error/state values must be read from the existing operation during implementation, not invented here. They are deliberately preserved external-to-slice behavior, not a blocking specification gap.

No architecture delta or new approval is needed for D-001. If repository inspection contradicts label availability or shows that this requires storage or access-boundary changes, return that concrete discrepancy to the architecture owner before expanding this slice; changed product semantics belong to the operator.
