# Request: job status display labels
Prepare the architecture change for the accepted status response extension and save a handoff for our specification agent.

## Accepted product requirements (operator, PRD-A)
A1: An authenticated workspace member reading an existing job's status shall receive an additional `displayLabel` property in the successful public response. Its value is the job's saved label, including an empty string when that is saved. A legacy job with no saved label returns JSON null. No label normalization is requested.
A2: Existing `id` and `state` values and error responses must retain their current semantics. The extension must work for legacy jobs without a data migration or user action. Existing clients tolerate added response properties.
A3: A member of another workspace and an unauthenticated caller must continue to receive no job data through this operation. No new access role, endpoint, job state, data write, logging obligation, asynchronous process or deployment unit is requested.
A4: Acceptance is an actual status response showing the right label/null for an authorized caller while existing state and access behavior remain correct. Architecture and spec completion do not exercise this response.

## Accepted architecture (ARCH-A)
The API service owns status response assembly and uses the existing workspace-scoped job repository. Preserve this boundary. The operator authorizes the architecture agent to select the bounded public-response mapping change required by PRD-A now. A fresh product approval is not required for this mapping.

## Current-state contract (STATE-A)
There is one public read-status operation. It receives an opaque job identifier and the current authentication context, and returns a JSON object `{id, state}` on success. The repository returns the authorized workspace's job with its optional saved label already available. Existing authentication, missing-job, foreign-workspace, and malformed-identifier responses are governed by the existing operation and must be preserved byte-for-byte; their concrete status/body values are intentionally not changed or respecified by this slice. State values are also opaque and preserved. This is response mapping in the API service; no other package or storage change is needed. Labels are ordinary user-visible strings, not secrets. No new latency or throughput target has been accepted.
