## architecture-engineer
Design or revise architecture for AI-agent-driven development. Use when product scope, features, integrations, data, security, deployment, or findings require architectural requirements, boundaries, patterns, trade-offs, quality scenarios, spikes, ADRs, or handoff—not implementation backlogs.

## spec-engineer
Create concise, falsifiable software specs for AI coding agents. Use to turn ideas, tickets, APIs, domain rules, migrations, workflows, or function behavior into implementation-ready Markdown with observable requirements, acceptance evidence, anti-claims, source authority, and handoff readiness.

## delivery-planner
Turn accepted product scope and architecture handoff into right-sized executable work for AI agents. Use for project, feature, module, service, or integration planning, sequencing, risk-aware breakdown, and routing gaps to owning skills. Produce one Delivery Plan, not rigid workflow registers.

## prd-engineer
Create, refine, and review PRDs, product specs, feature and AI requirements. Turn ideas into testable scope, non-goals, acceptance, rollout, and metrics; establish source authority and handoff readiness; address AI evaluation; or audit ambiguity, missing evidence, weak acceptance, and scope risk.
