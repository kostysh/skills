For each request below select the primary skill from catalog.md, or none, and give a one-sentence reason. Read only this file and catalog.md. Do not open any skill body, references, task fixtures, or other files. Do not execute the requests.
1. We have accepted product scope for an archive preview, but need to settle API/repository boundaries and decide whether an uncertain storage strategy needs a spike. Prepare the architecture and route its constraints.
2. The architecture and product behavior are already accepted. Write atomic behavioral requirements and falsifiers for one status-response extension.
3. Accepted specifications and architecture are ready. Break the work into executable tasks with dependencies and verification evidence.
4. Change a misspelled static button caption from “Preveiw” to “Preview”; behavior and component boundaries stay unchanged.
