# Request: archive retention and preview architecture
Prepare the architecture decisions and downstream handoffs for the accepted archive-preview change. Record what our next agents can do with the inputs available today.

## Accepted product requirements
PRD-B1 (product owner): Members can preview the first 20 saved archive titles for their own workspace; preserve title order and spelling. No cross-workspace reads. The preview is independent of retention changes and must be specified now.
PRD-B2 (product owner): All archive data must be permanently erased 30 days after creation, with no recoverable copy.
PRD-B3 (product owner, same authority as B2): Archive data must remain recoverable for 90 days after creation. No precedence or reconciliation has been accepted between B2 and B3.
PRD-B4 (product owner): A full-workspace archive download is under consideration. Its performance target, maximum archive size, and whether users need a download at all have not been accepted. Do not add download capability to the preview slice.

## Accepted architecture and investigation authority
ARCH-B1: Existing API and workspace-scoped archive repository remain the preview boundary. Saved records already expose title order and titles. This preview needs no new infrastructure or persistence.
ARCH-B2: Choosing the archive storage layout for future large archives needs evidence about ordered-title reads. The architecture agent is authorized to define a bounded local feasibility investigation comparing the current ordered-list representation with an indexed representation for 10,000 stipulated synthetic titles; this does not authorize a production change. The investigation question is whether either representation returns the first 20 titles in exact order for this dataset with its existing tenant partition preserved. Record duration and memory as exploratory measurements, not pass thresholds. Required correctness is exact title sequence and no other partition's titles. Return experiment artifacts and measurements before committing to a storage change. No performance threshold is accepted.

## Available downstream roles
A fresh spec-engineer can write preview behavior specifications from accepted architecture constraints. A delivery-planner is available to frame bounded executable investigation work. A repository implementation agent with local shell and filesystem tools can implement and run a small offline experiment in a disposable directory after receiving that brief; it cannot access production or an external service. No experiment has been run or supplied here. There is no retention-policy specialist or external archive vendor contract available.

## Current-state evidence
The archive repository is partitioned by workspace. Saved titles are held in their saved order. Current storage has a `retentionOverride` field used by an old internal maintenance script; no accepted requirement grants members or administrators an override mode. No runtime, benchmark or security validation evidence is supplied.
