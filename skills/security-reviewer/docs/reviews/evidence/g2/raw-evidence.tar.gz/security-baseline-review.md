# Независимая baseline-ревизия security-reviewer

**FAIL — установлены 3 P2; исправления пока не выполнялись.** Assurance: independent; mode: baseline. Это source-grounded оценка контракта, а не результат эмпирического baseline-прогона.

## Основание и снимок

Потребитель — координатор принятой группы 2 и автор исправления security-reviewer. Ожидаемая capability — ограниченный, воспроизводимый security-вывод с подтверждённым attack path, честной неполнотой и применимым handoff. Компиляция, regex-тесты и наличие reference — substrate; они не доказывают безопасность приложения, реальные внешние интеграции, независимую приёмку будущего candidate или выбор скила по каталогу.

Исходный HEAD, предоставленный координатором: `5982f982ba8b4d30a6a1f6c1e10fe50402d100d8`. Source-version `0.1.12`. Снимок: `/tmp/skills-revision-g2-20260907-qfdkj6eo/baseline/security-reviewer`; 36 файлов, все сверены с `baseline-source-manifests.json` → `files.security-reviewer`, SHA-256 каждого файла совпадает. Все 36 файлов рабочего skill-folder совпадают с baseline после инспекции. Дополнительный aggregate SHA-256 от конкатенации отсортированных относительных POSIX paths в формате `path:sha256\n`: `a635ff21f2930e842fa4cf25ecd8068d07f1afb61cba393e447230dbecb69671`.

Применены root/target AGENTS, docs/skill-standard.md, принятый docs/plans/implementation-plan-20260907-2.md, skill-reviewer с methodology и forward-testing, implementation-discipline 0.2.7. Frozen Astra guide прочитан как advisory, не как источник новых обязательных критериев. Source-of-truth: skill.yaml, fragments, references и объявленные copies; generated: SKILL.md, compile-report. История не заменяет действующий контракт.

## F1 — P2: специальные чеклисты противоречат порогу подтверждённой уязвимости

**Основание: conflicting, прямой текст; последствия выведены, не наблюдались в trial.** `references/supabase-rls.md:78–85` помещает «tests do not cover capture failure» в `Flag when`. Между тем `references/methodology.md:24` прямо запрещает FAIL из-за отсутствия evidence, а Review Standard требует attacker control, reachability, mitigation и impact. Отсутствующий тест не доказывает отсутствующий runtime control. Аналогично `references/secrets-config.md:38` требует `Always flag` credentials/cookies, восстанавливаемые JavaScript **или browser profile**, тогда как исходная модель не включает привилегированный доступ к устройству и общая методика запрещает выдумывать actor. `fragments/overview.md:74` усиливает это до `never accept browser storage ... cookies` без области хранилища. Здесь нет явного правила, что специализированные `Flag` являются только кандидатами и всегда подчинены общей методике.

Путь отказа: формальный аудит реализации с доказанным корректным fail-closed capture, но без конкретного negative test → исполнение буквального специального правила → подтверждённая security finding вместо ограничения evidence/передачи вопроса качества тестов. Второй контрольный случай — защищённая cookie-сессия с заданной моделью внешнего атакующего и без подтверждённого пути чтения cookie: browser-profile clause сама по себе не даёт такой путь. Не утверждается, что хранение credentials универсально безопасно.

**P1 screen:** показанный результат — ошибочная классификация/необоснованный отказ внутри ограниченного review, а не разрешение атаки, ложное доказательство безопасности, самостоятельная мутация или передача полномочий. Общий non-negotiable gate остаётся защитой; поэтому P2 как материальная конфликтность evidence-контракта, без утверждения систематического false FAIL.

Минимальная коррекция: один canonical confidence/status owner; специальные списки — кандидаты/вопросы до подтверждения полного пути. Разделить недостаток тестового evidence и эксплуатируемый дефект. Для credential storage назвать фактический storage/actor/exposure и подтверждённое нарушение, сохранив строгую оценку настоящих утечек. Проверить аналогичные `Flag` в GitHub Actions, Supabase и policy-governance, не расширяя предмет скила.

Falsifiers: достаточный корректный fail-closed случай без одного теста не превращается в vulnerability; реальный silent failure capture с достижимой защищённой операцией становится finding; protected-cookie случай не требует выдуманного local actor, а доказанная утечка session material остаётся finding. Существующий docs-test намеренно закрепляет `Always flag`; обновить его вместе с owning source, не считать regex доказательством безопасности.

## F2 — P2: расширение re-audit срабатывает на саму разрешённую коррекцию

**Основание: direct/conflicting.** `references/methodology.md:28–30`, `skill.yaml:168–171,224–226` одновременно ограничивают re-audit принятыми findings/delta и требуют fresh formal/targeted review при изменении `public behavior` без оговорки об ожидаемом изменении, которым устраняют finding.

Путь отказа: исправление auth bypass меняет публичное поведение unauthorized запроса с успеха на отказ; scope, threat model и blast radius фиксированы → буквальная проверка public-behavior condition требует fresh review вместо проверки исходной атаки и смежной регрессии. Это лишняя работа/ограничение приёмки уже разрешённой коррекции.

**P1 screen:** путь ведёт к чрезмерному review/задержке, а не к false closure или опасной операции; P2. Не утверждается, что всякое widening запрещено.

Минимальная коррекция: ожидаемая коррекция поведения в пределах принятых findings не является отдельным widening trigger; widening требуется при выходе за accepted remediation boundary, новом security contract/threat model, unrelated overlap или небounded blast radius. Один owner правила; root только кратко ссылается на него.

Falsifiers: точечное исправление ранее подтверждённой атаки остаётся re-audit с original-path/adjacent evidence; одновременно изменённый независимый permission model действительно требует нового scope. Проверять неизменённые cleared surfaces как исключённые, не как повторно доказанные.

## F3 — P2: stack discovery превращает существование второго стека в обязательное расширение scope

**Основание: direct/conflicting.** `references/methodology.md:64`: «If both frontend and backend exist, inspect both before claiming the review is complete». `references/domain-handoffs.md:19` ещё шире: «inspect both sides before finalizing a security conclusion». Здесь отсутствует привязка к нужному attack path и заданному report scope. Следующая Audit Order секция разрешает узкий пользовательский scope, но это исключение не установлено для предыдущего Surface Discovery и handoff.

Путь отказа: оператор задаёт complete bounded backend/RPC review с полными handler/direct-data evidence; в монорепозитории также есть независимый frontend → исполнение обеих безусловных строк требует чтения frontend либо INCOMPLETE для достаточного узкого review. Наличие второго стека само по себе не делает его необходимым security evidence.

**P1 screen:** доказанная проблема — лишний scope/необоснованная неполнота; не false PASS, не небезопасная мутация. P2.

Минимальная коррекция: обе стороны обязательны, когда они участвуют в проверяемом trust/attack path или входят в согласованный scope; отдельно поддержать независимо доказанные выводы при недоступном domain fact. `domain-handoffs.md:3,89` стоит согласовать с этим: передаётся зависимый факт, а не останавливается весь review. Неполный источник не должен подменяться названием отсутствующего эксперта.

Falsifiers: complete backend-only scope завершается без чтения unrelated frontend; реальный frontend→backend credential/authorization path требует обеих сторон; отсутствующий framework fact удерживает только зависимый вывод в needs verification, а независимо подтверждённая находка сохраняется.

## Проверки, interop и пределы

Прочитаны manifest, полный overview/generated root, все 9 active references, UI metadata, package.json, docs-contract tests и их fixture, compile-report и docs navigation. Assets отсутствуют по manifest; искусственный runtime не требуется. Reference paths существуют; source/generated содержательно согласованы в обнаруженных правилах. Полный compiler drift check не выполнялся: сохранённый compile-report не считается новой проверкой генерации.

Interop ownership подтверждён прямыми контрактами: code-reviewer принимает security findings/residual risk и владеет merge recommendation; spec-conformance-reviewer владеет requirement/control coverage и потребляет sourced security facts. security-reviewer оставляет exploitability у себя, передаёт framework facts соответствующему domain owner. Это inspection owner-producibility, а не наблюдённый producer→consumer run. Scan orchestrators условны «when available»; их отсутствие не признано дефектом. Доменные текущие API-факты и реальная безопасность Supabase/GitHub/webhooks этим review не сертифицированы.

Тестовый файл предварительно проверен: читает локальные файлы и делает assertions, fixture не исполняется. Запущен объявленный `pnpm --filter @kostysh/security-reviewer test`; launcher завершился code 1 с `[ERROR] unable to open database file` до TAP/test execution. Это **unavailable test evidence**, не падение assertions и не подтверждённый defect skill. Установка, Git/network mutation, compiler writes и повтор без гипотезы не выполнялись. Сам snapshot не изменён.

Blind baseline/candidate trials и catalog selection не запускались; не заявляется эмпирическая частота отказов, улучшение, скорость или tokens. Выше приведены source-grounded failure paths и предлагаемые falsifiers для фиксации независимых критериев до edits. Supporting исторические PASS не переиспользованы как текущий behavioral PASS.

Следующий владелец — автор security-reviewer: зафиксировать случаи/критерии, минимально согласовать source, регенерировать, выполнить owning checks в доступной среде и передать новый стабильный snapshot независимому re-audit. Группа 3, publication и изменения соседних skills не разрешены этим отчётом.
