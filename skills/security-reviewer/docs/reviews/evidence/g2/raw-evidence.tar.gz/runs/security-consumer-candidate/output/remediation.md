# Remediation

The supplied S1 contract authorizes the repair: both callable read functions must compare the account tenant with the authenticated principal tenant before returning the confidential balance. The review identifies the matching missing check in `read_balance`; direct inspection of the supplied implementation confirms it. No missing fact prevents preparing this change.

The smallest change adds the existing checked function's guard to `read_balance`, preserving lookup and missing-identifier behavior:

```diff
--- a/ledger.py
+++ b/ledger.py
@@ -17,6 +17,8 @@
 
 def read_balance(principal, account_id, store):
     account = store.load_by_id(account_id)
+    if account.tenant != principal.tenant:
+        raise PermissionError("Forbidden")
     return account.balance
 
 def read_balance_checked(principal, account_id, store):
```

## Executable checks

Run these two independent commands from the directory containing the repaired `ledger.py`. They load that file without bytecode writes. They have not been executed here; the fixture remains unchanged.

1. Verify tenant isolation through **both** public read paths, in both tenant directions. A returned value of any kind fails the check; only `PermissionError` passes. This fails on the original vulnerable `read_balance`.

```bash
python -B - <<'PY_CHECK'
import runpy
m = runpy.run_path("ledger.py")
store = m["Store"]({
    "a": m["Account"]("A", 100),
    "b": m["Account"]("B", 900),
})
for name in ("read_balance", "read_balance_checked"):
    for tenant, foreign_id in (("A", "b"), ("B", "a")):
        try:
            value = m[name](m["Principal"](tenant), foreign_id, store)
        except PermissionError:
            pass
        else:
            raise AssertionError(f"{name} returned a value for a foreign account")
print("PASS: both read paths deny cross-tenant access")
PY_CHECK
```

2. Verify both functions still return exact balances to their owning tenants and preserve `KeyError` for absent accounts. This also rejects an unconditional-denial repair.

```bash
python -B - <<'PY_CHECK'
import runpy
m = runpy.run_path("ledger.py")
store = m["Store"]({
    "a": m["Account"]("A", 100),
    "b": m["Account"]("B", 900),
})
for name in ("read_balance", "read_balance_checked"):
    for tenant, account_id, expected in (("A", "a", 100), ("B", "b", 900)):
        principal = m["Principal"](tenant)
        value = m[name](principal, account_id, store)
        if type(value) is not int or value != expected:
            raise AssertionError(f"{name} failed the owning-tenant balance check")
        try:
            m[name](principal, "missing", store)
        except KeyError:
            pass
        else:
            raise AssertionError(f"{name} did not raise KeyError for an absent account")
print("PASS: owning-tenant reads and missing-account behavior preserved")
PY_CHECK
```

These checks establish the relevant S1 examples on the repaired local callable boundary when run successfully. They do not establish production reachability, deployment correctness, or security beyond this supplied boundary. No repair was applied and no behavioral check was run during this preparation; only the supplied files were read and this artifact was written.
