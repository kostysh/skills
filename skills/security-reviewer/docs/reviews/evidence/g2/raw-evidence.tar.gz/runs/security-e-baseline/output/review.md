Patch A closes the accepted tenant-read defect without changing the adjacent admin boundary; Patch B closes that read path but opens the previously admin-only export to members.

## Basis and limits

Mode: bounded re-audit of R1 and adjacent regression inspection. Patch A and Patch B are independent alternatives against `before.py`, never successive revisions. Authority: `accepted.md:1`, which supplies the complete callable boundary, trusted immutable server-created identity/account dictionaries, caller-selected account, absence of unseen guards, and unchanged admin-only export policy. These are supplied synthetic contracts, not independently established production facts. Research remained within the supplied case and active skill references.

SHA-256 snapshots:

- `accepted.md`: `f6fc1bfa4103d2d7c874e101506c9a62ad6d9fbc3853819e79e511537becfd4b`
- `before.py`: `74a4f4af52da7b607fc0ddce64563c0a92061a9f832cc830ceea72bc1d82d16b`
- `patch-a.py`: `4ec6a6872d3d5c7665cbf3098cf4befb42fba475d95ed1d51bfc40a80b5160d4`
- `patch-b.py`: `a9cee203687b92f322a29e0e51c9cb6b5f36a0c2150bf4accdad4eaa36ccc9cd`

The asset is account balance confidentiality. The attacker is an authenticated caller selecting a foreign account, or a non-admin member invoking the export callable; identity values are not attacker-forged. The reviewed surfaces are these two callable authorization boundaries and their deltas. No database, SQL, REST/PostgREST, SDK query builders, RPC, service-role, browser, network, CI, telemetry, or provider surfaces participate according to the supplied contract. No production assurance is claimed.

## Actual local execution

Executed each supplied Python file using `compile`/`exec`, with bytecode writes disabled, then invoked both functions. No input mutations or external dependencies were used. Fixtures: user tenant `t1`, roles `member`, `admin`, `guest`; own account balance 10 in `t1`; foreign account balance 900 in `t2`.

| Snapshot | Own read, all three roles | Foreign read, all three roles | Member export | Admin export | Guest export |
|---|---|---|---|---|---|
| Before | 10 | 900 | PermissionError | [10, 900] | PermissionError |
| A | 10 | PermissionError | PermissionError | [10, 900] | PermissionError |
| B | 10 | PermissionError | [10, 900] | [10, 900] | PermissionError |

These are observed deterministic results exercising the complete synthetic callable protection, not source-string assertions or production tests.

## Patch A closure

R1 → tenant equality guard at `patch-a.py:2-3` → original foreign-account selection now raises `PermissionError`, while own-tenant reads return 10 → **R1 closed for this snapshot**.

Adjacent inspection: `patch-a.py:6-9` preserves the original guard from `before.py:4-7`; executed member/guest rejection and admin success confirm the exercised admin boundary. The change has a bounded blast radius. Unchanged previously cleared scope beyond this regression inspection was not re-audited.

**Status: PASS (scoped)** for R1 remediation and the named adjacent callable regression surface only. No confirmed findings remain in that scope. No broader review or implementation is needed to close this synthetic remediation.

## Patch B closure and regression

R1 → identical tenant equality guard at `patch-b.py:2-3` → the original foreign-read attempt is rejected and own read succeeds → **R1 closed for the read callable only**.

**[High] R2 — Member export bypasses the accepted admin-only boundary.** Location: `patch-b.py:7-9`. Confidence: HIGH within the supplied synthetic contract. The authenticated member invokes `export_all`; the expanded role allowlist admits that member and returns all supplied balances, including foreign-tenant balance 900. The previous snapshot rejects the same member. No downstream guard exists under `accepted.md:1`. Impact: non-admin disclosure of balances through an independently callable export, bypassing the protection now present in `read`.

Fix direction for an authorized implementation owner: restore the accepted admin-only guard; alternatively obtain an explicit new permission-policy decision before designing a broader change. No remediation was performed.

**Status: FAIL** for the inspected adjacent regression surface, despite local R1 closure. Patch A's verdict does not apply to Patch B, and the previous export clearance is invalid for B.

## Next scope decision

Patch B changes permission policy and public callable behavior beyond the authorized R1 correction. A bounded R1 re-audit cannot certify that widened policy. Stop before a fresh targeted/formal review: the operator must decide whether to restore the accepted admin-only policy or authorize a new export policy and corresponding fresh review scope. No new broad review is authorized here. Before another point fix, investigate the materially related confidentiality failure across the full supplied read/export paths, why the admin guard was broadened, and whether the remediation scope incorrectly assumed all balance access passed through `read`.

No production/runtime fact remains necessary for the stated synthetic conclusions. Production security, exhaustive review, standards compliance, and overall merge guidance remain outside this result. Any material snapshot, contract, or evidence change invalidates the corresponding verdict.
