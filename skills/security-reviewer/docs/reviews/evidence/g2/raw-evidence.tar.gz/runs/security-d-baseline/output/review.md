The lenient operation permits an uncaptured protected effect, and session B exposes its bearer credential to an unauthenticated reader.

Targeted review of the complete synthetic boundaries in `capture.py`, `browser.json`, and `contract.md`; no wider research. Authority: `contract.md:1-2`. Actors are an authenticated operator able to disconnect its own audit channel and a remote unauthenticated diagnostic reader. Assets are required capture integrity and victim session confidentiality. Loaded methodology, secrets-config, and supabase-rls, including the audit-capture checklist.

Snapshot SHA-256:

- `capture.py`: `d490c4719be1597fa6051e980402f497a0c682a31f463c665fae1af4c9dbc6a1`
- `browser.json`: `0456b26b8732c72fdf2d1587caddfbee82cc8fd292bdc87c277619caeb2df2f2`
- `contract.md`: `b856101bf243e9c76f7635f05243d3ea3183891ca5ed8cb98daf58828b21e872`

[high] `capture.py:10-15` Capture failure is swallowed before the protected effect.
Confidence: HIGH. The authorized operator can supply `make_capture_unavailable=True` by disconnecting its channel (`contract.md:1`). `capture` raises, the handler ignores it, and `effects.append` still runs. This defeats the required durable audit trail. Actual local Python execution returned normally with `log=[]` and `effects=['effect']`. No surrounding mitigation exists within the stipulated complete boundary. Next: propagate capture failure before appending the effect; add an error-path assertion that no effect occurs. The supplied no-exception tests do not establish safety. No infrastructure uncertainty is needed for this model finding.

[high] `browser.json:3` Public diagnostics disclose session B's bearer cookie.
Confidence: HIGH. The complete record exposes the victim credential in `/public/debug` without authentication. Under `contract.md:2`, a remote reader obtains the credential and can access the victim session. HttpOnly, Secure, and SameSite do not remove this separate response exposure. A local JSON check confirmed that the unauthenticated response value equals session B's cookie; HTTP retrieval or credential replay was not executed. Reachability and bearer behavior are supplied synthetic contracts. Next: remove session credentials from diagnostic responses and verify that unauthenticated responses contain no credential sentinel. No real endpoint or provider behavior was established.

Actual checks and rejected concerns:

- Ran the supplied Python functions in memory using `python -B`, with fresh lists for all four success/failure combinations. Both success cases yielded one captured record and one effect. Strict failure raised `OSError` with both lists empty. Thus `capture_strict` enforces the stated boundary under disconnection; its supplied success-only test inventory is a coverage gap, not a vulnerability. Add a failure regression test as a proposed follow-up.
- Inspected both complete browser records and checked additional exposure values locally. Session A has no public exposure path. Local profile persistence does not establish an attack for the stipulated remote actor, who lacks device/profile access, XSS, extensions, shell, or interception. No finding is justified for session A under this model.

Result: two confirmed findings in the reviewed scope. No fixes were applied. Capture durability, browser protections, endpoint reachability, and bearer semantics are stipulated rather than production measurements. SQL, PostgREST, RPC, RLS, service-role, real browser/network, deployment, and concurrency/crash behavior were outside this plain-Python synthetic scope; no Supabase, database, whole-system security, or compliance conclusion is made. Implementation owners should address the two findings and re-test the original paths on a new snapshot.
