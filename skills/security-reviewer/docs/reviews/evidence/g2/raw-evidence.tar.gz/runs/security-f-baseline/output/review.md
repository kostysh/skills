The local tenant comparison enforces the supplied confidentiality rule, while the client-to-server path lets an authenticated user read another tenant’s balance by changing the submitted tenant.

Mode: two separate targeted reviews of synthetic callable boundaries, under the supplied `scope.md`; no production route or deployment assurance is asserted. Research was limited to supplied inputs and active security-reviewer instructions. The unrelated public recipe frontend is explicitly excluded, has no shared boundary, and is not needed for either conclusion.

Review basis (SHA256):
- `scope.md`: `961f294953f87f164e4215cd5909d96eea4fb89658032340e5d933009d2d4d5b`
- `server.py`: `eb86492593dd15e6f8509cdb62ce09b367a7d83ac28ec70958a827b7db2a1ab1`
- `client.py`: `2832103026b4e0e3fd7a5c45df6e8f016ffe6f3c6c4abf44716faea29ef18aab`
- `ledger.py`: `0110611ee0199ecd1b962b084eb1991a8de71f41d9dced893f87d8d30e8d6021`

Scope 1 — `server.local_read` and `ledger.Principal`/`Account` only: no confirmed findings in reviewed scope. `server.py:2-4` rejects unequal tenants before returning the balance; `ledger.py:3-10` defines frozen tenant-bearing objects. Equality is the sole supplied confidentiality policy. Actual deterministic Python execution with these supplied classes returned sentinel balance 7341 for principal A/account A and raised `PermissionError` for principal A/account B. This checks the named callable boundary, not session creation or public admission. Other ledger functions are not part of this review.

Scope 2 — confirmed finding:

[high] `server.py:7-10`, `client.py:1-2` — Caller-selected tenant substitutes for authenticated authorization.
Confidence: HIGH within the supplied synthetic contract.
Impact: an authenticated tenant A user can retrieve a tenant B account’s confidential balance.
Evidence: the supplied contract establishes a server-created immutable principal with tenant A, editable account_id and tenant request fields, immutable server account storage, and no unshown controls. `client.load` forwards both editable fields. `web_read` loads the chosen account, compares its tenant only with the submitted tenant, and returns its balance without consulting principal. Actual local execution with account b belonging to B returned sentinel 7341 when the form supplied tenant B, both through `client.load → web_read` and by directly calling `web_read`; submitting tenant A instead raised `PermissionError`. The local driver used a tenant-A stand-in for the already-authenticated principal; session authentication itself was supplied authority, not tested. Scope 1’s guard does not mitigate this separate function.
Next: authorize the selected account against the server-authenticated principal before returning its balance; add a regression check where principal A submits both B’s identifier and tenant B. This remediation and regression check are proposed, not implemented.

Coverage and limits: inspected the complete supplied client/server path, caller-controlled dictionary key and tenant comparison, plus Scope 1’s local guard and declared classes. No SQL, REST/PostgREST, RPC, SDK, RLS, or service-role boundary exists in the supplied paths; no broader database security conclusion follows. No network or deployment checks ran. No unresolved fact is needed to establish the synthetic Scope 2 finding; real-world applicability would require actual route, session and storage evidence. The coordinator initially omitted `ledger.py`, then supplied it unchanged with the hash above; Scope 1 conclusions were made only after its receipt and execution. Inputs were not modified. No whole-system security or merge verdict is issued.
