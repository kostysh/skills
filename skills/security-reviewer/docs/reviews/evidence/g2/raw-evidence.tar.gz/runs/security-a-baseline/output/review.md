An authenticated caller can read another tenant’s balance through `read_balance`; the checked function rejects the same cross-tenant request.

Targeted review of the complete supplied callable boundary in `ledger.py`, against `contract.md:1` (S1). Actor: an authenticated tenant A principal choosing `account_id`; principal and private store are trusted server state. Asset: tenant-confidential balances. No wider research scope or production reachability claim.

Snapshot SHA-256:
- `ledger.py`: `a8cde467d30b2478229b61ed24d8e68cbac030f4cea3f44d6b9d7c947e0757e0`
- `contract.md`: `c80251a0746831e8418bf6922becb4f0b39f879814b63b01c6002bf9009afa39`

[high] `ledger.py:18–20` Missing tenant authorization discloses another tenant’s balance

Confidence: HIGH. The caller chooses another tenant’s existing account ID; `read_balance` passes it to `Store.load_by_id` (`ledger.py:15–16`) and returns its balance without comparing tenant ownership. Contract S1 explicitly permits this callable entry and establishes that the store performs no further authorization and no other guards exist. The check in `read_balance_checked:24–25` does not protect this separate entry point. Impact: cross-tenant confidential balance disclosure.

Actual behavioral evidence: tenant A principal, private store containing tenant B account `other` with sentinel balance `987654`, calling `read_balance(principal, 'other', store)` returned `987654`. Calling `read_balance_checked` with identical arguments raised `PermissionError`.

Fix direction: enforce `account.tenant == principal.tenant` before returning a balance in every callable read path, or delegate the unchecked function to the checked implementation. Add regression checks covering own-tenant success, cross-tenant rejection without a balance, and missing account behavior for both functions. These remediation steps are proposals, not executed changes. No further runtime or infrastructure fact is needed to confirm this finding within S1.

Coverage and limits: inspected all definitions, both callable reads, dictionary lookup, trusted principal/account records, and exception behavior. Exercised both reads for own tenant, different tenant, and absent ID. The checked function returned the own-tenant balance and rejected the other tenant; both functions raised `KeyError` for absent IDs. No other confirmed findings. Contract excludes network, SQL, database roles, frontend, and integration surfaces; no external deployment assurance was requested or established. This is evidence about the actual supplied synthetic callable boundary, not a production system.

Actual commands and results (all exited 0):
- `cat` of the supplied `task.md` and specified active `SKILL.md`; `cat` of its `references/methodology.md`; `nl -ba` of `contract.md` and `ledger.py`; `cat` of `references/api-auth-input.md`.
- Executed the following read-only local check with `python -B -` (no imports of the input module or bytecode writes):

```python
from pathlib import Path
import hashlib
p = Path('/tmp/skills-revision-g2-20260907-qfdkj6eo/runs/security-a-baseline/input')
for n in ('task.md', 'contract.md', 'ledger.py'):
    print(n, hashlib.sha256((p/n).read_bytes()).hexdigest())
ns = {}
exec(compile((p/'ledger.py').read_text(), str(p/'ledger.py'), 'exec'), ns)
s = ns['Store']({'own': ns['Account']('A', 10), 'other': ns['Account']('B', 987654)})
a = ns['Principal']('A')
for name in ('read_balance', 'read_balance_checked'):
    for key in ('own', 'other', 'missing'):
        try:
            print(name, key, 'RETURN', ns[name](a, key, s))
        except Exception as e:
            print(name, key, 'RAISE', type(e).__name__)
```

```text
read_balance own RETURN 10
read_balance other RETURN 987654
read_balance missing RAISE KeyError
read_balance_checked own RETURN 10
read_balance_checked other RAISE PermissionError
read_balance_checked missing RAISE KeyError
```

Result: one confirmed finding in the reviewed scope. Implementation owner should remediate the missing object-level authorization and recheck both read paths. No code was changed.
