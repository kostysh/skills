The supplied review finding agrees with S1 and the supplied code: `read_balance` omits the tenant equality check. No missing fact prevents this bounded remediation. Delegate that entry point to the existing checked function, preserving own-tenant results and `KeyError` for absent IDs.

```diff
--- a/ledger.py
+++ b/ledger.py
@@ -16,8 +16,7 @@
         return self.accounts[account_id]
 
 def read_balance(principal, account_id, store):
-    account = store.load_by_id(account_id)
-    return account.balance
+    return read_balance_checked(principal, account_id, store)
 
 def read_balance_checked(principal, account_id, store):
     account = store.load_by_id(account_id)
```

Two executable checks are in `checks.py`: `check_cross_tenant` requires `PermissionError` from both entry points; `check_own_and_missing` verifies own-tenant success and unchanged missing-account behavior for both entry points.

Run against a separately patched copy:

```sh
python -B checks.py /absolute/path/to/patched/ledger.py
```

Validation actually performed: applied this exact textual replacement only in memory, compiled the proposed module, and executed both check functions successfully. Input files were not edited and no bytecode was written. This establishes the proposed correction for the synthetic callable boundary; it does not establish an applied fix or production behavior.
