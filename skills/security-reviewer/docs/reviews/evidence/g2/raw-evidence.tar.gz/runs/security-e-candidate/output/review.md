Patch A closes the accepted tenant-read defect; Patch B closes that same defect but also opens the separate admin export to members, so its broader change cannot inherit closure.

Mode: bounded remediation re-audit. Authority: `accepted.md:1`. A and B are independent alternatives against `before.py`, not consecutive revisions. Report and research scope: R1, exact local deltas, original attack path, and adjacent permission regression inspection only. No broader review or implementation performed.

Stable SHA-256 basis:

| Input | SHA-256 |
|---|---|
| accepted.md | f6fc1bfa4103d2d7c874e101506c9a62ad6d9fbc3853819e79e511537becfd4b |
| before.py | 74a4f4af52da7b607fc0ddce64563c0a92061a9f832cc830ceea72bc1d82d16b |
| patch-a.py | 4ec6a6872d3d5c7665cbf3098cf4befb42fba475d95ed1d51bfc40a80b5160d4 |
| patch-b.py | a9cee203687b92f322a29e0e51c9cb6b5f36a0c2150bf4accdad4eaa36ccc9cd |

The supplied synthetic contract establishes authenticated callers, immutable server-created identity/account dictionaries, caller-selected account, a complete callable boundary, and no unseen guards. The asset is account balances; the boundaries are tenant ownership in `read()` and admin privilege in `export_all()`. These are supplied assumptions, not independently established production facts.

Actual checks: executed all three Python files with `python -B` using `compile`/`exec` in isolated namespaces, called the real supplied functions, and caught `PermissionError`. A member of tenant `own` selected own/foreign accounts with sentinel balance 913. Export checks used a foreign account containing 913 and server-created admin/member/guest identities.

| Exercised call | Before | A | B |
|---|---|---|---|
| read own account | 913 | 913 | 913 |
| read foreign account | 913 | denied | denied |
| export admin | [913] | [913] | [913] |
| export member | denied | denied | [913] |
| export guest | denied | denied | denied |

Patch A: R1 → tenant equality check at `patch-a.py:2-3` → original disclosure reproduced before and denied after, own-tenant success preserved → **R1 CLOSED; PASS (scoped)** for this bounded synthetic re-audit. The expected correction is inside the accepted remediation boundary and does not require widening. The export guard at `patch-a.py:7-8` is unchanged from `before.py:5-6`; its unchanged previously cleared full scope was excluded from renewed audit, with only the adjacent sentinel checks above performed. No confirmed remaining findings in this scope.

Patch B: R1 → same check at `patch-b.py:2-3` → same read-path behavioral evidence → **R1 CLOSED**, independently of the export regression.

**[High] R2 — Member gains admin-only export at `patch-b.py:7-9`. Confidence: HIGH within the supplied synthetic boundary.** A legitimate member invokes the separate export callable; the changed allowlist admits `member` and returns every supplied balance, including the foreign sentinel. The member needs no identity mutation or admin privilege. The complete supplied path has no subsequent guard. This creates unauthorized balance disclosure and removes the accepted admin boundary; before and A deny this same call. Result: **FAIL** for B's inspected adjacent regression surface. No production reachability claim is made and no missing framework/runtime fact affects this local result.

Next scope decision: B's export permission change exceeds the accepted R1 correction and changes a separate authoritative security contract/public behavior. Under the methodology's widening rule, a fresh targeted or formal review of that change is required if it is retained; the operator must first authorize that scope and settle any proposed permission policy. Do not silently expand this re-audit. Alternatively, an authorized implementation owner can restore the accepted admin-only export boundary and submit a new stable snapshot for bounded re-audit. These are proposed next steps, not performed changes or tests. The surviving cross-tenant disclosure through export requires root-cause investigation of the permission expansion, complete callable attack path, adjacent controls, and remediation scope before another point fix.

Evidence limits: local synthetic callable behavior only. No production, provider, infrastructure, penetration-test, compliance, or overall merge conclusion. No network/framework/frontend/database participates under the supplied contract; raw SQL, REST/PostgREST, SDK builders, RPC, RLS, storage and service-role paths are absent, not independently audited. No additional surfaces were researched. Changes to these snapshots invalidate the corresponding result. No input files were modified.
