The local callable enforces tenant equality; the supplied web callable lets an authenticated user read another tenant’s balance by editing the tenant field.

Mode: two separate targeted reviews of synthetic complete callable boundaries. Authority: supplied `scope.md`; tenant equality is the sole confidentiality policy. Research stayed within the supplied case and active security-reviewer references. No production route or deployment behavior is asserted.

Scope 1 — `server.py:1–4`, `ledger.py:3–10`: no confirmed findings in reviewed scope. `local_read` compares the principal tenant with the account tenant before returning the balance. Actual Python execution using supplied frozen `Principal` and `Account` returned 2468 for A/A and raised `PermissionError` for A/B. These tests exercise the specified local boundary, not authentication or production transport. The unrelated recipe frontend is explicitly excluded: it has no shared trust or data path and its absence does not limit this bounded result. The coordinator supplied the initially omitted `ledger.py` during review; its hash was verified before these checks. No substitute model was used for this scope. Other ledger functions were not included in the review conclusion.

Scope 2 — confirmed finding:

[high] `server.py:7–10`, `client.py:1–2`: caller-selected tenant replaces authenticated tenant in authorization.
Confidence: HIGH within the supplied synthetic contract.
Impact: a session principal from tenant A can retrieve a tenant B account balance by selecting that account ID and submitting tenant B.
Evidence: `client.load` forwards both editable form fields. `web_read` uses the chosen ID to load the immutable account and compares its tenant only with the submitted tenant; it never binds this check to `principal.tenant`. The supplied scope establishes a server-created immutable authenticated principal, attacker control of both request values, confidential balances, and no unshown controls. Actual deterministic Python execution with an immutable principal A and immutable account mappings returned own-account balance 123 for a/A, rejected b/A, then returned foreign balance 2468 for b/B through `client.load → web_read`. Bypassing the client and calling `web_read` with b/B also returned 2468. Thus client restrictions could not repair this server boundary.
Next: compare the selected account tenant to the authenticated principal tenant on the server before returning the balance. Proposed follow-up: repeat own-tenant and forged foreign-tenant cases against the corrected callable; no remediation or post-fix verification was performed.

Coverage and limits: inspected both supplied client and server for scope 2, the immutable identity/account types for scope 1, and the direct dictionary lookup/authorization path. The chosen account ID reaches a dictionary key; the tenant reaches the authorization comparison. This is an authorization bypass, not query-language injection. No SQL, REST/PostgREST, SDK builder, RPC, RLS, service-role, browser persistence, telemetry, or infrastructure boundary is represented in these scopes. No network, installation, input edits, deployment tests, or broader website review occurred. Supplied authentication and completeness facts are contracts, not independently measured production guarantees. There are no unresolved facts needed to confirm the synthetic scope 2 exploit; applying it to a real deployment would require the actual route and authentication path.

Stable SHA256 basis (unchanged supplied artifacts):
- `scope.md`: `961f294953f87f164e4215cd5909d96eea4fb89658032340e5d933009d2d4d5b`
- `client.py`: `2832103026b4e0e3fd7a5c45df6e8f016ffe6f3c6c4abf44716faea29ef18aab`
- `server.py`: `eb86492593dd15e6f8509cdb62ce09b367a7d83ac28ec70958a827b7db2a1ab1`
- Late supplied `ledger.py`: `0110611ee0199ecd1b962b084eb1991a8de71f41d9dced893f87d8d30e8d6021`
