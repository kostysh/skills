import sys
from pathlib import Path

ns = {}
source = Path(sys.argv[1])
exec(compile(source.read_text(), str(source), "exec"), ns)

def check_cross_tenant():
    store = ns["Store"]({"other": ns["Account"]("B", 987654)})
    principal = ns["Principal"]("A")
    for name in ("read_balance", "read_balance_checked"):
        try:
            result = ns[name](principal, "other", store)
        except PermissionError:
            pass
        else:
            raise AssertionError(f"{name} returned {result!r} across tenants")

def check_own_and_missing():
    store = ns["Store"]({"own": ns["Account"]("A", 42)})
    principal = ns["Principal"]("A")
    for name in ("read_balance", "read_balance_checked"):
        assert ns[name](principal, "own", store) == 42, name
        try:
            ns[name](principal, "missing", store)
        except KeyError as error:
            assert error.args == ("missing",), (name, error.args)
        else:
            raise AssertionError(f"{name} accepted missing account")

check_cross_tenant()
check_own_and_missing()
print("PASS: cross-tenant rejection; own-tenant success and missing-account behavior")
