An authenticated tenant can read another tenant's balance through `read_balance`; the checked function rejects the same attempt.

Targeted review of the complete synthetic callable boundary in `ledger.py` against `contract.md` (S1). SHA-256: ledger `a8cde467d30b2478229b61ed24d8e68cbac030f4cea3f44d6b9d7c947e0757e0`; contract `c80251a0746831e8418bf6922becb4f0b39f879814b63b01c6002bf9009afa39`. Research was limited to these inputs and the active security-reviewer instructions.

[high] `ledger.py:18-20` Missing tenant authorization exposes confidential balances

Confidence: HIGH. An authenticated principal controls `account_id`, including an existing account belonging to another tenant. `read_balance` passes that identifier to `Store.load_by_id` (`ledger.py:15-16`) and returns the resulting balance without comparing tenants. The supplied complete-boundary contract explicitly rules out downstream authorization and other guards. An immutable, authentic principal does not prevent this object-level authorization bypass.

Evidence: running the supplied module with principal tenant A and a server-owned account `b` in tenant B returned B's balance `900` from `read_balance`. The identical call to `read_balance_checked` raised `PermissionError`. Impact is unauthorized cross-tenant balance disclosure for chosen existing account identifiers; identifier discovery and production reachability are not claimed.

Next: enforce `account.tenant == principal.tenant` before returning from every callable read path, following the existing checked function. Add regression cases for same-tenant success, cross-tenant denial, and missing identifiers. No remediation was performed. No unresolved runtime fact affects this synthetic-boundary finding.

Coverage and limits: inspected both entry points, immutable records, private store lookup, and all return/exception paths. Behavioral calls confirmed both functions return `100` for tenant A's account, the checked function denies tenant B's account, and both raise `KeyError` for a missing identifier. Per S1 exceptions return no balance. No SQL, REST, query builders, RPC, database roles, network, frontend, telemetry, or integration surfaces exist in this supplied boundary. These are synthetic local results, not production facts or broader deployment assurance. No additional needs-verification item is required for the requested boundary.

Actual commands and results:

- `cat` read the supplied task, active skill, contract, methodology, API/auth/input and data-access references; `rg --files` listed only the input directory; `nl -ba` read numbered `ledger.py`. All exited 0.
- `python -B` used `hashlib.sha256` for the above hashes and `runpy.run_path` to execute the supplied module without bytecode writes. Constructed `Store({'a': Account('A',100), 'b': Account('B',900)})` and `Principal('A')`, called both read functions for `a`, `b`, and `missing`, and printed returned values or exception class names. Exit 0; results respectively: `read_balance: 100, 900, KeyError`; `read_balance_checked: 100, PermissionError, KeyError`.

Proposed checks: regression tests described in the finding; none were added or run as a remediation suite.

Result: one confirmed finding in reviewed scope. The implementation owner should repair the missing authorization and re-test the original cross-tenant path on the changed snapshot.
