def capture(record, unavailable, log):
    if unavailable:
        raise OSError("channel unavailable")
    log.append(record)

def capture_strict(make_capture_unavailable, log, effects):
    capture("effect", make_capture_unavailable, log)
    effects.append("effect")

def capture_lenient(make_capture_unavailable, log, effects):
    try:
        capture("effect", make_capture_unavailable, log)
    except OSError:
        pass
    effects.append("effect")
