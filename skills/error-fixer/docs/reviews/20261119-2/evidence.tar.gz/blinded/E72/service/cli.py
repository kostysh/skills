import json
import sys

def values(args):
    return [int(value) for value in (args or [""])]

if __name__ == "__main__":
    print(json.dumps(values(sys.argv[1:])))
