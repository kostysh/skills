Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Revise a draft function specification from its accepted source, removing unsupported requirements and making boundary cases testable.
