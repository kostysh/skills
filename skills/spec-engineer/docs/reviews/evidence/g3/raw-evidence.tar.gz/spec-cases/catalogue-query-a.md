Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Turn this accepted API behavior and errors into a concise falsifiable software specification for our coding agent; architecture is accepted.
