Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Turn accepted product scope, architecture and a ready specification into ordered implementation tasks with dependencies and verification owners.
