Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Compare this implementation against the accepted specification and report mismatches; do not change the specification.
