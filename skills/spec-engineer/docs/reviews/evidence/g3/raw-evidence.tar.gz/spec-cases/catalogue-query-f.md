Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Write the TypeScript implementation of this fully specified pure function. Do not create another specification.
