Select the primary skill from the attached catalogue for this request, or none if no entry fits. Explain the boundary briefly. Do not load skill bodies or execute the task.

Choose an architecture boundary for a new external integration and explain ownership and trade-offs before behavior is specified.
