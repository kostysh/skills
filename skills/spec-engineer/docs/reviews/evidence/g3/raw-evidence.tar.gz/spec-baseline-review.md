# Предварительная независимая baseline-ревизия spec-engineer

**FAIL — 1 P2; 2 замечания P3.** Scope: spec-engineer 0.2.13, baseline; assurance: independent. Авторство/исправления проверяемого снимка ревьюеру не принадлежали. Это предварительная инспекция потребителя до стабильного PASS architecture-engineer, а не принятие группы 3.

## Основание и границы

Проверен immutable snapshot `/tmp/skills-revision-g3-20260907-idvgqdrf/baseline/spec-engineer`, base commit `be557e915b03267df650b9ca5906ac59078110e9`. SHA-256 каждого из 29 файлов проверен до и после чтения по `baseline-source-manifests.json`; несовпадений нет. SKILL.md SHA-256: `ae518b843d8be85b695d4f88b8e5a3fd7760785fda35ab25db10ed2cd7e376ec`.

Основание: AGENTS.md рабочего worktree, docs/skill-standard.md, принятый implementation-plan-20260907-2.md; применены skill-reviewer (root, methodology, forward-testing) и implementation-discipline. Полностью прочитаны source skill.yaml, fragment, generated SKILL.md, все шесть references и agents/openai.yaml. Из supporting прочитаны navigation и журналы semantic authority/последнего package-provider изменения; старые журналы не служили нормативным основанием или доказательством всей текущей capability. Соседи прочитаны только в стабильном baseline: architecture methodology routed handoff/readiness, delivery methodology readiness propagation/task readback. Их будущие исправления этим отчётом не приняты.

Capability: при достаточных источниках агент выдаёт спецификацию с проверяемыми обязательствами и честной готовностью для автора реализации либо delivery-planner; при неполных источниках сохраняет поддержанный draft и конкретные dependent gaps. Спецификация является полезным конечным артефактом для этого потребителя, но не доказательством реализации, runtime, безопасности приложения или релиза. Компиляция и файлы — supporting substrate.

## F1 — P2: обязательный conditional reference объявлен optional с более узким trigger

**Basis: direct/conflicting.** Source `skill.yaml:28-33,140-148` объявляет high-risk backend reference как `required: false` и optional; его trigger ограничен «high-risk backend specification». Generated `SKILL.md:277-278` воспроизводит этот контракт. Одновременно `SKILL.md:29,89` требует чтения также для multi-package/component или external-provider scope без high-risk, а `references/high-risk-backend-contract.md:3,36-60` содержит обязательный conditional readback и readiness gate для таких случаев.

Failure path: обычная low-risk спецификация двух пакетов с уже принятым contract owner → исполнитель выбирает references по explicit optional index/trigger → не загружает файл, поскольку high-risk отсутствует → у него нет обязательных деталей dependency/member/readback → он либо пропускает требуемую проверку, либо необоснованно останавливает handoff из-за неразрешённого различия между root и index. Это не претензия к длине: одновременно существуют два несовпадающих условия обязательной загрузки.

**P1 screen:** root независимо запрещает ready при пропущенном applicable readback (`SKILL.md:160`), поэтому убедительно поддержан P2 retrieval/исполняемости, а не доказанный P1 false-ready. Исторический SPEC-BLIND-2 успешно загрузил reference в одном обычном provider случае; это полезное контрдоказательство систематического отказа, но не устраняет прямое противоречие двух active контрактов.

Минимальная коррекция: сделать reference conditionally required, синхронизировать trigger index с root (high-risk backend ИЛИ multi-package/component ИЛИ external-provider), сохранить запрет полной HRB matrix без high-risk. Проверить остальные optional entries на фактическую обязательность, но не превращать действительно вспомогательные patterns/examples в always-required.

Закрывающее evidence: source/emitted классификация совпадает; одинаковые baseline/candidate случаи обычного multi-package spec, high-risk spec и корректной single-function specification показывают необходимые чтения и достаточный результат без ненужной HRB matrix. Не требуется runtime навыка или постоянный harness.

## C1 — P3: provider-specific формулировка внутри общего multi-package readback

`references/high-risk-backend-contract.md:38-49` запускает supplement для любых нескольких компонентов, затем без локального уточнения просит accepted boundary generic adapter ↔ application-owned provider profile/admission/model literals. Для обычных parser + formatter packages это звучит как лишний вход. Однако readiness gate ограничен applicable items, а root запрещает неподдержанную архитектуру; достаточного основания объявлять обязательное изобретение provider architecture или P2 blockade нет.

Минимальное уточнение при авторской правке: привязать именно эту строку к реальному provider boundary и читать фактически принятую архитектуру, допускающую иной состав компонентов. Проверка: корректный multi-package case без provider остаётся готовым; отсутствие genuinely required provider owner оставляет blocked только зависимую часть.

## C2 — P3: Stop rules и поддержанный draft нуждаются в одном ясном владельце

Methodology `:221` разрешает убрать unsupported MUST либо оставить explicit gap; `:539-549` одновременно говорит Stop and ask для такого MUST и не останавливать полезный draft без invention. Root `:235-244` повторяет часть stop rules с другим набором условий. При буквальном чтении возможна лишняя пауза, но удаление неподдержанного собственного предложения и продолжение draft уже разрешены semantic gate и implementation-discipline. Поэтому утверждение о неизбежной P2 остановке не поддержано.

Минимальное уточнение: один canonical stop contract; отсутствие authority останавливает зависимую нормативную фиксацию/ready handoff, а не разрешённую полезную draft/review работу. Не вводить новый approval workflow. Не менять принятые требования только потому, что автор предпочёл более удобное acceptance.

## Поддержанные выводы и исключённые подозрения

- Draftable input отделён от ready input; readiness требует authority, architecture disposition, domain/external facts и named consumer. Неполный source не обязан останавливать draft.
- Semantic derivation/removal falsifier защищает от новых неподдержанных MUST; observed code и tests не легализуют требования. Изменение требований остаётся authoring, conformance implementation-review маршрутизируется отдельному владельцу.
- Capability/substrate и template/result разделены явно. Worked example содержит source-defined API behavior, отрицательные критерии и anti-claims; нет доказанного false-runtime closure.
- Architecture handoff может реально дать inherited constraints для spec/verification map; delivery consumer принимает behavior detail и блокирует только зависимое implementation work. Согласованность будущего изменённого architecture provider ещё должна быть проверена после его PASS.
- Domain interop оставляет специальные факты владельцам, а spec сохраняет оформление принятого behavior. Нет оснований выдавать domain-security PASS по одному названию skill.
- Source/emitted drift не найден. Отсутствие package.json/runtime/tests не дефект документационного навыка. Размер root и description сам по себе не использован для findings.

## Evidence и следующий шаг

Координатор выполнил lint, check, isolated compile и emitted check: все exit 0; 27/27 emitted parity. Прочитан `spec-engineer-baseline-checks.json`; reviewer эти команды повторно не запускал. Новых trials, network, Git operations, edits навыка или соседей не было. Исторические outputs учтены только с их прежними snapshot/coverage limits; текущая активация и end-to-end handoff не испытаны, улучшение над baseline не доказано.

Следующий владелец — автор spec-engineer после стабильного PASS architecture-engineer. Исправить F1, явно решить P3 без обязательного расширения правки, затем соразмерные fixed-input испытания и независимый re-audit accepted delta. Повторный аудит должен сохранить исходный failure path; изменение provider-контракта проверяется отдельно по затронутому handoff. До этого FAIL относится к указанному baseline; никакая новая версия им не оценена.

Scope delta: unchanged. Unauthorized additions: none. Единственная запись reviewer — этот отчёт в /tmp.
