Primary: typescript-engineer

The request is to implement an already specified pure function in TypeScript, so TypeScript language and type-system work is the primary fit. It does not ask for specification authoring, architecture, delivery planning, requirements refinement, or a conformance review; spec-engineer would cross the explicit boundary against creating another specification.
