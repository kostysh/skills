# Offline label preview specification

## Scope and handoff

Status: `ready for delivery-planner`. Next consumer: delivery-planner, preparing work for Ada (`@label/mode`) and Bruno (`@label/preview`), who own implementation and verification of their respective packages. No blocking decisions remain.

Authority: [PRD-LABEL and ARCH-LABEL](../../../spec-producer/input/task.md), expressly accepted by product owner Elena and technical lead Marco respectively; [governance](../input/context.md); and the [architecture handoff](../../../spec-producer/output/architecture.md), consumed as a constraint summary rather than authority for new scope. The accepted primary decisions govern every requirement below. No extra repository convention or identifier is assumed.

This low-risk extension preserves the existing two-package, in-memory preview. The outcome is an exact label or rejection for a local user's string. The only deliverable here is this specification; delivery planning and implementation are subsequent work. Incorrect labels, unintended acceptance, or duplicated mode ownership are the relevant failure classes.

## Behavior

A **mode** is exactly `plain` or `caption`. A **preview** is the result returned by `previewLabel` for one input string. An **invalid input** is any other string. A **published entry** is the existing public package entry available to callers.

For a caller supplying a string to the local preview, the accepted behavior is the following complete decision table. Each row applies to both published function paths; results shown are exact objects.

| Input | `parseMode(input)` | `previewLabel(input)` |
| --- | --- | --- |
| `"plain"` | `{ok:true,value:"plain"}` | `{ok:true,label:"Plain"}` |
| `"caption"` | `{ok:true,value:"caption"}` | `{ok:true,label:"Caption"}` |
| Every other string | `{ok:false,error:"invalid_mode"}` | `{ok:false,error:"invalid_mode"}` |

The direct path is caller string → preview (Bruno) → imported parser (Ada) → preview result (Bruno) → caller. Mode determines label presentation; rejection remains `invalid_mode` throughout. No normalization, persistence, reload, or remote transition is part of this path.

## Requirements

All requirements are explicit restatements of accepted primary decisions. The source column also states why each is necessary: removing it permits the indicated violation of that accepted decision. Applicability is the named package or complete local preview path, for all string calls.

| Source and removal falsifier | Atomic requirement |
| --- | --- |
| ARCH-LABEL: changing the type breaks canonical public mode ownership. | `@label/mode` MUST alone own public `Mode = "plain" \| "caption"`. |
| ARCH-LABEL: changing the parser signature breaks its accepted public contract. | `@label/mode` MUST alone own public `parseMode(input:string): {ok:true,value:Mode}\|{ok:false,error:"invalid_mode"}`. |
| ARCH-LABEL + PRD-LABEL: losing either valid member or accepting any other string violates exact mode parsing. | `parseMode` MUST return the exact parser result in each row of the behavior table. |
| ARCH-LABEL: changing preview's signature breaks its accepted public contract. | `@label/preview` MUST alone own public `previewLabel(input:string):{ok:true,label:"Plain"\|"Caption"}\|{ok:false,error:"invalid_mode"}`. |
| PRD-LABEL: a wrong label, omitted valid mode, or different rejection violates the accepted user result. | `previewLabel` MUST return the exact preview result in each row of the behavior table. |
| PRD-LABEL: trimming would accept forbidden whitespace variants. | The local preview path MUST NOT trim input. |
| PRD-LABEL: folding case would accept forbidden case variants. | The local preview path MUST NOT fold input case. |
| ARCH-LABEL: a runtime dependency would exceed mode's accepted dependency boundary. | `@label/mode` MUST have no direct runtime dependencies. |
| ARCH-LABEL: any other direct runtime dependency would exceed preview's accepted boundary. | `@label/preview` MUST directly depend only on `@label/mode`. |
| ARCH-LABEL: locally restating the type breaks imported canonical type ownership. | `@label/preview` MUST import `Mode` from `@label/mode`. |
| ARCH-LABEL: bypassing the parser breaks the accepted canonical validation path. | `@label/preview` MUST use the imported `parseMode` from `@label/mode` for parsing. |
| ARCH-LABEL: duplicating accepted literals permits competing mode definitions. | Each package MUST NOT maintain a second list of accepted mode literals. |
| PRD-LABEL: an I/O effect exceeds the accepted pure local boundary. | The preview path MUST NOT perform I/O. |
| PRD-LABEL: persisted state exceeds the accepted stateless boundary. | The preview path MUST NOT persist state. |

The last ownership prohibition means no independently maintained accepted-mode list; it does not prescribe branching or label-mapping syntax. No internal layout, helper names, or additional abstraction is prescribed. Authentication, tenant data, providers, and network are excluded by PRD-LABEL.

## Edge cases and revision disposition

Rejection examples: `""`, `" plain"`, `"plain "`, `"Plain"`, `"PLAIN"`, `" caption"`, `"caption "`, `"Caption"`, `"CAPTION"`, `"other"`. Each expects the exact failure object in both functions. These examples expose common mistakes; the normative rejection rule covers every nonmatching string.

The earlier brainstorming statement requiring telemetry is **removed from the normative target**: Elena did not accept it, and no accepted source authorizes analytics. It cannot create a requirement, event contract, instrumentation dependency, or readiness blocker. The accepted no-I/O behavior remains binding.

## Acceptance and verification map

All evidence below is future work, using the existing package test runner and published entries. No runner change, new harness, telemetry, or runtime seam is required.

| Coverage and owner | Required observation / smallest falsifier |
| --- | --- |
| Parser contract, Ada | Call the published parser with both valid modes and the rejected examples. Compare exact results to the table. Either missing mode, extra acceptance, or wrong error falsifies the contract. Inspect public type/signature ownership, including both union members. |
| Complete preview path, Bruno | Call the published preview with its real imported parser for both valid modes and the rejected examples. Exact `Plain`, `Caption`, and `invalid_mode` results establish the bounded behavior. Parser-only checks or a mocked parser do not establish this path. |
| Canonical member preservation, Ada and Bruno | Trace `plain` and `caption` from mode's canonical definition through parser values to their respective preview labels, and `invalid_mode` through both failure paths. Each omitted member or changed spelling fails acceptance. This covers both packages and every accepted enum, result, and error member. |
| Package boundary, Ada and Bruno | Inspect public exports, preview's type/parser imports and use, direct runtime dependencies, and absence of a second accepted-mode list. A duplicate definition, parser bypass, or unauthorized dependency fails even if returned examples pass. Reliance on an undeclared transitive dependency also violates the declared boundary. |
| Pure execution, Ada and Bruno | Inspect the complete function path for I/O, persistence, authentication, tenant/provider integration, and network effects. Any such addition contradicts PRD-LABEL; output tests alone cannot establish absence of side effects. |

Both entries and the existing runner are stipulated available. The only accepted upstream precondition is a string argument; preview relies on the canonical parser contract above. No external provider is present. The low-risk scope calls for this conditional package readback, not a high-risk backend matrix. Persistence/reload and deployment checks are inapplicable because accepted behavior is a pure in-memory return.

## Anti-claims and gaps

This artifact specifies capability; it does not implement it, prove runtime behavior, or establish release readiness. Prior deployed behavior has not been observed, so no historical bug or before/after execution result is claimed. Existing package boundaries and accepted public contracts are preserved; no migration is specified.

No behavior for non-string callers, UI rendering workflow, analytics, performance target, persistence, authentication, tenant system, provider, or network operation is added. There are no blocking questions or architecture deltas on the supplied facts. If preserving an accepted package contract or dependency boundary proves impossible, route the conflict to architecture-engineer and Marco; proposed product changes belong to Elena. Missing exact specification detail belongs to spec-engineer. Delivery-planner can proceed without inventing those decisions.
