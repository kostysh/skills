Primary: spec-engineer

The request revises a function specification using accepted source authority and testable boundary cases, directly matching spec-engineer's software-specification scope. It does not ask for code conformance review, product requirements, architecture, or delivery planning.
