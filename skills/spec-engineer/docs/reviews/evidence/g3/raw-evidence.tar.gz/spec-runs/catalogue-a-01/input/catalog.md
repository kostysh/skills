## spec-engineer
Create concise, falsifiable software specs for AI coding agents. Use to turn ideas, tickets, APIs, domain rules, migrations, workflows, or function behavior into implementation-ready Markdown with observable requirements, acceptance evidence, anti-claims, source authority, and handoff readiness.

## architecture-engineer
Design or revise architecture for AI-agent-driven development. Use when product scope, features, integrations, data, security, deployment, or findings require architectural requirements, boundaries, patterns, trade-offs, quality scenarios, spikes, ADRs, or handoff—not implementation backlogs.

## delivery-planner
Turn accepted product scope and architecture handoff into right-sized executable work for AI agents. Use for project, feature, module, service, or integration planning, sequencing, risk-aware breakdown, and routing gaps to owning skills. Produce one Delivery Plan, not rigid workflow registers.

## prd-engineer
Create, refine, and review PRDs, product specs, feature and AI requirements. Turn ideas into testable scope, non-goals, acceptance, rollout, and metrics; establish source authority and handoff readiness; address AI evaluation; or audit ambiguity, missing evidence, weak acceptance, and scope risk.

## spec-conformance-reviewer
Review code against authoritative specs, contracts, ADRs, tickets, PRDs, RFCs, migrations, and acceptance criteria. Build requirement-to-code traceability, identify compliance gaps or ambiguities, and issue an implementation-versus-spec verdict limited by source authority and evidence.

## typescript-engineer
Use for TypeScript language and type-system work, compiler diagnostics, type-safe APIs, tsconfig, and Biome/ESLint configuration. Ground explanations, review, diagnosis, and changes in repository and installed-version evidence; pair with runtime, framework, testing, validation, and domain owners.
