# Label utility specifications

## Scope And Handoff

Consumer: coding agent Oleg. Parent product: local text preview, without network or state. Scope: two independent string utilities in the existing utility module. Marco confirms no architecture impact. Risk is low: incorrect output would alter preview text; no persistent or external effects are in scope. This is specification authoring only.

- **FUN-A — ready for Oleg.** Elena approved the exact bracket transformation and absence of side effects. Oleg can implement it independently of FUN-B.
- **FUN-B — blocked for implementation; supported partial specification below.** Elena's accepted FUN-B-1 and FUN-B-2 have equal authority and conflict on boundary ASCII spaces. Neither supersedes the other. Elena owns resolution.

Terms: `value` is the string argument; “ASCII space” is U+0020; “boundary spaces” are leading and trailing spaces. Inputs outside the declared string signatures are unspecified; this spec adds no coercion or validation behavior.

## Behavior

`bracketLabel(value:string):string` supplies the caller with the unchanged input enclosed by one added opening bracket and one added closing bracket. It is a direct local string transformation supporting the preview.

`normalizeLabel(value:string):string` is a separate pure utility. Its case and non-ASCII preservation obligations are settled; its handling of boundary ASCII spaces is not. The function name supplies no authority for additional normalization.

## Requirements

All obligations below are **explicit**, sourced from Elena's accepted statements. They apply to calls with string arguments at the function boundary. Each is necessary to preserve the corresponding accepted behavior; the final column states an observable removal falsifier and the future verification contour.

| Source | Atomic obligation | Removal falsifier / verification |
| --- | --- | --- |
| FUN-A | `bracketLabel` MUST return exactly `"[" + value + "]"` for every string argument, including empty strings and Unicode. | An implementation that strips a space or changes an input character violates Elena's exact-concatenation rule. Invoke the actual function in the existing unit tests and compare exact output. |
| FUN-A | `bracketLabel` MUST have no side effects. | A call that changes state or performs I/O violates Elena's purity requirement. Inspect the direct utility implementation for effects; use existing tests where applicable. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST preserve case. | Changing `AbÉ` to `abé` violates both accepted sources. Check the actual function with mixed-case input in existing unit tests. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST preserve non-ASCII characters. | Removing or replacing a non-ASCII character violates both accepted sources. Check preservation using Unicode input in existing unit tests. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST have no side effects. | State mutation or I/O violates both accepted sources. Inspect the direct implementation for effects; use existing tests where applicable. |

Revision disposition: the earlier unapproved FUN-A draft's whitespace trimming is removed because it contradicts exact preservation. Its extensible formatter plugin obligation is removed because no accepted source requires it and a direct string transformation suffices. These removals revise the draft, not an established runtime behavior. Both accepted, conflicting FUN-B obligations remain recorded below without selecting or weakening either.

## Edge Cases

FUN-A illustrative exact-output cases:

| Input | Expected output |
| --- | --- |
| `""` | `"[]"` |
| `" Label "` | `"[ Label ]"` |
| `"É🙂"` | `"[É🙂]"` |
| `"[x]"` | `"[[x]]"` |

FUN-B conflict witness: for input `" AbÉ "`, FUN-B-1 requires the leading and trailing spaces to remain; FUN-B-2 requires those ASCII spaces to be removed before return. No test oracle selecting either behavior is authorized yet. Case and non-ASCII preservation checks do not resolve this conflict and cannot establish full FUN-B acceptance.

## Acceptance

Oleg uses the existing unit-test contour, calling the real utilities. No new runner, plugin system, or verification infrastructure is required.

FUN-A acceptance requires exact outputs for the cases above and implementation inspection consistent with the no-side-effects requirement. Returning `"[Label]"` for `" Label "`, changing Unicode, or introducing side effects fails acceptance. A function declaration or a test file alone is insufficient: the actual transformation must produce the required results.

For FUN-B, the agreed preservation and purity checks map to the requirements above, but full acceptance remains blocked until Elena resolves the boundary-space contract. After resolution, add its discriminating input/output check to the existing unit tests.

Verification has not been executed: this task supplies complete project facts for authoring, not implementation or runtime evidence. Persistence, projection, reload, and integration checks are inapplicable to these single-layer, stateless functions.

## Anti-Claims / Gaps

This artifact does not demonstrate implemented behavior, preview integration, release readiness, or any deployed defect. It specifies no formatter registry, network behavior, persistent state, or additional normalization policy. Current implementation behavior is not supplied.

**Decision required from Elena:** for `normalizeLabel`, should leading and trailing ASCII spaces be preserved exactly as FUN-B-1 requires, or removed as FUN-B-2 requires? An explicit resolution identifying which instruction governs or supersedes the other unblocks the dependent contract and Oleg's FUN-B implementation. There is no safe default, and FUN-A remains independently ready.
