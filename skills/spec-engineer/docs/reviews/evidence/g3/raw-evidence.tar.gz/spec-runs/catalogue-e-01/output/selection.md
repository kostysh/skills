Primary skill: `spec-conformance-reviewer`.

The request compares an implementation against an accepted specification and asks for mismatches, which directly matches implementation-versus-spec review and requirement-to-code traceability. `spec-engineer` authors specifications; changing the specification is explicitly outside this request.
