Primary skill: `typescript-engineer`.

The request is to implement an already specified pure function in TypeScript, so TypeScript language and type-system work is the relevant scope. `spec-engineer` would produce a specification, which the request explicitly excludes; planning, architecture, product requirements, and conformance review are not the requested deliverable.
