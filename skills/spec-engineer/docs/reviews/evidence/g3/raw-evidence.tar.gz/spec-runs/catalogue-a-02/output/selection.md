Primary skill: spec-engineer

The request directly calls for converting accepted API behavior and errors into a concise, falsifiable software specification for a coding agent. Architecture is already accepted; no architecture design, delivery sequencing, implementation, or code-conformance review is requested.
