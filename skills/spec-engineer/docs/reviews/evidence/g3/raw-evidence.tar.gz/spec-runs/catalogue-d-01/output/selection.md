Primary skill: delivery-planner

The request turns accepted scope, architecture, and a ready specification into sequenced implementation work with dependencies and verification owners. This is delivery planning; requirements and architecture are already inputs, and no specification authoring or implementation conformance review is requested.
