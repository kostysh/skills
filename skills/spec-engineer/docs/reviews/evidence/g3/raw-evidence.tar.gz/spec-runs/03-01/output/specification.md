# Local label utility specifications

## Scope And Handoff

Consumer: coding agent Oleg. Parent product: local text preview with no network or state. This revision specifies two independent string utilities; only this Markdown artifact is delivered. Risk is low: incorrect behavior changes preview text. Marco confirms one existing utility module and no architecture impact; direct local functions and existing unit tests suffice.

- `bracketLabel(value:string):string`: **ready for Oleg**, based on Elena's approved FUN-A.
- `normalizeLabel(value:string):string`: **blocked** for implementation pending Elena's resolution of accepted, equally authoritative FUN-B-1 and FUN-B-2. Neither supersedes the other. This blocker does not delay FUN-A.

The earlier unapproved FUN-A draft is corrected: its whitespace-trimming obligation is removed because it contradicts exact preservation; its formatter-plugin registration obligation is removed because no accepted source requires it. This is a specification delta, not evidence of current code behavior.

## Behavior

A caller supplies a string and observes the returned string. `value` is the supplied string; ASCII space means U+0020.

FUN-A brackets the entire supplied value exactly. FUN-B has accepted case, non-ASCII preservation, and purity constraints, but its leading/trailing ASCII-space behavior is unresolved. No new architecture, extension point, dependency, or verification harness is needed.

## Requirements

All requirements below are explicit accepted product instructions from Elena and apply to every string argument of the named function. Each necessity/removal witness identifies behavior the accepted source would otherwise permit an implementation to violate.

| Source | Supported requirement | Necessity / removal witness | Verification by Oleg |
| --- | --- | --- | --- |
| FUN-A | `bracketLabel` MUST return exactly `"[" + value + "]"`. | Omitting exact concatenation permits trimming, altered Unicode, or missing brackets, violating FUN-A. | Direct return-value assertions in existing unit tests, including the edge cases below. |
| FUN-A | `bracketLabel` MUST NOT cause side effects. | Returning correct text while changing state or making a network call violates approved purity and parent intent. | Inspect the function and any called code for effects; use existing tests where applicable. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST preserve case. | Case conversion violates both accepted sources. | Existing unit-test assertions with mixed case. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST preserve non-ASCII characters. | Changing or removing a non-ASCII character violates both sources. | Existing unit-test assertions including accented text, emoji, and non-ASCII spaces. |
| FUN-B-1 and FUN-B-2, agreed portion | `normalizeLabel` MUST NOT cause side effects. | State changes or network calls violate both sources. | Inspect the function and any called code for effects; use existing tests where applicable. |

No normative choice is made between the conflicting FUN-B boundary rules:

- FUN-B-1: preserve leading and trailing spaces exactly.
- FUN-B-2: remove leading and trailing ASCII spaces before return.

## Edge Cases

FUN-A illustrative exact input/output pairs:

| Input | Expected return |
| --- | --- |
| `""` | `"[]"` |
| `" Label "` | `"[ Label ]"` |
| `"  "` | `"[  ]"` |
| `"É🙂"` | `"[É🙂]"` |
| `"[x]"` | `"[[x]]"` |

FUN-B's minimal conflict witness is `" A "`: FUN-B-1 retains the boundary spaces; FUN-B-2 removes them. An all-ASCII-space input exposes the same conflict. Neither expected result is selected here. Non-ASCII-space preservation is part of the agreed constraint; using a broad whitespace-trimming operation could violate it.

## Acceptance

Oleg can implement and verify FUN-A independently in the existing utility module and unit-test contour. Its actual return values must match the exact-concatenation contract, including empty, whitespace, and Unicode inputs. A return of `"[Label]"` for `" Label "`, altered Unicode, or any side effect falsifies acceptance. A spec file or passing mock alone does not demonstrate the function's behavior.

FUN-B's agreed constraints can guide preparation, but satisfying them cannot establish complete acceptance while boundary-space behavior is undecided. After Elena resolves the conflict, update its normative rule and expected results before implementation handoff; then verify the selected rule alongside all agreed constraints using existing tests.

This is a single-layer function contract. Persistence, public projection, reload, and integration round trips do not apply because the supplied product has no state or network. No implementation or execution evidence is supplied, and no software tests were run for this documentation task.

## Anti-Claims / Gaps

This artifact proves neither implemented behavior nor end-to-end preview or release readiness. It adds no formatter plugin, runtime validation policy for non-string arguments, or product behavior beyond the accepted sources. Inputs outside the declared string signature are outside this specification.

**Decision needed from Elena:** for `normalizeLabel`, should leading and trailing ASCII spaces be preserved as FUN-B-1 requires, or removed as FUN-B-2 requires? A recorded resolution superseding the conflicting instruction is the unblock condition. Until then, only FUN-B's dependent handoff remains blocked.
