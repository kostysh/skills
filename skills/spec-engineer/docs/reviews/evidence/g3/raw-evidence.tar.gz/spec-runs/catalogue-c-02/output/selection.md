Primary skill: architecture-engineer.

The request concerns an external integration's architecture boundary, ownership, and trade-offs, which directly match architecture-engineer. Behavior has not yet been specified, so implementation-ready specification and delivery planning are subsequent work rather than the primary task.
