# Private export deletion

## Scope and handoff

**Deletion: ready for delivery-planner, for service owner Nina. External archive delivery: blocked for implementation.** This is a design artifact; implementation and runtime verification have not occurred.

The parent intent is account-owner control over saved private exports without exposing or deleting another account's data. Given an authenticated owner and a request that passes existing integrity checks, deletion removes the owned row atomically and returns `{deleted:true}` after commit; a same-owner repeat succeeds after absence. An unauthorized actor cannot observe private content or change that row.

Risk is high because this is irreversible deletion with authorization and transactional audit requirements. Scope is the existing single backend module and authenticated service function. The smallest sufficient implementation contour is the existing transaction, unique `(owner_id, export_id)` key, row lock, middleware, adapter and audit mechanism. The narrowest decisive falsifier is successful deletion reported while authoritative reload still finds the row, or a different principal reading/deleting it.

Authority is stipulated, not inferred from deployed code: Elena accepted PRD-EXPORT and PRD-DELIVERY-EXT; Marco accepted ARCH-EXPORT; Sara accepted SEC-EXPORT. EXPORT-CONTRACT is the existing package schema designated by SEC-EXPORT. The supplied facts are complete drafting inputs. No other artifact conventions apply. Current deployed deletion behavior is unspecified; the target below is not a claim that a particular defect has been observed. Existing module, interface, schema and security policies are preserved.

Terms: **owner** is the authenticated account owning the saved export; **other user** is a different authenticated account; **absence** is authoritative row absence, not an unavailable database; **unknown outcome** means commit/result certainty has been lost; **success** is the canonical `{deleted:true}` result. Audit accountability is separate from the saved export row.

## Requirements and authority

All requirements below are **explicit** accepted obligations, scoped by their condition and source. The final column states why each is necessary and the removal falsifier: allowing that observation would violate the cited accepted decision. Nina owns implementation and future verification throughout the deletion slice.

| ID | Accepted source / owner | Requirement | Necessity / removal falsifier |
| --- | --- | --- | --- |
| R1 | PRD-EXPORT / Elena | The operation MUST atomically remove an existing saved private export requested by its authenticated owner. | Owner control fails if the row survives a committed deletion. |
| R2 | PRD-EXPORT / Elena | The function MUST return `{deleted:true}` after successful commit. | The committed operation lacks its accepted public result. |
| R3 | PRD-EXPORT / Elena | A repeated deletion by the same owner MUST return `{deleted:true}` on authoritative absence. | A valid same-owner repeat fails. |
| R4 | PRD-EXPORT / Elena | A different authenticated user MUST receive opaque `not_found`. | Existence or private details are exposed in the result. |
| R5 | PRD-EXPORT / Elena | A different user MUST NOT read the private export. | Cross-account content becomes readable. |
| R6 | PRD-EXPORT / Elena | A different user MUST NOT delete the private export. | Cross-account authoritative state changes. |
| R7 | PRD-EXPORT / Elena | An unauthenticated request MUST receive `unauthenticated`. | A request without authentication reaches successful deletion. |
| R8 | ARCH-EXPORT / Marco | Malformed export IDs MUST map to existing `invalid_request`. | Invalid input is accepted or yields an invented outcome. |
| R9 | SEC-EXPORT / Sara | Existing authentication and CSRF middleware MUST pass before function entry. | A failed admission check enters the function. |
| R10 | SEC-EXPORT / Sara | The function MUST recheck owner and session inside the transaction. | Admission-time credentials alone permit a no-longer-authorized mutation. |
| R11 | ARCH-EXPORT / Marco | Direct table access MUST remain denied to every application principal, without elevated exceptions. | A principal bypasses the service function to read or mutate the row. |
| R12 | ARCH-EXPORT / Marco | The existing unique `(owner_id, export_id)` key and transaction row lock MUST remain the serialization point. | Concurrent commands bypass canonical serialization. |
| R13 | ARCH-EXPORT / Marco | A losing concurrent same-owner delete MUST succeed on the absence it observes. | A concurrency loser is incorrectly rejected. |
| R14 | ARCH-EXPORT / Marco | Rollback MUST leave the export row unchanged. | A failed transaction removes the row. |
| R15 | PRD-EXPORT / Elena | The function MUST NOT return success after an uncommitted transaction. | A rollback or incomplete commit is reported as deletion success. |
| R16 | ARCH-EXPORT / Marco | Both adapter classes `retryable_unavailable` and `internal_failure` MUST map to existing `temporarily_unavailable`. | Failure class is exposed or converted to absence/success. |
| R17 | ARCH-EXPORT / Marco | Public failures MUST NOT expose database/provider internals. | An error reveals internal failure details. |
| R18 | PRD-EXPORT / Elena | The workflow MUST NOT automatically retry unknown outcomes. | A lost outcome triggers automatic re-execution. |
| R19 | SEC-EXPORT / Sara | `export_deleted` MUST commit in the deletion transaction. | Deletion commits without its accountability event. |
| R20 | SEC-EXPORT / Sara | The event payload MUST contain only actor ID, export ID and existing correlation ID. | File contents, credentials, provider fields or other fields enter the event. |
| R21 | SEC-EXPORT / Sara | Audit failure MUST roll back deletion. | A failed audit accompanies a missing row. |
| R22 | SEC-EXPORT / Sara | Existing audit retention policy and Sara's ownership MUST remain unchanged. | This feature changes audit retention or deletes its audit. |
| R23 | SEC-EXPORT / Sara | Consumers MUST use EXPORT-CONTRACT's existing request `exportId:string`, success and four named error outcomes without aliases. | Another request/response symbol or invented ID format appears. |
| R24 | ARCH-EXPORT / Marco | The change MUST preserve the existing module, transaction and compatibility without a schema migration. | Delivery requires a new architecture or migration. |
| R25 | ARCH-EXPORT / Marco | Disabling the entry point MUST stop new requests. | A new request is admitted after disablement. |

R5–R6, R11, R14–R15 and R19–R21 are invariants, including concurrent and failing paths. Disabling admission does not undo a committed deletion. No latency, exactly-once audit cardinality, new identifier syntax or new error precedence is introduced; existing contracts govern those details.

## State and recovery boundaries

| Observed state/outcome | Permitted handling and actor | Forbidden interpretation |
| --- | --- | --- |
| Owned row present; accepted owner request | Existing service transaction deletes row and commits audit; owner receives success after commit. | Response-only success or partial audit/deletion commit. |
| Same-owner repeat; authoritative absence | Service returns success; owner may explicitly repeat a known deletion. | Treating absence as a database fault. |
| Other user's row | Service returns opaque `not_found`; row/content remain protected. | Returning content or deleting it. |
| Malformed ID / unauthenticated | Existing validation/authentication rejects with the canonical outcome. | Continuing deletion as an accepted request. |
| `retryable_unavailable` / `internal_failure` | Service maps to `temporarily_unavailable`; rollback preserves the row when transaction has not committed. Request terminates with the existing failure handling. | Assuming absence, leaking internals or inventing a retry policy from the word “retryable”. |
| Unknown outcome, including lost response around commit | Preserve uncertainty; workflow performs no automatic retry. Verification uses authoritative inspection in the existing integration environment. | Declaring success or rollback merely from transport loss. No recovery endpoint is authorized. |
| Audit failure | Transaction rolls back; service applies existing failure classification. | Successful unaudited removal. |
| Entry point disabled | New requests stop; committed deletion remains irreversible. | Restoration promise or migration rollback. |

Null, expiry, revocation states for exports, queues and cleanup lifecycles are not introduced. Existing session rechecks remain applicable; no new session-error aliases are defined.

## Acceptance and high-risk verification map

Nina owns all future checks below using the existing package integration setup, real database state and principal probes. These are executable test descriptions, not recorded passes. Each applicable row is ready for planning with no deletion blocker; source authority is inherited from the referenced requirements. Removing the row's constraint permits its listed negative oracle.

| Matrix row | Applicability, authoritative contract and layer | Smallest acceptance check / negative oracle |
| --- | --- | --- |
| HRB-01 | Applicable: PRD-EXPORT/Elena and ARCH-EXPORT/Marco; R1–R3, R12–R15. Command idempotency belongs to the owner/export pair and committed absence. No money ledger, fingerprint or new replay record is needed. | T1: owner deletes, reloads authoritative absence, then repeats with success. Fail on surviving row or rejection of the repeat. |
| HRB-02 | Applicable: ARCH-EXPORT/Marco; R12–R14. One keyed row is locked, so no multi-resource ordering is introduced. | T2: overlapping same-owner transactions produce winner deletion and loser success after absence; rollback case preserves row. Fail on loser conflict or partial state. |
| HRB-03 | Applicable: ARCH-EXPORT/Marco; R5–R6, R11. Database ACL closure covers all application principals; no elevated exception or new SECURITY DEFINER mode is selected. | T3: owner/other/unauthenticated and any existing elevated application principal attempt direct read and delete; all denied. Through service, other user gets opaque not_found and cannot read/delete; reload original row. Fail on any bypass. |
| HRB-04 | Applicable: SEC-EXPORT/Sara; R7, R9–R10. Admission middleware then in-transaction owner/session recheck. | T4: rejected auth never enters function; change effective session/ownership between admission and transaction check using existing setup; no unauthorized effect. Fail if admission check alone suffices. |
| HRB-05 | Applicable: ARCH-EXPORT/Marco; R16–R17. Existing adapter owns database/SQLSTATE classification; no guessed SQLSTATE map. | T5: exercise each existing adapter failure class through function and verify temporarily_unavailable, no internals and no false success. Confirm authoritative row preservation after known rollback. |
| HRB-06 | Applicable: PRD-EXPORT/Elena, ARCH-EXPORT/Marco; R3, R14–R18. Absence, unavailable DB and unknown commit outcome remain distinct. Null/expired/revoked export states not in accepted scope. | T6: compare authoritative absence with unavailable DB, and inject lost outcome around commit through existing integration contour. Fail on absence-success for DB failure, invented commit certainty or automatic unknown-outcome retry. |
| HRB-07 | not_applicable: PRD-EXPORT explicitly excludes money/numeric payload; existing opaque string IDs are preserved. | No numeric test family. |
| HRB-08 | Applicable: SEC-EXPORT/Sara; R9. Existing cookie request-integrity check unchanged. | T7: existing valid CSRF request passes; existing failed-CSRF cases never enter function or change state. Fail on bypass; no new signed-body/body-limit scheme. |
| HRB-09 | Applicable: SEC-EXPORT/Sara; R19–R22. Transactional access-accountability event with bounded payload, existing correlation and retention owner. | T8: reload committed audit with only the three allowed fields after deletion; force audit failure and reload unchanged row. Fail on partial commit or extra data. Inspect unchanged retention policy/ownership. |
| HRB-10 | Applicable: PRD-EXPORT/Elena, ARCH-EXPORT/Marco, SEC-EXPORT/Sara; state table above and R14–R18, R21–R25. | T9: execute known rollback, both adapter failures, unknown outcome and disablement cases; inspect state and next-action behavior. Fail on automatic unknown retry, unauthorized cleanup, requests admitted after disablement or presumed restoration. Create/expiry/external finalization are outside this slice. |
| HRB-11 | Applicable: all deletion sources; ownership, success-after-commit and atomic audit/deletion invariants. | T1–T8: assertions couple response, export state, audit state and principal. Any successful response without committed deletion or unauthorized state change fails acceptance. |
| HRB-12 | Applicable: SEC-EXPORT/Sara, EXPORT-CONTRACT; R8, R23–R24. Existing schema owns symbols at service/public boundary. | T10: validate actual responses for success, not_found, unauthenticated, invalid_request and temporarily_unavailable against owning schema; reject aliases and added fields/symbols. Check no new endpoint or migration. |

At least one production-equivalent integration round trip follows this complete path: authenticated owner request with opaque exportId → existing schema validation and middleware → transaction owner/session recheck and keyed lock → canonical row removal plus audit commit → existing response projection → consumer receives `{deleted:true}` → fresh authoritative database reload shows absence and committed audit. Nina owns each transition. Actor/session changes, malformed input, concurrent same-owner requests and adapter/audit faults are the dimensions that can change its result. A failure at any transition, an alias at projection, or contradictory reload falsifies the chain. There is no new normalization rule or DTO: existing EXPORT-CONTRACT controls both. T1 supplies the positive chain; T2–T8 supply its negative probes. Mocks, schema presence and response assertions alone cannot close acceptance.

## Optional external archive slice

PRD-DELIVERY-EXT (Elena, accepted) supports only this intent: an account owner may explicitly initiate delivery of existing export content to an external archive service in a separate optional next slice. It is not part of deletion readiness and supplies no external contract.

Conditional provider readback is **blocked**: provider and public symbols, owning provider contract, direct dependencies, upstream preconditions, adapter owner, application profile owner and admission policy are unchosen. No accepted adapter/application boundary or inherited limits/error/format member set exists to enumerate. Therefore no supported negative oracle or real-provider verification contour can yet be specified; inventing one would choose the contract. Marco owns disposition through architecture-engineer. Once those owners and boundaries are accepted, spec-engineer can specify exact signatures, canonical member coverage and negative oracles with a named downstream implementation/evidence owner. The unblock condition is that accepted architecture and provider contract, not a guessed integration wrapper or simulated provider success.

## Limits and completion

Deletion has no blocking source decision for delivery-planner. Runtime evidence remains absent because this task authorizes specification only; acceptance is future work. No code, tests, new harness, migration, queue, bulk operation, public endpoint, numeric payload, money, automatic unknown-outcome retry, provider adapter or external delivery has been implemented or authorized by this document. Audit deletion and export-content restoration are excluded. The supplied accepted decisions support Nina implementing deletion independently; the external slice remains blocked only at its dependent handoff.
