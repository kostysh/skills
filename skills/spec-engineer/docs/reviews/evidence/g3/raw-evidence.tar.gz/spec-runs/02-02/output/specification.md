# Private export deletion and optional archive-delivery boundary

## Scope and handoff

**Deletion: ready for delivery-planner, for service owner Nina.** **Optional archive delivery: blocked for implementation**, pending Marco’s architecture disposition. This document specifies behavior; it is not a delivery plan or evidence of implemented capability.

Parent intent: an account owner controls deletion of their saved private exports without granting another user access or reporting an uncommitted deletion as complete. Scope is the existing authenticated service operation in one backend module. Risk is high because authorization, private data, irreversible deletion and transactional audit are involved.

Authority: Elena accepted PRD-EXPORT (product deletion behavior) and PRD-DELIVERY-EXT (separate optional delivery intent); Marco accepted ARCH-EXPORT (existing architecture and failure contract); Sara accepted SEC-EXPORT (authentication, integrity, transactional audit and retention). EXPORT-CONTRACT, identified by SEC-EXPORT, owns the existing request and response symbols. These stipulated facts are the complete design inputs, not deployed observations. No further approval is needed for this specification. No repository IDs or conventions beyond supplied source IDs are assumed.

Current implementation behavior is not supplied. The target below is therefore an accepted behavior contract, not a claim that a particular current defect exists. Preserve the existing module, database transaction, adapter classification, session-cookie integrity middleware and public contract. No schema or compatibility migration is required.

Terms: **owner** is the authenticated account owner of the target private export; **other user** is a different authenticated user; **absence** is authoritative database absence rather than failure to read; **success** is `{deleted:true}` after transaction commit; **unknown outcome** means the caller cannot establish whether commit occurred. IDs remain existing opaque strings.

Capability: given an authenticated owner and a valid request passing existing integrity checks, deletion removes the saved row atomically and returns success only after commit; a repeated same-owner deletion succeeds on authoritative absence. A different user receives opaque `not_found` and gains no read or delete access.

The existing transaction, key, lock, contract and audit are supporting mechanisms. Their presence alone cannot demonstrate this capability. Authorized work here is only this Markdown artifact. The smallest verification contour is the existing package integration setup using service requests, database state readback and principal probes; no new harness or runtime layer is required.

## Atomic requirements and authority

All requirements below are **explicit**, applying only to the supplied deletion operation. Each row names its accepted basis. The final column states why it is necessary by identifying a prohibited observation if removed; it also supplies the removal falsifier. Verification references point to the acceptance inventory below.

| ID | Accepted basis / owner | Requirement | Necessity / removal falsifier; verification |
| --- | --- | --- | --- |
| R1 | PRD-EXPORT / Elena | The operation MUST atomically remove the requesting owner’s saved export row on successful deletion. | Success with row remaining breaks owner deletion; V1. |
| R2 | PRD-EXPORT / Elena | The operation MUST return `{deleted:true}` for a repeated deletion by the same owner on authoritative absence. | Repeat fails despite completed deletion; V2. |
| R3 | PRD-EXPORT / Elena | The operation MUST NOT return success before its transaction commits. | Commit failure accompanied by success violates completion semantics; V4. |
| R4 | PRD-EXPORT / Elena | A different authenticated user MUST receive existing opaque `not_found`. | Different outcome discloses an unauthorized distinction; V3. |
| R5 | PRD-EXPORT / Elena | A different authenticated user MUST NOT read the export through this operation. | Private contents exposed; V3. |
| R6 | PRD-EXPORT / Elena | A different authenticated user MUST NOT delete the export. | Another owner’s row disappears; V3. |
| R7 | PRD-EXPORT / Elena | An unauthenticated request MUST receive `unauthenticated`. | Request admitted without authentication; V3. |
| R8 | SEC-EXPORT / Sara | Existing authentication middleware MUST pass before function entry. | Function executes before authentication; V3. |
| R9 | SEC-EXPORT / Sara | Existing CSRF middleware MUST pass unchanged before function entry. | Failed integrity check reaches the operation; V3. |
| R10 | SEC-EXPORT / Sara | The service MUST recheck owner and session inside the transaction. | Stale admission context authorizes a mutation; V3. |
| R11 | ARCH-EXPORT / Marco | The operation MUST use the existing unique `(owner_id, export_id)` key and transaction row lock as its serialization point. | Same-key requests bypass accepted serialization; V2. |
| R12 | ARCH-EXPORT / Marco | A losing concurrent same-owner deletion MUST succeed on observed absence. | Losing request incorrectly fails; V2. |
| R13 | ARCH-EXPORT / Marco | Transaction rollback MUST leave the export row unchanged. | Failed transaction loses the row; V4. |
| R14 | ARCH-EXPORT / Marco | Direct table access MUST be denied to every application principal without elevated exceptions. | Any principal bypasses the service; V3. |
| R15 | ARCH-EXPORT / Marco | Only the existing authenticated service function MUST perform this operation. | Alternate execution surface bypasses accepted boundary; V3, V6. |
| R16 | ARCH-EXPORT / Marco | Adapter failures `retryable_unavailable` and `internal_failure` MUST map to existing public `temporarily_unavailable`. | Wrong public error or false absence; V4. |
| R17 | ARCH-EXPORT / Marco | Public failure responses MUST NOT disclose internal details. | Database/provider internals escape; V4. |
| R18 | ARCH-EXPORT / Marco | Malformed IDs MUST map to existing `invalid_request`. | Invalid input treated as successful absence; V5. |
| R19 | PRD-EXPORT / Elena | The workflow MUST NOT automatically retry unknown outcomes. | Lost acknowledgement triggers another operation; V4. |
| R20 | SEC-EXPORT / Sara | `export_deleted` MUST commit in the deletion transaction. | Deletion commits without its required audit; V4. |
| R21 | SEC-EXPORT / Sara | Audit payload MUST contain only actor ID, export ID and existing correlation ID. | File contents, credentials, provider fields or other data enter audit; V4. |
| R22 | SEC-EXPORT / Sara | Audit failure MUST roll back deletion. | Audit failure leaves row deleted; V4. |
| R23 | SEC-EXPORT / Sara | Existing audit retention policy and Sara’s retention ownership MUST remain unchanged. | Feature alters retention or deletes audit; V6. |
| R24 | SEC-EXPORT / Sara, EXPORT-CONTRACT | Consumers MUST preserve the existing canonical request `exportId:string`, success `deleted:true`, and errors `not_found`, `unauthenticated`, `temporarily_unavailable`, `invalid_request`, without aliases. | A canonical member is omitted or an invented alias is accepted/emitted; V5. |

Always-true invariants are R3 (commit before success), R5–R6 (owner isolation), R13 (rollback preserves row), R14 (direct-access closure), and R20–R22 (atomic bounded audit).

## State, failure and operational semantics

| Condition | Result / state | Permitted continuation within this slice |
| --- | --- | --- |
| Owner, row present, transaction commits | Row absent; transactional audit committed; success | Owner may explicitly repeat deletion through the existing service. |
| Repeated same-owner request, authoritative absence | Success; remains absent | Same idempotent behavior; no new ledger or fingerprint contract. |
| Concurrent same-owner requests | Existing key/lock serializes access; loser sees absence and succeeds | Both results evaluated after their transaction outcome. |
| Rollback, including audit failure | Row unchanged; no committed deletion audit from rolled-back work | Failure remains failure; no success or background cleanup invented. |
| Database unavailable or internal adapter failure | `temporarily_unavailable`; never infer absence | Existing classification is retained; this spec adds no retry schedule. |
| Unknown outcome / lost acknowledgement | Actual commit state may be unknown to caller | No automatic retry. Acceptance probe may inspect authoritative state; no new public status endpoint or recovery actor is introduced. |
| Malformed input / unauthorized requester | Existing rejection contract above; no deletion | No new lifecycle or retry behavior. |

There is one target row per command; no multi-row lock ordering is introduced. Absent, failed read and unknown commit are distinct. No null-as-absence convention, expiry, revocation lifecycle, queue or persistence-loss recovery protocol is supplied or added. Disabling the entry point stops new requests; it does not undo committed deletion. Existing audit retention continues independently.

## Acceptance and verification map

All execution below is future work owned by Nina using the existing package integration environment. No check has run and no runtime evidence is supplied. A response-only or mock-only pass is insufficient.

| Check | Production-equivalent contour and negative oracle |
| --- | --- |
| V1 — committed owner deletion | Begin with a saved owner row; invoke the existing authenticated path with valid integrity context; observe success, then independently reload authoritative database state and confirm absence and committed audit. Fail on success with surviving row or missing audit. |
| V2 — repeat and concurrency | Repeat V1 as the same owner; exercise simultaneous same-owner requests through the same service/key/lock. Confirm success for the loser, absence on fresh readback, and no resurrection. Observe actual transaction serialization, not only response shapes. Fail on false errors, lock bypass or persisted row. |
| V3 — principal and admission boundary | Probe owner, other authenticated user, unauthenticated caller and every application principal’s direct table access, including any elevated application role. Confirm denied read/delete and unchanged victim row; test failed CSRF and owner/session changing before transactional recheck. Fail if rejected admission reaches the function, stale identity mutates, private data appears, or direct access succeeds. Preserve existing CSRF rejection shape rather than inventing one. |
| V4 — failure and audit boundary | Exercise both adapter failure classes, rollback/commit failure, audit failure and lost acknowledgement with the existing integration facilities. Compare public outcome with authoritative row/audit state; inspect bounded payload and absence of internal disclosure. Fail on success before commit, deletion surviving rollback, audit leak, unavailable-as-absent, or automatic replay after an unknown result. A lost response after commit does not imply rollback. |
| V5 — contract preservation | Exercise valid existing opaque strings and malformed inputs, including invalid request types, through EXPORT-CONTRACT. Cover every existing success/error member on its applicable request path. Reject added aliases or numeric coercion; fail if any member is renamed, omitted, or an invalid ID becomes success. Existing validation owns exact malformed-string rules; invent no new format. |
| V6 — architecture and operational compatibility | Inspect implementation against existing module/function, key/lock and unchanged middleware/schema; exercise entry-point disablement to confirm new requests stop. Confirm committed deletion remains absent, and existing audit retention remains in force. Fail on new public entry point, migration, privileged exception or claim of undoing committed deletion. |

Cross-layer lifecycle, all owned for implementation/evidence by Nina under the source owners above: owner/other/anonymous input → existing authentication, integrity and EXPORT-CONTRACT validation (falsifier: rejected actor/type reaches function) → transactional session/owner recheck and key/lock → canonical row plus audit commit (falsifier: unauthorized or partial mutation) → existing public projection/consumer response (falsifier: alias, leak or premature success) → independent authoritative reload (falsifier: response contradicts committed state). V1 crosses this entire applicable path; V2–V5 vary actors, validity, concurrency and failure dimensions. No separate UI or downstream delivery transition is claimed.

## High-risk contract readback

Applicable rows inherit the requirements above rather than creating new scope. All deletion rows are ready for delivery-planner; executable checks remain pending. Nina owns every implementation layer and evidence contour listed here.

| Matrix row | Applicability, authority and layer | Contract, forbidden outcome and falsifier / evidence |
| --- | --- | --- |
| HRB-01 | Applicable; PRD-EXPORT Elena, ARCH-EXPORT Marco; service/transaction | Same-owner repetition and committed result, R2–R3. No ledger, fingerprint or new idempotency key is authorized. Repeat failure or uncommitted success falsifies; V2, V4. |
| HRB-02 | Applicable; ARCH-EXPORT Marco; database | Single-key row-lock serialization, loser absence success, rollback preservation R11–R13. Lock bypass or row loss on rollback falsifies; V2, V4. |
| HRB-03 | Applicable; ARCH-EXPORT Marco; database/service ACL | All application principals denied direct access, no elevated exception, sole authenticated service R14–R15. No new RLS or SECURITY DEFINER mechanism is selected. Successful negative-principal probe falsifies; V3. |
| HRB-04 | Applicable; SEC-EXPORT Sara; middleware/transaction | Admission auth plus transactional owner/session checks R8–R10. No additional assignment or delivery phase in this slice. Stale-session mutation falsifies; V3. |
| HRB-05 | Applicable; ARCH-EXPORT Marco; adapter/public mapping | R16–R17 preserve both supplied failure classes and opaque public mapping. Adapter owns lower-level database classification; no SQLSTATE list is invented. Wrong class mapping or leak falsifies; V4. |
| HRB-06 | Applicable; PRD-EXPORT Elena, ARCH-EXPORT Marco; service/DB | Authoritative absence differs from unavailable DB and unknown outcome; R2, R16, R19. Expired/revoked/null states are not supplied lifecycle states. False success or automatic unknown replay falsifies; V4, V5. |
| HRB-07 | Not applicable; PRD-EXPORT Elena | No money or numeric payload; existing opaque string IDs. No numerical contract needed. |
| HRB-08 | Applicable; SEC-EXPORT Sara; admission | Existing cookie authentication and CSRF unchanged, R8–R9. No signature/raw-byte protocol introduced. Failed-integrity admission falsifies; V3. |
| HRB-09 | Applicable; SEC-EXPORT Sara; transaction/audit | Access-accountability event `export_deleted`, bounded identifiers/correlation, commit phase, fail-closed audit, retention owner Sara; R20–R23. Partial commit or forbidden payload falsifies; V4, V6. |
| HRB-10 | Applicable; PRD-EXPORT Elena, ARCH-EXPORT Marco; service/transaction | State/continuation table controls deletion, replay, rollback, unavailable and unknown outcomes. Owner uses existing service; Nina’s integration probes read authoritative state. No cleanup worker or automatic recovery. Unauthorized continuation or inferred rollback after lost response falsifies; V2, V4, V6. |
| HRB-11 | Applicable; PRD-EXPORT Elena, ARCH-EXPORT Marco, SEC-EXPORT Sara; service/DB/audit | Commit-before-success, isolation, rollback and atomic audit invariants. A convenient success response with inconsistent persisted state falsifies; V1–V4. |
| HRB-12 | Applicable; SEC-EXPORT Sara / EXPORT-CONTRACT; validation/public consumers | R24 owns exact symbols; no aliases, new routes, pagination or DTO family. Missing/renamed canonical member falsifies; V5, V6. |

## Optional archive-delivery slice and gaps

PRD-DELIVERY-EXT authorizes only the optional intent: after explicit account-owner initiation, deliver existing export content to an external archive service. It is a separate slice, not a deletion side effect or prerequisite. Its handoff is blocked on Marco choosing the provider contract, admission policy, adapter owner and application profile owner.

Conditional provider readback: affected provider/component identities, accepted public symbols, direct dependencies, upstream preconditions, adapter capability/configuration versus application profile ownership, inherited limits/errors/formats and their preserving consumer paths are all **unsupplied**. None is guessed. Marco owns architecture disposition through architecture-engineer; after accepted ownership and boundary decisions, spec-engineer can specify exact contracts and negative member-coverage oracles for delivery-planner and the selected owners. Real provider-boundary acceptance must be chosen against that contract; no current provider evidence or executable acceptance claim is available. This blocker does not affect Nina’s deletion slice.

Anti-claims: no queue, bulk operation, money handling, public endpoint, new retry mechanism, schema migration, external adapter scaffold, audit-deletion feature or rollback of committed deletion. No exactly-once audit multiplicity claim beyond the supplied transaction requirement is introduced. No performance thresholds or external service guarantees are invented. This artifact demonstrates specification work only; implementation, runtime acceptance and release readiness remain unproven.
