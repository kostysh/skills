# Delivery plan: offline label preview

Ready for Ada and Bruno to use for the two-package delivery, once implementation is authorized. No input decision blocks planning. Implementation and verification remain future work.

## Scope and authority

One feature slice: a local user supplies a string through the public preview entry and receives the exact accepted label or rejection through the real parser. The simplest delivery path is the existing `@label/preview` → `@label/mode` dependency, with existing package tests and focused source inspection.

Baseline: [planning request](../input/task.md), Elena's explicit PRD-LABEL and Marco's ARCH-LABEL in the [original decisions](../../../spec-producer/input/task.md), the [ready architecture handoff](../../../spec-producer/output/architecture.md), and the [actual specification](../../01-01/output/specification.md). The current request accepts these decisions for this planning consumer; the architecture handoff's earlier spec-engineer stage has produced the supplied ready specification. Governance is supplied in [context](../input/context.md).

Scope delta: **unchanged** against those accepted sources. Material additions or removals: none. Unauthorized additions: none. Telemetry was never accepted and remains excluded, as recorded by the specification; its omission is not a reduction of accepted scope.

Only this Markdown plan is authorized now. Existing packages, public entries and sufficient tests are stipulated available to the future coding agent; their implementation state and test results have not been inspected. Exact runner commands and internal layout are non-blocking implementation details for Ada and Bruno to discover. No new runner, harness, wrapper, dependency, extension point or instrumentation is needed.

## Work and evidence

One slice has two bounded package tasks because ownership and public-entry verification differ. Parser work is a verifiable public contract increment supporting the preview outcome, not standalone proof of that outcome. Refer to the specification's **Behavior**, **Requirements**, **Edge cases**, and **Acceptance and verification map** for canonical shapes; this plan creates no alternative signatures.

| Task / owner / readiness | Goal and complete obligation disposition | Future evidence and return |
| --- | --- | --- |
| Parser package — Ada; **ready for Ada**; low risk; no input blocker | Deliver the canonical parser within `@label/mode`. ARCH-LABEL explicitly assigns sole public `Mode` and `parseMode` ownership, zero direct runtime dependencies, and no second accepted-mode list. PRD-LABEL's exact inputs plus that parser contract derive the specification's parser results. Preserve purity, strict matching, and rejection of every other string. Scope is this package and its existing tests; preview presentation belongs to Bruno. | Through the published parser entry, compare complete objects for both accepted modes and all specification negative witnesses. Inspect public contracts, canonical literal ownership, runtime dependencies, and execution path for I/O or persisted state. Ada returns actual check results and remaining gaps to Bruno for the slice's acceptance. Changed results, normalization, duplicated authority or side effects fail this task. |
| Preview package — Bruno; **ready for Bruno**; low risk; no start blocker | Deliver the user-facing preview through the actual imported parser. PRD-LABEL explicitly owns exact labels, invalid rejection, no trimming/case folding and no I/O or persisted state. ARCH-LABEL explicitly assigns sole public `previewLabel` ownership, direct runtime dependency only on `@label/mode`, imported `Mode` and parser, actual parser use and no second accepted-mode list. Scope is preview and its existing tests; do not redefine parser authority. | Through the published preview entry with the real parser, compare complete objects for both accepted modes and all specification negative witnesses. Inspect public exports, type/parser imports and use, direct dependency declarations, absence of transitive reliance or independent validation, and purity. Bruno returns combined preview evidence and Ada's package evidence for slice acceptance. Wrong labels, changed error, normalization, mocked-only success or duplicated validation fail. |

Both tasks retain the specification's universal invalid-string rule; finite witnesses expose likely regressions without replacing that rule. Inspect the matching logic as well as executing examples. The narrowest behavioral falsifier is an incorrect complete result for either valid mode or a rejected witness such as leading whitespace or changed case. Output examples cannot establish structural ownership or purity, so the stipulated inspection remains part of each task.

## Sequence and acceptance

Confirm the existing package entry and test commands within each owner's implementation work, then implement and verify their bounded changes. Accepted contracts are already stable; no predecessor implementation is asserted complete and no contract-design task is needed.

| Source → target | Dependency type | Gate, owner and return route |
| --- | --- | --- |
| Accepted sources and specification → both package tasks | `start` — satisfied for planning handoff | Product and architecture decisions, exact behavior, public entries and existing test contour are supplied. Ada and Bruno preserve these inputs; a discovered contradiction returns through the routes below. Current planning authority does not authorize execution. |
| Parser package → preview slice acceptance | `acceptance` — future | Ada supplies parser and structural evidence; Bruno exercises string → public preview → real imported parser → returned label/error against the same candidate package state. Missing either package's evidence keeps the complete slice unaccepted; return failure to the owning package. |

Package implementation may proceed in parallel after authorization if their write sets remain separate. This does not permit preview acceptance from a parser mock or from parser tests alone. There is no persistence, shared-record race or source-required integration order, so no additional race fixture, merge gate, deferred-owner task or operational wave is added.

## Limits and routing

Public contracts are review-sensitive, but they are already fully accepted and specified; the stipulated pure, local feature remains low risk. Ada owns contract/type and test evidence for mode; Bruno owns corresponding preview evidence and the complete function path. No security, tenancy, provider, data-migration, deployment or recovery task applies because PRD-LABEL excludes those boundaries. No specialist decision is outstanding.

If implementation cannot preserve package ownership, public contracts or dependencies, stop only the affected work and return the conflict to architecture-engineer and Marco. Missing detail inside an accepted boundary returns to spec-engineer. A product behavior change requires prd-engineer and Elena's disposition. Internal layout or exact command discovery alone is not a source blocker.

Planning self-check: both directions of source trace are covered above, all specification obligations have owners, and no architecture or behavior was invented. This plan establishes a usable delivery handoff only. It demonstrates no implemented behavior, passing tests, deployed UI or release readiness; no implementation or runtime execution was performed.
