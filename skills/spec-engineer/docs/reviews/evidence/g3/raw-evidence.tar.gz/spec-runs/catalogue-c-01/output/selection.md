Primary: architecture-engineer

The request concerns selecting an external integration boundary, assigning ownership, and explaining architectural trade-offs. Those decisions belong to architecture-engineer. Spec-engineer applies once behavior can be specified; delivery-planner requires accepted scope and an architecture handoff.
