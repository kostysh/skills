Primary skill: spec-engineer.

The request revises a function specification against accepted source authority and makes boundary behavior falsifiable, directly matching spec-engineer. It does not ask for product requirements, architecture, delivery planning, code changes, or implementation-versus-spec review.
