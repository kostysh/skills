# Offline label preview specification

## Scope and handoff

Status: **ready for delivery-planner**. Named consumer: delivery-planner, preparing work for Ada and Bruno. Blockers: none. This specification constrains the existing two-package offline preview; it is not a delivery plan or implementation.

Authority: [PRD-LABEL and ARCH-LABEL](../../../spec-producer/input/task.md) are expressly accepted by Elena (product behavior) and Marco (architecture), under the supplied [governance](../../../spec-producer/input/context.md). The [architecture handoff](../../../spec-producer/output/architecture.md) carries those decisions forward; it does not authorize additional scope. Risk is low: incorrect labels or unintended acceptance are the relevant behavioral failures in this pure in-memory feature.

Parent intent: a local preview user supplies a string and receives the exact accepted label or rejection. Existing package boundaries and public contracts remain. Current runtime behavior is not supplied; no observed defect or runtime before/after claim is made. The only revision from the brainstorming note is removal of its unaccepted telemetry obligation. Elena did not accept analytics; it cannot become a requirement through this specification.

## Behavior

Terms: a **mode** is exactly `plain` or `caption`; a **label** is its presentation, respectively `Plain` or `Caption`; **invalid input** is any other string. Inputs to the specified functions are strings; behavior for non-string callers is outside this contract.

Given a string supplied by a local preview user, `previewLabel` returns the corresponding result below through its real imported parser. Every call remains local and stateless. The parser is support for the preview capability and also has its own public caller contract; parser-only success does not establish preview success.

| Input condition | `parseMode` result | `previewLabel` result |
| --- | --- | --- |
| Exactly `plain` | `{ok:true,value:"plain"}` | `{ok:true,label:"Plain"}` |
| Exactly `caption` | `{ok:true,value:"caption"}` | `{ok:true,label:"Caption"}` |
| Every other string | `{ok:false,error:"invalid_mode"}` | `{ok:false,error:"invalid_mode"}` |

## Requirements

Each obligation below is explicit in the named accepted source, except parser result instances in the behavior table, which derive from ARCH-LABEL's parser contract and PRD-LABEL's exact valid inputs. The removal-falsifier column states why retaining each obligation is necessary within its indicated boundary.

| Source / applicability | Requirement | Necessity and removal falsifier |
| --- | --- | --- |
| ARCH-LABEL / mode public entry | `@label/mode` MUST alone own public `Mode = "plain" \| "caption"`. | Canonical type ownership fails if another package defines its own Mode authority or either member disappears. |
| ARCH-LABEL / mode public entry | `@label/mode` MUST own public `parseMode(input:string): {ok:true,value:Mode}\|{ok:false,error:"invalid_mode"}`. | Parser caller compatibility fails if its name, parameter or result contract changes. |
| PRD-LABEL + ARCH-LABEL / parser calls | `parseMode` MUST return the exact parser result selected by the behavior table. | A changed value, accepted extra string, omitted member or different error violates the accepted mode contract. |
| ARCH-LABEL / preview public entry | `@label/preview` MUST alone own public `previewLabel(input:string):{ok:true,label:"Plain"\|"Caption"}\|{ok:false,error:"invalid_mode"}`. | Public preview ownership or caller compatibility fails if relocated or changed. |
| PRD-LABEL / preview calls | `previewLabel` MUST return the exact preview result selected by the behavior table. | Wrong casing, wrong label, omitted success case or changed rejection violates Elena's accepted response. |
| PRD-LABEL / entire input path | The preview path MUST NOT trim input whitespace. | Accepting ` plain` would violate exact matching. |
| PRD-LABEL / entire input path | The preview path MUST NOT fold input case. | Accepting `Plain` would violate lowercase-only acceptance. |
| PRD-LABEL / both functions | Both functions MUST remain pure, without I/O or persisted state. | Logging, telemetry emission, network activity or state persistence would exceed the accepted local pure boundary. |
| ARCH-LABEL / mode package | `@label/mode` MUST have no direct runtime dependencies. | Any direct runtime dependency breaks the accepted package constraint. |
| ARCH-LABEL / preview package | `@label/preview` MUST directly depend only on `@label/mode`. | Any other direct runtime dependency or undeclared transitive reliance breaks the accepted boundary. |
| ARCH-LABEL / preview implementation | `@label/preview` MUST import the `Mode` type from `@label/mode`. | A local substitute abandons the accepted canonical type dependency. |
| ARCH-LABEL / preview execution | `previewLabel` MUST use the parser imported from `@label/mode`. | A second validator bypasses accepted parser ownership even if sample outputs match. |
| ARCH-LABEL / both packages | Each package MUST NOT maintain a second list of accepted mode literals. | A duplicated accepted-input authority violates canonical ownership. Preview presentation mapping does not authorize independent validation. |

No authentication, tenant data, external provider or network participates (PRD-LABEL). Internal file layout, helper names, branching and label-mapping syntax are implementation choices within these constraints.

## Edge cases

The invalid rule is universal over strings other than the two exact accepted inputs. Illustrative negative witnesses for both entries: `""`, `" plain"`, `"caption "`, `"plain\n"`, `"Plain"`, `"CAPTION"`, and `"other"`. Each yields exactly `{ok:false,error:"invalid_mode"}`. These witnesses expose empty-input acceptance, trimming, case folding and unrelated-mode acceptance; they do not replace the universal rule.

## Acceptance and verification map

Use pure calls through both published entries in the existing package test runner, as accepted in ARCH-LABEL. No new runner, harness or instrumentation is needed. All checks below are future verification, not reported execution evidence.

| Boundary / owner | Required evidence and negative oracle |
| --- | --- |
| `@label/mode` / Ada | Call the public parser for both valid strings and the negative witnesses. Compare complete returned objects to the table. Inspect public Mode and parser contracts and zero direct runtime dependencies. Missing either Mode member, any changed return field/error or accepting a negative witness fails. |
| `@label/preview` / Bruno | Call public `previewLabel` for both valid strings and the same negative witnesses, using the real imported parser. Compare complete returned objects. Either missing label, reversed mapping, different error or normalization acceptance fails. A mocked parser cannot close this boundary. |
| Package boundary / Ada for mode, Bruno for preview | Inspect public symbol ownership, preview's Mode and parser imports, actual parser use, direct dependency declarations and absence of a second accepted-mode list. Unauthorized dependency, transitive reliance, local type authority or independent validator fails even when output examples pass. |
| Pure execution / each package owner | Inspect the actual execution path for I/O and persisted state. Any telemetry emission or other side effect fails the accepted pure boundary. Functional examples alone cannot prove this structural obligation. |

Conditional package readback: input string → preview entry (Bruno) → canonical parser (Ada) → returned label or `invalid_mode` (Bruno). Upstream precondition is a string and the published mode contract; preview consumes both Mode members and preserves the parser's rejection. Mode owns `plain`, `caption` and parser rejection; preview owns the exact label format and preserves `invalid_mode`. The valid and negative cases above fail for omitted members or altered formats on either path. Both published entries are stipulated available. Provider/adapter boundaries are inapplicable because PRD-LABEL excludes external providers. High-risk backend rows are inapplicable to this accepted low-risk pure scope; only the package readback applies.

The narrow complete behavioral contour is a public preview call across the real parser boundary plus direct parser calls, with structural inspection for obligations outputs cannot prove. Persistence, reload, deployment and recovery transitions do not exist in the accepted flow.

## Anti-claims and gaps

This artifact establishes specification readiness only. It proves no implementation, test pass, deployed UI, release or runtime capability. No execution evidence was supplied or created. Telemetry and analytics are outside the accepted scope; no event payload or analytics infrastructure is specified. No new package, wrapper, extension point, persistence, migration or operational workflow is required.

No blocking product, architecture or verification decisions remain. Exact runner commands and internal layout are deliberately unspecified and remain with the future coding agents under the existing runner. If preserving a public contract or ownership boundary proves impossible, delivery-planner routes the conflict to architecture-engineer and Marco; any product behavior change belongs to Elena. This handoff grants no authority to redesign either domain.
