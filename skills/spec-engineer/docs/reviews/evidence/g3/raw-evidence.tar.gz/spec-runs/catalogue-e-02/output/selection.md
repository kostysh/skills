Primary: spec-conformance-reviewer

The request compares an implementation with an accepted specification and asks for mismatches, which is implementation-versus-spec review. spec-engineer owns specification authoring; the accepted specification must remain unchanged.
