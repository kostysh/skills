Primary skill: delivery-planner

The request is to sequence accepted scope, architecture, and a ready specification into executable implementation tasks with dependencies and verification owners. This is delivery planning. spec-engineer defines implementation-ready requirements, while architecture-engineer defines architectural decisions; neither owns the requested implementation breakdown.
