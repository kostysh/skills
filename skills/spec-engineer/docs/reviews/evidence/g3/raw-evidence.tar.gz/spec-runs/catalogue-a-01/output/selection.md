Primary: spec-engineer

The request is to translate accepted API behavior and errors into a concise, falsifiable software specification for a coding agent, which directly matches spec-engineer. Architecture is already accepted; no architecture redesign, delivery sequencing, product discovery, code conformance review, or TypeScript implementation is requested.
