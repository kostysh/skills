# Architecture handoff: offline label preview

Status: `ready`; blockers: none. Next owner: `spec-engineer`.

## Authority and scope

This is a low-risk, component-level handoff of already accepted architecture, not a new architecture decision. [PRD-LABEL and ARCH-LABEL](../input/task.md) provide the complete stipulated input. [Governance and evidence boundary](../input/context.md) establish Elena as product decision owner and Marco as architecture decision owner. Their accepted decisions suffice for spec authoring; these facts are not observations of deployed software.

The intended capability is a local preview user entering a string and receiving the exact accepted label or rejection. This artifact preserves constraints for a specification consumer; it does not implement the capability, execute tests, or demonstrate runtime verification. Only this Markdown handoff is in scope. No architecture choice remains open, so a new ADR, alternatives exercise, spike, or implementation backlog is unnecessary.

## Inherited product constraints — PRD-LABEL

Elena explicitly accepted these behaviors for the entire local preview path:

- Only exact lowercase `plain` and `caption` are valid. Neither trimming nor case folding is allowed.
- Valid preview results are respectively `{ok:true,label:"Plain"}` and `{ok:true,label:"Caption"}`.
- Every other string returns `{ok:false,error:"invalid_mode"}`.
- No I/O, persisted state, authentication, tenant data, external provider, or network is involved.

These are inherited product requirements, not architecture-authored additions. Removing exact matching or the error constraint would allow the preview to accept or report values contrary to PRD-LABEL; removing purity would exceed its accepted capability boundary.

## Inherited architecture constraints — ARCH-LABEL

Marco explicitly accepted the existing two-package boundary:

| Package | Sole public ownership | Direct runtime dependencies | Module and verification owner |
| --- | --- | --- | --- |
| `@label/mode` | `Mode = "plain" \| "caption"`; `parseMode(input:string): {ok:true,value:Mode}\|{ok:false,error:"invalid_mode"}` | None | Ada |
| `@label/preview` | `previewLabel(input:string):{ok:true,label:"Plain"\|"Caption"}\|{ok:false,error:"invalid_mode"}` | Only `@label/mode`; imports its `Mode` type and parser | Bruno |

No package may maintain a second list of accepted mode literals. The shortest accepted flow is input string → `previewLabel` → imported `parseMode` → label or the accepted rejection. `@label/mode` is the canonical authority for accepted modes; preview owns their presentation. Both published entries are available to the future coding agent.

These explicit constraints apply to both packages and protect canonical mode ownership and one-way dependency direction. Dropping them could let preview independently redefine accepted modes or introduce dependencies contrary to ARCH-LABEL. Their architectural force is preserving existing package ownership with the smallest direct in-memory flow. Confidence in the inherited disposition is high because it is stipulated accepted input; implementation conformance is unverified.

## Architecture handoff item (`architecture_handoff_item`)

- `kind`: `spec_candidate`
- `status`: `ready`
- `blockers`: `[]`
- `linked_prd`: [PRD-LABEL](../input/task.md)
- `linked_decision`: [ARCH-LABEL](../input/task.md)
- `next_stage_owner`: `spec-engineer`
- `expected_next_output`: implementation-ready behavior specification and verification map covering both packages, retaining their accepted public contracts, dependency limits, canonical mode ownership, strict input behavior, and pure execution boundary.
- `acceptance_constraints`: parser-only checks cannot establish preview behavior; successful output examples alone cannot establish rejection strictness or package ownership. Preserve both behavioral and structural obligations.
- `required_validation`: future pure function calls through both published entries in the existing package test runner must exercise the complete accepted behavior, including both valid modes and rejected strings that expose trimming, case folding, or other unintended acceptance. Exercise preview with its real imported parser. Inspect public exports, type/parser imports, direct runtime dependencies, and absence of a second accepted-mode list. Ada owns parser-package verification; Bruno owns preview-package verification.
- `not_prescribed`: internal file layout, helper names, local branching or label-mapping syntax, test file names, and exact runner commands. Public package names, types, function names, and signatures above are already prescribed by ARCH-LABEL.

The narrow behavioral falsifier is an unexpected returned object for an exact valid input or an invalid string such as ` plain` or `Plain`. Structural inspection separately falsifies duplicate ownership or unauthorized dependencies; output-only checks can miss those defects. The existing runner is sufficient by ARCH-LABEL, so no new harness, runtime seam, instrumentation, or runner change is needed. Persistence, reload, network, and deployment checks do not apply to this pure local function boundary.

No product or architecture decision is awaiting approval. Actual implementation and verification remain future work. If specification or implementation cannot preserve the accepted contracts, dependency direction, or canonical mode ownership, return that conflict to `architecture-engineer` and Marco; changes to product behavior belong to Elena. This handoff itself grants no authority to redesign them.
