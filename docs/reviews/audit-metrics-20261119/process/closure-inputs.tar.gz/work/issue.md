# Issue

## Language

Русский.

## Issue ID

`issue-20260810-1`

## Title

Требовать наблюдаемый отказ, точный источник material scope и bounded task switch

## Skill

`implementation-discipline` (`skills/implementation-discipline`)

## Context

В нескольких независимых delivery incidents агент начинал material mutation по
правдоподобной backend или contract hypothesis до воспроизведения сообщённого
failure path, принимал broad future source за authority новой boundary либо
переносил conclusions соседней задачи через длинный task context.

External provenance зафиксирован в accepted Aequitas retrospective и delivery
plan. Он объясняет origin issue, но не становится обязательной зависимостью
portable skill и не должен появляться в будущей active guidance.

Этот issue является supporting planning artifact по repository `AGENTS.md`.
Оператор разрешил execution T02 и выбрал `PR-before-integration`, но active
skill mutation остаётся заблокирована до нового independent `PASS` exact
current issue/plan snapshots.

## Problem

Текущий skill уже требует observable outcome, source-authorized scope, narrow
verification и stop после sufficient solution. Этого недостаточно для трёх
точных decision points:

1. Для bug/interactive correction отсутствует обязательный pre-mutation gate,
   который фиксирует actor, exact steps/path, actual failure и relevant
   network/persisted state, а затем требует same-path final witness.
2. Для новой `capability/route/domain/workflow/config boundary` generic source
   authority не требует exact operator decision или owning requirement locator
   до material addition.
3. При task switch нет compact `source / scope / state / next action` handoff,
   поэтому long-root conclusions могут ошибочно стать authority соседней task.

Ожидаемое поведение: агент сначала доказывает exact failure path либо честно
фиксирует evidence gap; material addition трассируется к exact owning locator;
новая task не наследует чужой scope; после direct proof агент останавливается.

Фактическое поведение current contract допускает hypothesis-first mutation,
broad-source expansion и cross-task carry-over, хотя более общие правила
source authority и surgical diff присутствуют.

## Evidence

- External provenance:
  `Aequitas-ADR/app@c4dea5920e29526bd10a1694c440537db2fc27b2:docs/delivery/plans/DP-0010-project-remediation-and-development-acceleration-plan.md`,
  SHA-256
  `e7160b9de52e30a60f90a4762e363fe0a48fb701eab45bf469525ecb816da3f2`,
  sections `T02`, `5.3`, `CP1`.
- External provenance:
  `Aequitas-ADR/app@c4dea5920e29526bd10a1694c440537db2fc27b2:docs/validation/retrospectives/RETRO-0004-issue-272-session-analysis.md`,
  SHA-256
  `0a14845e512cd4f4b8ed211038891207d3b379be717d5a61c7d48c4281dd78a6`,
  findings `P-001`, `P-002`, `P-006` and recommendations `R-001`, `R-002`,
  `R-006`.
- Skills repository planning base:
  `origin/master@0fd0c424371091494c79dcc30996bcd8c7ec8d08`.
- Current source:
  `skills/implementation-discipline/skill.yaml`, SHA-256
  `8da779643196790f383ea8c41af1d041d684f7c6ef5c819c826d015134b12f49`,
  source version `0.2.1`.
- Current generated surface:
  `skills/implementation-discipline/SKILL.md`, SHA-256
  `0246f124de2842ca5f9562290d6f177f5cd1df7a453245401266398b63800f61`.
- Baseline compiler readback: `lint OK`, `check OK`.
- Planning-only source candidate: `T02.md`, SHA-256
  `83f9606ac105fbf0cd2648fb2f87aedad0ac0f4c5555ca4242bdd79e4bfa4d63`.

## Impact

- Агент может исправить соседнюю hypothesis, сохранив исходный visible defect.
- Broad roadmap или integration appearance может молча расширить code/spec
  surface без owning authority.
- Task switch может смешать owners и привести к cross-task mutation.
- Green narrow checks и generated documentation могут создать false confidence,
  хотя behavioral failure path не закрыт.
- Operator рискует снова стать первым человеком, который проверяет exact path.

## Scope

Входит:

- conditional pre-mutation witness для bug/interactive correction;
- same-path final witness;
- exact owning locator для каждой material addition названных классов;
- compact task-switch handoff;
- direct-fix stop, который оставляет adjacent work finding/handoff;
- source-first update и patch source-version bump.

Не входит:

- обязательный browser witness для non-interactive tasks;
- project-specific terminology или Aequitas workflow rules в active guidance;
- universal provenance registry, tracker, runtime, CLI, harness или telemetry;
- изменение других skills, repository CI, branch policy или dependencies;
- отмена existing reviews, gates или task tracking.

## Proposed Resolution

Изменить только structured source `skills/implementation-discipline/skill.yaml`
и regenerated compiler-owned outputs.

Active contract должен:

- выбирать exact observable witness для bug path; browser используется только
  когда failure действительно interactive;
- до material addition требовать exact operator decision или owning
  requirement locator, а при conflict/missing authority — stop;
- при task switch передавать `source / scope / state / next action` либо
  начинать новый root без наследования conclusions;
- после direct fix и narrow proof останавливать unrequested adjacent work.

Формулировки остаются environment-neutral и не ссылаются на external
provenance.

## Alternatives Considered

- Добавить Aequitas-specific rule. Отклонено: skill должен быть portable.
- Создать universal provenance registry. Отклонено: добавляет второй mutable
  source truth и process overhead.
- Требовать browser для каждой bug task. Отклонено: non-interactive failure
  часто имеет более точный test/log witness.
- Добавить отдельный active reference. Не выбран по умолчанию: mandatory gate
  должен быть reachable из root `SKILL.md`, а текущего size budget достаточно.
- Оставить current generic rules. Отклонено: они не защищают exact observed
  failure, one-locator material addition и task-switch boundary.

## Destructive Side Effects

- Gate может пере-блокировать задачи без browser. Mitigation: witness выбирается
  по реальному failure path; browser conditional.
- Locator rule может стать бюрократическим для trivial edit. Mitigation: он
  применяется только к material addition названных boundary classes.
- Task-switch handoff может добавить лишний artifact. Mitigation: handoff
  compact и может оставаться в текущем conversation; registry не требуется.
- Duplicate wording может увеличить cognitive load. Mitigation: одна canonical
  active location и author self-check на duplication/precedence.
- Data migration, runtime compatibility и destructive filesystem effects
  отсутствуют: skill documentation-only.

## Verification

- Issue и implementation plan входят в supporting planning surface; до active
  mutation их exact current snapshots должны независимо получить `PASS`.
  Execution T02 уже разрешён, но не отменяет этот P1 gate.
- Compiler contour: `lint → regenerate → check`.
- Source/generated parity, `git diff --check`, portability и size readback.
- Isolated emitted-package compile.
- Blind baseline/candidate cases:
  interactive symptom + plausible backend hypothesis; ambiguous future
  workspace; trivial direct fix; long-context task switch; non-interactive
  deterministic failure.
- Candidate должен block hypothesis-first mutation, unsourced addition и scope
  carry-over, но не изобретать browser requirement для non-interactive case.
- Independent `skill-reviewer change PASS` на stable content hash.
- Repository `pnpm test:ci` и matching-SHA workflow после отдельно approved push.
- Closure после accepted remote integration требует successful workflow на
  exact remote-master OID, затем safe fast-forward local `master`. Dirty,
  foreign или diverged local state блокирует closure без stash/reset/clean.
- `Done` и final evidence допустимы только после exact readback
  `local master = origin/master = accepted OID`, clean status и отсутствия
  in-progress Git operation.


## Независимое заключение

[Запись проверки](../inbox/return.json).
