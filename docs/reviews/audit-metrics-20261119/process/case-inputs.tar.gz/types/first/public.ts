import { labelSchema } from "./protocol.ts";

type Parsed = Extract<ReturnType<typeof labelSchema.decode>, { ok: true }>["value"];

export function readParcel(raw: unknown): Parsed | null {
  const decoded = labelSchema.decode(raw);
  if (!decoded.ok) return null;
  return raw;
}
