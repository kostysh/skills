"""Read the actual delivered Markdown and compare the subject project with its initial inventory."""
import argparse
import hashlib
import json
import shutil
import tempfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("key", type=Path)
opts = p.parse_args()

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

for row in json.loads(opts.key.read_text()):
    receipt = Path(row["receipt"])
    if not receipt.is_absolute():
        receipt = opts.key.parent / receipt
    dispatch = json.loads((receipt / "dispatch.json").read_text())
    result = json.loads((receipt / "result.json").read_text())
    assert result["exit"] == 0 and (receipt / "answer.md").is_file()
    project = Path(dispatch["project"])
    index = dispatch["input_files"]
    with tempfile.TemporaryDirectory(prefix="observation-") as td:
        observed = Path(td)
        shutil.copytree(project, observed / "work")
        shutil.copyfile(receipt / "answer.md", observed / "answer.md")
        after = {str(f.relative_to(observed / "work")): sha(f)
                 for f in sorted((observed / "work").rglob("*")) if f.is_file() and ".git" not in f.parts}
        changed = sorted(f for f in set(index) | set(after) if index.get(f) != after.get(f))
        assert changed == result["changed"]
        materials = [f for f in index if f.startswith("materials/")]
        expected = {"ordinary": "handoff.md", "holdout": "review.md", "boundary": None}[row["case"]]
        note = "answer.md" if expected is None else "work/" + expected
        delivered = observed / note
        data = {"input_files_verified_unchanged": sorted(f for f in index if index[f] == after.get(f)),
                "source_materials_with_changed_bytes": sorted(f for f in materials if index[f] != after.get(f)),
                "all_project_paths_changed": changed,
                "requested_output": "chat response" if expected is None else expected,
                "delivered_readable": delivered.is_file() and bool(delivered.read_text().strip()),
                "readback_bytes": delivered.stat().st_size if delivered.is_file() else 0,
                "readback_sha256": sha(delivered) if delivered.is_file() else None}
        (receipt / "observer.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
        print(row["label"], row["case"], changed, data["readback_sha256"])
