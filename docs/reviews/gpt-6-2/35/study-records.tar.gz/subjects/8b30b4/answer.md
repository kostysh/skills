**Maple к выпуску для учебной смены не готова.** Сохранение через `notificationSettings.save` прошло все три проверки, но в выданном ASAR экран содержит только заголовок `Maple notifications`. В нём нет полей формы и кнопки сохранения, поэтому оператор не может выполнить сценарий из условий приёмки. [Условия приёмки](/tmp/casework-_ib66shp/desk.md#L1) · [Экран приложения](/tmp/casework-_ib66shp/distribution/index.html#L1)

| Частота | Результат `save` | Повторное чтение в main |
|---|---|---|
| `daily` | Промис выполнен со значением `undefined` | Одна запись с `desk@example.invalid`, `enabled: true`, `frequency: daily` |
| `weekly` | Промис выполнен со значением `undefined` | Одна запись с `desk@example.invalid`, `enabled: true`, `frequency: weekly` |
| `monthly` | Промис отклонён с сообщением `Settings could not be saved.` | Ноль записей, сохранённых данных нет |

Во всех трёх прогонах `notificationSettings` предоставлял только метод `save`. Диспетчер запускал выданный ASAR на Linux x64 с Electron 45.0.0 и пустым профилем. Он вызывал `save` напрямую из renderer и сообщал `appArchive: true`, `packaged: false`. Эти прогоны подтверждают работу сохранения из ASAR. Запуск готового упакованного приложения для смены остаётся неподтверждённым. Подпись и другие платформы вне приёмки. Файлы не менялись. [Способ запуска](/tmp/casework-_ib66shp/launch.md#L1)