**Выпуск Oak для указанной смены не готов.** Сборка отклоняет допустимую частоту `weekly`. Кроме того, в HTML выданного ASAR есть заголовок `Oak notifications`, а полей формы и кнопки сохранения нет. [Критерии приёмки](/tmp/casework-eeegxgku/desk.md) · [HTML окна](/tmp/casework-eeegxgku/distribution/index.html:1)

| Частота | Результат `notificationSettings.save` | Повторное чтение в `main` |
|---|---|---|
| `daily` | Промис разрешился со значением `undefined` | Одна запись с точными значениями `desk@example.invalid`, `true`, `daily` |
| `weekly` | Промис отклонён с сообщением `Settings could not be saved.` | Ноль записей. По условиям приёмки запись должна сохраниться |
| `monthly` | Промис отклонён с тем же сообщением | Ноль записей, как и требуется |

В ASAR обработчик сохранения допускает только `daily`. Во всех трёх запусках объект `notificationSettings` показал один метод `save`, `window.require` был `undefined`, песочница и изоляция контекста были включены. [Обработчик сохранения](/tmp/casework-eeegxgku/distribution/main.cjs:10)

**Граница проверки.** Локальный диспетчер запустил выданный ASAR в Electron 45.0.0 на Linux x64 с пустым профилем для каждого варианта. Он вызвал метод из renderer и повторно прочитал данные в `main`. Диспетчер вернул `appArchive: true` и `packaged: false`, поэтому результат относится к запуску ASAR. Установочный пакет не проверялся. Подпись и другие платформы вне приёмки. [Порядок запуска](/tmp/casework-eeegxgku/launch.md)