**Maple к указанной смене не готова.** Сохранение настроек через `notificationSettings.save` прошло все три проверки. В выданном ASAR экран содержит только заголовок `Maple notifications`. Полей и кнопки сохранения нет, поэтому оператор не может выполнить сценарий из [desk.md](/tmp/casework-926jlbtz/desk.md).

| Частота | Результат в renderer | Повторное чтение в main |
|---|---|---|
| `daily` | Промис выполнился с `undefined` | Одна запись: `desk@example.invalid`, `true`, `daily` |
| `weekly` | Промис выполнился с `undefined` | Одна запись: `desk@example.invalid`, `true`, `weekly` |
| `monthly` | Промис отклонён с `Settings could not be saved.` | Ноль записей, данных нет |

Во всех трёх запусках `notificationSettings` предоставлял только `save`, а `window.require` был `undefined`. Sandbox и изоляция контекста были включены.

**Граница проверки.** Диспетчер из [launch.md](/tmp/casework-926jlbtz/launch.md) запускал выданный ASAR на Linux x64 с Electron 45.0.0. Каждый вариант выполнялся в новом окне с пустым профилем. Проверка вызывала метод напрямую из renderer. Диспетчер сообщил `appArchive: true` и `app.isPackaged: false`, поэтому запуск в режиме упакованного приложения остался неподтверждённым. Подпись и другие платформы вне приёмки.