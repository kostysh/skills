**Выпуск Oak для указанной смены не готов.** Обязательный вариант `weekly` отклоняется, а в выданном ASAR страница содержит только заголовок `Oak notifications`. Полей формы и кнопки сохранения в ней нет. [Критерии смены]( /tmp/casework-zldwliss/desk.md) · [Страница приложения](/tmp/casework-zldwliss/distribution/index.html)

| Частота | Результат `notificationSettings.save` | Повторное чтение в `main` |
|---|---|---|
| `daily` | Промис выполнен со значением `undefined` | Одна запись с точными значениями `desk@example.invalid`, `true`, `daily` |
| `weekly` | Промис отклонён с ошибкой `Settings could not be saved.` | 0 записей, `null` |
| `monthly` | Промис отклонён с той же ошибкой | 0 записей, `null` |

Во всех трёх запусках объект `notificationSettings` предоставлял только метод `save`. Обработчик в `main` принимает только `daily`, что объясняет отказ для `weekly`. [Обработчик сохранения](/tmp/casework-zldwliss/distribution/main.cjs)

Проверка охватила три выданных сценария через локальный диспетчер на Linux x64 с Electron 45.0.0. Диспетчер подтвердил загрузку ASAR (`appArchive: true`) и вызов метода из renderer. Во всех запусках `packaged` был `false`, поэтому запуск в режиме упакованного приложения остался неподтверждённым. Подпись и другие платформы были вне приёмки. [Способ запуска](/tmp/casework-zldwliss/launch.md)