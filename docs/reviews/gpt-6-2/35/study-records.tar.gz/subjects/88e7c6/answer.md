**Выпуск Alder не готов к указанной смене.** По [desk.md](/tmp/casework-ixd0z4k8/desk.md) частота `monthly` должна отклонять промис и оставлять хранилище без записи. В проверке промис выполнился с `undefined`, а процесс `main` записал и прочитал обратно `monthly`.

| Частота | Результат `save` | Записей | Прочитанная частота | Приёмка |
|---|---|---:|---|---|
| `daily` | Выполнен с `undefined` | 1 | `daily` | Пройдена |
| `weekly` | Выполнен с `undefined` | 1 | `weekly` | Пройдена |
| `monthly` | Выполнен с `undefined` | 1 | `monthly` | Провалена |

Во всех трёх записях сохранились переданные `email: desk@example.invalid` и `enabled: true`. В `renderer` у `notificationSettings` наблюдался только метод `save`. Проверка в процессе `main` явно включает `monthly` в список допустимых частот. [main.cjs](/tmp/casework-ixd0z4k8/distribution/main.cjs:13)

Проверка охватила три вызова из `renderer` с чтением записи из `main` в Linux x64 на Electron 45.0.0. Запуск через [launch.md](/tmp/casework-ixd0z4k8/launch.md) подтвердил загрузку ASAR (`appArchive: true`) и вернул `app.isPackaged: false`. Работа в режиме `app.isPackaged: true` осталась неподтверждённой. Ручной ввод и клики не проверялись. Подпись и другие платформы были вне приёмки. Файлы не менялись, публикации не было.