**Alder не готов к выпуску для указанной смены.** Сборка принимает `monthly` и записывает настройки. По критериям приёмки промис должен быть отклонён, а число записей должно остаться равным нулю. [desk.md](/tmp/casework-q_k6_npm/desk.md)

| Частота | Результат `notificationSettings.save` | Записи | Повторное чтение в main |
|---|---|---:|---|
| `daily` | Промис выполнен со значением `undefined` | 1 | `desk@example.invalid`, `true`, `daily` |
| `weekly` | Промис выполнен со значением `undefined` | 1 | `desk@example.invalid`, `true`, `weekly` |
| `monthly` | Промис выполнен со значением `undefined` | 1 | `desk@example.invalid`, `true`, `monthly` |

Во всех трёх запусках у `notificationSettings` был только метод `save`. Песочница и изоляция контекста были включены, `window.require` был недоступен.

**Граница проверки.** Локальный диспетчер загрузил выданный ASAR в Electron 45.0.0 на Linux x64 и вызвал `save` из renderer. Он сообщил `appArchive: true` и `app.isPackaged: false`, поэтому запуск в режиме упакованного приложения не подтверждён. В HTML сборки есть только заголовок `Alder notifications`, без элементов формы. Проверка охватила вызов API сохранения и повторное чтение данных, но не сценарий оператора через форму. Подпись и другие платформы вне приёмки. Правок и публикации не было. [launch.md](/tmp/casework-q_k6_npm/launch.md) · [index.html](/tmp/casework-q_k6_npm/distribution/index.html)