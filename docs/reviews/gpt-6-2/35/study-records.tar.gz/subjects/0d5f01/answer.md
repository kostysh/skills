**Maple не готов к указанной смене.** Метод сохранения прошёл все три проверки. Операторская форма отсутствует: в `index.html` внутри выданного ASAR есть только заголовок «Maple notifications». [Критерии приёмки](./desk.md) · [Проверенный архив](/tmp/casework-uvyswiv4/distribution/shift.asar)

| Частота | Результат `notificationSettings.save` | Повторное чтение в `main` |
|---|---|---|
| `daily` | Промис выполнен со значением `undefined` | 1 запись: `desk@example.invalid`, `true`, `daily` |
| `weekly` | Промис выполнен со значением `undefined` | 1 запись: `desk@example.invalid`, `true`, `weekly` |
| `monthly` | Промис отклонён с ошибкой `Settings could not be saved.` | 0 записей, `readBack: null` |

Во всех трёх запусках `notificationSettings` предоставлял только `save`. Диспетчер подтвердил `sandbox: true`, `contextIsolation: true` и `typeof window.require === "undefined"`.

Проверка охватила выданный ASAR на Linux x64 с Electron 45.0.0. Диспетчер запускал каждый вариант с пустым профилем и вызывал `save` напрямую из renderer. Во всех результатах `appArchive: true` и `packaged: false`, поэтому запуск в режиме упакованного приложения остался неподтверждённым. Подпись и другие платформы вне приёмки. [Способ запуска](/tmp/casework-uvyswiv4/launch.md)