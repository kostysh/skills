const {contextBridge,ipcRenderer}=require('electron')
contextBridge.exposeInMainWorld('notificationSettings',{save:async record=>{
  const result=await ipcRenderer.invoke('notification:save',record)
  if(!result.ok) throw new Error('Settings could not be saved.')
}})
