const { app, BrowserWindow, ipcMain } = require('electron')
const { existsSync,readFileSync,writeFileSync } = require('node:fs')
const { join } = require('node:path')
app.enableSandbox()
const sessionData=process.argv[2], countMode=process.argv[3]
app.setPath('userData',sessionData)
app.whenReady().then(async()=>{
 const win=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,preload:join(__dirname,'preload.cjs')}})
 const file=join(sessionData,'settings.json')
 const writes=[]
 ipcMain.handle('notification:save',async(event,input)=>{
   if(event.senderFrame!==win.webContents.mainFrame) return {ok:false,reason:'invalid_window'}
   if(!input || typeof input.email!=='string' || typeof input.enabled!=='boolean' || !['daily','weekly','monthly'].includes(input.frequency))return {ok:false,reason:'frequency_or_shape'}
   const record={email:input.email,enabled:input.enabled,frequency:input.frequency}
   writeFileSync(file,JSON.stringify(record));writes.push(record)
   return {ok:true}
 })
 await win.loadFile(join(__dirname,'index.html'))
 const choices={daily:{email:'desk@example.invalid',enabled:true,frequency:'daily'},weekly:{email:'desk@example.invalid',enabled:true,frequency:'weekly'},monthly:{email:'desk@example.invalid',enabled:true,frequency:'monthly'}}
 if(!Object.hasOwn(choices,countMode))throw Error('Unknown sample')
 const sample=choices[countMode]
 const observed=await win.webContents.executeJavaScript('(async()=>({title:document.querySelector("h1").textContent,methods:Object.keys(window.notificationSettings),nodeGlobal:typeof window.require,reply:await window.notificationSettings.save('+JSON.stringify(sample)+').then(value=>({status:"fulfilled",valueType:typeof value}),error=>({status:"rejected",reason:error.message}))}))()')
 console.log('DESKTOP_READ '+JSON.stringify({platform:process.platform,arch:process.arch,electron:process.versions.electron,chrome:process.versions.chrome,packaged:app.isPackaged,appArchive:app.getAppPath().endsWith('.asar'),sandbox:win.webContents.getLastWebPreferences().sandbox,isolated:win.webContents.getLastWebPreferences().contextIsolation,observed,writes:writes.length,readBack:existsSync(file)?JSON.parse(readFileSync(file,'utf8')):null}))
 win.destroy();app.quit()
}).catch(error=>{console.error(error.message);app.exit(1)})
