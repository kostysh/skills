const { setTimeout: delay } = require('node:timers/promises');
const read = (win, fn, arg) => win.webContents.executeJavaScript('('+String(fn)+')('+JSON.stringify(arg)+')');
async function until(win, fn, arg) {
  for (let i=0; i<80; i++) {
    const value = await read(win, fn, arg);
    if (value) return value;
    await delay(80);
  }
  const state = await read(win, ()=>({docFocus:document.hasFocus(), active: document.activeElement?.outerHTML?.slice(0,240), tip:[...document.querySelectorAll('[role=tooltip]')].map(x=>x.outerHTML), status:document.querySelector('[role=status]')?.textContent}));
  throw Error('Timed out on '+fn+' with '+JSON.stringify(state));
}
module.exports = async function observe(win,openWindow,origin) {
  const route = '/settings/notifications';
  await until(win, ()=>document.querySelector('a[href="/settings/notifications"]')?.textContent);
  await read(win, ()=>document.querySelector('a[href="/settings/notifications"]').click());
  await until(win, ()=>document.querySelector('#email')?.tagName);
  const access = await read(win, ()=>({route:location.pathname,title:document.querySelector('h1').textContent,exposed:Object.keys(window.notificationSettings),nodeRequire:typeof window.require}));
  const prefs = win.webContents.getLastWebPreferences();
  const isolation = {sandbox:prefs.sandbox,contextIsolation:prefs.contextIsolation,nodeIntegration:prefs.nodeIntegration};
  win.focus();
  win.webContents.focus();
  await until(win, ()=>document.hasFocus());
  await read(win, ()=>{const b=[...document.querySelectorAll('button')].find(x=>x.textContent==='About these settings');b.blur();b.focus();return true;});
  const tooltip = await until(win, ()=>{
    const a=document.activeElement, t=document.getElementById(a.getAttribute('aria-describedby'));
    return t && {trigger:a.textContent,description:t.textContent,role:t.getAttribute('role')};
  });
  await read(win, ()=>{
    const email=document.querySelector('#email');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(email,'dispatcher@example.test');
    email.dispatchEvent(new Event('input',{bubbles:true}));
    document.querySelector('#weekly').click();
  });
  await until(win, ()=>document.querySelector('#weekly')?.getAttribute('aria-checked') === 'true');
  await read(win, ()=>[...document.querySelectorAll('button')].find(b=>b.textContent==='Review changes').click());
  const pending = await until(win, ()=>document.querySelector('[role=dialog]')?.innerText);
  await read(win, ()=>[...document.querySelectorAll('button')].find(b=>b.textContent==='Confirm').click());
  const saved = await until(win, ()=>{
    const s=document.querySelector('[role=status]')?.innerText;
    return s?.includes('Settings applied') && s.includes('dispatcher@example.test') && s.includes('Weekly') && s;
  });
  const invalid = await read(win, async ()=>window.notificationSettings.save({email:'unused@example.test',enabled:true,frequency:'monthly'}).then(()=>({state:'fulfilled'}),e=>({state:'rejected',reason:e.message})));
  const reopened = openWindow();
  await reopened.loadURL(origin + route);
  const fresh = await until(reopened, ()=>{
    const s=document.querySelector('[role=status]')?.innerText;
    return s?.includes('dispatcher@example.test') && {status:s,email:document.querySelector('#email')?.value,weekly:document.querySelector('#weekly')?.getAttribute('aria-checked')};
  });
  return {access,isolation,tooltip,pending,saved,invalid,fresh};
};
