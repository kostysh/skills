const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('notificationSettings', {
  async save(settings) {
    const accepted = await ipcRenderer.invoke('notification:save', settings);
    if (!accepted) throw new Error('Settings could not be saved.');
  },
});
