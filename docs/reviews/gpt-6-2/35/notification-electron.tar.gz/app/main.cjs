const { app, BrowserWindow, ipcMain } = require('electron');
const { join } = require('node:path');
const profile = process.argv[2];
const origin = process.argv[3];
const address = new URL(origin);
if (address.protocol !== 'http:' || address.hostname !== '127.0.0.1' || address.origin !== origin) throw Error('Invalid local settings service');
app.setPath('userData', profile);
app.enableSandbox();
let settingsWindow;
const calls = [];
function openWindow() {
  const win = new BrowserWindow({show: true, width: 600, height: 820, webPreferences: {
    sandbox: true, contextIsolation: true, nodeIntegration: false, preload: join(__dirname,'preload.cjs'),
  }});
  settingsWindow = win;
  return win;
}
function accepts(record) {
  if (!record || Object.keys(record).length !== 3) return false;
  return typeof record.email === 'string' && record.email.length <= 254 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(record.email) &&
    typeof record.enabled === 'boolean' && ['daily','weekly'].includes(record.frequency);
}
ipcMain.handle('notification:save', async (event, record) => {
  if (event.senderFrame !== settingsWindow.webContents.mainFrame || new URL(event.senderFrame.url).origin !== origin) return false;
  const valid = accepts(record);
  const call = { sender: new URL(event.senderFrame.url).pathname, record, valid };
  calls.push(call);
  if (!valid) return false;
  const response = await fetch(origin + '/api/notification-settings', {
    method: 'PUT', headers: {'content-type':'application/json'}, body: JSON.stringify(record),
  });
  call.status = response.status;
  return response.status === 204;
});
app.whenReady().then(async () => {
  const win = openWindow();
  await win.loadURL(origin);
  if (process.argv[4] === 'observe') {
    const evidence = await require('./observe.cjs')(win,openWindow,origin);
    console.log('OBSERVATION '+JSON.stringify({
      electron:process.versions.electron, chrome:process.versions.chrome, platform:process.platform,
      archive:app.getAppPath().endsWith('.asar'), isPackaged:app.isPackaged, ...evidence, calls,
    }));
    app.quit();
  }
}).catch(error => {console.error(error.stack); app.exit(1);});
