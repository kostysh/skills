from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import shutil
import json
import os
import subprocess

base = Path(__file__).resolve().parent
cli = argparse.ArgumentParser(description="Observe the notification form in a private Electron window.")
cli.add_argument("--form", type=Path, required=True, help="Extracted notification-spa archive")
cli.add_argument("--electron", type=Path, required=True, help="Installed Electron 45 Linux executable")
cli.add_argument("--xvfb-run", default="xvfb-run", help="Path to xvfb-run, if it is not on PATH")
args = cli.parse_args()
form = args.form.resolve()
executable = args.electron.resolve()
virtual_display = shutil.which(args.xvfb_run)
if not virtual_display:
    cli.error("xvfb-run is required")
env = {k:v for k,v in os.environ.items() if k not in ("DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS", "ELECTRON_RUN_AS_NODE")}
env["PATH"] = str(Path(virtual_display).parent) + os.pathsep + env["PATH"]
with TemporaryDirectory(prefix='notification-electron-joint-') as temp:
    private = Path(temp)
    for key,name in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('TMPDIR','tmp')]:
        p = private/name
        p.mkdir()
        env[key] = str(p)
    state = private/'service'
    server = subprocess.Popen(['node',str(form/'server.mjs'),'0',str(state)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    try:
        origin = json.loads(server.stdout.readline())['origin']
        args = [virtual_display,'-a','--server-args=-screen 0 900x900x24 -nolisten tcp',str(executable),str(base/'notification-desk.asar'),str(private/'profile'),origin,'observe']
        result = subprocess.run(args,capture_output=True,text=True,env=env,timeout=40)
        if result.returncode:
            raise RuntimeError(result.stderr[-3400:])
        value = next(json.loads(line[len('OBSERVATION '):]) for line in result.stdout.splitlines() if line.startswith('OBSERVATION '))
        disk = json.loads((state/'settings.json').read_text())
    finally:
        server.terminate()
        rest,errors = server.communicate(timeout=10)
    value['service'] = [json.loads(line) for line in rest.splitlines() if line]
    value['disk'] = disk
    print(json.dumps(value,ensure_ascii=False))
