Оператор открывает раздел Notification settings, получает подсказку у поля, задаёт адрес и частоту, проверяет изменения и подтверждает сохранение. Следующее открытие той же формы показывает сохранённые значения. Разрешены daily и weekly. Частота monthly должна отклоняться без изменения прежней записи. Desktop предоставляет форме единственное действие `window.notificationSettings.save({email,enabled,frequency}):Promise<void>`. Платформа текущей проверки — Linux x64.

Для учебного запуска переданы два локальных архива, новая оболочка с принятыми файлами формы и экземпляр Maple. Источники входа приведены ниже. У оператора нет запроса на отправку уведомлений или публикацию дистрибутива.

- `notification-spa.tar.gz` SHA-256 `1de3fc4e816441efa641bf9d81a1b453347b8a4a118eff8279f5ebf9ab8d127c`
- `Tooltip.js` SHA-256 `2dbb9773d492a717df9ddbcd804187d258d8d4b8c6bc26b8010c2b1047a60313`
- `Tooltip.d.ts` SHA-256 `71db6bd3785b5f25539ebb628e4d84c571c4bc07f94fedf918b6cac304c4426f`
- `notification-desk.asar` SHA-256 `b31197084d9dc4a9d9f276d9bf0628bec4e24000dcdbb5f58ebbc95496b1578d`
- `shift.asar` SHA-256 `703fb21f484b58c639cd139ccaa41bce6fd2b0c820f483d7023d0d344bca78bc`
