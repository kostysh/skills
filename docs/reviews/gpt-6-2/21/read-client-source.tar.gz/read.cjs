const {readFileSync} = require('node:fs');
const {createClient} = require('./node_modules/@supabase/supabase-js');
const [subject, operation, ...ids] = process.argv.slice(2);
if (!['worker-a','worker-b','support'].includes(subject) || !['list','get','role'].includes(operation)
    || ids.some(id => !['amber','birch','cedar','dune','missing'].includes(id))) process.exit(2);
const sessions = JSON.parse(readFileSync('/tmp/role-client/sessions.json','utf8'));
const client = createClient('http://127.0.0.1:4063','local-study-public',{
  db:{schema:'work'},accessToken:async()=>sessions[subject],
  auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}
});
(async()=>{
  const identity = await client.rpc('consumer_role');
  if (identity.error) throw Error(identity.status+' '+identity.error.code);
  const result = {session:subject,effectiveDatabaseRole:identity.data,identityStatus:identity.status};
  if (operation==='list') {
    const r = await client.from('documents').select('id').order('id');
    result.collection = {status:r.status,data:r.data,error:r.error && r.error.code};
  } else if (operation==='get') {
    result.records = {};
    for (const id of ids) {
      const r = await client.from('documents').select('id').eq('id',id);
      result.records[id] = {status:r.status,data:r.data,error:r.error && r.error.code};
    }
  }
  process.stdout.write(JSON.stringify(result)+'\n');
})().catch(e=>{process.stderr.write(e.message+'\n');process.exitCode=1;});

