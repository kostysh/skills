ALTER TABLE work.documents ENABLE ROW LEVEL SECURITY;
 GRANT USAGE ON SCHEMA work TO desk_employee,desk_support,desk_guest;
 GRANT SELECT ON work.documents TO desk_employee,desk_support;
 CREATE POLICY own_documents ON work.documents FOR SELECT TO desk_employee USING (owner_name = (current_setting('request.jwt.claims',true)::json->>'sub'));
 CREATE POLICY opted_in_documents ON work.documents FOR SELECT TO desk_support USING (support_consent);
 CREATE FUNCTION work.consumer_role() RETURNS text LANGUAGE sql STABLE SECURITY INVOKER AS 'SELECT current_user::text';
 REVOKE ALL ON FUNCTION work.consumer_role() FROM PUBLIC; GRANT EXECUTE ON FUNCTION work.consumer_role() TO desk_employee,desk_support;
 NOTIFY pgrst,'reload schema';
