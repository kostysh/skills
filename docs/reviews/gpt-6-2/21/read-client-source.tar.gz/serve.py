"""Restricted normal-operation bridge for a single disposable PostgreSQL/PostgREST instance."""
import json, pathlib, socketserver, threading, time, uuid
from concurrent.futures import ThreadPoolExecutor

private = pathlib.Path(__file__).resolve().parent
config = json.loads((private/'gateways.json').read_text())
events_file = private/'service-events.jsonl'
service_lock = threading.Lock()
def record(data):
    with service_lock, events_file.open('a') as stream:
        stream.write(json.dumps(data,ensure_ascii=False)+'\n')
class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        request = json.loads(self.rfile.readline(3600))
        who = request.get('session')
        op = request.get('operation')
        ids = request.get('identifiers')
        trace = request.get('workspace')
        if not isinstance(trace,str) or len(trace)>100: return
        result = None
        if who not in self.server.profiles:
            result = {'interfaceError':'session_not_assigned','session':who}
        elif op not in ('list','get','role') or not isinstance(ids,list) or len(ids)>8 or any(x not in ('amber','birch','cedar','dune','missing') for x in ids) or (op=='get') != bool(ids):
            result = {'interfaceError':'unsupported_read'}
        else:
            out = shell(['docker','exec','--user','postgres',name,'/tmp/role-client/node','/tmp/role-client/read.cjs',who,op,*ids],timeout=15)
            if out.returncode: result={'interfaceError':'local_interface_unavailable','message':out.stderr[:110]}
            else: result=json.loads(out.stdout)
        result['requestId']=uuid.uuid4().hex[:14]
        record({'workspace':trace,'scope':self.server.scope,'session':who,'operation':op,'identifiers':ids,'reply':result})
        self.wfile.write((json.dumps(result)+'\n').encode())
def serve():
    ok(['docker','cp',str(private/'read.cjs'),name+':/tmp/role-client/read.cjs'])
    running=[]
    try:
        for scope,entry in config.items():
            server=socketserver.ThreadingUnixStreamServer(entry['socket'],Handler)
            server.profiles=entry['sessions'];server.scope=scope
            server.daemon_threads=True
            thread=threading.Thread(target=server.serve_forever,daemon=True)
            thread.start();running.append((server,entry['socket']))
        (private/'ready.json').write_text(json.dumps({'startedAt':time.time(),'hostSocketOnly':True,
            'server':version,'seed':report['seedCount'],'api':'PostgREST 16.6','sdk':'2.119.1','scopes':list(config)})+'\n')
        while not (private/'finish').exists(): time.sleep(.4)
        report['finalSeedCount']=int(sql('SELECT count(*) FROM work.documents;').strip())
        report['finalSeedFingerprint']=sql("SELECT md5(string_agg(id || '/' || owner_name || '/' || support_consent::text, ',' ORDER BY id)) FROM work.documents;").strip()
    finally:
        for server,path in running:
            server.shutdown();server.server_close();pathlib.Path(path).unlink(missing_ok=True)

