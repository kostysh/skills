"""Read the local document desk with an assigned application session."""
import argparse
import json
import socket
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("session", choices=["worker-a", "worker-b", "support"])
parser.add_argument("operation", choices=["role", "list", "get"])
parser.add_argument("identifiers", nargs="*", choices=None, metavar="DOCUMENT")
args = parser.parse_args()
if (args.operation == "get") != bool(args.identifiers):
    parser.error("get requires one or more document identifiers; role and list take none")
profile = json.loads(Path(__file__).with_name("desk-profile.json").read_text())
request = dict(session=args.session, operation=args.operation, identifiers=args.identifiers, workspace=Path.cwd().name)
with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as conn:
    conn.settimeout(15)
    conn.connect(profile["socket"])
    conn.sendall((json.dumps(request)+"\n").encode())
    result = json.loads(conn.makefile("rb").readline(32000))
print(json.dumps(result, ensure_ascii=False))
raise SystemExit(1 if "interfaceError" in result else 0)

