const {readFileSync}=require('node:fs');
const {createClient}=require('/tmp/role-client/node_modules/@supabase/supabase-js');
const sessions=JSON.parse(readFileSync('/tmp/role-client/sessions.json','utf8'));
(async()=>{
 const report={};
 for(const [subject,session] of Object.entries(sessions)){
  const client=createClient('http://127.0.0.1:4063','local-study-public',{accessToken:async()=>session,db:{schema:'work'},auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
  const rows=await client.from('documents').select('id').order('id');
  if(rows.error)throw Error(rows.status+' '+rows.error.code+' '+rows.error.message);
  const read=await client.rpc('consumer_role');
  if(read.error)throw Error(read.error.message);
  const sample={};const checkIds=subject==='worker-a'?['amber','birch','missing']:subject==='worker-b'?['birch','amber','missing']:['birch','amber','missing'];
  for(const id of checkIds){
   const res=await client.from('documents').select('id').eq('id',id);
   if(res.error)throw Error(res.status+' '+res.error.code+' '+res.error.message);
   sample[id]={status:res.status,ids:res.data.map(r=>r.id)};
  }
  report[subject]={role:read.data,status:rows.status,ids:rows.data.map(r=>r.id),individual:sample};
 }
 process.stdout.write(JSON.stringify(report)+'\n');
})().catch(err=>{process.stderr.write(String(err.message)+'\n');process.exitCode=1;});
