"""Exercise ordinary read-only consumers of a private four-row test database. Every resource is task-owned."""
from pathlib import Path
import base64,hashlib,hmac,json,secrets,shutil,subprocess,tempfile,time,uuid
base=Path(__file__).resolve().parents[2];runtime=base/'toolchains';pkg=runtime/'supabase-client-2.119.1'
image='postgres@sha256:3a82e1f56c8f0f5616a11103ac3d47e632c3938698946a7ad26da0df1334744a'
name='skills62-doc-read-'+uuid.uuid4().hex[:12]
def shell(argv,**kwargs):return subprocess.run(argv,capture_output=True,text=True,timeout=kwargs.pop('timeout',35),**kwargs)
def ok(argv,**kwargs):
 p=shell(argv,**kwargs)
 if p.returncode:raise RuntimeError(str(p.stderr).replace(master,'[private]').replace(gateway,'[private]').replace(signing,'[private]')[:900])
 return p.stdout
def inside(args,**kw):return ok(['docker','exec',name]+args,**kw)
def sql(text):return ok(['docker','exec','-i','--user','postgres',name,'psql','-X','-q','-v','ON_ERROR_STOP=1','-At','-d','postgres'],input=text)
def b64(raw):return base64.urlsafe_b64encode(raw).decode().rstrip('=')
master=secrets.token_hex(24);gateway=secrets.token_hex(24);signing=secrets.token_hex(38)
def issue(subject,role):
 # The synthetic issuer assigns only the three preregistered fixture accounts.
 payload={'role':role,'sub':subject,'aud':'role-fixture','iat':int(time.time()),'exp':int(time.time())+600}
 parts='.'.join([b64(json.dumps({'alg':'HS256','typ':'JWT'},separators=(',',':')).encode()),b64(json.dumps(payload,separators=(',',':')).encode())])
 return parts+'.'+b64(hmac.new(signing.encode(),parts.encode(),hashlib.sha256).digest())
fixtures=json.loads((base/'handoffs/document-access/sources/documents.json').read_text())
report={'image':image,'isolation':'container network none; private loopback only; no host bind mounts','intendedPrincipals':['worker-a','worker-b','support'],'package':'@supabase/supabase-js 2.119.1','bin':'PostgREST 16.6'}
began=False
try:
 ok(['docker','run','--pull=never','--rm','--detach','--name',name,'--label','skills62.study='+name,'--network','none','--memory','480m','--pids-limit','170','--tmpfs','/var/lib/postgresql:rw,exec,mode=0750,uid=999,gid=999','--env','POSTGRES_PASSWORD='+master,image,'postgres','-c','listen_addresses=127.0.0.1'],timeout=40);began=True
 for n in range(55):
  if shell(['docker','exec',name,'pg_isready','-q','-h','127.0.0.1','-d','postgres']).returncode==0:break
  time.sleep(.3)
 else:raise RuntimeError('study database did not become ready on loopback')
 version=sql('SELECT version();').strip();report['server']=version
 sql("CREATE ROLE study_gateway LOGIN NOINHERIT PASSWORD '"+gateway+"'; CREATE ROLE desk_employee NOLOGIN; CREATE ROLE desk_support NOLOGIN; CREATE ROLE desk_guest NOLOGIN; GRANT desk_employee,desk_support,desk_guest TO study_gateway; CREATE SCHEMA work; CREATE TABLE work.documents(id text primary key,owner_name text not null,support_consent boolean not null);")
 for f in fixtures:
  assert f['id'] in ('amber','birch','cedar','dune') and f['owner'] in ('worker-a','worker-b')
  sql("INSERT INTO work.documents VALUES ('"+f['id']+"','"+f['owner']+"',"+str(f['supportConsent']).upper()+");")
 sql("""ALTER TABLE work.documents ENABLE ROW LEVEL SECURITY;
 GRANT USAGE ON SCHEMA work TO desk_employee,desk_support,desk_guest;
 GRANT SELECT ON work.documents TO desk_employee,desk_support;
 CREATE POLICY own_documents ON work.documents FOR SELECT TO desk_employee USING (owner_name = (current_setting('request.jwt.claims',true)::json->>'sub'));
 CREATE POLICY opted_in_documents ON work.documents FOR SELECT TO desk_support USING (support_consent);
 CREATE FUNCTION work.consumer_role() RETURNS text LANGUAGE sql STABLE SECURITY INVOKER AS 'SELECT current_user::text';
 REVOKE ALL ON FUNCTION work.consumer_role() FROM PUBLIC; GRANT EXECUTE ON FUNCTION work.consumer_role() TO desk_employee,desk_support;
 NOTIFY pgrst,'reload schema';""")
 report['seedCount']=int(sql('SELECT count(*) FROM work.documents;').strip())
 inside(['mkdir','-p','/tmp/role-client'])
 for f,target in [(runtime/'postgrest-16.6/postgrest','/tmp/role-client/postgrest'),(runtime/'node-24.22.3/node','/tmp/role-client/node'),(pkg/'node_modules','/tmp/role-client/node_modules'),(Path(__file__).with_name('client.cjs'),'/tmp/role-client/client.cjs')]:ok(['docker','cp',str(f),name+':'+target],timeout=65)
 sessions={key:issue(key,role) for key,role in [('worker-a','desk_employee'),('worker-b','desk_employee'),('support','desk_support')]}
 with tempfile.TemporaryDirectory(prefix='issued-study-sessions-') as td:
  directory=Path(td);cfg=directory/'postgrest.conf';auth=directory/'sessions.json'
  cfg.write_text('db-uri = "postgresql://study_gateway:'+gateway+'@127.0.0.1:5432/postgres"\ndb-schemas = "work"\ndb-anon-role = "desk_guest"\nserver-host = "127.0.0.1"\nserver-port = 4062\njwt-secret = "'+signing+'"\njwt-aud = "role-fixture"\nopenapi-mode = "disabled"\n')
  auth.write_text(json.dumps(sessions));cfg.chmod(0o600);auth.chmod(0o600)
  for f in (cfg,auth):ok(['docker','cp',str(f),name+':/tmp/role-client/'+f.name])
 inside(['chown','postgres:postgres','/tmp/role-client/postgrest.conf','/tmp/role-client/sessions.json'])
 ok(['docker','exec','-d','--user','postgres',name,'/tmp/role-client/postgrest','/tmp/role-client/postgrest.conf'])
 # The JS client normally uses /rest/v1/. The isolated PostgREST service has its API root at /. This local reverse proxy supplies the standard path.
 proxy=Path(__file__).with_name('gateway.cjs');ok(['docker','cp',str(proxy),name+':/tmp/role-client/gateway.cjs'])
 ok(['docker','exec','-d','--user','postgres',name,'/tmp/role-client/node','/tmp/role-client/gateway.cjs'])
 for attempt in range(22):
  run=shell(['docker','exec','--user','postgres',name,'/tmp/role-client/node','/tmp/role-client/client.cjs'],timeout=10)
  if run.returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('client readback failed: '+run.stderr[:360])
 report['clientReadback']=json.loads(run.stdout)
 assert {a:r['ids'] for a,r in report['clientReadback'].items()}=={'worker-a':['amber','cedar'],'worker-b':['birch','dune'],'support':['birch','cedar']},report['clientReadback']
 assert all(r['role']==('desk_support' if k=='support' else 'desk_employee') for k,r in report['clientReadback'].items())
 report['readback']='confirmed, from normal isolated Supabase JS client requests'
except Exception as exc:
 report['problem']=str(exc).replace(master,'[private]').replace(gateway,'[private]').replace(signing,'[private]')[:450]
finally:
 own=shell(['docker','container','inspect','--format','{{index .Config.Labels "skills62.study"}}',name])
 if own.returncode==0 and own.stdout.strip()==name:
  shell(['docker','stop','--timeout','2',name],timeout=15)
  if shell(['docker','container','inspect',name]).returncode==0:shell(['docker','rm',name],timeout=12)
 report['containerGone']=shell(['docker','container','inspect',name]).returncode!=0
 Path(__file__).with_name('preflight.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,ensure_ascii=False))
if 'problem' in report:raise SystemExit(1)
