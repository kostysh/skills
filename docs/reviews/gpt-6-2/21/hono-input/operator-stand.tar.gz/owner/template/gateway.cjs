const http=require('node:http');
http.createServer((req,res)=>{
 const incoming=new URL(req.url,'http://127.0.0.1');
 if(!incoming.pathname.startsWith('/rest/v1/')){res.writeHead(404);res.end();return;}
 const forward=http.request({host:'127.0.0.1',port:4062,path:incoming.pathname.slice('/rest/v1'.length)+incoming.search,method:req.method,headers:req.headers},up=>{res.writeHead(up.statusCode,up.headers);up.pipe(res);});
 forward.on('error',()=>{res.writeHead(503);res.end();});req.pipe(forward);
}).listen(4063,'127.0.0.1');
