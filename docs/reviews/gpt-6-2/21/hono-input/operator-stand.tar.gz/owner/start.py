"""Start one isolated, disposable document desk. The original three-session provisioner is pinned."""
import argparse, hashlib, json, os, re, shutil, signal, socketserver, sys, threading, uuid
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--tools', required=True, type=Path, help='directory containing the three pinned binary toolchains')
parser.add_argument('--state', required=True, type=Path, help='new, private directory for this run')
config=parser.parse_args()
here=Path(__file__).resolve().parent
state=config.state.resolve();state.mkdir(mode=0o700)
runtime_path=config.tools.resolve()
documents=here.parent/'documents.json'
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
assert sha(documents)=='e6608361b7b1718ab19546e5bf732abf860565f4e718d2baae2769720799e5a5'
template=here/'template/check.py'
assert sha(template)=='ab7babb01deda7f2ae6ea27bf585828d4ca01fb185270b37e33042eb0f4de3fb'
for filename in ('client.cjs','gateway.cjs'):shutil.copy2(here/'template'/filename,state/filename)
socket_path=state.parent/(state.name+'.sock')
if len(os.fsencode(socket_path))>100:raise SystemExit('Choose a shorter state path for the Unix socket.')
stop=threading.Event()
for s in (signal.SIGTERM,signal.SIGINT):signal.signal(s,lambda *_:stop.set())
def column_setup():
    payload=documents.read_bytes().hex()
    sql("ALTER TABLE work.documents ADD COLUMN title text; UPDATE work.documents d SET title = s.title FROM json_to_recordset(convert_from(decode('"+payload+"','hex'),'UTF8')::json) AS s(id text,title text) WHERE d.id=s.id; ALTER TABLE work.documents ALTER COLUMN title SET NOT NULL;")
def serve_titles():
    baseline=report['clientReadback']
    assert {k:r['ids'] for k,r in baseline.items()}=={'worker-a':['amber','cedar'],'worker-b':['birch','dune'],'support':['birch','cedar']}
    ok(['docker','cp',str(here/'query.cjs'),name+':/tmp/role-client/title-query.cjs'])
    class Request(socketserver.StreamRequestHandler):
        def handle(self):
            request=json.loads(self.rfile.readline(1200))
            who=request.get('principal');id_=request.get('id')
            if who not in ('worker-a','worker-b','support') or (id_ is not None and (not isinstance(id_,str) or not re.fullmatch('[a-z][a-z0-9-]{0,31}',id_))):
                response={'interfaceError':'unknown local session or unsupported document id'}
            else:
                cmd=['docker','exec','--user','postgres',name,'/tmp/role-client/node','/tmp/role-client/title-query.cjs',who]
                if id_ is not None:cmd.append(id_)
                result=shell(cmd,timeout=12)
                response=json.loads(result.stdout) if result.returncode==0 else {'interfaceError':'document desk unavailable'}
            response['requestId']=uuid.uuid4().hex[:14]
            with (state/'reads.jsonl').open('a') as log:log.write(json.dumps({'request':request,'reply':response},ensure_ascii=False)+'\n')
            self.wfile.write((json.dumps(response,ensure_ascii=False)+'\n').encode())
    with socketserver.UnixStreamServer(str(socket_path),Request) as server:
        server.timeout=.4
        (state/'ready.json').write_text(json.dumps({'origin':'private Supabase JS client on work.documents','database':report['server'],'api':report['bin'],'sdk':report['package'],'input_sha256':sha(documents),'socket':str(socket_path),'baselineIdRead':baseline},indent=2,ensure_ascii=False)+'\n')
        while not stop.is_set() and not (state/'finish').exists():server.handle_request()
    socket_path.unlink(missing_ok=True)
    report['finalRowCount']=int(sql('SELECT count(*) FROM work.documents;').strip())
source=template.read_text()
changes=[
    ("base=Path(__file__).resolve().parents[2];runtime=base/'toolchains'","runtime=runtime_path"),
    ("base/'handoffs/document-access/sources/documents.json'","documents"),
    ("int(time.time())+600","int(time.time())+7200"),
    ("report['seedCount']=int(","column_setup()\n report['seedCount']=int("),
    ("['docker','exec','-d','--user','postgres',name,'/tmp/role-client/postgrest'","['docker','exec','-d','--user','postgres','-e','GHCRTS=-N2',name,'/tmp/role-client/postgrest'"),
    ("report['readback']='confirmed, from normal isolated Supabase JS client requests'","report['readback']='confirmed, from normal isolated Supabase JS client requests'\n serve_titles()")
]
for old,new in changes:
    assert source.count(old)==1,old
    source=source.replace(old,new)
# Only the original, fixed three-account issuer lives in this private owner context.
__file__=str(state/'owner.py')
exec(compile(source,str(template),'exec'),globals())

