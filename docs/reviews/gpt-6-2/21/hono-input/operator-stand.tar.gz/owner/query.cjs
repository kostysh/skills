const {readFileSync} = require('node:fs');
const {createClient} = require('./node_modules/@supabase/supabase-js');
const [principal, id] = process.argv.slice(2);
if (!['worker-a', 'worker-b', 'support'].includes(principal)) process.exit(2);
const session = JSON.parse(readFileSync('/tmp/role-client/sessions.json', 'utf8'))[principal];
const client = createClient('http://127.0.0.1:4063', 'local-study-public', {
  accessToken: async () => session, db: {schema: 'work'},
  auth: {persistSession: false, autoRefreshToken: false, detectSessionInUrl: false}
});
(async () => {
  const who = await client.rpc('consumer_role');
  if (who.error) throw Error(String(who.status));
  const base = client.from('documents').select('id,title');
  const {status, data, error} = await (id ? base.eq('id', id) : base.order('id'));
  process.stdout.write(JSON.stringify({principal, effectiveDatabaseRole: who.data, status, data, error: error?.code ?? null}) + '\n');
})().catch(e => { process.stderr.write(e.message + '\n'); process.exitCode = 1; });

