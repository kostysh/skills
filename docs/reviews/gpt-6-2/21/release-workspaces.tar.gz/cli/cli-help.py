import argparse, os, pathlib, subprocess, tempfile
p=argparse.ArgumentParser(description="Show the local CLI help of one of the two provided projects")
p.add_argument('project',choices=['legacy','current'])
p.add_argument('topic',choices=['version','history','declarative'])
a=p.parse_args()
command={'version':['--version'],'history':['migration','list','--help'],'declarative':['db','schema','declarative','sync','--help']}[a.topic]
with tempfile.TemporaryDirectory(prefix='.tool-home-',dir='.') as d:
    root=str(pathlib.Path(d).resolve())
    env=os.environ | dict(SUPABASE_HOME=root,SUPABASE_TELEMETRY_DISABLED='1',NO_COLOR='1',XDG_CONFIG_HOME=root,XDG_CACHE_HOME=root)
    raise SystemExit(subprocess.run([str(pathlib.Path('/tmp/document-tools-26c65d65d3ab')/a.project),*command],env=env).returncode)
