# Локальная история миграций и генерация SQL

Запускайте команды из корня соответствующей копии проекта с её закреплённой версией Supabase CLI.

## Проверка истории миграций

| Копия | Версия CLI | Команда | Как выбирается база |
| --- | --- | --- | --- |
| `legacy` | `2.76.10` | `supabase migration list --local` | `--local` выбирает локальную БД. По умолчанию CLI обращается к связанному проекту. |
| `current` | `3.2.0` | `supabase migration list` | CLI по умолчанию выбирает локальную БД. `--remote` переключает цель на удалённую. |

## Генерация миграции в `current`

```sh
supabase db schema declarative sync --no-apply --name migration_name
```

Замените `migration_name` на имя миграции. CLI сравнит базовое состояние из `supabase/migrations` с декларативной схемой и запишет разницу в файл миграции. `--no-apply` выполняет генерацию без запроса подтверждения и без применения к локальной БД.

**Уберите глобальный `--yes` из этого шага**, в том числе если его добавляет общий скрипт запуска. Справка `sync` для `3.2.0` указывает, что и `--yes`, и `--apply` применяют миграцию к локальной БД и обновляют её историю.

## Проверка команд

Для сверки использованы следующие запросы к закреплённым CLI.

```sh
python3 cli-help.py legacy version
python3 cli-help.py legacy history
python3 cli-help.py current version
python3 cli-help.py current history
python3 cli-help.py current declarative
```

`python3 cli-help.py legacy declarative` вывела справку родительской команды `supabase db`. Проверка ограничилась версиями и справкой CLI. Команды чтения истории и генерации миграции оставлены для запуска владельцем проекта.

[Правила навыка](SKILL.md) · [Справочник по миграциям](references/migrations-cli.md) · [Скрипт локальной справки](cli-help.py)
