// The screen uses the same cache entry before and after a write.
export async function verifyContact(client, options) {
  await client.invalidateQueries({ queryKey: options.queryKey });
  return client.getQueryData(options.queryKey);
}
