for (const line of ['mainline', 'maintenance']) {
  const { QueryClient } = await import(`./${line}/vendor/index.js`);
  const { verifyContact } = await import(`./${line}/contact.mjs`);
  const client = new QueryClient();
  let source = 'new@example.test';
  let reads = 0;
  const options = {
    queryKey: ['contact', 'editor'],
    staleTime: Infinity,
    retry: false,
    queryFn: async () => {
      reads++;
      if (!source) throw new Error('Contact service unavailable');
      return source;
    }
  };
  client.setQueryData(options.queryKey, 'old@example.test');
  for (const example of ['saved', 'unavailable', 'retry']) {
    if (example === 'unavailable') source = null;
    if (example === 'retry') source = 'again@example.test';
    try {
      console.log(JSON.stringify({ line, example, result: await verifyContact(client, options), reads }));
    } catch (error) {
      console.log(JSON.stringify({ line, example, error: error.message, reads }));
    }
  }
  client.clear();
}
