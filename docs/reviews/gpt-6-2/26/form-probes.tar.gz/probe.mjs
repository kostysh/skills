import assert from "node:assert/strict";
import { createFormControl } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { createStore } from "zustand/vanilla";

const accept = z.object({
  email: z.email({ error: "Enter a valid email address" }),
  password: z.string().min(8, { error: "Use at least eight characters" }),
  terms: z.boolean().refine((accepted) => accepted, { error: "Accept the terms to continue" }),
});
const form = createFormControl({
  defaultValues: { email: "bad", password: "sufficient", terms: true },
  resolver: zodResolver(accept),
});
let firstError;
let corrected;
for (const name of ["email", "password", "terms"]) form.register(name);
await form.handleSubmit(() => assert.fail("Invalid submission succeeded"), (errors) => { firstError = errors.email.message; })();
form.setValue("email", "team@example.test");
await form.handleSubmit((data) => { corrected = data; }, () => assert.fail("Correction failed"))();
const store = createStore(() => ({ open: false }));
store.setState({ open: true });
assert.equal(firstError, "Enter a valid email address");
assert.equal(corrected.email, "team@example.test");
assert.equal(store.getState().open, true);
console.log(JSON.stringify({ node: process.version, firstError, corrected, zustandAfterSet: store.getState(), runtime: "node form control + actual resolver; no rendered field" }, null, 2));
