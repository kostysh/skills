import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdir, mkdtemp, readFile, rename, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright-core";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const state = await mkdtemp(join(tmpdir(), "settings-source-"));
const evidence = resolve(process.argv[2] ?? join(root, "observations"));
await mkdir(evidence, { recursive: true });
const backend = spawn(process.execPath, [join(root, "server.mjs"), "0", state], {
  env: { ...process.env, NOTIFICATION_WRITE_DELAY_MS: "900" },
  stdio: ["ignore", "pipe", "inherit"],
});
const closed = once(backend, "exit");
const lines = createInterface({ input: backend.stdout });
const origin = JSON.parse((await once(lines, "line"))[0]).origin;
const service = [];
lines.on("line", (line) => service.push(JSON.parse(line)));
let browser;
try {
  browser = await chromium.launch({ channel: "chrome", executablePath: process.env.CHROME_BIN || undefined, headless: true });
  const browserName = browser.version();
  const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const timeline = [];
  const http = [];
  const errors = [];
  context.on("response", (response) => {
    if (new URL(response.url()).pathname === "/api/notification-settings") {
      const entry = { method: response.request().method(), status: response.status() };
      http.push(entry);
      if (entry.method === "PUT") entry.input = response.request().postDataJSON();
    }
  });
  let page;
  function watchTab(tab) { tab.on("pageerror", (error) => errors.push(error.message)); }
  page = await context.newPage();
  watchTab(page);
  const button = (name) => page.getByRole("button", { name, exact: true });
  const email = () => page.getByLabel("Email address", { exact: false });
  const status = () => page.getByRole("status");
  async function observe(stage, shot = false) {
    const result = await page.evaluate(() => ({
      route: location.pathname, heading: document.querySelector("h1")?.textContent,
      email: document.querySelector("#email")?.value,
      weekly: document.querySelector("#weekly")?.getAttribute("aria-checked"),
      focus: document.activeElement?.id || document.activeElement?.getAttribute("role") || document.activeElement?.textContent?.trim(),
      status: document.querySelector("[role=status]")?.innerText,
      fieldError: document.querySelector("#email-error")?.textContent,
      dialog: document.querySelector("[role=dialog][data-state=open]")?.innerText,
      tooltips: [...document.querySelectorAll("[role=tooltip]")].map((el) => ({ id: el.id, text: el.textContent })),
      viewport: innerWidth, pageWidth: document.documentElement.scrollWidth,
    }));
    timeline.push({ stage, ...result });
    assert.equal(result.viewport, result.pageWidth);
    if (shot) await page.screenshot({ path: join(evidence, stage + ".png") });
    return result;
  }
  async function review() {
    await button("Review changes").click();
    await button("Cancel").waitFor();
    assert.equal(await button("Cancel").evaluate((el) => el === document.activeElement), true);
  }
  async function confirm(close) {
    await page.keyboard.press("Tab");
    assert.equal(await button("Confirm").evaluate((el) => el === document.activeElement), true);
    await page.keyboard.press("Enter");
    if (close) {
      await button("Close").waitFor();
      assert.equal(await button("Close").evaluate((el) => el === document.activeElement), true);
      await page.keyboard.press("Enter");
      await page.waitForFunction(() => !document.querySelector("[role=dialog]") && document.activeElement?.getAttribute("role") === "status");
      const pending = await observe("closed-during", true);
      assert.equal(pending.focus, "status");
      assert.match(pending.status, /Applying changes/);
    }
  }
  async function applied(value) {
    await page.waitForFunction((email) => {
      const body = document.querySelector("[role=status]")?.innerText ?? "";
      return body.includes("Settings applied") && body.includes(email) && !document.querySelector("[role=dialog][data-state=open]");
    }, value);
  }
  await page.goto(origin);
  await page.getByRole("link", { name: "Notification settings" }).click();
  await email().waitFor();
  assert.equal((await observe("opened")).route, "/settings/notifications");
  await button("About these settings").focus();
  const hint = await page.getByRole("tooltip").textContent();
  assert.equal(hint, "Review your changes before you confirm.");
  assert.equal(await button("About these settings").getAttribute("aria-describedby"), (await observe("help")).tooltips[0].id);
  await page.keyboard.press("Escape");
  await page.getByRole("tooltip").waitFor({ state: "hidden" });

  await email().fill("first@example.test");
  await review(); await confirm(false); await applied("first@example.test");
  await email().fill("bad"); await page.getByRole("radio", { name: "Weekly" }).click();
  await button("Review changes").click();
  const invalid = await observe("invalid");
  assert.equal(invalid.focus, "email"); assert.equal(invalid.weekly, "true"); assert.ok(invalid.fieldError);
  await email().fill("team@example.test"); await review(); await page.keyboard.press("Escape");
  await page.waitForFunction(() => !document.querySelector("[role=dialog]") && document.activeElement?.textContent === "Review changes");
  const cancelled = await observe("cancelled");
  assert.equal(cancelled.focus, "Review changes"); assert.equal(cancelled.email, "team@example.test");
  assert.match(cancelled.status, /first@example.test/);
  await review(); await confirm(true); await applied("team@example.test");
  await observe("saved", true);
  const persisted = JSON.parse(await readFile(join(state, "settings.json"), "utf8"));
  assert.deepEqual(persisted, { email: "team@example.test", enabled: true, frequency: "weekly" });

  await rename(join(state, "pending"), join(state, "paused"));
  await email().fill("again@example.test"); await review(); await confirm(false);
  await page.getByText("Settings could not be saved. Review your changes and try again.").waitFor();
  const failed = await observe("write-failed", true);
  assert.match(failed.status, /Previously applied settings/); assert.match(failed.status, /team@example.test/);
  assert.equal(failed.email, "again@example.test");
  assert.deepEqual(JSON.parse(await readFile(join(state, "settings.json"), "utf8")), persisted);
  await page.reload(); await applied("team@example.test");
  const prior = await observe("reloaded-after-failure"); assert.equal(prior.email, "team@example.test");
  await rename(join(state, "paused"), join(state, "pending"));
  await email().fill("again@example.test"); await review(); await confirm(false); await applied("again@example.test");
  await page.close(); page = await context.newPage(); watchTab(page);
  await page.goto(origin + "/settings/notifications"); await applied("again@example.test");
  const reopened = await observe("reopened", true);
  assert.equal(reopened.email, "again@example.test"); assert.equal(reopened.weekly, "true");
  const final = JSON.parse(await readFile(join(state, "settings.json"), "utf8"));
  assert.deepEqual(final, { ...persisted, email: "again@example.test" });
  assert.deepEqual(http.filter((entry) => entry.method === "PUT").map((entry) => entry.status), [204, 204, 503, 204]);
  assert.deepEqual(service.map((entry) => [entry.method, entry.status]), http.map((entry) => [entry.method, entry.status]));
  assert.deepEqual(service.at(-1).body, final);
  assert.deepEqual(errors, []);
  const report = { browser: browserName, node: process.version, timeline, http, server: service, persisted, final, pageErrors: errors };
  await writeFile(join(evidence, "route.json"), JSON.stringify(report, null, 2) + "\n");
  console.log(JSON.stringify({ http: http.map((r) => [r.method, r.status]), final, observed: timeline.length, browser: browserName }));
} finally {
  await browser?.close();
  backend.kill();
  await closed;
  await rm(state, { recursive: true, force: true });
}
