import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {createBrowserRouter, useParams} from 'react-router';
import {RouterProvider} from 'react-router/dom';
import {QueryClient, QueryClientProvider, useMutation, useQuery, useQueryClient} from '@tanstack/react-query';
import Dexie from 'dexie';
import './style.css';
const db = new Dexie('duty-contact-desk');
db.version(1).stores({settings:'site'});
const cache = new QueryClient({defaultOptions:{queries:{retry:false}}});
const labels = {river:'River desk',cedar:'Cedar desk',harbor:'Harbor desk'};
const initial = site => ({site,address:'desk@example.test'});

function Form({record}) {
  const [email,setEmail] = useState(record.address);
  const [note,setNote] = useState('');
  const [error,setError] = useState('');
  const client=useQueryClient();
  const write=useMutation({
    mutationFn: async value => {
      if(record.site==='harbor' && value==='paused@example.test') throw new Error('Saving is temporarily unavailable for this address.');
      const next={site:record.site,address:value};
      if(record.site!=='cedar') await db.settings.put(next);
      return next;
    },
    onSuccess: data=>{client.setQueryData(['settings',record.site],data);setNote('Saved: '+data.address);setError('')},
    onError: reason=>{setError(reason.message);setNote('')}
  });
  return <form noValidate onSubmit={event=>{
    event.preventDefault();
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){setError('Enter a complete address.');setNote('');return;}
    write.mutate(email);
  }}>
    <label htmlFor="address">Duty contact</label>
    <input id="address" type="email" value={email} onChange={event=>setEmail(event.currentTarget.value)}/>
    <button type="submit" disabled={write.isPending}>Save contact</button>
    {error && <div role="alert">{error}</div>}
    <p role="status">{note || 'Saved contact: '+record.address}</p>
  </form>;
}
function Desk() {
  const {site}=useParams();
  const query=useQuery({queryKey:['settings',site],queryFn:async()=>await db.settings.get(site) ?? initial(site)});
  return <main><h1>{labels[site] ?? site}</h1>{query.data?<Form record={query.data}/>:<p>Reading stored contact…</p>}</main>;
}
const router=createBrowserRouter([{path:'/desk/:site',element:<Desk/>}]);
createRoot(document.getElementById('root')).render(<QueryClientProvider client={cache}><RouterProvider router={router}/></QueryClientProvider>);

