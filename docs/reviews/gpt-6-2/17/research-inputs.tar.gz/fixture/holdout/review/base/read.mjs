import {offset} from './paging.mjs';
export function readPage(items,page,size){ const start=offset(page,size); return items.slice(start,start+size); }
