Paging begins at page 1. GET page 1 of size 2 must return the first two rows. readPage and the admin view use the same offset.
