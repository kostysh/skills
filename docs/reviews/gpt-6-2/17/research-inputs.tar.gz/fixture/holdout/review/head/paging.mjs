export function offset(page, size) { return page * size; }
