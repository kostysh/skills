import test from 'node:test';
import assert from 'node:assert/strict';
import {readPage} from './read.mjs';
test('empty list',()=>assert.deepEqual(readPage([],1,2),[]));
