import test from 'node:test';
import assert from 'node:assert/strict';
import { copyFileSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog, saveCatalog, setPinned, pinnedTitles } from '../src/catalog.mjs';

function temporaryCatalog(t) {
  const directory = mkdtempSync(fileURLToPath(new URL('../.catalog-test-', import.meta.url)));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const path = join(directory, 'catalog.json');
  copyFileSync(new URL('../fixture/catalog.json', import.meta.url), path);
  return path;
}

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

test('pinning and unpinning survive save and reload without changing other cards', t => {
  const path = temporaryCatalog(t);
  const original = loadCatalog(path);

  saveCatalog(path, setPinned(original, 'a', true));
  const reopened = loadCatalog(path);
  assert.deepEqual(reopened, [
    { id: 'a', title: 'Alpha', pinned: true },
    { id: 'b', title: 'Beta', pinned: true },
  ]);
  assert.deepEqual(pinnedTitles(reopened), ['Alpha', 'Beta']);

  saveCatalog(path, setPinned(reopened, 'a', false));
  const reopenedAfterUnpin = loadCatalog(path);
  assert.deepEqual(reopenedAfterUnpin, original);
  assert.deepEqual(pinnedTitles(reopenedAfterUnpin), ['Beta']);
});

test('legacy records without pinned default to false and can retain a new pin', t => {
  const path = temporaryCatalog(t);
  writeFileSync(path, JSON.stringify([{ id: 'legacy', title: 'Legacy' }]));
  const cards = loadCatalog(path);
  assert.deepEqual(cards, [{ id: 'legacy', title: 'Legacy', pinned: false }]);

  saveCatalog(path, setPinned(cards, 'legacy', true));
  assert.deepEqual(loadCatalog(path), [{ id: 'legacy', title: 'Legacy', pinned: true }]);
});
