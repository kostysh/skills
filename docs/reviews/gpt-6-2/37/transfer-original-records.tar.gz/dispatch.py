from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, tarfile, tempfile
run=Path(__file__).resolve().parent
lab=run.parents[1]
sys.path.insert(0,str(lab))
from slots import available_session
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def inventory(p):
 result={}
 for d,sub,files in os.walk(p):
  sub[:]=[n for n in sub if n not in ['node_modules','.git']]
  for n in files:
   q=Path(d)/n
   if n!='node' and q.is_file():result[q.relative_to(p).as_posix()]=h(q)
 return result
proj=Path(tempfile.mkdtemp(prefix='content-transfer-'))
shutil.copytree(run/'input',proj,dirs_exist_ok=True)
archive=run/'pack/payload-migration-0.1.4.tgz'
skill=proj/'skill';skill.mkdir()
with tarfile.open(archive) as t:t.extractall(skill,filter='data')
tc=lab/'toolchains'
shutil.copy2(tc/'node-24.22.3/node',proj/'node')
shutil.copytree(tc/'cms-sqlite-3.94.0/node_modules',proj/'node_modules',symlinks=True)
before=inventory(proj)
ver=subprocess.check_output([str(proj/'node'),'--version'],text=True).strip()
assert ver=='v24.22.3'
receipt=run/'subject-live';receipt.mkdir()
task=(run/'task.md').read_text()
cmd=['codex','exec','--disable','memories','--ephemeral','--skip-git-repo-check','--sandbox','workspace-write','--model','gpt-6.2-sol','-c','model_reasoning_effort="medium"','--cd',str(proj),'--json','--output-last-message',str(receipt/'answer.md'),'-']
dump(receipt/'dispatch.json',{'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(proj),'argv':cmd,'before':before,'node':ver,'nodeSHA256':h(proj/'node'),'archiveSHA256':h(archive),'taskSHA256':h(run/'task.md'),'scope':'private work directory with physically copied dependencies, no study files, criteria, prior transcripts or history supplied'})
with available_session(),(receipt/'events.jsonl').open('w') as ev,(receipt/'stderr.txt').open('w') as er:
  result=subprocess.run(cmd,input=task,cwd=proj,text=True,stdout=ev,stderr=er)
after=inventory(proj)
dump(receipt/'result.json',{'exit':result.returncode,'endedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changedInputs':[n for n,v in before.items() if after.get(n)!=v],'addedFiles':sorted(set(after)-set(before)),'inputs':{n:after.get(n) for n in before},'eventsSHA256':h(receipt/'events.jsonl'),'answerSHA256':h(receipt/'answer.md') if (receipt/'answer.md').exists() else None})
print(proj,result.returncode)
raise SystemExit(result.returncode)
