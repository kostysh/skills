import {randomBytes} from 'node:crypto'
import {readFile,writeFile} from 'node:fs/promises'
import {join} from 'node:path'
import {buildConfig,getPayload} from 'payload'
import {sqliteAdapter} from '@payloadcms/db-sqlite'

export const sections=[
 {key:'S-A',title:'Реестр'}, {key:'S-B',title:'Пересчёт'}
]
export const records=[
 {key:'C-111',title:'Акт смены',section:'S-B',desk:'east',state:'issued'},
 {key:'C-112',title:'Лист смены',section:'S-A',desk:'east',state:'draft'},
 {key:'C-113',title:'Акт смены',section:'S-A',desk:'east',state:'issued'},
 {key:'C-114',title:'Папка смены',section:'S-B',desk:'west',state:'issued'}
]
const limited=({req})=>req.user?{and:[{desk:{equals:req.user.desk}},{state:{equals:'issued'}}]}:false
const collections=[
 {slug:'operators',auth:true,fields:[{name:'desk',type:'text',required:true}]},
 {slug:'sections',fields:[{name:'sourceKey',type:'text',required:true},{name:'title',type:'text',required:true}]},
 {slug:'records',access:{read:limited},fields:[
  {name:'sourceKey',type:'text',required:true},{name:'title',type:'text',required:true},
  {name:'section',type:'relationship',relationTo:'sections',required:true},{name:'desk',type:'text',required:true},
  {name:'state',type:'select',options:['issued','draft'],required:true}
 ]}
]
export async function open(local){
 let secret
 try{secret=await readFile(join(local,'session'), 'utf8')}catch{secret=randomBytes(32).toString('hex');await writeFile(join(local,'session'),secret,{mode:0o600})}
 const config=buildConfig({secret,telemetry:false,typescript:{autoGenerate:false},db:sqliteAdapter({client:{url:'file:'+join(local,'working.sqlite')},push:true}),collections})
 return getPayload({config})
}
async function all(cms,coll){
 return (await cms.find({collection:coll,limit:100,depth:0,sort:'id'})).docs
}
export async function init(cms){
 if((await all(cms,'operators')).length===0){
  await cms.create({collection:'operators',data:{email:'east@example.invalid',password:randomBytes(24).toString('hex'),desk:'east'}})
  const other=await cms.create({collection:'sections',data:{sourceKey:'LOCAL',title:'Своя полка'}})
  await cms.create({collection:'records',data:{sourceKey:'LOCAL-01',title:'Местная запись',section:other.id,desk:'east',state:'issued'}})
 }
}
async function stored(cms,collection,key){const r=await cms.find({collection,where:{sourceKey:{equals:key}},limit:2,depth:0,sort:'id'});return r.docs[0]}
async function persist(cms,collection,key,data,edition){
 let existing
 if(collection!=='records')existing=await stored(cms,collection,key)
 if(existing){await cms.update({collection,id:existing.id,data});return 'updated'}
 await cms.create({collection,data});return 'created'
}
export async function run(cms,dir,edition,interrupt){
 let seen=[]
 try{seen=JSON.parse(await readFile(join(dir,'checkpoint.json'),'utf8'))}catch{}
 const counts={created:0,updated:0,skipped:0,interrupted:false}
 for(const s of sections){counts[await persist(cms,'sections',s.key,{sourceKey:s.key,title:s.title},edition)]++}
 for(const row of records){
  if(seen.includes(row.key)){counts.skipped++;continue}
  const relationKey=row.section
  const relation=await stored(cms,'sections',relationKey)
  const data={sourceKey:row.key,title:row.title,section:relation.id,desk:row.desk,state:row.state}
  counts[await persist(cms,'records',row.key,data,edition)]++
  if(interrupt){counts.interrupted=true;break}
  seen.push(row.key);await writeFile(join(dir,'checkpoint.json'),JSON.stringify(seen))
 }
 return counts
}
export async function inspect(cms,dir,limitedRead){
 const sections=(await all(cms,'sections')).map(({id,sourceKey,title})=>({id,sourceKey,title}));const byId=new Map(sections.map(s=>[s.id,s.sourceKey]))
 const who=(await all(cms,'operators'))[0]
 const rows=limitedRead?(await cms.find({collection:'records',user:{...who,collection:'operators'},overrideAccess:false,depth:0,limit:100,sort:'id'})).docs:await all(cms,'records')
 const records=rows.map(({id,sourceKey,title,section,desk,state})=>({id,sourceKey,title,sectionID:section,sectionKey:byId.get(section),desk,state}))
 let checkpoint=[];try{checkpoint=JSON.parse(await readFile(join(dir,'checkpoint.json'),'utf8'))}catch{}
 return limitedRead?{actor:'east',records}:{sections,records,checkpoint}
}
