Форма Notification settings не выполнила оба критерия команды в Chrome при 390 × 844.

Статус `findings`.

- **Перезагрузка с черновиком.** Chrome перезагрузил страницу без предложения остаться на форме. Введённый синтетический адрес исчез из поля. [Снимок после перезагрузки](/tmp/casework-qg7pruwf/observations/after-reload.png)
- **Кнопка во время отправки.** Та же кнопка `Confirm` стала неактивной и показала `Applying…`. До ответа сервера атрибут `aria-busy` на кнопке отсутствовал. Запись завершилась с HTTP 204. [App.tsx](/tmp/casework-qg7pruwf/app/project/src/App.tsx:168) · [Снимок отправки](/tmp/casework-qg7pruwf/observations/applying.png)

Проверка охватила эти два состояния в Chrome 158 в режиме headless. Сценарий использует искусственную задержку записи 1200 мс. [Инструкция запуска](/tmp/casework-qg7pruwf/observations/README.md) · [Сценарий](/tmp/casework-qg7pruwf/observations/review.mjs) · [Журнал](/tmp/casework-qg7pruwf/observations/browser.log)