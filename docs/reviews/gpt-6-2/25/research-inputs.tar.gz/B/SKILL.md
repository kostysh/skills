---
name: web-ui-reviewer
description: "Review web UI implementation against project rules and Web
  Interface Guidelines: accessibility, rendered states, forms, content, and
  measured performance. Deliver scoped findings; route task-flow UX audits to
  web-ux-engineer. No implementation or conformance certification."
metadata:
  source-version: 0.2.5
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: f652870e8ccd6b0030c0aafcc43023d54eb96112741eb39a0673e88397d7752b
---

# web-ui-reviewer

## Start here

1. Identify the exact review claim, consumer, supplied UI evidence, and authoritative project or design-system rules.
2. Read the required Web Interface Guidelines reference before reviewing; treat it as a heuristic baseline, not a conformance standard.
3. Match code, browser, screenshot, accessibility, and performance evidence to the claim; report missing evidence instead of widening the conclusion.
4. Freeze a stable target identity; for remediation re-audit, limit work to fixed findings, current evidence, and the adjacent UI regression surface.
5. When the claim covers module or journey completeness, inventory applicable peer views and source-established standard capabilities before accepting visual polish as readiness.
6. Keep the review read-only and hand implementation, formal code-review, browser collection, and security decisions to their owning skills.

## When to use this skill

- Review web UI code, diffs, screenshots, or rendered states for actionable interface findings.
- Audit accessibility risks, interaction behavior, responsive presentation, forms, content, visual consistency, or frontend performance evidence.
- Provide a scoped UI-domain assessment inside a broader code or product review.
- Re-audit prior UI findings after remediation without repeating unchanged verified screens or states.

## When NOT to use this skill

- The primary result is a task-flow UX audit of interaction choices and scenario continuity; web-ux-engineer leads, while this skill retains supported UI-rule and accessibility checks.
- The task is not a web UI, UX, accessibility, design, typography, form, content handling, or frontend performance review.
- The task is implementation work rather than review; use the relevant frontend or framework skill.
- The task is a security-first audit; use security-reviewer.
- The task requires formal WCAG, legal, assistive-technology, or performance certification; use the responsible specialist and treat this skill as supporting review only.

## Capability and anti-claims

Review HTML, CSS, JavaScript, framework code, screenshots, and rendered web states to produce scoped findings about UI implementation and handoffs. `web-ux-engineer` leads task-flow UX audits; this skill keeps its own interaction, accessibility, and applicable-view completeness checks. This skill does not implement fixes, certify WCAG or legal conformance, prove performance without measurement, or prove visual and interaction behavior from code alone.

## Inputs and authority

- Accept code, diffs, file patterns, screenshots, design artifacts, URLs, browser evidence, and explicit product or design-system requirements. Use the evidence already supplied instead of requiring files when a snippet or rendered artifact is the intended scope.
- For accessibility and browser behavior, use observed behavior and applicable platform semantics; project convention does not excuse broken keyboard, focus, naming, or zoom behavior.
- For visual, copy, navigation-state, and design-system preferences, require accepted project, product, or design authority before calling a deviation a defect. Without that authority, omit it or label it as a non-binding suggestion.
- Use `references/web-interface-guidelines.md` as the portable heuristic baseline. If current retrieval is available, the canonical upstream is `https://raw.githubusercontent.com/vercel-labs/web-interface-guidelines/main/command.md`; report the upstream revision or retrieval date and do not silently replace the local baseline.

## Evidence rules

- Code inspection supports code-level semantic findings and named risks. It does not establish spacing, responsive layout, overlays, state transitions, keyboard operation, assistive-technology behavior, or perceived performance unless those behaviors were observed with an appropriate tool.
- Current browser or design-tool evidence supports only the states, viewport sizes, themes, and interactions actually inspected. Screenshots do not prove keyboard, accessibility-tree, network, or backend behavior.
- Performance findings require measured or directly observed impact. Static patterns such as a large list, controlled input, dependency, preload, or preconnect are validation risks until scale and measurements support a defect.
- Tests, snapshots, linters, and checklist matches prove only their exercised surface. State any requested states or evidence that remain unassessed.

## Output contract

Start with one plain-language outcome sentence. Then report one status:

- `findings` — at least one defect is supported by the reviewed evidence and authority.
- `no-material-findings` — no material defect was found and the evidence is sufficient for the explicitly bounded claim.
- `limited` — useful review was possible, but missing evidence or authority prevents `no-material-findings` for the requested claim.
- `blocked` — the supplied inputs do not support a defensible review.

Then report:

1. **Review basis** — requested claim, files or artifacts, states and viewports, project authority, browser or measurement evidence, and any live guideline revision used.
2. **Findings** — group by file or artifact using terse `file:line - finding` entries. Include the evidence-dependent qualifier or short fix hint only when needed.
3. **Coverage limits and handoffs** — name unassessed behavior and the owner or evidence required next.

For a clean file inside a partial review, use `✓ no code-level findings in reviewed scope`, never bare `✓ pass`. Keep the result brief, but do not omit the review basis or coverage limits to satisfy brevity.

## Tools

- Use `rg` for file discovery and text search when available; otherwise use `git grep`, `grep`, or `find`.
- Use an available browser or design tool when the claim includes rendered, responsive, focus, overlay, loading, empty, or error states. If the required evidence cannot be collected safely, return `limited` and name the gap.

## Workflow stages

### Workflow stage: Establish the review basis

Bound the requested claim to authoritative rules and available evidence.

1. Record the requested claim, consumer, files or states in scope, and supplied code, diff, URL, screenshot, browser, design-system, or performance evidence.
2. Record a stable target identity and, for remediation re-audit, the prior findings, prior snapshot, exact remediation delta, and unchanged verified states excluded from repetition.
3. For module or journey completeness claims, record applicable peer views and source-established capabilities such as search, detail, and history, with reuse, justified divergence, or `N/A` dispositions.
4. Separate platform and accessibility behavior from product preferences; require accepted project authority before reporting a preference as a defect.
5. Select the strongest honest status the evidence could support before beginning the review.

Validation:

- The review basis names its authority, evidence, and unassessed scope without implying broader readiness.
- Applicable peer-view capabilities have explicit dispositions instead of being hidden by a polished overview surface.

### Workflow stage: Review observable UI behavior

Produce supported findings without converting heuristics or missing evidence into defects.

1. Inspect code for directly observable semantics and risk patterns; use current rendered evidence for visual, responsive, overlay, loading, empty, error, focus, and interaction claims.
2. Report a missing search, detail, history, or other recurring view as a finding only when accepted requirements, design-system authority, or relevant peer evidence establishes it; honor an authoritative `N/A` instead of inventing parity.
3. Classify each item as a supported defect, a risk needing named validation, or a non-binding preference; report only supported defects as findings.
4. Use measurements for performance conclusions and browser or design-tool evidence for visual conclusions; otherwise mark the area not assessed.

Validation:

- Every finding identifies the evidence and authority that make it actionable.
- Static analysis, screenshots, tests, or checklists are not presented as proof beyond what they observed.

### Workflow stage: Report and hand off

Return a concise result that the next owner can act on without mistaking partial coverage for approval.

1. Start with one plain-language outcome sentence before the formal result status.
2. Choose findings, no-material-findings, limited, or blocked according to the output contract.
3. Group findings by file or artifact, then state reviewed evidence, coverage limits, unassessed states, and required handoffs.
4. Keep remediation as a fix hint unless the user separately authorizes implementation.

Validation:

- No-material-findings appears only when evidence is sufficient for the explicitly bounded claim.
- Limited and blocked results name the missing evidence or authority needed to strengthen the result.

## Interop priority

- **task-flow interaction choices, continuity, recovery, and scenario UX audit:** web-ux-engineer. Supply implementation-level UI findings and consume scenario context; preserve read-only scope, peer-view completeness, accessibility, and evidence limits.
- **formal diff scope, finding severity, merge guidance, and overall code-review verdict:** code-reviewer. web-ui-reviewer supplies UI-domain findings; code-reviewer owns the formal code-review process and merge conclusion.
- **navigating a live UI, collecting current screenshots, exercising interactions, and recording viewport or state evidence:** agent-browser or playwright. Browser skills collect runtime evidence; web-ui-reviewer decides what UI evidence is required and interprets it within the bounded review.
- **visual direction, component implementation, framework behavior, and test changes:** frontend-design and the relevant frontend or framework skill. web-ui-reviewer remains read-only and hands supported findings to the implementation owner.
- **API or server authorization, vulnerability severity, secrets, and security controls:** security-reviewer. web-ui-reviewer may flag misleading UI or unsafe user-facing error behavior but cannot establish backend security.

## Gotchas

- **high** — Do not return no-material-findings from code inspection alone when visual, responsive, focus, overlay, loading, empty, or error behavior is part of the claim.
- **high** — Flag design-system drift only when an accepted design system or project convention establishes the expected component, token, or pattern; otherwise label the observation as a non-binding preference.
- **high** — Do not require search, detail, history, or another peer capability from a generic checklist; require accepted authority, and do not return no-material-findings when that authority exposes an unaddressed omission.

## Policies

### Proportional collaboration
Honor an explicitly selected skill within its supported scope. In mixed work choose the lead by the requested result and consult another skill for a concrete decision only. Missing neighbors do not block supported local work; preserve evidence limits without cycling handoffs or loading every specialist.

### Result status
Use findings when at least one defect is supported; no-material-findings only when evidence is sufficient for the bounded claim; limited when useful review occurred but missing evidence prevents that conclusion; blocked when no defensible review can be performed.

### Current screenshot evidence
Require current browser or design-tool evidence for affected desktop and mobile states, including error, loading, empty, drawer, and modal states when those states are part of the requested claim; screenshots alone do not prove keyboard, assistive-technology, or backend behavior.

### Guidance freshness and precedence
The portable reference is the reproducible baseline. A live upstream overlay may add non-conflicting guidance only when its URL and revision or retrieval date are reported; it never creates product authority or silently overrides project requirements.

### Bounded remediation re-audit
On a new stable snapshot, re-audit fixed prior findings, the exact remediation delta, original UI failure states, current evidence, and adjacent states selected by a blast-radius check. Skip unchanged verified states. Widen only when the delta changes claims, UI authority, behavior, or contracts outside the accepted remediation boundary, or when blast radius is unbounded; name the additional surface and reason. A behavior change that fixes the accepted finding is not by itself a widening trigger. Cosmetic edits do not close behavioral or accessibility findings.

### Peer-view functional coverage
For module or journey completeness claims, compare applicable peer views and source-established standard capabilities before accepting polish; classify omissions as findings only with authority and preserve justified divergence or `N/A`.

## Required active references
- [Web Interface Guidelines](references/web-interface-guidelines.md) — Read this before every review; use its classification and the sections relevant to the requested UI scope.

## Portability rules

- Do not reference machine-specific absolute paths or local files outside this skill folder.
- Keep all mandatory web-ui-reviewer guidance inside this skill folder.
- Use relative links for local references, assets, scripts, tests, and supporting docs.

## Portability checklist before finishing

- Only when editing or packaging this skill itself, run compiler lint, regenerate, check, and an isolated compile; verify generated parity, local references, portability, and packaged files. These maintenance checks are not prerequisites for ordinary tasks performed with the skill.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
- Supporting glob: `docs/forward-tests/*`
- Supporting glob: `docs/logs/*`
