import { spawn } from "node:child_process"
import { createHash, randomUUID } from "node:crypto"
import { readFile, writeFile, mkdir, mkdtemp, rm } from "node:fs/promises"
import http from "node:http"
import os from "node:os"
import path from "node:path"
import { setTimeout as sleep } from "node:timers/promises"

const args = JSON.parse(process.argv[2] ?? "[]")
if (!Array.isArray(args)) throw new Error("Pass a JSON array of actions")
const root = path.resolve("dist")
const types = { ".html":"text/html", ".js":"text/javascript", ".css":"text/css", ".woff2":"font/woff2" }
const httpServer = http.createServer(async (request,response) => {
  try {
    const url = new URL(request.url, "http://localhost")
    const file = path.resolve(root, "." + (url.pathname === "/" ? "/index.html" : url.pathname))
    if (!file.startsWith(root + path.sep)) throw new Error("Unknown file")
    const data = await readFile(file)
    response.writeHead(200, {"Content-Type":types[path.extname(file)] ?? "application/octet-stream"}).end(data)
  } catch { response.writeHead(404).end() }
})
await new Promise((resolve,reject)=>httpServer.once("error",reject).listen(0,"127.0.0.1",resolve))
const profile = await mkdtemp(path.join(os.tmpdir(), "form-browser-"))
const chrome = spawn(process.env.CHROME_BIN ?? "google-chrome", [
  "--headless=new", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage", "--disable-background-networking",
  "--disable-component-update","--disable-sync","--no-default-browser-check","--no-first-run",
  "--remote-debugging-pipe", "--user-data-dir="+profile, "about:blank"
], {stdio:["ignore","ignore","ignore","pipe","pipe"],env:{...process.env,XDG_CONFIG_HOME:profile,XDG_CACHE_HOME:profile}})
let buffer="", serial=0, sessionId
const pending = new Map()
function request(method,params={},session=sessionId){
  const id=++serial
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{pending.delete(id);reject(new Error("CDP timeout: "+method))},12000)
    pending.set(id,{resolve(v){clearTimeout(timer);resolve(v)},reject(e){clearTimeout(timer);reject(e)}})
    chrome.stdio[3].write(JSON.stringify({id,method,params,...(session?{sessionId:session}:{})})+"\0")
  })
}
chrome.stdio[4].on("data",data=>{
  buffer+=data
  for(let split; (split=buffer.indexOf("\0"))!==-1;){
    const message=JSON.parse(buffer.slice(0,split)); buffer=buffer.slice(split+1)
    const sender=pending.get(message.id)
    if(sender){pending.delete(message.id);message.error?sender.reject(new Error(message.error.message)):sender.resolve(message.result)}
  }
})
const closed = new Promise(resolve=>chrome.once("close",resolve))
chrome.once("exit",()=>{for(const p of pending.values())p.reject(new Error("Chrome closed"));pending.clear()})
async function evaluate(fn,arg){
  const reply=await request("Runtime.evaluate",{expression:"("+fn.toString()+")("+JSON.stringify(arg??null)+")",returnByValue:true,awaitPromise:true})
  if(reply.exceptionDetails)throw new Error(reply.exceptionDetails.exception?.description??reply.exceptionDetails.text)
  return reply.result.value
}
function element(data) {
  const {target, action}=data
  const nodes=target.startsWith("text=") ? [...document.querySelectorAll("button,label,a,[role=button]")].filter(n=>n.textContent.trim()===target.slice(5)) : [...document.querySelectorAll(target)]
  const found=nodes.find(n=>n.getClientRects().length>0 && getComputedStyle(n).visibility!=="hidden")
  if(!found)throw new Error("No rendered control for "+target)
  found.scrollIntoView({block:"center",inline:"nearest",behavior:"instant"})
  if(found.matches(":disabled,[aria-disabled=true]")) throw new Error("Disabled control: "+target)
  const r=found.getBoundingClientRect(), x=r.x+r.width/2, y=r.y+r.height/2
  const actual=document.elementFromPoint(x,y)
  if(!actual || !(found===actual||found.contains(actual)))throw new Error("Control is covered: "+target)
  if(action==="fill"){found.focus();found.select()}
  return {x,y}
}
function pageState(){
  const visible=n=>n && n.getClientRects().length>0 && getComputedStyle(n).visibility!=="hidden"
  if (!window.measureDesk) {
    const m=window.measureDesk={start:null,completed:null,applyingSeen:false};
    document.addEventListener('click',ev=>{if(ev.target.closest('button')?.innerText.trim()==='Confirm'){m.start=performance.now();m.completed=null;m.applyingSeen=false}},true);
    new MutationObserver(()=>{
      if(m.start===null||m.completed!==null)return;
      const status=[...document.querySelectorAll('[role=status]')].map(n=>n.textContent).join(' ');
      if(status.includes('Applying changes'))m.applyingSeen=true;
      if(m.applyingSeen && status.includes('Settings applied') && !status.includes('Applying changes'))m.completed=performance.now()-m.start;
    }).observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  }
  const focus=document.activeElement
  return {applyDurationMs:window.measureDesk.completed,focusPaint:{tag:focus?.tagName,role:focus?.getAttribute("role"),outline:focus?getComputedStyle(focus).outline:null},heading:document.querySelector("h1")?.innerText, width:innerWidth,
    page: document.body.innerText.replace(/\n{2,}/g,"\n").trim(),
    fields:[...document.querySelectorAll("input:not([type=hidden]),[role=switch],[role=radio]")].filter(visible)
      .map(n=>({id:n.id||null, role:n.getAttribute("role")||n.type, value:n.value??null,checked:n.getAttribute("aria-checked"),invalid:n.getAttribute("aria-invalid")})),
    dialog:[...document.querySelectorAll('[role=dialog]')].filter(n=>visible(n)&&n.getAttribute("data-state")!=="closed").map(n=>n.innerText),
    status:[...document.querySelectorAll('[role=status],[role=alert]')].filter(visible).map(n=>n.innerText),
    focus:{id:focus?.id||null,text:(focus?.tagName==="BODY"?"":(focus?.innerText||"")).trim().slice(0,70)} }
}
const actions=[], timeline=[]
let error
try{
  const targets=await request("Target.getTargets",{},null)
  const target=targets.targetInfos.find(x=>x.type==="page")
  sessionId=(await request("Target.attachToTarget",{targetId:target.targetId,flatten:true},null)).sessionId
  const version=(await request("Browser.getVersion",{},null)).product
  await request("Page.enable"); await request("Runtime.enable")
  const route="http://127.0.0.1:"+httpServer.address().port+"/"
  await request("Page.navigate",{url:route})
  for(let i=0;i<100 && !(await evaluate(()=>Boolean(document.querySelector("h1"))));i++) await sleep(50)
  if(!(await evaluate(()=>Boolean(document.querySelector("h1")))))throw new Error("Application did not mount")
  await evaluate(()=>document.fonts.ready.then(()=>true))
  console.log("Browser "+version)
  timeline.push({action:{op:"open"},state:await evaluate(pageState)})
  for(const a of args){
    const op=a.op
    if(op==="click"||op==="fill"){
      const hit=await evaluate(element,{target:a.target,action:op})
      if(op==="click"){
        await request("Input.dispatchMouseEvent",{type:"mouseMoved",...hit})
        for(const type of ["mousePressed","mouseReleased"])await request("Input.dispatchMouseEvent",{type,...hit,button:"left",clickCount:1})
      } else if(String(a.value).length) await request("Input.insertText",{text:String(a.value)})
      else { for(const type of ["keyDown","keyUp"])await request("Input.dispatchKeyEvent",{type,key:"Backspace",code:"Backspace",windowsVirtualKeyCode:8}) }
    }else if(op==="key"){
      const keys={Escape:27,Enter:13,Tab:9," ":32,ArrowLeft:37,ArrowRight:39}
      if(!(a.key in keys))throw new Error("Unsupported key")
      for(const type of ["keyDown","keyUp"])await request("Input.dispatchKeyEvent",{type,key:a.key,code:a.key===" "?"Space":a.key,windowsVirtualKeyCode:keys[a.key],modifiers:a.shift?8:0,...(type==="keyDown" && a.key==="Enter"?{text:"\r",unmodifiedText:"\r"}:{})})
    }else if(op==="wait")await sleep(Math.min(Math.max(Number(a.ms)||0,0),30000))
    else if(op==="width")await request("Emulation.setDeviceMetricsOverride",{width:a.width,height:a.height??800,deviceScaleFactor:1,mobile:false})
    else if(op!=="look")throw new Error("Unknown operation: "+op)
    await sleep(240)
    actions.push(a);timeline.push({action:a,state:await evaluate(pageState)})
  }
}catch(e){error=String(e);process.exitCode=1}
finally{
  const image=await request("Page.captureScreenshot",{format:"png"}).catch(()=>null)
  const digest=image?createHash("sha256").update(Buffer.from(image.data,"base64")).digest("hex"):null
  const dir="visits";await mkdir(dir,{recursive:true});const stem=path.join(dir,randomUUID())
  await writeFile(stem+".json",JSON.stringify({actions,requested:args,timeline,error:error??null,screenSha256:digest},null,2)+"\n")
  if(image)await writeFile(stem+".png",Buffer.from(image.data,"base64"))
  console.log(JSON.stringify(timeline,null,0));if(error)console.error(error);console.log(stem+".json")
  await request("Browser.close",{},null).catch(()=>chrome.kill())
  await closed;httpServer.close();await rm(profile,{recursive:true,force:true}).catch(()=>{})
}
