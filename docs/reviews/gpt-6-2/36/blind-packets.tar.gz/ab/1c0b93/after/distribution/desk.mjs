export const cards={
  slug:'cards',
  access:{read:({req})=>req.user?{and:[{desk:{equals:req.user.desk}},{visibility:{equals:'issued'}}]}:false},
  fields:[
    {name:'sourceKey',type:'text',required:true,unique:true},
    {name:'title',type:'text',required:true},
    {name:'desk',type:'select',options:['east','west'],required:true},
    {name:'visibility',type:'select',options:['issued','draft'],required:true},
    {name:'shelf',type:'text',required:true},
  ],
};
export async function listForShift(cms,operator){
  const rows=await cms.find({collection:'cards',depth:0,sort:'sourceKey',limit:20,user:{...operator,collection:'operators'},overrideAccess:false});
  return rows.docs.map(({id,sourceKey,title,shelf})=>({id,sourceKey,title,shelf}));
}
