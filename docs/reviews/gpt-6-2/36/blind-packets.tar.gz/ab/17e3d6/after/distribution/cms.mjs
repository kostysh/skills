import {randomBytes} from 'node:crypto';
import {join} from 'node:path';
import {buildConfig,getPayload} from 'payload';
import {sqliteAdapter} from '@payloadcms/db-sqlite';
import {cards, listForShift} from './desk.mjs';
export async function openDesk(directory){
 const config=buildConfig({secret:randomBytes(32).toString('hex'),telemetry:false,typescript:{autoGenerate:false},db:sqliteAdapter({client:{url:'file:'+join(directory,'desk.sqlite')},push:true}),collections:[{slug:'operators',auth:true,fields:[{name:'desk',type:'select',options:['east','west'],required:true}]},cards]});
 return getPayload({config});
}
export {listForShift};
