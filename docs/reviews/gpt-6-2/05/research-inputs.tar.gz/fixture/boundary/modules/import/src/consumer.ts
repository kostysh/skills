import { readParcel } from "./public.ts";

export const forChute = (v: unknown): string => { const label = readParcel(v); return label ? label.zone + ":" + label.position.toFixed(0) : ""; };
