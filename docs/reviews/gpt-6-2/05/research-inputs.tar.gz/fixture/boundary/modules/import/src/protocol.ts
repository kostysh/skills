type Label = { zone: "north" | "south"; position: number };
type Scan = { ok: true; value: Label } | { ok: false };

export const labelSchema = {
  decode(raw: unknown): Scan {
    if (typeof raw !== "string") return { ok: false };
    const match = /^(N|S)-([0-9]{3})$/.exec(raw);
    if (!match) return { ok: false };
    return { ok: true, value: { zone: match[1] === "N" ? "north" : "south", position: Number(match[2]) } };
  }
};
