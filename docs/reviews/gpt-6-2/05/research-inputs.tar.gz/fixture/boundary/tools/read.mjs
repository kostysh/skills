import { readParcel } from "../modules/import/src/public.ts";
const raw = JSON.parse(process.argv[2]);
const result = readParcel(raw);
console.log(JSON.stringify(result));
