import { loadPeriod } from "../modules/import/src/public.ts";
const raw = JSON.parse(process.argv[2]);
const result = loadPeriod(raw);
console.log(JSON.stringify(result === null ? null : { day: result.day.toISOString(), shifts: result.shifts }));
