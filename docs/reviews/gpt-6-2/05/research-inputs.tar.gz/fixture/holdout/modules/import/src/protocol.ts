type Period = { day: Date; shifts: number };
type PeriodParse = { ok: true; value: Period } | { ok: false };

export const calendarSchema = {
  decode(raw: unknown): PeriodParse {
    if (typeof raw !== "object" || raw === null || !("day" in raw) || typeof raw.day !== "string") return { ok: false };
    if (!/^\d{4}-\d{2}-\d{2}$/.test(raw.day)) return { ok: false };
    const day = new Date(raw.day + "T00:00:00Z");
    if (!isFinite(day.getTime()) || day.toISOString().slice(0, 10) !== raw.day) return { ok: false };
    const shifts = "shifts" in raw ? raw.shifts : 1;
    if (typeof shifts !== "number" || shifts < 1 || shifts > 3 || shifts !== Math.floor(shifts)) return { ok: false };
    return { ok: true, value: { day, shifts } };
  }
};
