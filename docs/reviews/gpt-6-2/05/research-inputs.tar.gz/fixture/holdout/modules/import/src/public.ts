import { calendarSchema } from "./protocol.ts";

type Parsed = Extract<ReturnType<typeof calendarSchema.decode>, { ok: true }>["value"];

export function loadPeriod(raw: unknown): Parsed | null {
  const decoded = calendarSchema.decode(raw);
  if (!decoded.ok) return null;
  return raw;
}
