import { loadPeriod } from "./public.ts";

export const dayNumber = (v: unknown): number | undefined => loadPeriod(v)?.day.getUTCDate();
