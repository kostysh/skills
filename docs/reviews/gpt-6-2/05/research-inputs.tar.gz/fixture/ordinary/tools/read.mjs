import { importReading } from "../modules/import/src/public.ts";
const raw = JSON.parse(process.argv[2]);
const result = importReading(raw);
console.log(JSON.stringify(result));
