import { importReading } from "./public.ts";

export const forDisplay = (v: unknown): string => importReading(v)?.toFixed(2) ?? "—";
