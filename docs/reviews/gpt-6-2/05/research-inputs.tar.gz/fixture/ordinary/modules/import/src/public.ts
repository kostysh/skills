import { readingSchema } from "./protocol.ts";

type Parsed = Extract<ReturnType<typeof readingSchema.decode>, { ok: true }>["value"];

export function importReading(raw: unknown): Parsed | null {
  const decoded = readingSchema.decode(raw);
  if (!decoded.ok) return null;
  return raw;
}
