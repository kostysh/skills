type ReadingResult =
  | { ok: true; value: number }
  | { ok: false };

export const readingSchema = {
  decode(raw: unknown): ReadingResult {
    if (typeof raw === "number" && isFinite(raw)) return { ok: true, value: raw };
    if (typeof raw !== "string" || !/^[+-]?\d+(?:\.\d+)?$/.test(raw)) return { ok: false };
    const value = Number(raw);
    return isFinite(value) ? { ok: true, value } : { ok: false };
  }
};
