"""Run checks on a fresh private copy after execution; keep the tested project untouched."""
from pathlib import Path
import argparse, hashlib, json, subprocess, shutil, tempfile
p=argparse.ArgumentParser()
p.add_argument('case',choices=['ordinary','boundary','holdout'])
p.add_argument('project',type=Path)
opts=p.parse_args()
base=Path(__file__).resolve().parent
case=opts.case
fixture=base/'fixture'/case
applied=opts.project
def fingerprint(d):
 return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file() and '.agents' not in p.parts and '.git' not in p.parts}
orig=fingerprint(fixture); curr=fingerprint(applied)
def run(d,argv):
 try:
  result=subprocess.run(argv,cwd=d,capture_output=True,text=True,timeout=15)
  return {'argv':argv,'exit':result.returncode,'stdout':result.stdout.replace(str(d),'.'),'stderr':result.stderr.replace(str(d),'.')}
 except (FileNotFoundError,subprocess.TimeoutExpired) as e: return {'argv':argv,'error':str(e)}
cases={'ordinary':('importReading','number',[2,'2.50','-0.75','0','',None,'2kg',True],'"2.50"','return isFinite(value) ? { ok: true, value }','return isFinite(value) ? { ok: true, value: value + 7 }'),
'boundary':('readParcel','{ zone: "north" | "south"; position: number }',['N-042','S-007','X-123','N-9',{'deferred':True},False],'"N-042"','position: Number(match[2])','position: Number(match[2]) + 5'),
'holdout':('loadPeriod','{ day: Date; shifts: number }',[{'day':'2026-04-21'},{'day':'2024-02-29','shifts':3},{'day':'2026-02-29'},{'day':'2026-02-01','shifts':0},{'day':'2026-04-21T00:00:00+02:00'},None],'{"day":"2026-04-21"}','{ day, shifts }','{ day, shifts: shifts + 1 }')}
name,expected,values,mutant_value,old,new=cases[case]
with tempfile.TemporaryDirectory(prefix='observation-') as temp:
 d=Path(temp)
 shutil.copytree(applied,d,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','.agents'))
 cmd=['node','node_modules/typescript/bin/tsc']
 observations={'project_delta':sorted(n for n in orig.keys()|curr.keys() if orig.get(n)!=curr.get(n)),
 'original_package':run(fixture,['npm','run','typecheck']),
 'empty_solution':run(d,cmd+['--noEmit']),
 'actual_package':run(d,['npm','run','typecheck']),
 'program_config':run(d,cmd+['-p','modules/import/tsconfig.json','--showConfig']),
 'entrypoints':[run(d,['node','tools/read.mjs',json.dumps(value,ensure_ascii=False,separators=(',',':'))]) for value in values]}
 q=d/'modules/import/src/probe.external.ts'
 q.write_text(f'''import {{ {name} }} from "./public.ts";
declare const received: unknown;
const result: {expected} | null = {name}(received);
const nonAny: 0 extends (1 & ReturnType<typeof {name}>) ? never : true = true;
// @ts-expect-error The public result is not a serialized string.
const wrong: string = {name}(received);
''')
 observations['consumer_compile_assertions']=run(d,['npm','run','typecheck'])
 schema=d/'modules/import/src/protocol.ts'
 s=schema.read_text()
 if old in s:
  schema.write_text(s.replace(old,new,1))
  observations['decoder_substitution']={'input':mutant_value,'replace':old,'with':new,'result':run(d,['node','tools/read.mjs',mutant_value])}
 else: observations['decoder_substitution']={'unavailable':'baseline decoder text changed in the work product'}
 print(json.dumps(observations,ensure_ascii=False,indent=2))
