"""Materialize exact CLI bytes from the upstream 5.9.3 tarball in three fixture copies."""
from pathlib import Path
import hashlib, io, json, tarfile, urllib.request
root=Path(__file__).resolve().parent
files=json.loads((root/'installation.json').read_text())['standalone_compiler']
data=urllib.request.urlopen('https://registry.npmjs.org/typescript/-/typescript-5.9.3.tgz',timeout=35).read()
with tarfile.open(fileobj=io.BytesIO(data)) as tar:
 for rel,expected in files.items():
  content=tar.extractfile('package/'+rel).read()
  assert hashlib.sha256(content).hexdigest()==expected,rel
  for f in (root/'fixture').iterdir():
   destination=f/'node_modules/typescript'/rel
   destination.parent.mkdir(parents=True,exist_ok=True)
   destination.write_bytes(content)
