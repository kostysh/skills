const defaults = { port: 3000, host: "localhost" } satisfies Record<string, string | number>;
export const port: 3000 = defaults.port;
export const host: "localhost" = defaults.host;
