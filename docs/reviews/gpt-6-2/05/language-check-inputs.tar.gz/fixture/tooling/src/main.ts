import { port, host } from "#settings";
if (!host || !port) throw new Error("Missing endpoint");
