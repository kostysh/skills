export const config = { port: 3000, host: "localhost" } satisfies Record<string, string | number>;
config.port = 3001;
config.host = "backup";
const fixed = { port: 3000, host: "localhost" } as const satisfies Record<string, string | number>;
const exactPort: 3000 = fixed.port;
const exactHost: "localhost" = fixed.host;
const route = { method: "GET" } satisfies { method: "GET" | "POST" };
const method: "GET" = route.method;
