export const config = { port: 3000, host: "localhost" } satisfies Record<string, string | number>;
const port: 3000 = config.port;
const host: "localhost" = config.host;
