async function flush(): Promise<void> {}
flush();
export {};
