async function flush(): Promise<void> {}
await flush();
export {};
