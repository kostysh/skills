import { marker } from "#readout";
if (marker !== "loaded") throw new Error("Unexpected marker");
