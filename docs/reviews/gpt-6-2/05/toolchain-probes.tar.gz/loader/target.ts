export const marker: string = "loaded";
