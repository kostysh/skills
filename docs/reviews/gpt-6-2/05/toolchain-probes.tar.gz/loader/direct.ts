import { marker } from "./target.ts";
if (marker !== "loaded") throw new Error("Unexpected marker");
