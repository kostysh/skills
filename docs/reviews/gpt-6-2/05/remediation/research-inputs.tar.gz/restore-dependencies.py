"""Restore all physically isolated npm package files with the recorded bytes and permissions."""
from pathlib import Path
import hashlib,io,json,tarfile,urllib.request
root=Path(__file__).resolve().parent
for name,item in json.loads((root/'dependencies.json').read_text()).items():
 data=urllib.request.urlopen(f'https://registry.npmjs.org/{name}/-/{name}-{item["version"]}.tgz',timeout=40).read()
 with tarfile.open(fileobj=io.BytesIO(data)) as tar:
  for rel,record in item['files'].items():
   b=tar.extractfile('package/'+rel).read()
   assert hashlib.sha256(b).hexdigest()==record['sha256'],rel
   for fixture in (root/'fixture').iterdir():
    f=fixture/'node_modules'/name/rel;f.parent.mkdir(parents=True,exist_ok=True)
    f.write_bytes(b);f.chmod(int(record['mode'],8))
