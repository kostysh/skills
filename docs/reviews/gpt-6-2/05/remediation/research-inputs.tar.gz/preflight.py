from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,shutil,tempfile
from observe import root,observe,judge,public_code,cmd
spec=json.loads((root/'private-cases.json').read_text())
def run(case,style):
 c=spec[case]
 with tempfile.TemporaryDirectory(prefix='schema-control-') as tmp:
  d=Path(tmp);shutil.copytree(root/'fixture'/case,d,dirs_exist_ok=True)
  if style!='raw':(d/'src/public.ts').write_text(public_code(c,style))
  if style=='raw':return case,style,{'initial_package':cmd(d,['npm','run','typecheck'])}
  o=observe(case,d);result=judge(c,o)
  if style in ('api','inferred'):assert all(result.values()),(case,style,result,o['initial_package'],o['initial_public_contract'],o['schema_revision_consumer'],o['revised_public_contract'])
  if style=='manual':assert all(result[k] for k in ('initial_package','initial_runtime','initial_type_contract','revised_runtime','revised_client_runtime')) and not result['revised_consumer_typecheck'] and 'TS2339' in o['schema_revision_consumer']['stdout'],(case,style,result,o['initial_public_contract'],o['schema_revision_consumer'])
  if style=='wire-output':assert not result['initial_type_contract'] and not result['initial_package'],(case,result)
  if style=='any':assert not result['initial_type_contract'],(case,result)
  return case,style,{'phenotype':result,'initial_package':o['initial_package'],'initial_public_contract':o['initial_public_contract'],'changed_schema_consumer':o['schema_revision_consumer'],'changed_type_contract':o['revised_public_contract'],'runtime_examples':{'before':o['initial_cli'][0],'after':o['revised_cli'][0]}}
rows=[(k,s) for k in spec for s in ('raw','api','inferred','manual','wire-output','any')]
with ThreadPoolExecutor(max_workers=4) as workers: outcomes=list(workers.map(lambda x:run(*x),rows))
result={k:{s:r for c,s,r in outcomes if c==k} for k in spec}
for c,r in result.items():
 assert r['raw']['initial_package']['exit']!=0 and 'TS2305' in r['raw']['initial_package']['stdout']
 print(c,{s:v['phenotype']['revised_consumer_typecheck'] for s,v in r.items() if s!='raw'})
(root/'preflight.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
