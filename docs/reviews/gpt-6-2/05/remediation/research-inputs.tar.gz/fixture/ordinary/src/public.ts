export function readMeter(raw: unknown): unknown {
  return raw;
}
