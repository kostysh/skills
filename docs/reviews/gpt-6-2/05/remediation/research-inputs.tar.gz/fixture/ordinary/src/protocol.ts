import * as v from "valibot";

export const meterSchema = v.pipe(
  v.object({ station: v.string(), level: v.pipe(v.string(), v.regex(/^\d{1,3}$/)) }),
  v.transform((entry) => ({
    station: entry.station.toUpperCase(),
    level: Number(entry.level),
  }))
);
