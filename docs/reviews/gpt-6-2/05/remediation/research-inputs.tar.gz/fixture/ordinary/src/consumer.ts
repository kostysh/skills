import { readMeter, type Reading } from "./public.ts";

export function describe(row: Reading): string {
  return row.station + "/" + row.level.toFixed(0);
}

export function displayWire(value: unknown): string {
  const row = readMeter(value);
  return row === null ? "invalid" : describe(row);
}
