export function readLabel(raw: unknown): unknown {
  return raw;
}
