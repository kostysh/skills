import { readLabel, type Parcel } from "./public.ts";

export function describe(row: Parcel): string {
  return row.zone + ":" + row.position.toFixed(0);
}

export function displayWire(value: unknown): string {
  const row = readLabel(value);
  return row === null ? "invalid" : describe(row);
}
