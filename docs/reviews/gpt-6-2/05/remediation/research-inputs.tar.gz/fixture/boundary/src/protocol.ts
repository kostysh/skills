import * as v from "valibot";

export const parcelSchema = v.pipe(
  v.string(), v.regex(/^[NS]-[0-9]{3}$/),
  v.transform((code) => ({
    zone: code[0] === "N" ? "north" as const : "south" as const,
    position: Number(code.slice(2)),
  }))
);
