export function readPeriod(raw: unknown): unknown {
  return raw;
}
