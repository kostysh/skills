import type { PeriodRequest } from "./public.ts";

export function templateFor(day: string): PeriodRequest {
  return { day };
}
