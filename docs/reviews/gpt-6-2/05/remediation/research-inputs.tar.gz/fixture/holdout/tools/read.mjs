import { readPeriod } from "../src/public.ts";
import { describe } from "../src/consumer.ts";
const value = readPeriod(JSON.parse(process.argv[2]));
console.log(JSON.stringify({ value, display: value === null ? "invalid" : describe(value) }));
