import * as v from "valibot";

export const periodSchema = v.pipe(
  v.object({
    day: v.pipe(v.string(), v.isoDate()),
    shifts: v.optional(v.pipe(v.number(), v.integer(), v.minValue(1), v.maxValue(3)), 1),
  }),
  v.transform((request) => ({
    midnight: new Date(request.day + "T00:00:00Z"),
    shifts: request.shifts,
  }))
);
