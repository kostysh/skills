import { readPeriod, type Period } from "./public.ts";

export function describe(row: Period): string {
  return row.midnight.toISOString() + "/" + row.shifts.toFixed(0);
}

export function displayWire(value: unknown): string {
  const row = readPeriod(value);
  return row === null ? "invalid" : describe(row);
}
