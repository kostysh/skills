"""Read the public API on a neutral copy before and after a compatible schema release."""
import argparse, hashlib, json, shutil, subprocess, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inventory(d):
 return {str(f.relative_to(d)):[sha(f),format(f.stat().st_mode&0o7777,'04o')] for f in sorted(d.rglob('*')) if f.is_file() and not ({'.agents','.git'} & set(f.relative_to(d).parts))}
def cmd(d,argv):
 r=subprocess.run(argv,cwd=d,capture_output=True,text=True,timeout=30)
 return {'argv':argv,'exit':r.returncode,'stdout':r.stdout.replace(str(d),'.'),'stderr':r.stderr.replace(str(d),'.')}
def public_code(c,style):
 name,typ,schema=c['fn'],c['typ'],c['schema']
 code=f'import * as v from "valibot";\nimport {{ {schema} }} from "./protocol.ts";\n'
 field=''
 if style=='api':field=f'export type {typ} = v.InferOutput<typeof {schema}>;'
 if style=='manual':field=f'export type {typ} = '+c['manual']+';'
 if style=='wire-output':field=f'export type {typ} = v.InferInput<typeof {schema}>;'
 if style=='any':field=f'export type {typ} = any;'
 if 'input' in c:
  incoming=c['manualinput'] if style=='manual' else f'v.InferInput<typeof {schema}>'
  code+=f"export type {c['input']} = {incoming};\n"
 if field:code+=field+'\n'
 annotation='' if style=='inferred' else f': {typ} | null'
 code+=f'export function {name}(raw: unknown){annotation} {{\n  const parsed = v.safeParse({schema}, raw);\n  return parsed.success ? parsed.output : null;\n}}\n'
 if style=='inferred':code+=f'export type {typ} = NonNullable<ReturnType<typeof {name}>>;\n'
 return code
def contract_probe(c):
 typ,schema,fn=c['typ'],c['schema'],c['fn']
 x=f'''import type * as v from "valibot";
import {{ {fn}, type {typ} }} from "./public.ts";
import {{ {schema} }} from "./protocol.ts";
type Expected = v.InferOutput<typeof {schema}>;
type IsAny<T> = 0 extends (1 & T) ? true : false;
type Safe<T> = IsAny<T> extends true ? false : [T] extends [never] ? false : true;
type FieldsSafe<T> = true extends {{ [K in keyof T]-?: IsAny<T[K]> }}[keyof T] ? false : true;
declare const actual: {typ};
declare const canonical: Expected;
declare const opaque: unknown;
const fromPublic: Expected = actual;
const fromSchema: {typ} = canonical;
const called = {fn}(opaque);
const accepted: Expected | null = called;
const checked: ReturnType<typeof {fn}> = canonical;
const failure: ReturnType<typeof {fn}> = null;
const safeNamed: Safe<{typ}> = true;
const safeReturn: Safe<ReturnType<typeof {fn}>> = true;
const safeNamedFields: FieldsSafe<{typ}> = true;
const safeReturnFields: FieldsSafe<NonNullable<ReturnType<typeof {fn}>>> = true;
const preciseNamed: string extends keyof {typ} ? false : true = true;
const preciseReturn: string extends keyof NonNullable<ReturnType<typeof {fn}>> ? false : true = true;
// @ts-expect-error A serialized string is not a parsed record.
const wrong: {typ} = "invalid";
'''
 if 'input' in c:
  inp=c['input']
  x+=f'''import type {{ {inp} }} from "./public.ts";
type ExpectedIn = v.InferInput<typeof {schema}>;
declare const supplied: {inp};
declare const expectedInput: ExpectedIn;
const acceptedIn: ExpectedIn = supplied;
const exposedIn: {inp} = expectedInput;
const safeIn: Safe<{inp}> = true;
const guardedIn: FieldsSafe<{inp}> = true;
const preciseIn: string extends keyof {inp} ? false : true = true;
// @ts-expect-error A normalized Date is not the request's day string.
const wrongRequest: {inp} = {{ day: new Date() }};
'''
 return x
def run_probe(d,c):
 (d/'src/contract-external.ts').write_text(contract_probe(c))
 (d/'tsconfig.probe.json').write_text(json.dumps({'extends':'./tsconfig.json','files':['src/public.ts','src/consumer.ts','src/contract-external.ts']+(['src/templates.ts'] if 'input' in c else []),'include':[]}))
 return cmd(d,['node','node_modules/typescript/bin/tsc','-p','tsconfig.probe.json'])
def observe(case,project):
 c=json.loads((root/'private-cases.json').read_text())[case]
 fixture=root/'fixture'/case;before=inventory(fixture);after=inventory(project)
 obs={'original_changes':{n:[before.get(n),after.get(n)] for n in sorted(before.keys()|after.keys()) if before.get(n)!=after.get(n)},'files_and_modes_sha256':{'input':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'output':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest()}}
 with tempfile.TemporaryDirectory(prefix='observation-') as tmp:
  d=Path(tmp);shutil.copytree(project,d,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','.agents'))
  obs['initial_package']=cmd(d,['npm','run','typecheck'])
  def read(v):return cmd(d,['node','tools/read.mjs',json.dumps(v,ensure_ascii=False,separators=(',',':'))])
  obs['initial_cli']=[read(v) for v in c['values']]
  obs['initial_public_contract']=run_probe(d,c)
  protocol=d/'src/protocol.ts';source=protocol.read_text()
  for old,new in c['patches']:
   if source.count(old)!=1:
    obs['schema_revision_unavailable']='The approved source context has changed.'
    return obs
   source=source.replace(old,new)
  protocol.write_text(source)
  typ,fn,prop,pt=c['typ'],c['fn'],c['prop'],c['pt']
  fresh=f'''import {{ {fn}, type {typ} }} from "./public.ts";
export function markerForNamed(record: {typ}): {pt} {{ return record.{prop}; }}
export function markerForImported(raw: unknown): {pt} | null {{
  const record = {fn}(raw);
  return record === null ? null : record.{prop};
}}
'''
  if 'input' in c:
   fresh+=f'''import type {{ {c["input"]} }} from "./public.ts";
export const reserveRequest: {c["input"]} = {{ day: "2025-07-01", desk: "reserve" }};
'''
  (d/'src/revision-client.ts').write_text(fresh)
  (d/'tsconfig.revision.json').write_text(json.dumps({'extends':'./tsconfig.json','files':['src/revision-client.ts','src/consumer.ts']+(['src/templates.ts'] if 'input' in c else []),'include':[]}))
  obs['schema_revision_consumer']=cmd(d,['node','node_modules/typescript/bin/tsc','-p','tsconfig.revision.json'])
  obs['revised_public_contract']=run_probe(d,c)
  obs['revised_cli']=[read(v) for v in c['values']]
  command=f'''import {{ markerForNamed, markerForImported }} from "./src/revision-client.ts";
import {{ {fn} }} from "./src/public.ts";
const result={fn}(JSON.parse(process.argv[1]));
console.log(JSON.stringify([result===null?null:markerForNamed(result),markerForImported(JSON.parse(process.argv[1]))]));'''
  obs['revised_client_runtime']=[cmd(d,['node','--input-type=module','-e',command,json.dumps(v,ensure_ascii=False,separators=(',',':'))]) for v in c['values']]
  if 'input' in c:
   obs['revised_producer_consumer']=cmd(d,['node','--input-type=module','-e','import { reserveRequest, markerForImported } from "./src/revision-client.ts"; console.log(JSON.stringify([reserveRequest,markerForImported(reserveRequest)]));'])
  return obs
def judge(c,obs):
 def unpack(r):return json.loads(r['stdout']) if r['exit']==0 else {'process_exit':r['exit']}
 before=[{'value':v,'display':display} for v,display in c['results']]
 after=[{'value':(dict(v,**{c['prop']:marker}) if v is not None else None),'display':display} for (v,display),marker in zip(c['results'],c['changed'])]
 return {'initial_package':obs['initial_package']['exit']==0,'initial_runtime':[unpack(r) for r in obs['initial_cli']]==before,'initial_type_contract':obs['initial_public_contract']['exit']==0,'revised_consumer_typecheck':obs.get('schema_revision_consumer',{}).get('exit')==0,'revised_type_contract':obs.get('revised_public_contract',{}).get('exit')==0,'revised_runtime':[unpack(r) for r in obs.get('revised_cli',[])]==after,'revised_client_runtime':[unpack(r) for r in obs.get('revised_client_runtime',[])]==[[v,v] for v in c['changed']],'revised_request': 'input' not in c or unpack(obs['revised_producer_consumer'])==[{'day':'2025-07-01','desk':'reserve'},'reserve']}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('project',type=Path);opts=p.parse_args()
 print(json.dumps(observe(opts.case,opts.project),ensure_ascii=False,indent=2))
