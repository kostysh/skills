"""Run the joint consumer on independent copies of its real incoming state."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest() if file.is_file() else None


def check(program, package, revision):
    run = subprocess.run([sys.executable, "queue_status.py", package, revision],
                         cwd=program, text=True, capture_output=True, timeout=10)
    return {"pair": [package, revision], "code": run.returncode,
            "stdout": run.stdout.splitlines(), "stderr": run.stderr.splitlines()}


def main():
    before, after = map(Path, sys.argv[1:])
    protected = [f.relative_to(before) for f in (before/"handoff").rglob("*") if f.is_file()]
    protected += [Path("producer-02.json"), Path("joint-02-03.json")]
    result = {"protected_sha256": {str(n): [sha(before/n), sha(after/n)] for n in sorted(protected)}}
    with tempfile.TemporaryDirectory(prefix="check-handoff-") as temp:
        work = Path(temp)/"work"
        shutil.copytree(after, work)
        result["original_calls"] = [check(work, a, b) for a,b in
                                    [("M-42", "v6"), ("M-43", "v2"), ("K-09", "v1"), ("N-15", "v9")]]
        registry = work/"handoff/registry.tsv"
        with registry.open("a") as stream:
            stream.write("M-42\tv5\tevening\nN-15\tv9\tmorning\n")
        result["updated_calls"] = [check(work, a, b) for a,b in
                                   [("M-42","v5"), ("M-42","v6"), ("N-15","v9")]]
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
