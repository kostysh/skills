import argparse
import csv
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Read the local handoff status")
    parser.add_argument("package")
    parser.add_argument("revision")
    args = parser.parse_args()
    root = Path("handoff")
    with (root / "registry.tsv").open() as registry:
        rows = list(csv.DictReader(registry, delimiter="\t"))
    lane = next((row["lane"] for row in rows if
                 (row["package"], row["revision"]) == (args.package, args.revision)), None)
    receipt = False
    for line in (root / "receipts.txt").read_text().splitlines():
        fields = [field.strip() for field in line.split("|")]
        if fields[1:3] == [args.package, args.revision]:
            receipt = True
    if receipt:
        print(f"received\t{lane or '-'}")
    elif lane:
        print(f"queued\t{lane}")
    else:
        print("unknown\t-")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
