"""Read selected project snapshots and replay the public program in disposable copies."""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def run(root, program, *args):
    command = [sys.executable, program, *args]
    result = subprocess.run(command, cwd=root, capture_output=True, text=True, timeout=10)
    return {"args": [program, *args], "exit": result.returncode,
            "stdout": result.stdout.splitlines(), "stderr": result.stderr.splitlines()}


def changes(before, after, path="$"):
    if type(before) is not type(after):
        return [path]
    if isinstance(before, dict):
        names = before.keys() | after.keys()
        diffs = []
        for name in sorted(names):
            child = f"{path}.{name}"
            if name not in before or name not in after:
                diffs.append(child)
            else:
                diffs.extend(changes(before[name], after[name], child))
        return diffs
    if isinstance(before, list):
        if len(before) != len(after):
            return [path]
        return [diff for i, (a, b) in enumerate(zip(before, after))
                for diff in changes(a, b, f"{path}[{i}]")]
    return [path] if before != after else []


def desk(project, source, altered):
    book_path = project/"probe-book.json"
    data = json.loads(source.read_text())
    if altered:
        data["reservations"][0]["number"] = "P-930"
        data["reservations"][1]["number"] = "A-810"
        data["reservations"][0]["paper"]["operator_extra"] = {"unit": "R8"}
        data["shift_note"] += " (оператор дополнил)"
    book_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    result = []
    for entry, section in zip(data["reservations"][:2], ("paper", "app")):
        number = entry["number"]
        before = json.loads(book_path.read_text())
        args = ["--book", book_path.name]
        commands = [run(project, "desk.py", *args, "show", number),
                    run(project, "desk.py", *args, "collect", number),
                    run(project, "desk.py", *args, "show", number)]
        after = json.loads(book_path.read_text())
        result.append({"number": number, "native_section": section,
                       "commands": commands, "changed_values": changes(before, after)})
    return result


def rota(project, source, altered):
    roster_path = project/"probe-rota.json"
    data = json.loads(source.read_text())
    target = "E-23"
    if altered:
        target = "X-90"
        data["rehearsals"][0].update(id=target, time="22:45", title="Дуэт")
        data["rehearsals"].append({"id": "F-18", "weekday": "wed", "time": "18:00",
                                   "title": "Генеральная", "lead": "Таня"})
    roster_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    args = ["--roster", roster_path.name]
    before = json.loads(roster_path.read_text())
    day = run(project, "rota.py", *args, "day", "wed")
    next_day = run(project, "rota.py", *args, "day", "thu")
    after_day = json.loads(roster_path.read_text())
    lead_before = run(project, "rota.py", *args, "lead", target)
    assign = run(project, "rota.py", *args, "assign", target, "Анна")
    lead_after = run(project, "rota.py", *args, "lead", target)
    after_assign = json.loads(roster_path.read_text())
    return {"commands": [day, next_day, lead_before, assign, lead_after],
            "changed_by_day": changes(before, after_day),
            "changed_by_assign": changes(after_day, after_assign)}


def files(root):
    skip = {"SKILL.md", "references", ".git"}
    return {p.relative_to(root).as_posix(): p.read_bytes()
            for p in root.rglob("*") if p.is_file()
            and p.relative_to(root).parts[0] not in skip}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("before", type=Path)
    parser.add_argument("after", type=Path)
    args = parser.parse_args()
    if (args.before/"desk.py").is_file():
        data_path, replay = "data/reservations.json", desk
    elif (args.before/"rota.py").is_file():
        data_path, replay = "data/rota.json", rota
    else:
        parser.error("No supported public program in before/")
    baseline = files(args.before)
    final = files(args.after)
    original = args.before/data_path
    report = {"project_file_delta": sorted(k for k in baseline.keys() | final.keys()
                                         if baseline.get(k) != final.get(k)),
              "working_data_byte_equal": final.get(data_path) == baseline[data_path]}
    for label, altered in [("reported_ids", False), ("independent_data", True)]:
        with tempfile.TemporaryDirectory(prefix="check-program-") as temp:
            project = Path(temp)/"work"
            shutil.copytree(args.after, project)
            try:
                report[label] = replay(project, original, altered)
            except (OSError, ValueError, KeyError, subprocess.TimeoutExpired) as err:
                report[label] = {"observer_error": str(err).replace(str(project), ".")}
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
