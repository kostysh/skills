import argparse
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Register a parcel pickup")
    parser.add_argument("--book", type=Path, default=Path("data/reservations.json"))
    parser.add_argument("action", choices=("show", "collect"))
    parser.add_argument("number")
    args = parser.parse_args()
    book = json.loads(args.book.read_text())
    entry = next((item for item in book["reservations"] if item["number"] == args.number), None)
    if entry is None:
        parser.exit(2, f"Unknown reservation: {args.number}\n")
    if args.action == "show":
        counter = entry["app"] if "app" in entry else entry["paper"]
        print(f'{args.number}\t{counter["state"]}')
        return
    counter = entry.get("app", {})
    counter["state"] = "collected"
    args.book.write_text(json.dumps(book, ensure_ascii=False, indent=2) + "\n")
    print(f"{args.number}\tcollected")

if __name__ == "__main__":
    main()
