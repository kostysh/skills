# Working agreement

- Carry forward permissions already given for the current task. Do authorized inspection, preparation, and reversible work without asking for the same permission again.
- A review request authorizes inspection and reporting, not remediation. Keep the reviewed snapshot unchanged; use a disposable copy for checks that may write locally. Determine command side effects before running it.
- Complete what the available facts and authority support. Report any blocked part.
