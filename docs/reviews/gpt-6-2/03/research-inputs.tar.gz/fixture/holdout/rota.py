import argparse
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Read the rehearsal rota")
    parser.add_argument("--roster", type=Path, default=Path("data/rota.json"))
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("day").add_argument("weekday")
    sub.add_parser("lead").add_argument("event")
    assign = sub.add_parser("assign")
    assign.add_argument("event")
    assign.add_argument("name")
    args = parser.parse_args()
    schedule = json.loads(args.roster.read_text())
    rehearsals = schedule["rehearsals"]
    if args.action == "day":
        for event in sorted(rehearsals, key=lambda row: row["time"]):
            if event["weekday"] == args.weekday and event["time"] < "18:00":
                print(f'{event["id"]}\t{event["time"]}\t{event["title"]}')
        return
    event = next((row for row in rehearsals if row["id"] == args.event), None)
    if event is None:
        parser.exit(2, f"Unknown rehearsal: {args.event}\n")
    if args.action == "lead":
        print(event["lead"])
        return
    change = event.copy()
    change["lead"] = args.name
    args.roster.write_text(json.dumps(schedule, ensure_ascii=False, indent=2) + "\n")
    print(change["lead"])

if __name__ == "__main__":
    main()
