"""Rejoin the captured input on a neutral copy. Do not score the written conclusion."""
import csv
import hashlib
import json
import shutil
import sys
from collections import defaultdict
from pathlib import Path
from tempfile import TemporaryDirectory

def checksum(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def csvrows(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))

def observe(receipt):
    dispatch = json.loads((receipt/"dispatch.json").read_text())
    result = json.loads((receipt/"result.json").read_text())
    if result["exit"] or not (receipt/"answer.md").is_file():
        raise ValueError("unfinished session")
    project = Path(dispatch["project"])
    output = receipt/"files/architecture-note.md"
    with TemporaryDirectory(prefix="reading-") as temp:
        copy = Path(temp)
        for directory in ["lab","draft"]:
            shutil.copytree(project/directory,copy/directory)
        if output.is_file():
            shutil.copyfile(output,copy/"architecture-note.md")
        traced=defaultdict(dict)
        for e in csvrows(copy/"lab/events.csv"):
            traced[e["run"]].setdefault((e["report"],e["employee"]),{})[e["event"]] = int(e["ts_ms"])
        emails=csvrows(copy/"lab/mail.csv")
        findings={}
        for row in csvrows(copy/"lab/captures.csv"):
            rid=row["run"]
            origin=traced[rid]
            starts=[v["ready"] for v in origin.values() if "ready" in v]
            spans={}
            for (report,employee),ev in origin.items():
                if "ready" not in ev:
                    continue
                spans[report+"/"+employee]=ev["badge"]-ev["ready"] if "badge" in ev else None
            outgoing=[(m["report"],m["employee"]) for m in emails if m["run"]==rid and m["reason"]=="report_ready" and (m["report"],m["employee"]) in origin]
            findings[rid]={"profile":row["profile"],"window_ends_ms":int(row["end_ms"]),"ready_spread_ms":max(starts)-min(starts),"recipient_badge_delays_ms":spans,"matched_report_ready_letters":len(outgoing),"mail_export":row["mail_export"]}
        orig={n:h for n,h in dispatch["input_files"].items() if n.startswith(("lab/","draft/"))}
        changed_sources=[n for n,h in orig.items() if not (copy/n).is_file() or checksum(copy/n)!=h]
        note = copy/"architecture-note.md"
        obs={"method":"On a fresh neutral copy rejoin raw rows by (run, report, employee); take badge minus ready, ready spread and matching report_ready messages. Null denotes missing observation. The paper reproduction uses supplied teaching records only.","work_product":"architecture-note.md" if note.is_file() else None,"work_product_sha256":checksum(note) if note.is_file() else None,"work_product_bytes":note.stat().st_size if note.is_file() else None,"all_changed_paths":result["changed"],"unchanged_input_record_sha256":{k:v for k,v in orig.items() if k not in changed_sources},"modified_case_evidence":changed_sources,"same_run_calculations":findings}
    (receipt/"observer.json").write_text(json.dumps(obs,ensure_ascii=False,indent=2)+"\n")
    print(receipt.name,obs["all_changed_paths"],sorted(findings),obs["work_product_bytes"])

if __name__=="__main__":
    for arg in sys.argv[1:]:
        observe(Path(arg))
