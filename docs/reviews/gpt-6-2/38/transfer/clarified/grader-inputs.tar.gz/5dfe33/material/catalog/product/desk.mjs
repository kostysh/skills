import {loadCatalog,setPinned,saveCatalog,pinnedTitles} from './src/catalog.mjs';
const [file,action,id]=process.argv.slice(2);
if (!file||!['pin','pins'].includes(action)){console.error('Usage: node desk.mjs <data> pin <id> | <data> pins');process.exitCode=2;}
else if(action==='pins'){console.log(JSON.stringify(pinnedTitles(loadCatalog(file))));}
else {const cards=setPinned(loadCatalog(file),id,true);saveCatalog(file,cards);console.log(JSON.stringify(pinnedTitles(cards)));}
