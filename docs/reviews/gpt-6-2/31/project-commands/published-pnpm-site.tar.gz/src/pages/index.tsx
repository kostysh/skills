import React from 'react';
import Layout from '@theme/Layout';
import Link from '@docusaurus/Link';

export default function Home() {
  return (
    <Layout title="Справочник дежурного">
      <main>
        <h1>Справочник дежурного</h1>
        <p><Link to="/docs/guide">Получить сумму для электронного журнала</Link></p>
        <p><a href="/downloads/engineering-tally-fixture-1.0.0.tar.gz" download>Скачать Tally 1.0.0</a></p>
      </main>
    </Layout>
  );
}
