---
slug: /desk
title: Tally desk guide 2.0
---
Use the shift's Tally 1.1.0 archive in a clean folder. Install the attached local file offline.
```sh
npm install --offline --ignore-scripts --no-audit --no-fund ./engineering-tally-fixture-1.1.0.tgz
./node_modules/.bin/tally sum 2 3 --machine
./node_modules/.bin/tally sum bad --machine
```
The result is `{"sum":5}`. The error prints `Number expected` on stderr and leaves code 2.
