module.exports = {
  title: 'Desk handbook', tagline: 'Local operator notes', url: 'https://desk.example.invalid', baseUrl: '/',
  onBrokenLinks: 'throw', trailingSlash: true, i18n: {defaultLocale:'en',locales:['en','it']},
  presets: [['classic', {docs:{routeBasePath:'handbook',sidebarPath:false,lastVersion:'current',
    versions:{current:{label:'2.0',path:'2.0'},'1.0':{label:'1.0',path:'1.0'}}},blog:false}]]
};
