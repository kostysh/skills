---
slug: /desk
title: Tally desk guide 1.0
---
Use the shift's Tally 1.0.0 archive in a clean folder. Install the attached local file offline.
```sh
npm install --offline --ignore-scripts --no-audit --no-fund ./engineering-tally-fixture-1.0.0.tgz
./node_modules/.bin/tally sum 2 3 --json
./node_modules/.bin/tally sum bad --json
```
The first command after installation reports `{"total":5}`. Invalid input sends `Invalid number` to stderr and exits with code 2.
