---
slug: /desk
title: Manuale Tally 1.0
---
In una cartella vuota, installare l’archivio Tally 1.0.0 assegnato al turno.
```sh
npm install --offline --ignore-scripts --no-audit --no-fund ./engineering-tally-fixture-1.0.0.tgz
./node_modules/.bin/tally sum 2 3 --json
./node_modules/.bin/tally sum bad --json
```
Il primo comando dopo l’installazione restituisce `{"total":5}`. Invalid input sends `Invalid number` to stderr and exits with code 2.
