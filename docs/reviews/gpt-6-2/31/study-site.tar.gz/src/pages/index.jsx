import React from 'react';
import Link from '@docusaurus/Link';
import Layout from '@theme/Layout';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
export default function Start(){
 const locale=useDocusaurusContext().i18n.currentLocale;
 return <Layout title="Desk notes"><main><h1>{locale==='it'?'Istruzioni per il turno':'Desk notes'}</h1>
 <p><Link to="/handbook/2.0/desk/">{locale==='it'?'Manuale del turno 2.0':'Current shift manual 2.0'}</Link></p>
 <p><Link to="/handbook/2.0/desk/">{locale==='it'?'Archivio del turno 1.0':'Archived shift manual 1.0'}</Link></p>
 </main></Layout>
}
