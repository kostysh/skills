module.exports = {
  title: 'Справочник уведомлений', url: 'http://localhost', baseUrl: '/',
  trailingSlash: true, onBrokenLinks: 'throw',
  i18n: {defaultLocale: 'ru', locales: ['ru']},
  presets: [['classic', {docs: {routeBasePath: 'spravochnik', sidebarPath: false}, blog: false}]],
};
