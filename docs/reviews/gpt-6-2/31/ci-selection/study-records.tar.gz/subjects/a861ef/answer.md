В [docs-quality.yml](/tmp/casework-tjcchpzf/site/.github/workflows/docs-quality.yml:17) добавил установку pnpm `10.28.2` через `pnpm/action-setup@v4` сразу после checkout и перед `setup-node`, которому pnpm нужен для кеширования.

Локально проверил YAML, условия запуска, порядок шагов и команды. Полный прогон не выполнен: в локальном `package.json` отсутствуют скрипты проверок и сборки.