Добавил установку pnpm `10.28.2` через `pnpm/action-setup@v4` сразу после checkout, до настройки кэша в `setup-node`. [docs-quality.yml](./site/.github/workflows/docs-quality.yml:17)

Локально проверил YAML, порядок шагов, сохранение триггеров и команд. Запуск на GitHub не проверял. В локальном `package.json` отсутствуют скрипты `format:check`, `lint:md` и `build`.