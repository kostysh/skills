# Справочник дежурного

[Получить сумму для электронного журнала](/spravochnik/guide/)

[Скачать Tally 1.0.0 для рабочего места](/downloads/engineering-tally-fixture-1.0.0.tar.gz)
