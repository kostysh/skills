# Справочник дежурного

[Получить сумму для электронного журнала](/spravochnik/guide/)

<a href="/downloads/engineering-tally-fixture-1.0.0.tar.gz" download>Скачать Tally 1.0.0 для рабочего места</a>
