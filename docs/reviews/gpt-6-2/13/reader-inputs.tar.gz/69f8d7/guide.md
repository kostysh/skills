# Tally 1.0.1 для дежурного оператора

Выпуск устанавливается локально, но штатная команда `tally` не возвращает сумму в JSON и не распознаёт некорректное число.

## Установка без сети

В Linux с Node.js и npm откройте пустой рабочий каталог, в который скопирован архив `engineering-tally-fixture-1.0.1.tgz`. Выполните:

```sh
npm install --offline --ignore-scripts --no-audit --no-fund --cache ./.npm-cache ./engineering-tally-fixture-1.0.1.tgz
```

## Проверка выпуска

Запустите установленную команду из того же каталога.

| Ввод | Команда | Фактический результат |
| --- | --- | --- |
| Числа 2 и 3 | `./node_modules/.bin/tally sum 2 3 --json` | `legacy tally0.1` в stdout, пустой stderr, код 0 |
| Некорректное число | `./node_modules/.bin/tally sum 2 abc --json` | `legacy tally0.1` в stdout, пустой stderr, код 0 |

Строка `legacy tally0.1` указывает на дефект выпуска. Код 0 в этом случае не подтверждает ни расчёт, ни проверку ввода. Для смены нужен исправленный архив. При его проверке ожидайте `{"total":5}` в stdout и код 0 для первого вызова, `Invalid number` в stderr и код 2 для второго.
