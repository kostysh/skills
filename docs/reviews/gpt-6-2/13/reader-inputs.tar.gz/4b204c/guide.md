# Tally 1.1.0 — сумма в JSON

На Linux с установленными Node.js и npm положите архив
`engineering-tally-fixture-1.1.0.tgz` в новую пустую папку. Откройте терминал
в этой папке и установите пакет локально, без сети.

```sh
npm install --offline --no-audit --no-fund ./engineering-tally-fixture-1.1.0.tgz
```

Запустите установленную команду `tally` с флагом `--machine`.

```sh
./node_modules/.bin/tally sum 2 3 --machine
```

Команда завершится с кодом `0` и выведет в стандартный вывод (stdout) строку
`{"sum":5}`.

Чтобы проверить обработку некорректного числа, передайте `abc` и выведите
код завершения.

```sh
status=0
./node_modules/.bin/tally sum 2 abc --machine || status=$?
printf '%s\n' "$status"
```

Tally завершится с кодом `2`, выведет `Number expected` в поток ошибок
(stderr) и оставит stdout пустым. Последняя строка примера отдельно печатает
сохранённый код `2`.
