# Tally 1.0.1 для дежурного

На Linux с установленными Node.js и npm откройте терминал в пустой рабочей папке, куда положили архив `engineering-tally-fixture-1.0.1.tgz`. Установите пакет в эту папку без доступа к сети.

```sh
npm install --prefix . --offline --no-audit --no-fund --ignore-scripts --cache ./.npm-cache ./engineering-tally-fixture-1.0.1.tgz
```

В этом выпуске штатная команда `./node_modules/.bin/tally` запускает `dist/legacy.js`. Для обоих примеров она печатает `legacy tally0.1` и возвращает код 0. На эту смену запускайте внутренний файл установленного пакета напрямую.

```sh
node ./node_modules/engineering-tally-fixture/dist/cli.js sum 2 3 --json
```

Ожидайте `{"total":5}` в stdout и код завершения 0.

```sh
status=0
node ./node_modules/engineering-tally-fixture/dist/cli.js sum 2 abc --json || status=$?
printf 'Код завершения: %s\n' "$status"
```

Для `abc` Tally пишет `Invalid number` в stderr, оставляет stdout пустым и возвращает код 2. Отдельная команда `printf` показывает этот код.
