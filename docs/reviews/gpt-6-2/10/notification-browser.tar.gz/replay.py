"""Reproduce the observed notification UI transitions on the unmodified build."""
import json
from pathlib import Path
from lab import Preview

OUT = Path(__file__).resolve().parent / "observations"
JS = """(() => {
  const el = document.activeElement, form = document.querySelector("form");
  const dialog = [...document.querySelectorAll('[role=dialog]')].find(d => d.dataset.state === 'open');
  const email = form.querySelector('[name=email]');
  const review = [...form.querySelectorAll('button')].find(b => b.textContent.includes('Review changes'));
  return {
    email: email.value, invalid: email.getAttribute('aria-invalid'),
    error: form.querySelector('[role=alert]')?.textContent || null,
    switch: form.querySelector('[role=switch]').getAttribute('aria-checked'),
    selected: form.querySelector('[role=radio][aria-checked=true]')?.id,
    reviewDisabled: review.disabled,
    dialog: dialog ? dialog.innerText : null,
    applied: document.querySelector('[role=status]')?.innerText || '',
    focus: {tag:el.tagName,id:el.id,label:el.tagName==='BODY'?'':el.innerText || el.getAttribute('aria-label') || ''},
    width: innerWidth, height: innerHeight
  }
})()"""


def exercise(p, name, width, height):
    out = OUT / name
    out.mkdir(parents=True, exist_ok=True)

    def run(*args):
        result, code = p.browser(list(args))
        if code:
            raise RuntimeError(f"{args}: {result}")
        return result

    def read(label, screenshot=True):
        data = json.loads(run("eval", JS))
        if screenshot:
            run("screenshot", str((out / (label + ".png")).relative_to(OUT.parent)))
            (out / (label + ".txt")).write_text(run("snapshot"))
        rows.append({"stage":label,**data})
        return data

    def button(label):
        if label == "Confirm":
            run("wait","--fn",'document.querySelector("[role=dialog]") && document.getAnimations().every(a => a.playState !== "running")')
        run("find","role","button","click","--name",label)

    def status_contains(email):
        run("wait","--fn",f'document.querySelector("[role=status]").innerText.includes("{email}")')

    rows = []
    run("open", "PREVIEW_URL")
    run("set", "viewport",str(width),str(height))
    read("initial", False)
    run("fill","#email","first@example.test")
    button("Review changes")
    button("Confirm")
    status_contains("first@example.test")
    run("wait","--fn",'!document.querySelector("[role=dialog]")')
    baseline = read("initial-applied",False)
    assert "Frequency: Daily" in baseline["applied"]
    run("fill","#email","not-an-email")
    run("click","#weekly")
    button("Review changes")
    invalid=read("invalid")
    assert invalid["invalid"] == "true" and invalid["focus"]["id"] == "email"
    run("fill","#email","team@example.test")
    button("Review changes")
    review=read("review")
    assert review["focus"]["label"]=="Cancel" and "Weekly" in review["dialog"]
    button("Cancel")
    run("wait","--fn",'!document.querySelector("[role=dialog]")')
    before=read("dismissed-before",False)
    assert before["email"]=="team@example.test" and "first@example.test" in before["applied"]
    button("Review changes")
    button("Confirm")
    during=read("applying")
    assert "Applying" in during["dialog"]
    button("Cancel")
    run("wait","--fn",'!document.querySelector("[role=dialog]")')
    closed=read("dismissed-during",False)
    assert closed["reviewDisabled"] and "first@example.test" in closed["applied"]
    status_contains("team@example.test")
    final=read("final")
    assert not final["reviewDisabled"] and "Frequency: Weekly" in final["applied"]
    run("press","Tab")
    read("tab-after-final",False)
    run("reload")
    after=read("reloaded")
    assert not after["applied"] and not after["email"] and after["selected"]=="daily"
    (out/"states.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2)+"\n")
    (out/"requests.txt").write_text(run("network","requests"))


if __name__ == "__main__":
    for viewport in [("wide",1180,820),("narrow",390,844)]:
        with Preview() as preview:
            exercise(preview,*viewport)
