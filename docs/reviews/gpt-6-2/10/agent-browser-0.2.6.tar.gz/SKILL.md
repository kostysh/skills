---
name: agent-browser
description: Use agent-browser to navigate and interact with rendered web pages,
  fill forms, take screenshots, extract data, and run browser smoke or
  diagnostic checks. Verify the requested terminal state and report completed,
  partial, or blocked; do not replace a formal project E2E suite.
metadata:
  source-version: 0.2.6
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: 9502c12456d1bf9fd2d061b308c96c76b74060c329951a69f2f210f7322caf27
allowed-tools: Bash(agent-browser:*)
---

# agent-browser

## Start here

1. Identify the target, requested user-visible result, expected terminal state, and any material limit on external side effects or extraction scope.
2. Run `agent-browser --version` and load the installed CLI's version-matched guidance with `agent-browser skills get core --full`; if unavailable, use `agent-browser --help`.
3. Before the first open and when the target, entrypoint, browser, session, profile, or authentication state changes, apply `Guidance and authority` to the browser environment actually selected.
4. Read `references/cloudflare-access-otp.md` before a human Cloudflare Access email-OTP flow; keep that browser identity gate separate from application authentication and infrastructure credentials.
5. Follow the snapshot loop, verify the requested result, and report exactly one status: completed, partial, or blocked.

## When to use this skill

- Navigating or interacting with rendered websites and web applications from the terminal.
- Filling forms, taking screenshots, recording evidence, exporting PDFs, or extracting rendered content.
- Running sampled browser smoke or diagnostic scenarios and inspecting page, console, or network behavior.
- Producing SPA evidence while distinguishing real backend paths from intercepted or mocked traffic.

## When NOT to use this skill

- Static source inspection or a direct HTTP client can establish the result without a rendered browser.
- The task is to author, maintain, or replace a formal project E2E suite.
- The requested tool is explicitly Playwright or a more specific browser skill owns the target workflow.

## Quick start

Use the guidance shipped by the installed CLI instead of a copied command
reference:

```bash
agent-browser --version
agent-browser skills get core --full
```

The stable interaction loop is:

Apply [Guidance and authority](#guidance-and-authority) before the first `open`
and at each route or identity transition. The loop does not choose an authorized
browser environment for you.

```bash
agent-browser open <url>
agent-browser snapshot -i
# interact with refs from the current snapshot
# wait for the expected result
agent-browser snapshot -i
agent-browser get url
```

Refs become stale after navigation and material page changes, so snapshot again
before reusing them. If bundled guidance is unavailable, check the root and
relevant subcommand help.

## What proves completion

- Navigation or interaction: the requested final URL or visible state is
  observed.
- Extraction: the requested fields and scope are checked, including pagination
  or lazy loading; otherwise report the extracted subset as partial.
- SPA or integration behavior: state whether relevant network calls were real or
  intercepted. Mocks prove local UI behavior only.
- Diagnosis: browser requests, responses, console, and page errors are evidence;
  another domain owner must establish backend or provider root cause.

## Setup boundary

Agent-browser owns its browser runtime. Do not install Playwright packages in the
target project to prepare it. Use the installed CLI's diagnostic and install
guidance, or report a blocked handoff when environment changes are not in scope.

Do not put secrets in command history or reports. Use the installed CLI's
authentication guidance and treat saved state, downloads, screenshots, traces,
and recordings as potentially sensitive.

## Workflow stages

### Workflow stage: Run and verify the browser task

Reach the requested observable result through the rendered page without confusing CLI activity with task completion.

1. Apply the governing user, system, and project policies, then the `Guidance and authority` browser-environment check before opening or changing route or identity; this skill does not grant authority for additional external side effects.
2. Use the installed CLI help for runtime errors. Before running `agent-browser doctor`, check its help and your authority for its side effects. Even `--offline --quick` can remove stale daemon files across the selected socket directory. Run repairs only within existing permissions. Keep Playwright installation out of the target project when preparing agent-browser.
3. Open the target, snapshot before using refs, interact, wait for the expected condition, and re-snapshot after navigation or material page changes.
4. Verify the final URL, visible state, or extracted values that establish the requested result; use console, page-error, network, screenshot, or trace evidence only when relevant.
5. For extraction, verify the requested fields and scope, including pagination or lazy-loading limits; if completeness is not established, report the observed subset as partial.
6. Treat intercepted responses as local UI evidence, not proof of a live API or provider path, and do not infer backend root cause from browser symptoms alone.

Validation:

- The expected terminal state is directly observed, or the exact blocker and strongest supported partial result are recorded.

### Workflow stage: Report the browser result

Provide an evidence-bounded outcome instead of a command transcript.

1. Report exactly one status: completed, partial, or blocked.
2. Name the target and context, main actions, expected and observed terminal state, real or intercepted network mode when relevant, and any unverified scope.
3. Do not expose credentials, tokens, cookies, or saved-state contents; report artifacts only when created.
4. Close task-owned sessions and processes and verify their actual termination, including any server child; Ctrl-C or launcher exit alone is not cleanup evidence. Confirm ownership before further termination actions.
5. If termination cannot be completed or verified, report the running or unverified remainder and its owner without claiming successful cleanup.

Validation:

- The user can tell what result was achieved, what was not proved, and whether anything remains running.

## Interop priority

- **Formal browser test suites, fixtures, assertions, coverage, and CI behavior:** the project E2E framework and its testing owner. Agent-browser supplies sampled smoke or diagnostic evidence and does not replace suite coverage.
- **Explicit Playwright CLI work or persistent interactive browser and Electron QA:** playwright or playwright-interactive as requested. Do not silently switch tools when the requested tool or persistent session model is part of the task.
- **Static retrieval or backend, security, accessibility, and other conclusions beyond observed browser facts:** the relevant source, HTTP, or domain skill. Agent-browser owns rendered browser interaction and observed evidence, not adjacent specialized conclusions.

## Gotchas

- **high** — Use the installed CLI's version-matched guidance and help for command syntax; do not maintain or trust a copied command encyclopedia when they disagree.
- **high** — Keep secrets out of shell history and reports, treat browser artifacts as potentially sensitive, and clean up sessions or processes started for the task.
- **high** — Never substitute Wrangler login, a Cloudflare API token, or an Access service token for a human Cloudflare Access browser login; report blocked when the authorized browser identity or confidential OTP path is unavailable.

## Policies

### Guidance and authority
Governing user, system, and project policies define authority; installed version-matched CLI guidance defines command syntax, not permission. Before the first open and whenever the target, entrypoint, browser, session, profile, or authentication state changes, compare the browser environment actually selected, its identity, and its owner with current permissions and prohibitions. Include selection through flags and applicable configuration without reading secrets. Continue in the same task-owned authorized isolated session when it remains valid; changing pages or completing a separate application login alone does not require another browser or renewed approval. CLI capability, permission to run a tool command, or an instruction to log in independently does not authorize another profile, and the tool name alone does not prove isolation. Do not make an unverified transition: keep an available authorized path or name the concrete blocker for the dependent action, while continuing independent authorized work. An explicit permission for another specific environment applies only within its scope and subject to stricter governing rules. This skill widens no authority.

### Browser evidence
Match evidence to the claim and report the target, expected and observed terminal state, relevant real or intercepted network mode, and exact limits of partial or blocked results.

## Required active references
- [Cloudflare Access OTP](references/cloudflare-access-otp.md) — Read this before a browser flow protected by a human Cloudflare Access email OTP, especially when the application has a separate OTP or infrastructure credentials are also available.

## Portability rules

- Do not reference machine-specific absolute paths or local files outside this skill folder.
- Keep the stable snapshot workflow and evidence contract inside this skill; external CLI guidance supplies only version-specific command details.

## Portability checklist before finishing

- Only when editing or packaging this skill itself, run compiler lint, regenerate, check, and an isolated compile; verify generated parity, local references, portability, and packaged files. These maintenance checks are not prerequisites for ordinary tasks performed with the skill.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
- Supporting glob: `docs/logs/*`
