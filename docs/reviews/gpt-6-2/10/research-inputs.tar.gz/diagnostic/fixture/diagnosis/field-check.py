"""Route the local CLI to the socket namespace selected by the caller."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
area, *args = sys.argv[1:]
if area not in ("support", "personal"):
    raise SystemExit("Choose support or personal")
env = {k: v for k,v in os.environ.items() if not k.startswith("AGENT_BROWSER_")}
env.update(AGENT_BROWSER_CONFIG=str(root/"empty.json"), AGENT_BROWSER_SESSION="demo",
           AGENT_BROWSER_SOCKET_DIR=str(root/area), AGENT_BROWSER_EXECUTABLE_PATH=shutil.which("google-chrome"))
sys.exit(subprocess.call(["agent-browser", *args], env=env, cwd=root))
