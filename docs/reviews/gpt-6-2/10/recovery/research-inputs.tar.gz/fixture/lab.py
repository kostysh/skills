"""Interactive transport for the installed CLI and a private loopback static server."""
import functools
import hashlib
import http.server
import json
import os
from pathlib import Path
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time

ROOT = Path(__file__).resolve().parent


def record(event):
    with (ROOT / "browser-record.jsonl").open("a") as stream:
        stream.write(json.dumps({"time_ns": time.monotonic_ns(), **event}, ensure_ascii=False) + "\n")


def process(pid):
    try:
        fields = Path(f"/proc/{pid}/stat").read_text().split(") ", 1)[1].split()
        return (fields[0], fields[19])
    except (FileNotFoundError, ProcessLookupError):
        return None


def descendants(pid):
    result = {}
    pending = [str(pid)]
    while pending:
        p = pending.pop()
        info = process(p)
        if p in result or not info:
            continue
        result[p] = info[1]
        try:
            for child_file in Path(f"/proc/{p}/task").glob("*/children"):
                pending.extend(child_file.read_text().split())
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


class Preview:
    def __enter__(self):
        self.temp = tempfile.TemporaryDirectory(prefix="screen-runtime-")
        self.private = Path(self.temp.name)
        self.processes = {}
        (self.private / "config.json").write_text("{}\n")
        handler = functools.partial(QuietHandler, directory=str(ROOT / "dist"))
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f"http://127.0.0.1:{self.server.server_port}/"
        self.env = {k: v for k, v in os.environ.items() if not k.startswith("AGENT_BROWSER_")}
        self.env.update(AGENT_BROWSER_SOCKET_DIR=str(self.private / "socket"),
                        AGENT_BROWSER_SESSION="preview", AGENT_BROWSER_CONFIG=str(self.private / "config.json"),
                        AGENT_BROWSER_EXECUTABLE_PATH=shutil.which("google-chrome"), AGENT_BROWSER_ALLOWED_DOMAINS="127.0.0.1",
                        AGENT_BROWSER_ARGS="--no-sandbox,--disable-dev-shm-usage,--disable-background-networking",
                        XDG_CONFIG_HOME=str(self.private / "config"), XDG_CACHE_HOME=str(self.private / "cache"))
        record({"kind":"start","url":self.url})
        return self

    def browser(self, args):
        args = [self.url if a == "PREVIEW_URL" else a for a in args]
        started = time.monotonic_ns()
        res = subprocess.run(["agent-browser", *args], cwd=ROOT, env=self.env, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
        output = res.stdout.decode(errors="replace")
        event = {"kind":"browser","args":args,"start_ns":started,"exit":res.returncode,
                 "output_sha256":hashlib.sha256(res.stdout).hexdigest()}
        if len(res.stdout) <= 20000:
            event["output"] = output
        else:
            event["output_bytes"] = len(res.stdout)
        record(event)
        pidfile = self.private / "socket" / "preview.pid"
        if pidfile.exists():
            self.processes.update(descendants(int(pidfile.read_text().strip())))
        return output, res.returncode

    def __exit__(self, *_):
        sockfile = self.private / "socket" / "preview.sock"
        if sockfile.exists():
            print(self.browser(["close"])[0], end="", flush=True)
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)
        port = self.server.server_port
        for _ in range(100):
            running = [pid for pid, stamp in self.processes.items()
                       if (current := process(pid)) and current[0] not in ("Z", "X") and current[1] == stamp]
            if not running:
                break
            time.sleep(.02)
        with socket.socket() as sock:
            result = {"port_open":sock.connect_ex(("127.0.0.1",port)) == 0,
                      "server_thread_running":self.thread.is_alive(),"browser_socket_exists":sockfile.exists(),
                      "observed_processes":len(self.processes), "surviving_observed_pids":running}
        record({"kind":"stopped","observed":result})
        print(json.dumps(result), flush=True)
        self.temp.cleanup()


if __name__ == "__main__":
    with Preview() as preview:
        print(f"Preview {preview.url}\nagent-browser> ", end="", flush=True)
        for line in sys.stdin:
            try:
                args = shlex.split(line)
                if args in (["quit"], ["exit"]):
                    break
                if args:
                    output, code = preview.browser(args)
                    print(output, end="")
                    print(f"[exit {code}]")
            except (ValueError, OSError) as error:
                print(str(error))
            print("agent-browser> ", end="", flush=True)
