"""Read substrate-independent state evidence in each neutral trial copy."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def observe(run, fixture):
    dispatch=json.loads((run/"dispatch.json").read_text())
    report=json.loads((run/"result.json").read_text())
    root=Path(dispatch["project"])
    before=dispatch["input_files"]
    expected={p.relative_to(fixture).as_posix():sha(p) for p in sorted(fixture.rglob("*")) if p.is_file()}
    assert all(before[k]==v for k,v in expected.items()) and report["exit"] == 0
    with tempfile.TemporaryDirectory(prefix="product-readback-") as d:
        copy=Path(d)
        for rel in (*expected,"browser-record.jsonl"):
            source=root/rel
            if source.is_file():
                dest=copy/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
        def values(names):
            return {name:{"bytes":(copy/name).stat().st_size,"sha256":sha(copy/name),"mode":oct((copy/name).stat().st_mode & 0o777)} if (copy/name).is_file() else None for name in names}
        log=copy/"browser-record.jsonl"
        if log.exists():
            records=[json.loads(line) for line in log.read_text().splitlines()]
            summary=[]
            for r in records:
                if r["kind"]!="browser":
                    summary.append(r);continue
                args=r["args"];out=r.get("output","")
                if args[:2]==["skills","get"] or any(t=="--help" for t in args):
                    continue
                if not out:
                    lines=[]
                elif len(out)<650:
                    lines=out.splitlines()
                else:
                    lines=[l for l in out.splitlines() if re.search(r"@|Settings applied|Saved for|Applying|Cancel|Confirm|\b(Daily|Weekly)\b|\bstatus\b|email address|Notifications:|button .*Review|reload|textbox |checked=true|notification",l,re.I)][:30]
                summary.append({"args":args,"runtime_exit":r["exit"],"stdout_sha256":r["output_sha256"],"observed_lines":lines})
            result={"method":"Neutral copy of the final standalone application and its unmodified CLI transport; read its recorded command stdout, exit and lifecycle. Snapshot excerpts below, complete small stdout in the original browser record.","fixture_files_changed":{k:v for k,v in expected.items() if not (copy/k).is_file() or sha(copy/k)!=v},"browser_record_sha256":sha(log),"actual_events":summary}
        else:
            result={"method":"Neutral copy after the commands. Read the bytes and modes independently for each supplied daemon namespace. See the accompanying observed command output.","namespace_files":values(k for k in expected if k.startswith(("support/","personal/"))),"support_before_sha256":{k:v for k,v in expected.items() if k.startswith("support/")},"personal_before_sha256":{k:v for k,v in expected.items() if k.startswith("personal/")}}
            evidence=[]
            for line in (run/"events.jsonl").read_text().splitlines():
                i=json.loads(line).get("item",{})
                if i.get("type")=="command_execution" and i.get("status")=="completed":
                    output=i.get("aggregated_output","")
                    match=[s[:450].replace(root.owner(),"{account}") for s in output.splitlines() if re.search('Cleaned stale|daemon.cleaned|spent\\.|process gone',s,re.I)]
                    if match: evidence.append({"command":i["command"].replace(str(root),"."),"output_sha256":hashlib.sha256(output.encode()).hexdigest(),"observations":match[:12]})
            result["relevant_command_stdout"]=evidence
        (run/"observer.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")


if __name__=="__main__":
    receipts=Path(sys.argv[1]);source=Path(sys.argv[2]);key=Path(sys.argv[3])
    for row in json.loads(key.read_text()):
        run=receipts/row["receipt"]
        if (run/"result.json").is_file():
            observe(run,source/"fixture"/row["case"])
            print(row["label"],"observed")
