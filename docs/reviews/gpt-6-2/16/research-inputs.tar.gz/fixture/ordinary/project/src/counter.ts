export function count(args: string[]): number { return args.length; }
