import test from 'node:test';
import assert from 'node:assert/strict';
import { count } from '../src/counter.ts';
test('counts values', () => assert.equal(count(['alpha','beta']), 2));
