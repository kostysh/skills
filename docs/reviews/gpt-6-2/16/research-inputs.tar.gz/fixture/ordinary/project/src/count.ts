import { count } from './counter.ts';
const total = count(process.argv.slice(2));
process.stdout.write(JSON.stringify({ count: total }) + '\n');
