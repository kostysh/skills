import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { display } from './display.ts';
const [file, operation, label] = process.argv.slice(2);
if (operation === 'set') {
  writeFileSync(file, JSON.stringify({ label }));
} else if (operation === 'show') {
  const stored = existsSync(file) ? JSON.parse(readFileSync(file, 'utf8')).label : 'Default';
  process.stdout.write(display(stored));
}
