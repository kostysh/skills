import test from 'node:test';
import assert from 'node:assert/strict';
import { display } from '../src/display.ts';
test('display line', () => assert.equal(display('Day'),'Day\n'));
