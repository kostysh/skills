export function display(label: string): string { return label + '\n'; }
