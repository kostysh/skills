import test from 'node:test';
import assert from 'node:assert/strict';
import { valid } from '../src/valid.ts';
test('valid integer', () => assert.ok(valid('4')));
