export function valid(text: string): boolean { const n = Number(text); return Number.isInteger(n) && n > 0; }
