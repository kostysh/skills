import { valid } from './valid.ts';
const input = process.argv[2] || '';
if (valid(input)) {
  process.stdout.write(String(Number(input)) + '\n');
} else {
  process.stderr.write('Invalid quantity\n');
  process.exitCode = 2;
}
