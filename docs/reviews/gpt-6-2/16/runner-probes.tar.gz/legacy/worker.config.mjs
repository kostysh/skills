import { defineConfig } from "vitest/config";
import { cloudflareTest } from "@cloudflare/vitest-pool-workers";
export default defineConfig({plugins:[cloudflareTest({wrangler:{configPath:"./worker/wrangler.jsonc"}})],test:{include:["worker/worker.test.ts"]}});
