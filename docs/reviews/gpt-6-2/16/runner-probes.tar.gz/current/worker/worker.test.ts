import { exports } from "cloudflare:workers";
import { expect, test } from "vitest";

test("serves the configured Worker binding through the fetch entry point", async () => {
  const ready = await exports.default.fetch("https://example.test/ready");
  expect(ready.status).toBe(200);
  expect(await ready.text()).toBe("local binding");
  const missing = await exports.default.fetch("https://example.test/other");
  expect(missing.status).toBe(404);
});
