export default {
  fetch(request: Request, env: { PROBE_MESSAGE: string }) {
    if (new URL(request.url).pathname === "/ready") {
      return new Response(env.PROBE_MESSAGE, {status: 200});
    }
    return new Response("missing", {status: 404});
  }
};
