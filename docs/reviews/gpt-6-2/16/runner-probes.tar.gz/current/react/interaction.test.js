import { createElement, useState } from "react";
import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, expect, test } from "vitest";

afterEach(cleanup);

function Counter() {
  const [total, setTotal] = useState(0);
  return createElement("button", { onClick: () => setTotal(total + 1) }, String(total));
}

test("a user click changes the visible counter", async () => {
  const user = userEvent.setup();
  render(createElement(Counter));
  await user.click(screen.getByRole("button", { name: "0" }));
  expect(screen.getByRole("button", { name: "1" })).toBeTruthy();
});

test("waitFor retries a rejection and resolves a returned false", async () => {
  let attempts = 0;
  await waitFor(async () => {
    attempts++;
    if (attempts === 1) throw new Error("pending");
  });
  expect(attempts).toBe(2);
  let observations = 0;
  expect(await waitFor(() => { observations++; return false; })).toBe(false);
  expect(observations).toBe(1);
});
