import { expect, test } from "vitest";

test("browser performs layout for a styled element", () => {
  const element = document.createElement("div");
  element.style.width = "32px";
  document.body.appendChild(element);
  try { expect(element.getBoundingClientRect().width).toBe(32); }
  finally { element.remove(); }
});
