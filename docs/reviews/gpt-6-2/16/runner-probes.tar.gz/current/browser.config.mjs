import { defineConfig } from "vitest/config";
import { playwright } from "@vitest/browser-playwright";
export default defineConfig({test:{
  include:["react/interaction.test.js","react/geometry.browser.test.js"],
  browser:{enabled:true, headless:true, instances:[{browser:"chromium"}],
    provider:playwright({launchOptions:{executablePath:process.env.ROW16_CHROMIUM}})}
}});
