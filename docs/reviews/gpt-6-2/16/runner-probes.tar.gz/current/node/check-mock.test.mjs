import { test } from "node:test";
import assert from "node:assert/strict";
test("uses the selected Node module mock options", async t => {
  const version = process.env.PROBE_OPTIONS;
  const options = version === "old" ? { namedExports: { observed: 17 } } : { exports: { observed: 17 } };
  t.mock.module("./dep.mjs", options);
  const module = await import("./dep.mjs");
  assert.equal(module.observed, 17);
});
