# Tally
Use `tally add 2 3 --output=json`.
