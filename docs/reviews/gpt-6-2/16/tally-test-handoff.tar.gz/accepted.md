Maintainer accepted: sum finite numbers, one JSON object {total}, invalid number stderr + exit2, help/version, noninteractive. No network or telemetry. Preserve tsc/tsx. No release or Git writes.
