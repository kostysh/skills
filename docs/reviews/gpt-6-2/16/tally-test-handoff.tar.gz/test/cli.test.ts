import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
enum Mode { Json = '--json' }
test('JSON is one object without narration',()=> { const r=spawnSync(process.execPath,['dist/cli.js','sum','2','3',Mode.Json],{encoding:'utf8'}); assert.equal(r.status,0); assert.deepEqual(JSON.parse(r.stdout),{total:5}); assert.equal(r.stderr,''); });
test('invalid input uses stderr and exit2',()=> { const r=spawnSync(process.execPath,['dist/cli.js','sum','bad'],{encoding:'utf8'}); assert.equal(r.status,2); assert.equal(r.stdout,''); assert.match(r.stderr,/Invalid number/); });
