import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const cli = fileURLToPath(new URL('../dist/cli.js', import.meta.url));

test('compiled sum separates JSON results from invalid input errors', () => {
  const options = { encoding: 'utf8', input: '', timeout: 5_000 } as const;

  const invalid = spawnSync(process.execPath, [cli, 'sum', '8', 'bad', '1.5', '--json'], options);
  assert.ifError(invalid.error);
  assert.equal(invalid.status, 2);
  assert.equal(invalid.stdout, '');
  assert.match(invalid.stderr, /Invalid number/);

  const valid = spawnSync(process.execPath, [cli, 'sum', '8', '-2', '1.5', '--json'], options);
  assert.ifError(valid.error);
  assert.equal(valid.status, 0);
  assert.equal(valid.stderr, '');
  assert.deepEqual(JSON.parse(valid.stdout), { total: 7.5 });
});
