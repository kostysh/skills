import { exports } from "cloudflare:workers";
import { expect, test } from "vitest";
test("serves a ready message",async()=>{expect(await (await exports.default.fetch("https://example.test/")).text()).toBe("Ready");});
