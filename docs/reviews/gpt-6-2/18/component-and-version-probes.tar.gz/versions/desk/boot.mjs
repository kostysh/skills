import React from 'react';
import {hydrateRoot} from 'react-dom/client';
import {App} from './view.mjs';
const native=document.startViewTransition?.bind(document);
const first=document.querySelector('h1');
window.probe={version:React.version,activity:typeof React.Activity,viewTransition:typeof React.ViewTransition,native:typeof native,starts:0,entries:0,effects:[],hydration:[],fragmentAPI:null,original:first};
if(native)document.startViewTransition=(...args)=>{window.probe.starts++;return native(...args);};
hydrateRoot(document.getElementById('root'),React.createElement(React.StrictMode,null,React.createElement(App)),{onRecoverableError:e=>window.probe.hydration.push(e.message)});
