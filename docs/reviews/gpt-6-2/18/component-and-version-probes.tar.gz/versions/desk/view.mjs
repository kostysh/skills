import React from 'react';

export function App() {
  const [open,setOpen]=React.useState(false);
  const fragment=React.useRef(null);
  React.useEffect(()=>{
    window.probe.effects.push('setup');
    window.probe.fragmentAPI=typeof fragment.current?.getClientRects;
    return ()=>{window.probe.effects.push('cleanup');};
  },[]);
  const h=React.createElement;
  const contents=open?h('p',null,'Schedule is open'):null;
  return h('main',null,h('h1',null,'Schedule'),h('button',{onClick:()=>React.startTransition(()=>setOpen(value=>!value))},'Toggle schedule'),
    h(React.Fragment,{ref:fragment},h('span',null,'Information')),
    React.ViewTransition && open?h(React.ViewTransition,{onEnter:()=>window.probe.entries++},contents):contents);
}
