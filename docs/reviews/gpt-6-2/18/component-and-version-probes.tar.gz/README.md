# Проверка в Chrome

Приложены исходные сценарии, которые сформировали component/*-chrome.json и version-probes.json. Папки component содержат исторический и исправленный файлы. В каждой папке из versions лежит тот же компонент Schedule. В действительных запусках использовались установленные React/DOM указанных версий и Vite 8.2.2. Манифесты воспроизводят версии прямых зависимостей для независимой копии.

В отдельном экземпляре нужной папки с Node 24.15.0 и настольным Chrome установите зависимости из package.json. Для component выполните node build.mjs, затем node visit.mjs. Отчёт появится в joint.json. Для versions выполните node build.mjs "$PWD/package.json", затем node visit.mjs. Отчёт появится в browser.json. Для проверки типов в component/handoff запустите tsc --noEmit --strict --target ES2022 --module NodeNext --moduleResolution NodeNext --jsx react-jsx client.tsx через установленный TypeScript. Результат ожидает правильную ссылку на кнопку и ошибку для ссылки на span.
