import {Tooltip} from './Tooltip.js'; import {createRef} from 'react';
const button=createRef<HTMLButtonElement>();
export const ok=<Tooltip label="First tip" ref={button}>First</Tooltip>;
// @ts-expect-error This component forwards its ref to a button, not a span.
export const wrong=<Tooltip label="Wrong element" ref={createRef<HTMLSpanElement>()}>Test</Tooltip>;
