import React from 'react';
import {hydrateRoot} from 'react-dom/client';
import {ComponentDemo} from './Tooltip.js';
const originalAdd=window.addEventListener.bind(window);
const originalRemove=window.removeEventListener.bind(window);
const listeners=new Map();
const delivered=[];
const recoverable=[];
let serial=0;
window.addEventListener=(kind,callback,options)=>{
  if(kind!=='resize') return originalAdd(kind,callback,options);
  if(!listeners.has(callback)){
    const identity=++serial;
    const bound=event=>{delivered.push(identity);return callback.call(window,event);};
    listeners.set(callback,{identity,bound});
  }
  return originalAdd(kind,listeners.get(callback).bound,options);
};
window.removeEventListener=(kind,callback,options)=>{
  if(kind!=='resize' || !listeners.has(callback))return originalRemove(kind,callback,options);
  const {bound}=listeners.get(callback);
  listeners.delete(callback);
  return originalRemove(kind,bound,options);
};
const firstBefore=document.querySelector('section button');
window.readEvidence=()=>({recoverable:[...recoverable],live:[...listeners.values()].map(v=>v.identity),delivered:[...delivered],retainedButton:firstBefore===document.querySelector('section button')});
hydrateRoot(document.getElementById('root'),React.createElement(ComponentDemo),{onRecoverableError:e=>recoverable.push(e.message)});
