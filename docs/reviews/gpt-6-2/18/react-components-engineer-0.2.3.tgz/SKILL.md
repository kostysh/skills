---
name: react-components-engineer
description: Build, harden, review, and diagnose reusable React components
  across SSR, hydration, multiple instances, portals, Effects, opaque children,
  and server/client boundaries. Use for component-level runtime resilience;
  route app architecture, styling, test strategy, and security verdicts to their
  owners.
metadata:
  source-version: 0.2.3
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: efc2571710b4cc8d22763fe5aa974f9944e00dfc9577204a4d50486af9fc61e0
---

# react-components-engineer

## Start here

1. Classify the task as create/change, review, or diagnose; review and diagnosis remain read-only unless remediation is explicitly authorized.
2. Establish the observable component behavior, consumer, supplied code, repository instructions, installed React and framework versions, release channel, applicable execution contexts, existing conventions, and available verification before choosing a pattern.
3. Apply precedence in this order: operator and repository instructions; accepted product, API, accessibility, and security contracts; manifest, lockfile, configuration, and existing code; official documentation matching the installed version and release channel; then examples in this skill.
4. Apply only risks supported by the component's actual execution contexts. Do not introduce a Canary or Experimental API, change the React release channel, or replace a framework-owned mechanism without explicit authority.
5. Stop as blocked when equal-authority sources conflict or a required product, security, framework, or compatibility decision has no owner-supplied answer. Otherwise provide the strongest bounded result and label missing evidence.
6. Define claim-matched behavioral evidence before changing anything. Source files, API imports, Storybook stories, mocks, typecheck, lint, build, or compiler success prove only their own contours.

## When to use this skill

- Creating, changing, reviewing, or diagnosing reusable React components and providers when runtime correctness across rendering contexts is material.
- Hardening component behavior for SSR, hydration, repeated mounts, multiple instances or roots, opaque children, portals, iframes, pop-out windows, Effects, transitions, Activity, or memoization.
- Assessing component-level server/client boundary mechanics alongside the framework and security owners.

## When NOT to use this skill

- App routing, data layers, forms, persistence, or SPA integration are the primary concern; use react-spa-engineer.
- Next.js App Router, RSC transport, caching, hydration shell, or framework configuration is the primary concern; use nextjs and pair this skill only for component semantics.
- The task is primarily visual design, design-system presentation, or styling; use frontend-design.
- The task is a formal accessibility or UX audit, test-runner strategy, TypeScript toolchain decision, security verdict, or general PR verdict; route that primary decision to its owning skill.

## Overview

Build React components that preserve their declared behavior in the rendering contexts the project actually uses.

## Capability and anti-claims

This skill succeeds when it implements an accepted component contract or provides a supported review or diagnosis. Preserve the public behavior, choose project-compatible patterns where needed, and match completion to the requested source or runtime claim; a clean review does not require finding a defect.

The instructions do not create runtime capability, choose a framework contract, grant authorization, prove accessibility or performance, or establish security by themselves. A hook, API import, wrapper, Storybook story, mock, typecheck, build, or generated file is bounded evidence and cannot close a broader behavior claim.

## Context decision matrix

| Context | Apply when | Required invariant | Claim-matched evidence |
| --- | --- | --- | --- |
| Every render | Always | Render is pure; state ownership is explicit; Effects synchronize only with external systems and have symmetric cleanup | Re-render and lifecycle scenario covering the external behavior |
| SSR and hydration | The component is server-rendered and hydrated | Server render does not touch browser-only APIs; initial client output matches server output | Server render plus hydration with mismatch/recoverable-error observation |
| Multiple instances or roots | Reuse, repeated mounts, or multiple roots are possible | No hardcoded shared DOM IDs or mutable singleton state; root prefixes are coordinated by the root owner | Two instances or roots exercised together |
| Opaque composition | The public API accepts arbitrary `children` or slots | Do not infer child shape without an explicit element contract; data flow remains traceable | Supported child forms and invalid-contract behavior exercised |
| Portal, iframe, or pop-out | DOM or events may live in another document | Browser resources derive from the owned DOM node or an explicit realm contract | Scenario in the actual target document/window |
| Visibility lifecycle | Activity or retained hidden UI is used | State and external side effects follow the installed API's visible/hidden lifecycle | Hide, update, reveal, and cleanup behavior exercised |
| Server/client boundary | RSC or another server/client component boundary is real | Client props follow the framework serialization contract; sensitive fields are allowlisted on the server | Framework integration/build plus boundary behavior; security owner evidence for security claims |
| Transition or optimization | The feature exists and a measured interaction or duplicate-work path is in scope | Optimization APIs never carry semantic correctness; version and release-channel gates are satisfied | Observed transition or measurement matching the claim |

The evidence column applies to claims about runtime behavior in that context. A source-only review may assess the corresponding code invariant without exercising or claiming the runtime boundary. Exclude contexts that project evidence makes impossible; do not add substrate to satisfy an inapplicable row.

## Version-sensitive API gates

| API | Gate | Boundary |
| --- | --- | --- |
| `useId` | Installed React supports it and a component-owned DOM relationship needs an ID | Not for list keys, data identity, cache keys, or async Server Components; multiple roots require owner-coordinated `identifierPrefix` |
| `cache` | React Server Components are actually used | Request-scoped memoization and shared snapshots only; it is not a concurrency-correctness primitive and framework caching policy still wins |
| `startTransition` | A non-urgent state update is appropriate | Marks the update as non-blocking. Keep text input updates urgent. Use `useTransition` for pending state |
| `<Activity>` | The installed stable React version exposes it and the component uses retained hidden UI | Hidden mode destroys Effects and later recreates them while preserving state; verify any globally scoped DOM or CSS behavior separately |
| `<ViewTransition>` | Stable since React 19.3, or an earlier installed prerelease that exports it | Observe the requested animation under a participating boundary and a transition-driven update in a supporting browser |
| Experimental taint APIs | The project already uses a compatible Experimental RSC environment | Optional defense-in-depth after authorization, DTO allowlisting, and isolation; never security closure |
| `useMemo`, `memo`, `useCallback` | Profiling or a concrete dependency-identity need justifies them | Performance hints only; correctness must survive cache discard or re-render |

For detailed patterns and caveats, load [React Component Resilience Patterns](references/bulletproof-patterns.md) only for the applicable contexts.

## Workflow stages

### Workflow stage: Establish the component basis

Make the task mode, authority, compatibility boundary, runtime claim, side effects, and proof target explicit.

1. Inspect applicable repository instructions, accepted contracts, package manifest and lockfile, relevant component and call sites, renderer or framework configuration, installed versions, current behavior, and available checks.
2. Record mode, in-scope component contract, consumer, allowed mutations, applicable contexts, source precedence, unresolved inputs, and the observable behavior or review question.
3. For review or diagnosis, remain read-only. For authorized changes, preserve the public API unless the requested outcome requires a deliberate contract change.

Validation:

- The next action does not depend on an invented React version, release channel, framework behavior, product rule, or security claim.
- Each selected resilience risk has a concrete failure path in the supplied component and contexts.

### Workflow stage: Select and apply the smallest supported pattern

Implement or assess the component contract without inventing defects, universal checklists, or version-incompatible APIs.

1. Load the conditional resilience reference only for the concrete risks in scope and apply its version and context gates.
2. Prefer project-native and stable React or framework mechanisms; add a version-sensitive API only when the installed environment supports it and the component actually uses the corresponding feature.
3. Preserve render purity, deterministic server/client output where hydration applies, symmetric Effect setup and cleanup, per-instance ownership, opaque-child contracts, correct DOM realm ownership, and explicit server/client data boundaries as applicable.
4. Route framework, security, accessibility, visual, TypeScript, test-runner, and formal-review decisions to their owners while retaining component-semantics responsibility.

Validation:

- The result addresses the accepted component contract or supported failure path; a clean review need not invent a defect or add an API, wrapper, story, or checklist item.
- Stable projects receive no unsupported Canary or Experimental imports and no release-channel change without explicit authority.

### Workflow stage: Verify and hand off the component result

Match the completion status to observed evidence and give the next consumer an actionable result.

1. Run only applicable scenarios, using the existing project test stack and a real renderer or browser boundary when the claim depends on hydration, another document, visibility lifecycle, or server/client integration.
2. Classify the result using the Evidence and status policy for the requested claim, distinguishing a source-level conclusion from runtime verification.
3. Report mode, component contract, applicable contexts, change or findings, verification evidence, status, residual risks or blockers, anti-claims, and next owner.

Validation:

- Missing evidence lowers only the conclusion that depends on it; a completed source-level review does not imply runtime verification.
- The handoff does not imply framework support, accessibility, performance, or security assurance that was not established by the owning skill and evidence.

## Interop priority

- **TypeScript language, compiler, tsconfig, module resolution, and lint configuration:** typescript-engineer. react-components-engineer owns component runtime semantics; typescript-engineer owns language and toolchain correctness.
- **Test strategy, runner behavior, fixtures, mocks, determinism, and CI contours:** typescript-test-engineer. react-components-engineer defines the component behavior and required scenario; typescript-test-engineer owns test design and runner correctness.
- **Client-side routing, data, forms, state, persistence, and SPA feature integration:** react-spa-engineer. react-spa-engineer owns the application flow; react-components-engineer owns reusable component behavior within that flow.
- **Next.js App Router, RSC transport, directives, caching, hydration shell, and framework configuration:** nextjs. nextjs owns framework semantics and installed-version behavior; react-components-engineer owns the reusable component contract at that boundary.
- **Visual hierarchy, styling, motion design, responsive composition, and design-system presentation:** frontend-design. frontend-design owns presentation decisions; react-components-engineer preserves runtime correctness.
- **Formal UX and accessibility review:** web-ui-reviewer. web-ui-reviewer owns the audit verdict; react-components-engineer implements or reviews component-level runtime corrections.
- **Sensitive-data classification, authorization, exploitability, threat modeling, and security verdicts:** security-reviewer. security-reviewer owns security assurance; react-components-engineer enforces only the accepted server/client component boundary.
- **Formal PR findings, severity, merge guidance, and review verdict:** code-reviewer. code-reviewer owns the formal verdict; react-components-engineer supplies React component domain analysis and implements authorized remediation.

## Gotchas

- **high** — Do not recommend an API from a different React release channel or version as a universal hardening step; prove installed support and feature applicability first.
- **high** — An imported API, hook, wrapper, Storybook story, mock, typecheck, build, or green unit test can be useful substrate without proving SSR, hydration, cross-document, lifecycle, RSC, performance, or security behavior.
- **high** — A reusable component must not silently inject a pre-hydration script or suppress a mismatch; app-shell ownership, CSP and escaping, framework support, and identical initial output must be resolved first.
- **high** — Experimental taint APIs are optional defense-in-depth for supported RSC environments, not a substitute for server authorization, DTO allowlisting, isolation, or a security review.
- **high** — Keep DOM ownership per instance and clean up its Effects.
- **medium** — Use useId for component-owned DOM and accessibility relationships, not list keys, data identities, cache keys, or async Server Components.

## Policies

### Applicability-first policy
Evaluate and verify only contexts that the component contract and project evidence make possible; an inapplicable axis is excluded with rationale, not mechanically implemented.

### Stable supported mechanism policy
Prefer the installed stable React and framework mechanisms. Canary or Experimental APIs require existing project adoption or explicit operator authority and must retain their channel caveats.

### Evidence and status policy
Report verified when evidence establishes the requested claim. A source-only review or diagnosis may be complete from inspected code, including a clean result; name that boundary without implying runtime verification. A runtime behavior claim requires the relevant renderer or browser evidence. Report partial only for a requested conclusion whose evidence is missing, and block only decisions that depend on unresolved authority or conflict.

## Required active references
- [React Component Resilience Patterns](references/bulletproof-patterns.md) — Read this when a concrete SSR, hydration, multi-instance, composition, portal, Effect lifecycle, transition, Activity, RSC, sensitive-data, or memoization risk is in scope and exact pattern or version caveats are needed.

## Portability rules

- Portable documentation-only engineering skill. It ships no runtime or test harness and requires repository evidence plus installed React and framework versions for project-specific decisions.
- Do not reference machine-specific absolute paths or local files outside this skill folder.
- Keep all mandatory react-components-engineer guidance inside this skill folder.
- Treat external documentation links as optional provenance; the local instructions must remain sufficient offline.
- Use relative links for local references, assets, scripts, tests, and supporting docs.

## Portability checklist before finishing

- Only when editing or packaging this skill itself, run compiler lint, regenerate, check, and an isolated compile; verify generated parity, local references, portability, and packaged files. These maintenance checks are not prerequisites for ordinary tasks performed with the skill.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
- Supporting glob: `docs/logs/*`
