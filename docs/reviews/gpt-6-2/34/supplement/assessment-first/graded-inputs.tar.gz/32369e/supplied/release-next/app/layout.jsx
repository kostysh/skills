export const metadata = {title: 'Dossiers'};
export default function Layout({children}) {return <html lang="en"><head><link rel="stylesheet" href="/assets/index-Cjq7RuI-.css"/></head><body><main>{children}</main></body></html>}
