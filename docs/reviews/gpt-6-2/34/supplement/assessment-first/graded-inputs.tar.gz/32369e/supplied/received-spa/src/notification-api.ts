export type Settings = { email: string; enabled: boolean; frequency: "daily" | "weekly" }

declare global {
  interface Window {
    notificationSettings?: { save(settings: Settings): Promise<void> }
  }
}

const endpoint = "/api/notification-settings"

export async function readSettings(signal?: AbortSignal): Promise<Settings | null> {
  const response = await fetch(endpoint, { signal, cache: "no-store" })
  if (!response.ok) throw new Error("Settings could not be read.")
  return response.json()
}

export async function saveSettings(settings: Settings): Promise<void> {
  if (window.notificationSettings) return window.notificationSettings.save(settings)
  const response = await fetch(endpoint, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(settings),
  })
  if (!response.ok) throw new Error("Settings could not be saved.")
}
