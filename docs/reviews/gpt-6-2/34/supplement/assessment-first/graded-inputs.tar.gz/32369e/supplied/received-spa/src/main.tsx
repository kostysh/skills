import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import { createBrowserRouter, Link } from "react-router"
import { RouterProvider } from "react-router/dom"
import { QueryClientProvider } from "@tanstack/react-query"
import { ThemeProvider } from "~ui/components/theme-provider.tsx"
import App from "./App"
import { client, settingsQuery } from "./notification-query"
import "./index.css"

const router = createBrowserRouter([
  { path: "/", element: <main className="mx-auto max-w-2xl p-8"><h1>Preferences</h1><Link to="/settings/notifications">Notification settings</Link></main> },
  {
    path: "/settings/notifications",
    loader: () => client.query(settingsQuery),
    Component: App,
    errorElement: <main className="mx-auto max-w-2xl p-8"><h1>Notification settings</h1><p role="alert">Settings could not be read.</p><a href="/settings/notifications">Try again</a></main>,
  },
])

createRoot(document.getElementById("root")!).render(
  <StrictMode><QueryClientProvider client={client}><ThemeProvider><RouterProvider router={router} /></ThemeProvider></QueryClientProvider></StrictMode>
)
