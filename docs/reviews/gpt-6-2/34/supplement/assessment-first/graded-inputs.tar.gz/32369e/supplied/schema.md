Файл приёмщика запускает текущий next start и передаёт объект страницы в прежний сценарий маршрута, как показано выбранными строками кода. Два объекта страницы SPA и Next различны. В SPA значение indicator кнопки снимается при чтении её оформления, до наведения и клавиатурного фокуса на эту кнопку. Проверка действий подтверждения идёт далее. Результаты выдаются в JSON только после фактического визита.

```js
const next=await context.newPage();const doc=await next.goto(endpoint);assert.equal(doc.status(),200);const raw=await doc.text();const serverView=await next.evaluate(html=>{const d=new DOMParser().parseFromString(html,'text/html');return {heading:d.querySelector('h1').textContent,ready:d.querySelector('[data-ready]').getAttribute('data-ready'),count:d.querySelector('[role=status]').textContent,mark:d.querySelector('button[data-stage]').getAttribute('data-stage'),href:d.querySelector('a[data-stage]').getAttribute('href')};},raw);
const recurrence=(0,eval)('('+await readFile(join(root,'previous-next-check.js'),'utf8')+')');const prior=await recurrence(next);
```
