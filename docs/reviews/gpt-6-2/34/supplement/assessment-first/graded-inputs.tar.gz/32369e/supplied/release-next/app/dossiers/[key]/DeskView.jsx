'use client';
import {useEffect, useState} from 'react';
import {Tooltip} from './Tooltip';
import {Button} from '../../components/button';
export default function DeskView({caseKey}) {
  const [count,setCount]=useState(0);
  const [ready,setReady]=useState(false);
  useEffect(()=>{setReady(true)},[]);
  return <section id="ledger" data-ready={ready ? 'yes' : 'no'}><p role="status">Selections: {count}</p>
    <Button type="button" variant="brand" onClick={()=>{if(caseKey !== 'cedar')setCount(value=>value+1)}}>Mark inspected</Button>
    <Tooltip label="Use the approved desk entry">Entry help</Tooltip>
    <Tooltip label="See the owner of this docket">Owner help</Tooltip>
    <Button asChild variant="brand"><a href="#ledger">Open record</a></Button></section>;
}
