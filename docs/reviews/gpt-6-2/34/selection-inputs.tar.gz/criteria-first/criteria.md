1. shadcn. 2. react-components-engineer. 3. frontend-design. Одна и та же опись и порядок для двух независимых выдач. Это три конкретные заявки.
