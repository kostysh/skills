import React,{useState} from 'react'
import {createRoot} from 'react-dom/client'
import {Button} from './components/ui/button'
import {Tooltip} from './components/Tooltip.js'
import './index.css'
function Desk(){const [count,mark]=useState(0);return <main><h1>Larch desk</h1><Button asChild variant="brand"><a id="open" href="#record">Open record</a></Button><Button id="save" variant="brand" onClick={()=>mark(c=>c+1)}>Keep record</Button><p id="record" role="status">Kept: {count}</p><Tooltip label="Read the shift details">Entry help</Tooltip></main>}
createRoot(document.querySelector('#root')!).render(<Desk/>)
