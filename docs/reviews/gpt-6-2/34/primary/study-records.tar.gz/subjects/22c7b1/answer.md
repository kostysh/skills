**Поставку Willow пока не принимать.** Регистровое обновление удаляет локальный вариант `brand`, а готовый кандидат ломает активацию **Keep record** с клавиатуры. [Требования владельца](/tmp/casework-tez9adfy/owner.md)

| Проверка | Результат |
|---|---|
| Регистровое обновление | Пробный запуск shadcn 4.23.0 показал, что замена `button.tsx` добавит `data-stage="ready"` и удалит `brand` с токеном `font-bold`. SHA-256 исходного файла до и после совпал. [Исходный Button](/tmp/casework-tez9adfy/installed/src/components/ui/button.tsx:11) · [Поставка из реестра](/tmp/casework-tez9adfy/registry/button.json) |
| Вариант `brand` и атрибут | Кандидат сохраняет `font-bold`. В Chrome оба элемента имели вычисленный `font-weight: 700` и `data-stage="ready"`. [Button кандидата](/tmp/casework-tez9adfy/candidate/src/components/ui/button.tsx:11) |
| **Open record** | `Tab` установил фокус на единственную ссылку без вложенного интерактивного элемента. `Enter` выполнил переход к `#record`. |
| **Keep record** | В отдельном чистом окне второй `Tab` установил фокус на **Keep record**. После `Space` статус остался `Kept: 0` вместо `Kept: 1`. Кандидат заменяет нативный `<button>` на `<div role="button">` без обработки `Space`. [Button кандидата](/tmp/casework-tez9adfy/candidate/src/components/ui/button.tsx:54) |

**Необходимое действие.** Вернуть поставку на доработку. Перенести только `data-stage="ready"` в установленный `Button`, сохранив `brand`, нативный `<button>` и композицию ссылки через `asChild`. Перед приёмкой повторить обе проверки в Chrome и подтвердить, что одно нажатие `Space` меняет статус с `Kept: 0` на `Kept: 1` в том же окне. [Порядок локальной проверки](/tmp/casework-tez9adfy/workplace.md)

Файлы не изменялись. Проверка охватила пробный запуск CLI и два сценария в Chrome. Полная сборка и проверка типов не запускались.