import { QueryClient, queryOptions } from "@tanstack/react-query"
import { readSettings } from "./notification-api"

export const client = new QueryClient()
export const settingsQuery = queryOptions({
  queryKey: ["notification-settings"],
  queryFn: ({ signal }) => readSettings(signal),
  staleTime: 0,
  retry: false,
})
