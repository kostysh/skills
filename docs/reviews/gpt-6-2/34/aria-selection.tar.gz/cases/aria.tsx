import { ToggleButtonGroup } from "react-aria-components";
export const group = <ToggleButtonGroup selectionMode="single" aria-label="View" />;
