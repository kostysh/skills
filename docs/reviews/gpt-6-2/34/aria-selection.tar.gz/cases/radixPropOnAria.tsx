import { ToggleButtonGroup } from "react-aria-components";
export const group = <ToggleButtonGroup type="single" aria-label="View" />;
