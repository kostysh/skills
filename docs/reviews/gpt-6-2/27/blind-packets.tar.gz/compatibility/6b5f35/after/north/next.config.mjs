export default {
  "cacheComponents": false,
  "partialPrefetching": false,
  "experimental": {
    "cpus": 1
  }
};
