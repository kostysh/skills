export default {
  "cacheComponents": true,
  "partialPrefetching": true,
  "experimental": {
    "cpus": 1
  }
};
