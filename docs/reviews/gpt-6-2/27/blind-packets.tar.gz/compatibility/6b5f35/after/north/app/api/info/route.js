export async function GET() {
  return Response.json({queue: 'public-desk'});
}
