import {cookies, headers} from 'next/headers';
export async function GET() {
  const desk = (await headers()).get('x-desk');
  const theme = (await cookies()).get('theme')?.value;
  return Response.json({desk, theme});
}
