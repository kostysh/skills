**Экран дежурного на маршруте `/dossiers/amber` прошёл приёмку по `contract.md`.**

- Первый HTTP-ответ на прямую ссылку вернул `200 OK`. Исходный HTML уже содержал заголовок `Amber docket`.
- В новой приватной вкладке Chrome виджет был готов к работе. Два нажатия `Mark inspected` изменили счётчик с `Selections: 0` на `Selections: 1`, затем на `Selections: 2`. Страницу не обновляли. [Журнал проверки](./visits/d6264d6f-3387-4fc1-a9cd-dff3ef484e7e.json) · [Итоговый снимок](./visits/d6264d6f-3387-4fc1-a9cd-dff3ef484e7e.png)