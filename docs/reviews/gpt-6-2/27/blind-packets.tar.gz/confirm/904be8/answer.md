**Экран Reed docket на маршруте `/dossiers/reed` готов для дежурного.** Действующий кандидат прошёл проверку по [contract.md](./contract.md).

Первый HTTP-ответ вернул `200 OK`. В исходном HTML были заголовок `Reed docket` и начальный счётчик `Selections: 0`. [Исходный HTML](./reed-response.html)

| Шаг в одной вкладке Chrome | Что показал экран |
|---|---|
| После двух нажатий `Mark inspected`, до обновления | `Selections: 2` |
| Сразу после обновления, до нового нажатия | `Selections: 0` |
| После одного нового нажатия `Mark inspected` | `Selections: 1` |

[Журнал браузерной проверки](./visits/1a0dadcc-656c-4fb2-81b3-cd0c6e349895.json)