# RSC Boundaries

Detect and prevent invalid patterns when crossing Server/Client component boundaries.

## Detection Rules

### 1. Async Client Components Are Invalid

Client components **cannot** be async functions. Only Server Components can be async.

**Detect:** File has `'use client'` AND component is `async function` or returns `Promise`

```tsx
// Bad: async client component
'use client'
export default async function UserProfile() {
  const user = await getUser() // Cannot await in client component
  return <div>{user.name}</div>
}

// Good: Remove async, fetch data in parent server component
// page.tsx (server component - no 'use client')
export default async function Page() {
  const user = await getUser()
  return <UserProfile user={user} />
}

// UserProfile.tsx (client component)
'use client'
export function UserProfile({ user }: { user: User }) {
  return <div>{user.name}</div>
}
```

```tsx
// Bad: async arrow function client component
'use client'
const Dashboard = async () => {
  const data = await fetchDashboard()
  return <div>{data}</div>
}

// Good: Fetch in server component, pass data down
```

### 2. Non-Serializable Props to Client Components

Props passed from Server to Client must satisfy React serialization, which is broader than JSON. Supported values include primitives (including bigint and globally registered symbols), Date, Map/Set containing supported values, typed arrays/ArrayBuffer, plain objects/arrays, Promises, JSX, and server functions. Preserve these public contracts; do not convert Date/Map/Set simply to pass the boundary.

Reject ordinary functions, arbitrary class instances, WeakMap/WeakSet, unregistered symbols and other unsupported values. Consult the installed React/Next contract for a less common value.

Reference: https://react.dev/reference/rsc/use-client

```tsx
// Bad: Function prop
// page.tsx (server)
export default function Page() {
  const handleClick = () => console.log('clicked')
  return <ClientButton onClick={handleClick} />
}

// Good: Define function inside client component
// ClientButton.tsx
'use client'
export function ClientButton() {
  const handleClick = () => console.log('clicked')
  return <button onClick={handleClick}>Click</button>
}
```

```tsx
// page.tsx (server): preserve supported types
export default async function Page() {
  const post = await getPost()
  return <PostCard createdAt={post.createdAt} counts={new Map([["likes", 1]])} />
}

// PostCard.tsx
'use client'
export function PostCard({ createdAt, counts }: { createdAt: Date; counts: Map<string, number> }) {
  return <span>{createdAt.getUTCFullYear()}: {counts.get("likes")}</span>
}
```

```tsx
// Bad: Class instance
const user = new UserModel(data)
<ClientProfile user={user} /> // Unsupported class instance: map explicitly to an allowed DTO

// Good: Pass plain object
const user = await getUser()
<ClientProfile user={{ id: user.id, name: user.name }} />
```

Date/Map/Set examples above exercise React transport; JSON HTTP responses have their separate JSON contract.

### 3. Server Actions Are the Exception

Functions marked with `'use server'` CAN be passed to client components.

```tsx
// Valid: Server Action can be passed
// actions.ts
'use server'
export async function submitForm(formData: FormData) {
  // server-side logic
}

// page.tsx (server)
import { submitForm } from './actions'
export default function Page() {
  return <ClientForm onSubmit={submitForm} /> // OK!
}

// ClientForm.tsx (client)
'use client'
export function ClientForm({ onSubmit }: { onSubmit: (data: FormData) => Promise<void> }) {
  return <form action={onSubmit}>...</form>
}
```

## Quick Reference

| Pattern | Valid? | Fix |
|---------|--------|-----|
| `'use client'` + `async function` | No | Fetch in server parent, pass data |
| Pass `() => {}` to client | No | Define in client or use server action |
| Pass `new Date()` to client | Yes | Preserve Date contract |
| Pass `new Map()` / `new Set()` to client | Yes | Entries must be supported values |
| Pass class instance to client | No | Pass plain object |
| Pass server action to client | Yes | - |
| Pass `string/number/boolean` | Yes | - |
| Pass plain object/array | Yes | - |
