**Не принят.** Экран `/dossiers/cedar` на действующем кандидате не выполняет обязательный сценарий дежурного. [Контракт](/tmp/casework-0zrzfi9v/contract.md)

Прямая ссылка вернула HTTP 200. Chrome показал заголовок `Cedar docket` и зафиксировал `data-ready="yes"`. После первого и второго нажатий `Mark inspected` статус остался `Selections: 0`. По контракту ожидались `Selections: 1` и `Selections: 2`. Через 1,5 секунды после второго нажатия значение всё ещё было `0`. [Журнал браузера](/tmp/casework-0zrzfi9v/visits/8b0c6df0-fa3b-48b2-b284-8081f13bd87f.json) · [Снимок экрана](/tmp/casework-0zrzfi9v/visits/8b0c6df0-fa3b-48b2-b284-8081f13bd87f.png)

Причина сбоя не установлена.