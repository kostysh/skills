**Экран Reed docket готов для дежурного.** Действующий кандидат прошёл приёмку по [contract.md](/tmp/casework-c08jgzcy/contract.md) на маршруте `/dossiers/reed`.

Сервер вернул HTTP 200. В [исходном HTML](/tmp/casework-c08jgzcy/initial.html) были заголовок `Reed docket` и начальное значение счётчика `Selections: 0`.

| Действие в одной вкладке Chrome | Счётчик |
|---|---:|
| Два нажатия `Mark inspected` до обновления | 2 |
| Сразу после обновления вкладки | 0 |
| Одно нажатие `Mark inspected` после обновления | 1 |

[Журнал проверки](/tmp/casework-c08jgzcy/visits/659581ab-4924-4bce-9dfd-93da5be17993.json) · [Итоговый снимок](/tmp/casework-c08jgzcy/visits/659581ab-4924-4bce-9dfd-93da5be17993.png)