**Экран `/dossiers/amber` готов для дежурного.** Действующий кандидат прошёл приёмку по [contract.md](/tmp/casework-5fner1wq/contract.md).

- Прямой запрос вернул `HTTP 200`. Исходный HTML уже содержал заголовок `Amber docket` и счётчик `Selections: 0`.
- После загрузки в новой вкладке Chrome два нажатия `Mark inspected` изменили счётчик с `0` на `1`, затем на `2`. Страницу вручную не обновлял. [Журнал проверки](/tmp/casework-5fner1wq/visits/2b55e945-099f-4f78-9921-c19f1d168996.json)