**Экран `/dossiers/amber` прошёл приёмку и готов для дежурного.**

- Прямой запрос вернул `HTTP 200`. Заголовок `Amber docket` уже присутствовал в HTML первого ответа.
- В новой сессии Chrome два нажатия `Mark inspected` изменили счётчик с `Selections: 0` на `Selections: 1`, затем на `Selections: 2`. Ручное обновление страницы не потребовалось.

[Контракт](/tmp/casework-pb7cml6l/contract.md) · [Журнал браузера](/tmp/casework-pb7cml6l/visits/ca5bee0d-5380-4e7e-a9d1-da353520819e.json)