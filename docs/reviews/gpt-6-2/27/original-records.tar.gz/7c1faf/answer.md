**Экран `/dossiers/cedar` не готов для дежурного.**

Прямая ссылка вернула `HTTP 200`, и Chrome показал заголовок `Cedar docket`. Перед первым нажатием виджет показывал `data-ready="yes"`. После каждого из двух нажатий `Mark inspected` счётчик оставался на `Selections: 0`, хотя [контракт](/tmp/casework-9sprevv5/contract.md) требует сначала `Selections: 1`, затем `Selections: 2`. Через две секунды счётчик всё ещё показывал `0`.

[Журнал проверки](/tmp/casework-9sprevv5/visits/42d5a1fd-c261-491d-b143-f2c2ae737ed6.json) · [Итоговый снимок](/tmp/casework-9sprevv5/visits/42d5a1fd-c261-491d-b143-f2c2ae737ed6.png)