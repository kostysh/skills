**Заявку целиком подтвердить нельзя.** На Next.js 16.4.6 `/api/info` готовится при сборке только у River. `/api/desk` у обеих служб возвращает данные текущего запроса. Патч River следует отклонить.

| Часть заявки | Решение |
|---|---|
| North `/api/info` | **Не подтверждено.** При `cacheComponents: false` и `partialPrefetching: false` GET не включает статическую генерацию явно. Сборка помечает маршрут `ƒ`, записи в манифесте пререндеринга нет. Постоянный ответ `{"queue":"public-desk"}` сам по себе не доказывает генерацию при сборке. [Протокол North](/tmp/casework-a8oo0ynd/north/build-and-http.json) |
| River `/api/info` | **Подтверждено для исходной поставки.** При включённых `cacheComponents` и `partialPrefetching` сборка помечает маршрут `○`. Маршрут есть в манифесте пререндеринга. [Протокол River](/tmp/casework-a8oo0ynd/river/build-and-http.json) |
| `/api/desk` у обеих служб | **Подтверждено.** Оба маршрута помечены `ƒ`. Обработчики читают заголовок `x-desk` и cookie `theme` из текущего запроса. В каждом протоколе два запроса вернули соответственно `amber/dark` и `reed/light`. [Протокол North](/tmp/casework-a8oo0ynd/north/build-and-http.json), [протокол River](/tmp/casework-a8oo0ynd/river/build-and-http.json) |
| Патч River | **Отклонить.** River уже использует Node.js по умолчанию. При включённых Cache Components явный `export const runtime = 'nodejs'` несовместим с конфигурацией. Сборка с патчем завершилась с кодом `1`. [Протокол сборки с патчем](/tmp/casework-a8oo0ynd/candidate-build.txt) |

**Выбор образа Node.js**

- **North** — оба предложенных образа, `24.15.0` и `24.22.3`, удовлетворяют указанному в локальном навыке минимуму Next.js 16 (`>=20.9`). Ограничение адаптера Payload к North не относится. [Зависимости North](/tmp/casework-a8oo0ynd/north/package.json), [локальный навык](/tmp/casework-a8oo0ynd/SKILL.md)
- **River с `@payloadcms/next@3.94.0`** — из двух образов подходит только `24.22.3`. Для ветки Node 24 адаптер требует `^24.22.3`. Next.js `16.4.6` входит в допустимый диапазон `>=16.4.5 <17.0.0`. Также нужны `payload@3.94.0` и `graphql@^16.8.1`. Это вывод по манифесту. Работу CMS на образе протоколы не проверяют. [Манифест адаптера](/tmp/casework-a8oo0ynd/adapter-manifest.json)

**Команда для коллеги** из каталога нужной службы с установленными зависимостями:

```bash
./node_modules/.bin/next analyze --output
```

Команда использует локальную Next CLI и записывает отчёт Turbopack в `.next/diagnostics/analyze` без запуска веб-интерфейса. [Справка CLI](/tmp/casework-a8oo0ynd/analyzer-help.txt), [локальная справка по анализу](/tmp/casework-a8oo0ynd/references/bundling.md:128)

Проверка выполнена по исходникам и приложенным протоколам. Сборку и анализатор повторно не запускал. Файлы не менял.