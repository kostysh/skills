Репозиторий github.com/kostysh/skills. Ветка codex/cli-list-bounds → master. Ссылка на PR https://github.com/kostysh/skills/pull/35.
