Публичный репозиторий github.com/kostysh/skills. PR https://github.com/kostysh/skills/pull/35 из codex/cli-list-bounds в master. Запуск https://github.com/kostysh/skills/actions/runs/40044930201.
