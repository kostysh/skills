Публичный репозиторий github.com/kostysh/skills. Ветка codex/typescript-test-async-determinism. Строка журнала https://github.com/kostysh/skills/actions/runs/42397445487/attempts/1.
