Публичный репозиторий github.com/kostysh/skills. Ветка codex/cli-list-bounds. В ведомости указана https://github.com/kostysh/skills/actions/runs/40044930201/attempts/2. В ведомости нет результата.
