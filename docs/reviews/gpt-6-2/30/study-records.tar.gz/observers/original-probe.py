from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib,json,os,shutil,subprocess,sys
lab=Path(__file__).resolve().parent;source=Path('/tmp/skills62-row-30-inputs/fixture')
def run(args,cwd):
    p=subprocess.run(args,capture_output=True,text=True,cwd=cwd,timeout=30,env={**os.environ,'npm_config_cache':str(lab.parent/'toolchains/offline-fixture-cache')})
    return {'command':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
def probe(project,case):
    with TemporaryDirectory(prefix='catalog-observer-') as temp:
        root=Path(temp);app=root/'code';shutil.copytree(project,app)
        trace={};node=['node','desk.mjs']
        if case=='holdout':
            for name,desk,sector in [('one','North','R21'),('two','South','R88')]:
                path=root/(name+'.json'); trace[name+'Write']=run(node+['issue',str(path),desk,sector],app); trace[name+'Read']=run(node+['open',str(path)],app)
            old=root/'old.json';old.write_text('{"desk":"West"}\n');trace['legacy']=run(node+['open',str(old)],app)
        else:
            saved=root/'data.json';shutil.copy2(app/'fixture/catalog.json',saved)
            trace['before']=run(node+[str(saved),'pins'],app);trace['pin']=run(node+[str(saved),'pin','a'],app);trace['after']=run(node+[str(saved),'pins'],app)
            old=root/'legacy.json';old.write_text('[{"id":"old","title":"Legacy"}]');trace['legacy']=run(node+[str(old),'pins'],app)
            trace['saved']=json.loads(saved.read_text())
        trace['tests']=run(['npm','test','--offline'],app)
        return json.loads(json.dumps(trace,ensure_ascii=False).replace(str(root),'<temporary>'))
if __name__=='__main__':
    if not sys.argv[1:]:
        data={case:probe(source/case/'product',case) for case in ('ordinary','boundary','holdout')}
        assert all(obs['tests']['exit']==0 for obs in data.values())
        for case in ('ordinary','boundary'):
            assert json.loads(data[case]['pin']['stdout'])==['Alpha','Beta'] and json.loads(data[case]['after']['stdout'])==[]
        assert json.loads(data['holdout']['oneRead']['stdout'])=={'desk':'North','sector':None}
        (lab/'preflight.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        print('3 baseline outcomes, tests green')
    else:
        for row in json.loads(Path(sys.argv[1]).read_text()):
            r=Path(row['receipt']);r=r if r.is_absolute() else lab/r
            d=json.loads((r/'dispatch.json').read_text());z=json.loads((r/'result.json').read_text());project=Path(d['project'])
            evidence=[]
            for ln in (r/'events.jsonl').read_text().splitlines():
                ev=json.loads(ln);i=ev.get('item',{});cmd=i.get('command','');out=i.get('aggregated_output','')
                if ev.get('type')!='item.completed' or i.get('type')!='command_execution' or not ('desk.mjs' in cmd or 'npm test' in cmd):continue
                if '## Workflow' in out or 'name: error-fixer' in out:continue
                evidence.append({'command':cmd.replace(str(project),'.'),'exit':i.get('exit_code'),'output':out[:5500].replace(str(project),'.'),'eventSha256':hashlib.sha256(ln.encode()).hexdigest()})
            changed=[name for name,prior in d['input_files'].items() if z['output_files'].get(name)!=prior or z['output_modes'].get(name)!=d['input_modes'][name]]
            data={'independentReplay':probe(project/'product',row['case']),'changedPriorFiles':changed,'added':sorted(set(z['output_files'])-set(d['input_files'])),'participantOperations':evidence}
            (r/'observer.json').write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
            print(row['label'],changed,data['added'])

