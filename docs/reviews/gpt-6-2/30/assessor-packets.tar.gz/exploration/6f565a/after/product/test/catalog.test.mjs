import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog, pinnedTitles, saveCatalog, setPinned } from '../src/catalog.mjs';

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

test('pinning and unpinning survive saving and reloading', (t) => {
  const directory = mkdtempSync(fileURLToPath(new URL('./.catalog-test-', import.meta.url)));
  t.after(() => rmSync(directory, { recursive: true }));
  const path = join(directory, 'catalog.json');
  const beta = { id: 'b', title: 'Beta', pinned: true };
  const alpha = { id: 'a', title: 'Alpha', pinned: false };
  writeFileSync(path, JSON.stringify([{ id: 'a', title: 'Alpha' }, beta]));

  const catalog = loadCatalog(path);
  assert.deepEqual(catalog, [alpha, beta]);

  saveCatalog(path, setPinned(catalog, 'a', true));
  const pinned = loadCatalog(path);
  assert.deepEqual(pinned, [{ ...alpha, pinned: true }, beta]);

  saveCatalog(path, setPinned(pinned, 'a', false));
  assert.deepEqual(loadCatalog(path), [alpha, beta]);
});
