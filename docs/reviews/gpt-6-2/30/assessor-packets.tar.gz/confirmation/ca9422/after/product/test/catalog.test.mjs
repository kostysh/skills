import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { loadCatalog, pinnedTitles, saveCatalog, setPinned } from '../src/catalog.mjs';

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

test('pinning and unpinning survive saving and reloading the catalog', t => {
  const directory = mkdtempSync(join(tmpdir(), 'card-catalog-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const file = join(directory, 'catalog.json');
  const alpha = { id: 'a', title: 'Alpha' };
  const beta = { id: 'b', title: 'Beta', pinned: true };
  writeFileSync(file, JSON.stringify([alpha, beta]));

  const original = loadCatalog(file);
  assert.deepEqual(original, [{ ...alpha, pinned: false }, beta]);

  saveCatalog(file, setPinned(original, 'a', true));
  const pinned = loadCatalog(file);
  assert.deepEqual(pinned, [{ ...alpha, pinned: true }, beta]);

  saveCatalog(file, setPinned(pinned, 'a', false));
  assert.deepEqual(loadCatalog(file), original);
});
