import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';

function runDesk(...args) {
  return JSON.parse(execFileSync(process.execPath, ['desk.mjs', ...args], {
    cwd: import.meta.dirname,
    encoding: 'utf8',
  }));
}

test('issued passes keep their desk and sector when opened in a new process', (t) => {
  const directory = mkdtempSync(join(import.meta.dirname, '.passes-'));
  t.after(() => rmSync(directory, { recursive: true }));

  for (const [desk, sector] of [['Atrium', '007'], ['Северная стойка', '42']]) {
    const path = join(directory, `pass-${sector}.json`);
    const expected = { desk, sector };
    assert.deepEqual(runDesk('issue', path, desk, sector), expected);
    assert.deepEqual(runDesk('open', path), expected);
  }
});

test('opens an existing pass containing only a desk', (t) => {
  const directory = mkdtempSync(join(import.meta.dirname, '.passes-'));
  t.after(() => rmSync(directory, { recursive: true }));

  const path = join(directory, 'legacy.json');
  writeFileSync(path, '{"desk":"Archive"}');
  assert.deepEqual(runDesk('open', path), { desk: 'Archive', sector: null });
});
