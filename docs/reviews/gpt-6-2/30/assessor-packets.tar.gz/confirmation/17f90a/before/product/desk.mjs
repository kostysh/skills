import {writeFileSync,readFileSync} from 'node:fs';
const [action,path,desk,sector]=process.argv.slice(2);
if(action==='issue'){writeFileSync(path,JSON.stringify({desk}));console.log(JSON.stringify({desk,sector}));}
else if(action==='open'){const record=JSON.parse(readFileSync(path,'utf8'));console.log(JSON.stringify({desk:record.desk,sector:record.sector??null}));}
else {console.error('issue or open');process.exitCode=2;}
