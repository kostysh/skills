import test from 'node:test';import assert from 'node:assert/strict';test('visible desk name serializes',()=>assert.equal(JSON.parse(JSON.stringify({desk:'Atrium'})).desk,'Atrium'));
