import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { loadCatalog, setPinned, saveCatalog, pinnedTitles } from '../src/catalog.mjs';

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

test('pinning and unpinning survive a save and reload', (t) => {
  const directory = mkdtempSync(join(import.meta.dirname, '.catalog-'));
  t.after(() => rmSync(directory, { recursive: true }));
  const path = join(directory, 'catalog.json');
  const alpha = { id: 'a', title: 'Alpha' };
  const beta = { id: 'b', title: 'Beta', pinned: true };
  writeFileSync(path, JSON.stringify([alpha, beta]));

  const cards = loadCatalog(path);
  assert.deepEqual(cards, [{ ...alpha, pinned: false }, beta]);
  saveCatalog(path, setPinned(cards, 'a', true));

  const reloaded = loadCatalog(path);
  assert.deepEqual(reloaded, [{ ...alpha, pinned: true }, beta]);
  saveCatalog(path, setPinned(reloaded, 'a', false));

  assert.deepEqual(loadCatalog(path), [{ ...alpha, pinned: false }, beta]);
});
