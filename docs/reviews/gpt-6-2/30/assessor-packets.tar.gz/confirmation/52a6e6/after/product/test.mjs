import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { copyFileSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const command = fileURLToPath(new URL('./desk.mjs', import.meta.url));
const scratchPrefix = fileURLToPath(new URL('./.desk-test-', import.meta.url));

function runDesk(...args) {
  return JSON.parse(execFileSync(process.execPath, [command, ...args], { encoding: 'utf8' }));
}

test('new passes retain their desk and sector across processes', (t) => {
  const directory = mkdtempSync(scratchPrefix);
  t.after(() => rmSync(directory, { recursive: true }));

  const passes = [
    { desk: 'Atrium', sector: '12' },
    { desk: 'Северная стойка', sector: '007' },
    { desk: 'West Desk', sector: '0' },
  ];

  for (const [index, pass] of passes.entries()) {
    const path = join(directory, `pass-${index}.json`);
    assert.deepEqual(runDesk('issue', path, pass.desk, pass.sector), pass);
  }

  for (const [index, pass] of passes.entries()) {
    const path = join(directory, `pass-${index}.json`);
    assert.deepEqual(runDesk('open', path), pass);
  }
});

test('opening a legacy pass returns its desk and leaves the file intact', (t) => {
  const directory = mkdtempSync(scratchPrefix);
  t.after(() => rmSync(directory, { recursive: true }));

  const original = join(directory, 'previous.json');
  const copy = join(directory, 'legacy.json');
  writeFileSync(original, '{"desk":"Архив"}\n');
  copyFileSync(original, copy);

  assert.deepEqual(runDesk('open', copy), { desk: 'Архив', sector: null });
  assert.deepEqual(readFileSync(copy), readFileSync(original));
});
