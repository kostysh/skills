import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { copyFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog, setPinned, saveCatalog, pinnedTitles } from '../src/catalog.mjs';

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

test('pinning and unpinning survive reopening the catalog', t => {
  const directory = mkdtempSync(join(process.cwd(), '.catalog-test-'));
  t.after(() => rmSync(directory, { recursive: true }));
  const file = join(directory, 'catalog.json');
  copyFileSync(new URL('../fixture/catalog.json', import.meta.url), file);
  const desk = fileURLToPath(new URL('../desk.mjs', import.meta.url));
  const runDesk = (...args) => JSON.parse(
    execFileSync(process.execPath, [desk, file, ...args], { encoding: 'utf8' })
  );

  assert.deepEqual(runDesk('pin', 'a'), ['Alpha', 'Beta']);
  assert.deepEqual(runDesk('pins'), ['Alpha', 'Beta']);

  saveCatalog(file, setPinned(loadCatalog(file), 'a', false));
  assert.deepEqual(runDesk('pins'), ['Beta']);
  assert.deepEqual(loadCatalog(file), [
    { id: 'a', title: 'Alpha', pinned: false },
    { id: 'b', title: 'Beta', pinned: true },
  ]);
});
