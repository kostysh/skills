import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCatalog, setPinned, pinnedTitles } from '../src/catalog.mjs';

test('smoke: pinned card is visible immediately', () => {
  const cards = [{ id: 'a', title: 'Alpha', pinned: false }, { id: 'b', title: 'Beta', pinned: false }];
  assert.deepEqual(pinnedTitles(setPinned(cards, 'a', true)), ['Alpha']);
});

test('unknown card is rejected', () => {
  assert.throws(() => setPinned([], 'missing', true), /Unknown card/);
});

const catalogModule = new URL('../src/catalog.mjs', import.meta.url).href;
const desk = fileURLToPath(new URL('../desk.mjs', import.meta.url));
const fixture = new URL('../fixture/catalog.json', import.meta.url);

function workFile(t, contents) {
  const directory = mkdtempSync(join(tmpdir(), 'card-catalog-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const path = join(directory, 'catalog.json');
  writeFileSync(path, contents);
  return path;
}

function runNode(...args) {
  return JSON.parse(execFileSync(process.execPath, args, { encoding: 'utf8' }));
}

const scenarios = [
  { name: 'pin', alpha: { pinned: false }, pinned: true },
  { name: 'unpin', alpha: { pinned: true }, pinned: false },
  { name: 'pin legacy card', alpha: {}, pinned: true },
];

for (const { name, alpha, pinned } of scenarios) {
  test(`save and reopen: ${name}`, t => {
    const cards = [
      { id: 'a', title: 'Alpha', ...alpha },
      { id: 'b', title: 'Beta', pinned: true },
      { id: 'c', title: 'Gamma', pinned: false },
    ];
    const expected = [{ ...cards[0], pinned }, cards[1], cards[2]];
    const path = workFile(t, JSON.stringify(cards));
    assert.deepEqual(loadCatalog(path), [
      { ...cards[0], pinned: alpha.pinned ?? false }, cards[1], cards[2],
    ]);

    const changed = runNode('--input-type=module', '-e', `
      import { loadCatalog, setPinned, saveCatalog } from ${JSON.stringify(catalogModule)};
      const [path, value] = process.argv.slice(1);
      const cards = setPinned(loadCatalog(path), 'a', value === 'true');
      saveCatalog(path, cards);
      console.log(JSON.stringify(cards));
    `, path, String(pinned));
    assert.deepEqual(changed, expected);

    const reopened = runNode('--input-type=module', '-e', `
      import { loadCatalog } from ${JSON.stringify(catalogModule)};
      console.log(JSON.stringify(loadCatalog(process.argv[1])));
    `, path);
    assert.deepEqual(reopened, expected, 'catalog reopened in a fresh process');
    assert.deepEqual(JSON.parse(readFileSync(path, 'utf8')), expected, 'saved JSON');
  });
}

test('desk retains the new and existing pins after reopen', t => {
  const path = workFile(t, readFileSync(fixture));
  assert.deepEqual(runNode(desk, path, 'pins'), ['Beta']);
  assert.deepEqual(runNode(desk, path, 'pin', 'a'), ['Alpha', 'Beta']);
  assert.deepEqual(runNode(desk, path, 'pins'), ['Alpha', 'Beta']);
});

test('desk rejects an unknown id without writing the catalog', t => {
  const original = readFileSync(fixture);
  const path = workFile(t, original);
  const result = spawnSync(process.execPath, [desk, path, 'pin', 'missing'], { encoding: 'utf8' });
  assert.equal(result.status, 1);
  assert.match(result.stderr, /Error: Unknown card: missing/);
  assert.deepEqual(readFileSync(path), original);
});
