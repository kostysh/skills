enum Field { Items = 'items' }
export function report(count: number) {
  return JSON.stringify({[Field.Items]: count});
}
