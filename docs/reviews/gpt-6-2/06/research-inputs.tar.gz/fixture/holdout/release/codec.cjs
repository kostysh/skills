exports.report = count => JSON.stringify({items: count});
