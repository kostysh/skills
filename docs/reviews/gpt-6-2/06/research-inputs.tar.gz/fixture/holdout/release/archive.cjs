const {setTimeout: delay} = require('node:timers/promises');

async function writeReport(count, onStop) {
  try {
    const codec = onStop ? await import('#codec') : require('#codec');
    if (onStop) await delay(20);
    process.stdout.write(codec.report(count) + '\n');
  } catch (error) {
    console.error(error.code ?? error.message);
    process.exitCode = 7;
  }
}

if (process.argv[2] === '--follow') {
  const heartbeat = setInterval(() => {}, 1000);
  process.once('SIGTERM', () => {
    clearInterval(heartbeat);
    void writeReport(5, true);
  });
  process.stdout.write('ready\n');
} else {
  const count = Number(process.argv[2]);
  if (Number.isInteger(count) && count >= 0) void writeReport(count, false);
  else { console.error('invalid count'); process.exitCode = 2; }
}
