export function report(count: number) {
  return JSON.stringify({items: count});
}
