import { field } from './header.mts';
export function report(count: number) {
  return JSON.stringify({[field]: count});
}
