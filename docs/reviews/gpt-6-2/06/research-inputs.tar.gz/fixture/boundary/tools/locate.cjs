const {relative} = require('node:path');
console.log(relative(process.cwd(), require.resolve('#codec')));
