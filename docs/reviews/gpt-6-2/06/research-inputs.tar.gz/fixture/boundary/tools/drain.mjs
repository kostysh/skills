import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';

const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url)));
const entry = pkg.scripts.start.split(' ')[1];
const worker = spawn(process.execPath, [entry, '--follow'], {stdio: ['ignore', 'pipe', 'pipe']});
let ready = '';
let signalled = false;
let expired = false;
const budget = setTimeout(() => { expired = true; worker.kill('SIGKILL'); }, 2000);
worker.stdout.on('data', chunk => {
  process.stdout.write(chunk);
  ready += chunk.toString();
  if (!signalled && ready.includes('ready\n')) {
    signalled = true;
    worker.kill('SIGTERM');
  }
});
worker.stderr.pipe(process.stderr, {end:false});
worker.on('close', (code, signal) => {
  clearTimeout(budget);
  console.error(JSON.stringify({sent: signalled ? 'SIGTERM' : null, exit: code, signal, deadline: expired}));
  process.exitCode = code ?? 125;
});
