#!/usr/bin/env node
const args=process.argv.slice(2);
if(args.includes('--help')) { console.log('tally 1.0.0\nUsage: tally sum <numbers...> [--json]'); }
else if(args.includes('--version')) { console.log('1.0.0'); }
else if(args[0]==='sum') {
  const json=args.includes('--json');
  const values=args.slice(1).filter(x=>x!=='--json').map(Number);
  if(values.length===0 || values.some(x=>!Number.isFinite(x))) { console.error('Invalid number'); process.exitCode=2; }
  else {
    const total=values.reduce((a,b)=>a+b,0);
    if(!json) console.log('Calculating');
    console.log(json?JSON.stringify({total}):String(total));
  }
} else { console.error('Unknown command'); process.exitCode=2; }
