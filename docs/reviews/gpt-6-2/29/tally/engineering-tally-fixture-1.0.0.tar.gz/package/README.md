# Tally
Use `tally sum 2 3 --json`.
