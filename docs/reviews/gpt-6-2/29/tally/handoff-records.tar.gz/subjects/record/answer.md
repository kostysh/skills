Подготовил и проверил [npm-архив engineering-tally-fixture 1.0.0](/tmp/casework-rl506lec/delivery/engineering-tally-fixture-1.0.0.tgz). Исправленные исходники сохранены в `product/`.

**SHA-256** `8c13c0d5a93ffe152e34cd80beb0bb0c4b23434fadc7ab979c34b503278adc59`

Команда `tally` запускает актуальную сборку. `sum --json` выводит в stdout один объект JSON. Ошибки идут в stderr с кодом `2` и пустым stdout. Пустые аргументы отклоняются, а переполнение суммы возвращает ошибку вместо `{"total":null}`. `--version` берёт версию из манифеста. README в архиве содержит проверенные команды установки, запуска и удаления.

Из каталога своего npm-проекта выполните:

```sh
npm install --offline --no-audit --no-fund /path/to/engineering-tally-fixture-1.0.0.tgz
./node_modules/.bin/tally sum 8 -2 1.5 --json
```

Ожидаемый stdout — `{"total":7.5}` с переводом строки. Код завершения — `0`, stderr пуст.

После распаковки `dev-dependencies.tgz` в `product/` прошли `npm run typecheck`, `npm run build` и `npm test` — **3 из 3 тестов**, включая дополнительный процессный. `npm pack --dry-run --json` и проверка готового архива подтвердили состав поставки: `README.md`, `package.json` и `dist/cli.js`.

В чистом npm-проекте проверил офлайн-установку и удаление архива. Через установленную команду с перенаправленным stdin прошли 11 проверок, включая `--help`, `--version`, обычную сумму, JSON и ошибочные входные данные. Проверка ограничена Linux x64, Node.js 24.15.0 и npm 12.0.1. Сеть, публикация и Git не использовались.