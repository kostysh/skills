Исправленный Tally 1.0.0 находится в [product/]({project}/product/). Готовый npm-архив [engineering-tally-fixture-1.0.0.tgz]({project}/delivery/engineering-tally-fixture-1.0.0.tgz) проверен после чистой локальной установки. Команда `tally` запускает `dist/cli.js`, а `sum --json` печатает один JSON-объект. Пример в README обновлён.

**Установка и запуск из каталога поставки**

```sh
archive="$PWD/delivery/engineering-tally-fixture-1.0.0.tgz"
recipient=$(mktemp -d "$PWD/tally-recipient.XXXXXXXX")
cd "$recipient"
npm --offline --no-update-notifier --cache "$PWD/.npm-cache" \
  install --no-audit --no-fund "$archive"
export PATH="$PWD/node_modules/.bin:$PATH"
tally sum 2 3 --json
```

Архив не требует dev-зависимостей для установки и запуска. Они распакованы в `product/` для сборки и тестов.

**Наблюдаемый вывод установленной команды**

| Команда | Код | stdout | stderr |
|---|---:|---|---|
| `tally --help` | 0 | `tally 1.0.0\nUsage: tally sum <numbers...> [--json]\n` | пусто |
| `tally --version` | 0 | `1.0.0\n` | пусто |
| `tally sum 2 3 --json` | 0 | `{"total":5}\n` | пусто |
| `tally sum 8 -2 1.5 --json` | 0 | `{"total":7.5}\n` | пусто |
| `tally sum 2 3` | 0 | `Calculating\n5\n` | пусто |
| `tally sum bad --json` | 2 | пусто | `Invalid number\n` |

`\n` обозначает перевод строки. Команды проверены с неинтерактивным stdin, без запросов ввода. Семантика чисел сохранена. Например, при переполнении суммы `tally sum 1e308 1e308 --json` по-прежнему выводит `{"total":null}` с кодом `0`.

В `product/` прошли `npm run typecheck`, `npm run build` и все три существующих теста через `npm test`. Проверка выполнена на Linux x64 с Node.js `v24.15.0` и npm `12.0.1`. Другие платформы и версии не проверялись. Работа выполнена локально, без сети, публикации и Git.

**SHA-256 архива**  
`7c9f8bff28fee4cb4acd9dfec592b15e688cf040990a001d66a8d1ba73bce0cc`