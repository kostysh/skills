# Tally

Tally sums finite numbers locally. The npm package is `engineering-tally-fixture`.

## Install from the archive

Local installation was verified on Linux x64 with Node.js 24.15.0 and npm 12.0.1.
From your npm project directory, run the following command with the archive path.

```sh
npm install --offline --no-audit --no-fund /path/to/engineering-tally-fixture-1.0.0.tgz
```

## Run the local command

```sh
./node_modules/.bin/tally sum 8 -2 1.5 --json
./node_modules/.bin/tally --help
./node_modules/.bin/tally --version
```

`sum` takes one or more numbers as arguments. It runs without prompts or a terminal and does not read stdin. It makes no network requests and sends no telemetry.

On success, the exit code is `0`. With `--json`, stdout contains one JSON object followed by a newline, for example `{"total":7.5}`. Without `--json`, stdout contains the sum as text. Invalid or missing numbers, a non-finite sum, and unknown commands produce a diagnostic on stderr and exit code `2`. Stdout is empty on these errors.

To remove the local installation, run `npm uninstall --offline --no-audit --no-fund engineering-tally-fixture`.
