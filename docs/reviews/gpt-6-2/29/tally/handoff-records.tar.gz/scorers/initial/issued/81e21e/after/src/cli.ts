#!/usr/bin/env node
import { readFileSync } from 'node:fs';

const args = process.argv.slice(2);
const [command, ...operands] = args;

function fail(message: string): void {
  console.error(message);
  process.exitCode = 2;
}

if (args.includes('--help') || args.includes('--version')) {
  const manifest = readFileSync(new URL('../package.json', import.meta.url), 'utf8');
  const { version } = JSON.parse(manifest) as { version: string };

  if (args.includes('--help')) {
    console.log(`tally ${version}\nUsage: tally sum <numbers...> [--json]`);
  } else {
    console.log(version);
  }
} else if (command === 'sum') {
  const numbers = operands.filter(operand => operand !== '--json');
  const values = numbers.map(number => number.trim() === '' ? NaN : Number(number));

  if (values.length === 0 || values.some(value => !Number.isFinite(value))) {
    fail('Invalid number');
  } else {
    const total = values.reduce((sum, value) => sum + value, 0);

    if (!Number.isFinite(total)) {
      fail('Invalid number: sum is outside the finite range');
    } else {
      console.log(operands.includes('--json') ? JSON.stringify({ total }) : String(total));
    }
  }
} else {
  fail('Unknown command');
}
