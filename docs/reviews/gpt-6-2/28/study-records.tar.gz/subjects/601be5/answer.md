**Поставку выдавать нельзя.** Для записи `m3` договор требует `502` с телом `{"error":"invalid_record"}`. Приложение вернуло `200` с телом `{"id":"m3","title":33}`. Этап `error` отсутствует. Обработчик чтения передаёт запись в JSON без проверки `title`, поэтому `app.onError` не вызывается. [Договор](/tmp/casework-bfggyw7h/contract.md:1) · [Код маршрута](/tmp/casework-bfggyw7h/release/app.mjs:13)

| Сценарий | Фактический ответ | `x-desk-steps` | Итог |
|---|---|---|---|
| Чтение `k8` с рабочей сессией | `200`, `{"id":"k8","title":"River"}` | `dispatch,session,read` | Соответствует |
| Чтение без сессии | `401`, `{"error":"sign_in"}` | `dispatch,session` | Соответствует |
| Чтение отсутствующей карточки `absent` | `404`, `{"error":"not_found"}` | `dispatch,session,read` | Соответствует |
| Чтение непригодной записи `m3` | `200`, `{"id":"m3","title":33}` | `dispatch,session,read` | Нарушение. Ожидался также этап `error` после `read` |

Проверил четыре сценария в расходной копии через `app.request()` на поставленной Hono 4.13.19 и Node.js 24.15.0. Штатный `npm test` прошёл. Он проверяет только статус и заголовок карточки `k8` в теле ответа. [Smoke-тест](/tmp/casework-bfggyw7h/release/smoke.test.mjs:2)