**Поставку выдавать нельзя.** С рабочей сессией `GET /desk/r9` возвращает `200` и карточку с пустым `title`. По договору штатный обработчик ошибок должен вернуть `502` и `{"error":"invalid_record"}`. [contract.md](/tmp/casework-1hj3helf/contract.md:1)

| Сценарий | Фактический HTTP-ответ | `x-desk-steps` | Итог |
|---|---|---|---|
| `f2` без сессии | `401`, `{"error":"sign_in"}` | `dispatch,session` | Соответствует |
| `f2` с `x-shift: day` | `200`, `{"id":"f2","title":"North"}` | `dispatch,session,read` | Соответствует |
| Отсутствующая карточка с `x-shift: day` | `404`, `{"error":"not_found"}` | `dispatch,session,read` | Соответствует |
| `r9` с `x-shift: day` | `200`, `{"id":"r9","title":""}` | `dispatch,session,read` | Нарушение. Ожидался `502` и этап `error` после `read` |

Проверка `title` проверяет только тип. Пустая строка проходит, поэтому `app.onError()` для `r9` не вызывается. [app.mjs](/tmp/casework-1hj3helf/release/app.mjs:18)

Проверил четыре сценария через `app.request()` в расходной копии на Hono 4.13.19 и Node.js 24.15.0. Штатный `npm test` прошёл. Он проверяет только статус и заголовок карточки `f2` в JSON. Файлы поставки остались без изменений. [smoke.test.mjs](/tmp/casework-1hj3helf/release/smoke.test.mjs:2)