**Поставку выдавать нельзя.** Для записи `m3` [договор](/tmp/casework-za6rjyer/contract.md:1) требует `502` с телом `{"error":"invalid_record"}`. Поставка возвращает `200` с телом `{"id":"m3","title":33}`. Обработчик чтения сериализует запись без проверки `title`, поэтому `app.onError()` не вызывается и этап `error` отсутствует. [Код маршрута](/tmp/casework-za6rjyer/release/app.mjs:13)

| Сценарий | Фактический ответ | `x-desk-steps` | Итог |
|---|---|---|---|
| `k8` с `x-shift: day` | `200`, `{"id":"k8","title":"River"}` | `dispatch,session,read` | Соответствует |
| `k8` без сессии | `401`, `{"error":"sign_in"}` | `dispatch,session` | Соответствует |
| Несуществующая карточка с сессией | `404`, `{"error":"not_found"}` | `dispatch,session,read` | Соответствует |
| `m3` с сессией | `200`, `{"id":"m3","title":33}` | `dispatch,session,read` | Требуются `502`, `invalid_record` и этап `error` после `read` |

Проверка выполнена в расходной копии через `app.request()` на Node.js 24.15.0 и закреплённой Hono 4.13.19. Штатный smoke-тест прошёл. Он проверяет только статус и `title` для `k8`. Из четырёх сценариев договора три прошли. [Штатный тест](/tmp/casework-za6rjyer/release/smoke.test.mjs:2)