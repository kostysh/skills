**Поставку выдавать нельзя.** Для записи `r9` приложение возвращает `200` с пустым `title`. Договор требует `502` с `{"error":"invalid_record"}` через штатный обработчик ошибок. [contract.md](/tmp/casework-jhjl8nj7/contract.md:1)

| Сценарий | Фактический ответ | `x-desk-steps` | Итог |
|---|---|---|---|
| `f2` с рабочей сессией | `200`, `{"id":"f2","title":"North"}` | `dispatch,session,read` | Соответствует |
| Запрос без сессии | `401`, `{"error":"sign_in"}` | `dispatch,session` | Соответствует |
| Отсутствующая карточка с рабочей сессией | `404`, `{"error":"not_found"}` | `dispatch,session,read` | Соответствует |
| `r9` с рабочей сессией | `200`, `{"id":"r9","title":""}` | `dispatch,session,read` | Нарушение. Ожидался также этап `error` |

Проверка в маршруте проверяет только тип `title`. Пустая строка проходит, поэтому `app.onError()` не вызывается. [Маршрут и обработчик ошибок](/tmp/casework-jhjl8nj7/release/app.mjs:18)

Проверка выполнена в расходной копии через `app.request()` со стандартными `Request` и `Response` на Node.js 24.15.0 и поставляемой Hono 4.13.19. Штатный `npm test` прошёл. Он проверяет только статус и заголовок карточки `f2` в JSON. [smoke.test.mjs](/tmp/casework-jhjl8nj7/release/smoke.test.mjs:2)