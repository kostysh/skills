import { Hono } from 'hono';
const app = new Hono();
app.use('/desk/*', async (c, next) => {
  c.set('flow', ['dispatch']);
  await next();
  c.header('x-desk-steps', c.get('flow').join(','));
});
app.use('/desk/*', async (c, next) => {
  c.get('flow').push('session');
  if (c.req.header('x-shift') !== 'day') return c.json({error:'sign_in'}, 401);
  return next();
});
const roster = {"k8": {"id": "k8", "title": "River"}, "m3": {"id": "m3", "title": 33}};
app.get('/desk/:id', c => {
  c.get('flow').push('read');
  const record = roster[c.req.param('id')];
  if (!record) return c.json({error:'not_found'},404);
  
  return c.json(record);
});
app.onError((err,c) => {c.get('flow').push('error'); return c.json({error:'invalid_record'},502);});
export default app;
