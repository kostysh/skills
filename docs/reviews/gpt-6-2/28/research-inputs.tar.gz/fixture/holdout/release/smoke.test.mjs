import test from 'node:test';import assert from 'node:assert/strict';import app from './app.mjs';
test('valid title',async()=>{const r=await app.request('/desk/f2',{headers:{'x-shift':'day'}});assert.equal(r.status,200);assert.equal((await r.json()).title,'North');});
