import { Hono } from 'hono';
const app = new Hono();
app.use('/desk/*', async (c, next) => {
  c.set('flow', ['dispatch']);
  await next();
  c.header('x-desk-steps', c.get('flow').join(','));
});
app.use('/desk/*', async (c, next) => {
  c.get('flow').push('session');
  if (c.req.header('x-shift') !== 'day') return c.json({error:'sign_in'}, 401);
  return next();
});
const roster = {"f2": {"id": "f2", "title": "North"}, "r9": {"id": "r9", "title": ""}};
app.get('/desk/:id', c => {
  c.get('flow').push('read');
  const record = roster[c.req.param('id')];
  if (!record) return c.json({error:'not_found'},404);
  if (typeof record.title !== 'string') throw new TypeError('Invalid roster record');
  return c.json(record);
});
app.onError((err,c) => {c.get('flow').push('error'); return c.json({error:'invalid_record'},502);});
export default app;
