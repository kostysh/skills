// An observer may select another instance of the same public interface.
process.env.DOCUMENT_DESK_SOCKET ??= '/tmp/skills62-conductor-bi4uq4p0/handoffs/document-access/stand28.sock';
