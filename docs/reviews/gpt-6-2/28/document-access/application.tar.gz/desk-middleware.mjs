import { channel } from 'node:diagnostics_channel';
import { verifiedEmployee, sessionRequired } from './session.mjs';

const diagnostic = channel('training.desk.events');
export async function observeRequest(c, next) {
  diagnostic.publish({ step: 'enter' });
  await next();
  diagnostic.publish({ step: 'complete', status: c.res.status });
}

export async function requireEmployee(c, next) {
  const principal = verifiedEmployee(c.req.raw);
  diagnostic.publish({ step: 'session', principal: principal ?? null });
  if (!principal) return sessionRequired();
  c.set('employee', principal);
  await next();
}
