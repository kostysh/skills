import { serve } from '@hono/node-server';
import { once } from 'node:events';
import { app } from './app.mjs';

export async function openServer() {
  const server = serve({ fetch: app.fetch, hostname: '127.0.0.1', port: 0 });
  if (!server.listening) await once(server, 'listening');
  return server;
}
