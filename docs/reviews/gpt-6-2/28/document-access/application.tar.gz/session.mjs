// Issued by the local test-workbench operator. These identifiers only work in this exercise.
export const testSessions = Object.freeze({
  'worker-a': 'training-pass-olive',
  'worker-b': 'training-pass-plum',
});
const principals = new Map(Object.entries(testSessions).map(([person, ticket]) => [ticket, person]));

export function verifiedEmployee(request) {
  return principals.get(request.headers.get('x-lab-session'));
}

export function sessionRequired() {
  return new Response(null, { status: 401 });
}
