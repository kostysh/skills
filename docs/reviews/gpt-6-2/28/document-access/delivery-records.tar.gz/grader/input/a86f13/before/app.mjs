import './environment.mjs';
import { Hono } from 'hono';
import { observeRequest, requireEmployee } from './desk-middleware.mjs';

export const app = new Hono();
app.use('/documents/*', observeRequest);
app.use('/documents/*', requireEmployee);
