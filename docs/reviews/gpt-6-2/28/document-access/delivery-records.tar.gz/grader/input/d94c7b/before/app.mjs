import './environment.mjs';
import { Hono } from 'hono';

export const app = new Hono();
