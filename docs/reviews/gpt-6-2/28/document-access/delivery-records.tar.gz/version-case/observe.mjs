import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';
import assert from 'node:assert/strict';

const dir=process.argv[2];
const {app}=await import(pathToFileURL(join(dir,'app.mjs')).href);
const version=JSON.parse(await readFile(join(dir,'node_modules/hono/package.json'),'utf8')).version;
assert.equal(version,'5.0.0-rc.1');
const samples=[];
for(const [path,status,body] of [
  ['/records/river',200,{title:'River notebook'}],
  ['/records/delayed',503,{error:'record_pending'}],
  ['/general/delayed',503,{error:'general_unavailable'}],
]){
  const r=await app.request(path); const got=await r.json();
  assert.equal(r.status,status);assert.deepEqual(got,body);
  samples.push({path,status:r.status,body:got});
}
await writeFile(process.argv[3],JSON.stringify({node:process.version,version,samples},null,2)+'\n');
