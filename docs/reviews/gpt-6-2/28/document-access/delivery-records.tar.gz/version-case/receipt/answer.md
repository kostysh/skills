В [app.mjs](/tmp/casework-k_u2z1ry/app.mjs:4) добавил `app.onError('/records/*', …)`. Теперь ошибки раздела записей возвращают `503` с `{"error":"record_pending"}`.

Установленный Hono `5.0.0-rc.1` поддерживает `onError` с шаблоном пути и обработчиком `(c, next)`. На одном уровне подходящие обработчики запускаются в порядке регистрации, поэтому обработчик `/records/*` стоит перед общим. Это подтверждают декларации установленного пакета и руководство Hono. В стабильной ветке v4 у `onError` другая сигнатура — `(err, c)`. [Руководство по переходу на Hono v5](https://hono.dev/docs/guides/migrating-to-v5#onerror-and-notfound-register-routable-middleware)

Через `app.request()` из `app.mjs` в Node.js `24.15.0` проверил статус, `Content-Type` и точное тело каждого ответа. Все три проверки прошли.

| GET | Статус | JSON |
|---|---:|---|
| `/records/river` | 200 | `{"title":"River notebook"}` |
| `/records/delayed` | 503 | `{"error":"record_pending"}` |
| `/general/delayed` | 503 | `{"error":"general_unavailable"}` |