import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { Hono as V4 } from '../../toolchains/hono-4-node/node_modules/hono/dist/index.js';
import { validator } from '../../toolchains/hono-4-node/node_modules/hono/dist/validator/index.js';
import { Hono as V5 } from './candidate/package/dist/index.js';

const receipt = { node: process.version, hooks: [], requests: [] };
for (const [version, Framework] of [['4.13.19', V4], ['5.0.0-rc.1', V5]]) {
  const app = new Framework();
  if (Framework === V4) {
    app.onError((err, c) => c.json({ marker: err.message, handled: 'hook' }, 503));
  } else {
    app.onError('/lab/*', async (c, next) => {
      c.header('x-handler', 'scoped');
      await next();
    }, (c) => c.json({ marker: c.error.message, handled: 'middleware' }, 503));
  }
  app.get('/lab/error', () => { throw new Error('scheduled failure'); });
  const reply = await app.request('/lab/error');
  const body = await reply.json();
  assert.equal(reply.status, 503);
  assert.equal(body.marker, 'scheduled failure');
  assert.equal(body.handled, Framework === V4 ? 'hook' : 'middleware');
  assert.equal(reply.headers.get('x-handler'), Framework === V4 ? null : 'scoped');
  receipt.hooks.push({ version, status: reply.status, body, header: reply.headers.get('x-handler') });
}

const app = new V4();
app.post('/echo', validator('json', value => value), c => c.json(c.req.valid('json')));
for (const type of ['application/json','text/plain']) {
  const result = await app.request('/echo', { method: 'POST', headers: { 'content-type': type }, body: JSON.stringify({ label: 'valid' }) });
  const observed = await result.json();
  assert.deepEqual(observed, type === 'application/json' ? { label: 'valid' } : {});
  receipt.requests.push({ version: '4.13.19', contentType: type, status: result.status, observed });
}
await writeFile(new URL('./version-probe.json', import.meta.url), JSON.stringify(receipt, null, 2)+'\n');
console.log(JSON.stringify(receipt));
