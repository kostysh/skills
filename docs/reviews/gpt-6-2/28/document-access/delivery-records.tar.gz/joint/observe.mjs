import assert from 'node:assert/strict';
import { createServer, createConnection } from 'node:net';
import { mkdtemp, readFile, writeFile, unlink, rmdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { once } from 'node:events';

const [projectPath, liveSocket, output] = process.argv.slice(2);
assert.ok(projectPath && liveSocket && output, 'Supply the project, live socket and output path');
const project = resolve(projectPath);
const load = file => import(pathToFileURL(join(project, file)).href);
const known = JSON.parse(await readFile(join(project, 'sources/documents.json'), 'utf8'));
const ids = [...known.map(x => x.id), 'missing'];
const visible = (person, id) => known.filter(row =>
  (id === null || id === row.id) &&
  (person === 'support' ? row.supportConsent : row.owner === person)
).map(({id, title}) => ({id, title}));
const ordered = rows => rows.toSorted((a,b) => a.id.localeCompare(b.id));

const work = await mkdtemp(join(tmpdir(), 'hono-observe-'));
const publicWire = join(work, 'desk.sock');
const exchanges = [];
// Forward the original bytes in both directions. Each socket has one public request and one real reply.
const proxy = createServer(client => {
  const live = createConnection(liveSocket);
  const sent = [];
  const received = [];
  client.on('data', chunk => sent.push(chunk));
  live.on('data', chunk => received.push(chunk));
  live.on('end', () => {
    const request = JSON.parse(Buffer.concat(sent).toString());
    const reply = JSON.parse(Buffer.concat(received).toString());
    exchanges.push({request, reply});
  });
  live.on('error', error => client.destroy(error));
  client.on('error', () => live.destroy());
  client.pipe(live);
  live.pipe(client);
});
proxy.listen(publicWire);
await once(proxy, 'listening');
process.env.DOCUMENT_DESK_SOCKET = publicWire;
const receipt = { node: process.version, direct: [], requests: [] };
let server;
try {
  const {app} = await load('app.mjs');
  const {openServer} = await load('server.mjs');
  const {testSessions} = await load('session.mjs');
  const {readDocument, listDocuments} = await load('public/desk-client.mjs');
  const seen = new Set();
  function inspect(person, id, row) {
    assert.deepEqual(row.request,{principal:person,id});
    assert.equal(row.reply.principal,person);
    assert.equal(row.reply.effectiveDatabaseRole,person === 'support' ? 'desk_support' : 'desk_employee');
    assert.equal(row.reply.status,200);
    assert.equal(row.reply.error,null);
    assert.deepEqual(ordered(row.reply.data),ordered(visible(person,id)));
    assert.ok(typeof row.reply.requestId === 'string' && row.reply.requestId.length > 0 && !seen.has(row.reply.requestId));
    seen.add(row.reply.requestId);
  }

  for (const person of ['worker-a','worker-b','support']) {
    for (const id of [null,...ids]) {
      const before = exchanges.length;
      const response = id === null ? await listDocuments(person) : await readDocument(person,id);
      assert.equal(exchanges.length,before+1);
      const live = exchanges.at(-1);
      inspect(person,id,live);
      assert.deepEqual(response,live.reply);
      receipt.direct.push(live);
    }
  }
  server = await openServer();
  const origin = 'http://127.0.0.1:'+server.address().port;
  const calls = Object.entries(testSessions).flatMap(([person,ticket]) => ids.map(id => ({person,ticket,id})));
  calls.push({person:null,id:'amber'},{person:null,ticket:'training-pass-expired',id:'amber'});
  for (const transport of ['app.request','node-http']) {
    const hidden = new Map();
    for (const {person,ticket,id} of calls) {
      const before = exchanges.length;
      const path = '/documents/'+id;
      const init={method:'GET',headers:ticket?{'x-lab-session':ticket}:{}};
      const result= transport==='app.request' ? await app.request(path,init) : await fetch(origin+path,init);
      const wire=await result.text();
      const reads=exchanges.slice(before);
      if (person) {
        assert.equal(reads.length,1);
        inspect(person,id,reads[0]);
        assert.match(result.headers.get('content-type') ?? '',/^application\/json\b/i);
        const body=JSON.parse(wire);
        const expected=visible(person,id);
        if (expected.length) {
          assert.equal(result.status,200);
          assert.deepEqual(body,expected[0]);
        } else {
          assert.equal(result.status,404);
          assert.deepEqual(body,{error:'not_found'});
          if(hidden.has(person)) assert.equal(wire,hidden.get(person));
          hidden.set(person,wire);
        }
      } else {
        assert.equal(result.status,401);
        assert.equal(reads.length,0);
      }
      receipt.requests.push({transport,session:person ?? (ticket?'invalid':'absent'),id,status:result.status,contentType:result.headers.get('content-type'),wire,reads});
    }
  }
  receipt.uniqueRequestIds=seen.size;
  assert.equal(seen.size,38);
  await writeFile(output,JSON.stringify(receipt,null,2)+'\n');
  console.log(JSON.stringify({direct:receipt.direct.length,http:receipt.requests.length,unique:seen.size}));
} finally {
  if(server) await new Promise(resolveClose=>server.close(resolveClose));
  await new Promise(resolveClose=>proxy.close(resolveClose));
  await unlink(publicWire).catch(error => { if (error.code!=='ENOENT') throw error; });
  await rmdir(work);
}
