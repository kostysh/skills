# Night handbook

Consult the printed timetable.
The evening desk moves to platform two.
Later idea: open a second counter after midnight.
