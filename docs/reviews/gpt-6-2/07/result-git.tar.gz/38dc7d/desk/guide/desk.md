# Desk handbook

Consult the printed timetable.
The service desk now opens at nine.
