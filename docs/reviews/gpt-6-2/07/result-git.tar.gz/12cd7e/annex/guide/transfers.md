# Transfers handbook

Consult the printed timetable.
Use the north corridor for transfers.
