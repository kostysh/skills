# Editorial handbook

The two working copies belong to the same handbook repository.
No build is needed for ordinary handbook text.
