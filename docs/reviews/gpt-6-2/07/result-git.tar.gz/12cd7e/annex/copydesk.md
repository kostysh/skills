# Copy desk

Co-editor: first marked revision.
Co-editor: later working revision.
