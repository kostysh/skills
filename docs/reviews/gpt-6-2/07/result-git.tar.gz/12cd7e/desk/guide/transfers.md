# Transfers handbook

Consult the printed timetable.
Colleague: alternate edition draft.
