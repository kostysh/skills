# Copy desk

Colleague: awaiting layout approval.
Colleague: second wording still under discussion.
