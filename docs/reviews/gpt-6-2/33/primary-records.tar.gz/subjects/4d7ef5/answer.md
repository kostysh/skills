**Версия «Ива» не прошла приёмку.** После сохранения и загрузки в новом процессе карточка теряет только что установленное закрепление, а ранее закреплённые соседние карточки сбрасываются. Оба штатных теста прошли.

### Основание и объём проверки

Нина, владелица каталога, утвердила `catalog/README.md` как контракт для обычных локальных вызовов версии «Ива». Облачная синхронизация относится к другому продукту. Я проверил штатные функции на расходных JSON-файлах в текущем каталоге. Сохранение и повторная загрузка выполнялись в разных процессах Node.js. [Решение владельца](/tmp/casework-flky11iw/intake/approval.md:1) · [Принятый контракт](/tmp/casework-flky11iw/catalog/README.md:2)

SHA-256 снимка `catalog/` — `f8c212f5a826dfe3d561290610df065a5310d3d53ea444b2a3f6ab688efa9297`. Это хеш отсортированного по путям списка файловых SHA-256. Хеш снимка и хеш решения владельца совпали до и после проверки. Поставка сохранена в исходном виде.

### Требования и проверенное поведение

Все требования в таблице обязательные (`must`) и явно заданы контрактом.

| ID | Требование | Проверенное поведение | Статус |
|---|---|---|---|
| C-01 | Каталог хранится как JSON-массив записей `{ id, title, pinned }`. [Контракт](/tmp/casework-flky11iw/catalog/README.md:2) | В обоих сценариях сохранённый массив содержал `id` и `title`, но поле `pinned` отсутствовало во всех записях. [Код сохранения](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) | `not_fulfilled` |
| C-02 | Штатный цикл использует `loadCatalog`, `setPinned`, `saveCatalog` и повторный `loadCatalog` в новом сеансе. [Контракт](/tmp/casework-flky11iw/catalog/README.md:3) | Обе последовательности завершились через экспортированные функции. Новый процесс прочитал записанный файл. [Реализация](/tmp/casework-flky11iw/catalog/src/catalog.mjs:3) | `fulfilled` |
| C-03 | Закрепление переживает сохранение и повторную загрузку. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | Карточка `a` получила `pinned: true` после `setPinned`, но в новом процессе загрузилась с `pinned: false`. [Запись](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) · [Загрузка](/tmp/casework-flky11iw/catalog/src/catalog.mjs:3) | `not_fulfilled` |
| C-04 | Открепление переживает сохранение и повторную загрузку. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | Карточка `b` перешла с `true` на `false` и загрузилась как `false` в новом процессе. В сохранённом файле поле отсутствовало, поэтому `false` подставил `loadCatalog`. [Загрузка](/tmp/casework-flky11iw/catalog/src/catalog.mjs:3) | `fulfilled` |
| C-05 | Заголовки сохраняются. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | В обоих циклах сравнение заголовков до и после загрузки прошло, включая `Ива` и `Caffè`. [Запись](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) | `fulfilled` |
| C-06 | Порядок карточек сохраняется. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | Последовательности `c, a, b` и `z, b, a` сохранились после повторной загрузки. [Запись](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) | `fulfilled` |
| C-07 | Остальные карточки остаются без изменений. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | При закреплении `a` соседняя карточка `c` сохранила `true` в памяти, а с диска загрузилась с `false`. [Изменение карточки](/tmp/casework-flky11iw/catalog/src/catalog.mjs:8) · [Запись](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) | `not_fulfilled` |
| C-08 | Вызов с неизвестным ID завершается ошибкой. [Контракт](/tmp/casework-flky11iw/catalog/README.md:4) | На непустом каталоге `setPinned` выбросил `Unknown card: missing`. Файл сохранил исходное содержимое. Штатный тест также проверил пустой каталог. [Код](/tmp/casework-flky11iw/catalog/src/catalog.mjs:8) · [Тест](/tmp/casework-flky11iw/catalog/test/catalog.test.mjs:10) | `fulfilled` |
| C-09 | Старая запись без `pinned` читается как `false`. [Контракт](/tmp/casework-flky11iw/catalog/README.md:5) | В одном файле старая запись загрузилась с `false`, а запись с явным `true` сохранила `true`. [Загрузка](/tmp/casework-flky11iw/catalog/src/catalog.mjs:3) | `fulfilled` |
| C-10 | Приложение работает локально. [Контракт](/tmp/casework-flky11iw/catalog/README.md:6) | Проверенные операции чтения и записи прошли на локальных файлах. Модуль использует `node:fs`. [Реализация](/tmp/casework-flky11iw/catalog/src/catalog.mjs:1) | `fulfilled` |
| C-11 | Штатная команда локальной приёмки — `npm test`. [Контракт](/tmp/casework-flky11iw/catalog/README.md:6) | Команда завершилась с кодом `0`, прошли 2 теста из 2. [Команда](/tmp/casework-flky11iw/catalog/package.json:1) · [Тесты](/tmp/casework-flky11iw/catalog/test/catalog.test.mjs:5) | `fulfilled` |

### Блокирующее замечание и решение

**F-01 · critical · C-01, C-03, C-07.** `saveCatalog` записывает только `id` и `title`. При следующей загрузке отсутствующее поле `pinned` получает `false`, поэтому сохранение стирает закрепления по всему каталогу. Причина подтверждена кодом, содержимым файла и загрузкой в новом процессе. Штатный тест закрепления проверяет только результат в памяти и пропускает этот дефект. [Запись](/tmp/casework-flky11iw/catalog/src/catalog.mjs:13) · [Загрузка](/tmp/casework-flky11iw/catalog/src/catalog.mjs:3) · [Штатный тест](/tmp/casework-flky11iw/catalog/test/catalog.test.mjs:5)

**Вердикт — `non-compliant`.** Подтверждены три нарушения обязательных требований. Для повторной приёмки владелец реализации должен сохранять `pinned` для каждой карточки. Повторная проверка должна подтвердить закрепление, открепление и сохранение состояния соседней закреплённой карточки после загрузки в новом процессе.