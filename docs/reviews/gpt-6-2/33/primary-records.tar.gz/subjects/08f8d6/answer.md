**Поставка `catalog` не соответствует принятому контракту (`non-compliant`).** Закрепление и открепление выбранной карточки переживают сохранение и повторную загрузку, но если у другой карточки тот же заголовок, её состояние тоже меняется. Обязательная команда `npm test` прошла, но этот сценарий штатные тесты пропускают.

### Основание и границы проверки

Нина утвердила `catalog/README.md` как контракт автономного выпуска «Клён». Утверждённое дополнение разрешает одинаковые `title`, требует выбора по `id` и сохраняет требование о неизменности остальных карточек. Облачная синхронизация относится к другому продукту. [Решение о приёмке](/tmp/casework-i7kcquvo/intake/approval.md:1) · [Дополнение](/tmp/casework-i7kcquvo/intake/approved-addendum.md:1) · [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:1)

Проверил публичные функции, запись в локальный JSON и повторное чтение в новом процессе Node.js. Сценарии запускал на расходных данных внутри рабочего каталога. Агрегированный SHA-256 `catalog/` — `8349b680d3ec7ba33c91057b1bfaef6e78180cc9f5befaf575fa77f8a9dc4e73`, `intake/` — `6c2dc56d71246c947227e55e047cd6f5a471fe626ef88ab20ab04cb96f808ab7`. Хеши до и после проверки совпали.

### Требования и результаты

Все требования ниже явно заданы и обязательны.

| ID | Требование и основание | Проверенное поведение | Статус |
|---|---|---|---|
| R1 | Каталог хранится в JSON-массиве записей `{ id, title, pinned }`. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:2) | После сохранения проверил структуру файла и её совпадение с результатом повторной загрузки. [Запись и чтение](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:3) | `fulfilled` |
| R2 | Закрепление переживает сохранение и повторную загрузку. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:3) | В новом процессе у целевой `a` получено `pinned: true` при разных и одинаковых заголовках. [Сохранение](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:14) | `fulfilled` |
| R3 | Открепление переживает тот же цикл. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) | В новом процессе у `a` получено `pinned: false` при разных и одинаковых заголовках. [Сохранение](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:14) | `fulfilled` |
| R4 | Заголовки сохраняются. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) | Список заголовков совпал с исходным во всех четырёх сценариях изменения. [Запись](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:14) | `fulfilled` |
| R5 | Порядок карточек сохраняется. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) | Порядок `z, b, a` сохранился во всех четырёх сценариях. [Изменение и запись](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:8) | `fulfilled` |
| R6 | Карточка выбирается по `id`. [Дополнение](/tmp/casework-i7kcquvo/intake/approved-addendum.md:1) | При вызове для `a` обновились и `a`, и `b` с тем же заголовком. Код находит заголовок по `id`, затем обновляет по `title`. [Выбор карточки](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:8) | `not_fulfilled` |
| R7 | Остальные карточки сохраняются без изменений, в том числе при одинаковых заголовках. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) · [Дополнение](/tmp/casework-i7kcquvo/intake/approved-addendum.md:1) | При разных заголовках соседние записи сохранились. При совпадении заголовков у `b` сохранилось чужое изменение в обоих направлениях. [Изменение карточек](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:11) | `not_fulfilled` |
| R8 | Отсутствующий `id` вызывает ошибку. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) | Для `missing` получена ошибка `Unknown card: missing`. Байты файла остались прежними. [Проверка ID](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:9) | `fulfilled` |
| R9 | Старая запись без `pinned` читается как `false`. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:5) | Запись без поля прочитана с `pinned: false`, соседняя запись с `true` сохранила значение. [Чтение](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:3) | `fulfilled` |
| R10 | Приложение работает локально. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:6) | Штатный цикл выполнен через локальный файл. Чтение и запись используют `node:fs`. [Реализация](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:1) | `fulfilled` |
| R11 | Для локальной приёмки используется `npm test`. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:6) | Команда в `catalog/` завершилась с кодом `0`, прошли 2 теста из 2. [Команда](/tmp/casework-i7kcquvo/catalog/package.json:1) · [Тесты](/tmp/casework-i7kcquvo/catalog/test/catalog.test.mjs:5) | `fulfilled` |

### Блокирующее замечание

**F1 · `major` · R6 и R7.** В двух независимых прогонах карточки `a` и `b` имели одинаковый заголовок. При закреплении `a` значение `b.pinned` после повторной загрузки стало `true` вместо ожидаемого `false`. При откреплении `a` оно стало `false` вместо ожидаемого `true`. Пользователь может изменить состояние чужой карточки обычным вызовом. Владельцу реализации следует ограничить обновление совпадением `id` и подтвердить исправление обоими сценариями после сохранения и повторной загрузки. [Контракт](/tmp/casework-i7kcquvo/catalog/README.md:4) · [Дополнение](/tmp/casework-i7kcquvo/intake/approved-addendum.md:1) · [Причина в коде](/tmp/casework-i7kcquvo/catalog/src/catalog.mjs:8)

Штатные тесты подтверждают немедленную видимость закрепления в памяти и ошибку для отсутствующего `id`. Сохранение, открепление, старые записи и совпадающие заголовки проверены отдельными локальными прогонами. [Штатные тесты](/tmp/casework-i7kcquvo/catalog/test/catalog.test.mjs:5)

**Решение для Нины:** отложить приёмку этой версии до устранения F1. Проверенная поставка и принятые документы сохранены в исходном виде.