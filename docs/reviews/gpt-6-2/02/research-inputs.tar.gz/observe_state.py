"""Read a finished trial. Exercise the invalid destination only on a disposable copy."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

base = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("case", choices=("ordinary", "boundary", "holdout"))
parser.add_argument("project_or_receipt", type=Path)
args = parser.parse_args()
provided = args.project_or_receipt.resolve()
dispatch = provided / "dispatch.json"
record = json.loads(dispatch.read_text()) if dispatch.exists() else {}
project = Path(record.get("project", provided))
spec = json.loads((base / "expected" / f"{args.case}.json").read_text())
cli = base / "A/tooling/skill-source-compiler/scripts/skill-source-compiler.mjs"
assert project.is_dir() and cli.is_file()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def files(folder):
    if not folder.is_dir():
        return {}
    return {p.relative_to(folder).as_posix(): digest(p) for p in sorted(folder.rglob("*")) if p.is_file() and ".git" not in p.parts}

def dirs(folder):
    return sorted(p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_dir())

def compare(wanted, actual):
    return {"missing": sorted(wanted.keys()-actual.keys()),
            "changed": sorted(k for k in wanted.keys() & actual.keys() if wanted[k]!=actual[k]),
            "extra": sorted(actual.keys()-wanted.keys())}

def run(*cmd, work=project):
    result = subprocess.run(["node", str(cli), *map(str,cmd)], cwd=work, capture_output=True, text=True)
    merged = (result.stdout+result.stderr).strip()
    return {"exit":result.returncode, "message":merged.replace(str(work),"{work}").replace(str(project),"{project}")}

def tree_digest(table):
    return hashlib.sha256(json.dumps(table, sort_keys=True).encode()).hexdigest()

current = files(project)
business = {k:v for k,v in current.items() if not k.startswith("tooling/")}
before = {k:v for k,v in record.get("input_files",{}).items() if k.startswith("tooling/")}
tooling = {k:v for k,v in current.items() if k.startswith("tooling/")}
report = {"case":args.case,"expected_state_difference":compare(spec["expected_files"],business),
          "protected_tool_files_difference":compare(before,tooling) if before else "receipt unavailable",
          "targets":{}}
for name, detail in spec["targets"].items():
    src, out = project/"source"/name, project/"delivery"/name
    old = detail["original_source_sha256"]
    actual_src = files(src)
    protected = {n:v for n,v in old.items() if n not in ("SKILL.md","docs/compile-report.md") or not detail["valid"]}
    rows = {"protected_source_difference":compare(protected,{k:actual_src[k] for k in protected if k in actual_src}),
            "source_check":run("check",src), "output_exists":out.exists()}
    if detail["valid"]:
        rows["source_render_difference"]=compare(detail["expected_source_sha256"],actual_src)
        rows["out_of_place_difference"]=compare(detail["output_sha256"],files(out))
        rows["output_check"]=run("check",out)
        if src.is_dir():
            with tempfile.TemporaryDirectory() as t:
                isolated = Path(t)
                copy = isolated / name
                shutil.copytree(src,copy)
                before_files,before_dirs=files(copy),dirs(copy)
                rejected=run("compile",copy,"--out-dir",copy/"preview",work=isolated)
                after_files,after_dirs=files(copy),dirs(copy)
                rows["nested_destination_on_disposable_copy"]={
                    "command":rejected, "source_bytes_identical":before_files==after_files,
                    "directories_identical":before_dirs==after_dirs,
                    "sha256_before":tree_digest(before_files),"sha256_after":tree_digest(after_files)}
    report["targets"][name]=rows
print(json.dumps(report,ensure_ascii=False,indent=2))
