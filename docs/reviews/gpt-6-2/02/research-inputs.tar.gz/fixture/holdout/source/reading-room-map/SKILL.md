---
name: reading-room-map
description: Prepare catalogue transfer labels for reading room map cards.
metadata:
  source-version: 1.3.9
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: 155417e97cfb5eb56dee2b0647baad43dfc0fab256928ad1ec6e499f91a6ecdb
---

# reading-room-map

## Start here

1. Read the catalogue card and its recorded shelf mark.

## When to use this skill

- An operator needs the label for a catalogue transfer.

## When NOT to use this skill

- The operator asks for a new acquisition decision.

## Overview

The catalogue desk uses the primary shelf mark to direct transfers between reading rooms. Keep the catalogue number exactly as printed.

## Receiving desk table

| Collection | Volume | Mark | Receipt note |
| --- | --- | --- | --- |
| Ceramics | 01 | R1-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 02 | R1-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 03 | R1-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 04 | R1-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 05 | R1-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 06 | R1-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 07 | R1-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 08 | R1-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 09 | R1-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 10 | R1-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 11 | R1-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 12 | R1-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 13 | R1-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 14 | R1-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 15 | R1-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 16 | R1-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 17 | R1-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 18 | R1-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 19 | R1-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 20 | R1-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 21 | R1-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 22 | R1-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 23 | R1-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 24 | R1-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 25 | R1-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 26 | R1-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Ceramics | 27 | R1-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 01 | R2-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 02 | R2-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 03 | R2-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 04 | R2-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 05 | R2-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 06 | R2-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 07 | R2-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 08 | R2-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 09 | R2-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 10 | R2-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 11 | R2-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 12 | R2-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 13 | R2-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 14 | R2-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 15 | R2-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 16 | R2-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 17 | R2-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 18 | R2-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 19 | R2-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 20 | R2-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 21 | R2-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 22 | R2-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 23 | R2-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 24 | R2-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 25 | R2-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 26 | R2-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Costume | 27 | R2-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 01 | R3-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 02 | R3-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 03 | R3-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 04 | R3-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 05 | R3-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 06 | R3-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 07 | R3-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 08 | R3-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 09 | R3-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 10 | R3-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 11 | R3-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 12 | R3-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 13 | R3-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 14 | R3-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 15 | R3-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 16 | R3-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 17 | R3-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 18 | R3-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 19 | R3-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 20 | R3-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 21 | R3-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 22 | R3-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 23 | R3-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 24 | R3-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 25 | R3-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 26 | R3-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Editions | 27 | R3-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 01 | R4-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 02 | R4-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 03 | R4-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 04 | R4-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 05 | R4-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 06 | R4-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 07 | R4-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 08 | R4-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 09 | R4-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 10 | R4-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 11 | R4-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 12 | R4-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 13 | R4-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 14 | R4-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 15 | R4-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 16 | R4-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 17 | R4-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 18 | R4-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 19 | R4-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 20 | R4-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 21 | R4-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 22 | R4-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 23 | R4-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 24 | R4-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 25 | R4-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 26 | R4-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Engraving | 27 | R4-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 01 | R5-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 02 | R5-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 03 | R5-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 04 | R5-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 05 | R5-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 06 | R5-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 07 | R5-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 08 | R5-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 09 | R5-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 10 | R5-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 11 | R5-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 12 | R5-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 13 | R5-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 14 | R5-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 15 | R5-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 16 | R5-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 17 | R5-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 18 | R5-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 19 | R5-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 20 | R5-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 21 | R5-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 22 | R5-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 23 | R5-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 24 | R5-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 25 | R5-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 26 | R5-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Glass | 27 | R5-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 01 | R6-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 02 | R6-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 03 | R6-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 04 | R6-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 05 | R6-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 06 | R6-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 07 | R6-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 08 | R6-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 09 | R6-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 10 | R6-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 11 | R6-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 12 | R6-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 13 | R6-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 14 | R6-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 15 | R6-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 16 | R6-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 17 | R6-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 18 | R6-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 19 | R6-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 20 | R6-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 21 | R6-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 22 | R6-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 23 | R6-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 24 | R6-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 25 | R6-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 26 | R6-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Maps | 27 | R6-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 01 | R7-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 02 | R7-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 03 | R7-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 04 | R7-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 05 | R7-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 06 | R7-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 07 | R7-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 08 | R7-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 09 | R7-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 10 | R7-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 11 | R7-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 12 | R7-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 13 | R7-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 14 | R7-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 15 | R7-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 16 | R7-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 17 | R7-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 18 | R7-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 19 | R7-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 20 | R7-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 21 | R7-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 22 | R7-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 23 | R7-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 24 | R7-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 25 | R7-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 26 | R7-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Prints | 27 | R7-027 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 01 | R8-001 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 02 | R8-002 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 03 | R8-003 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 04 | R8-004 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 05 | R8-005 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 06 | R8-006 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 07 | R8-007 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 08 | R8-008 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 09 | R8-009 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 10 | R8-010 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 11 | R8-011 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 12 | R8-012 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 13 | R8-013 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 14 | R8-014 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 15 | R8-015 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 16 | R8-016 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 17 | R8-017 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 18 | R8-018 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 19 | R8-019 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 20 | R8-020 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 21 | R8-021 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 22 | R8-022 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 23 | R8-023 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 24 | R8-024 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 25 | R8-025 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 26 | R8-026 | Copy this edition number with the collection mark to the receiving desk slip. |
| Theatre | 27 | R8-027 | Copy this edition number with the collection mark to the receiving desk slip. |

## Workflow stages

### Workflow stage: Prepare the transfer label

Give the receiving desk a usable label.

1. Copy the primary shelf mark to the receiving label.

Validation:

- Match the catalogue number and shelf mark against the card.

## Required active references
- [Entry examples](references/entries.md) — Read when the card has more than one shelf or label.

## Portability rules

- Use the entries supplied with the skill.

## Portability checklist before finishing

- Confirm the entry examples can be read from this folder.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
