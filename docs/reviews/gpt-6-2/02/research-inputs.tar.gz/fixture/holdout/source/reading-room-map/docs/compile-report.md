# Compile report
Generated from `skill.yaml`.

## Versions
- Skill source version: `1.3.9`

## Source files
- `fragments/overview.md`
- `references/entries.md`
- `skill.yaml`

## Required references
- `references/entries.md`

## Warnings
- Generated SKILL.md is 24319 bytes, above the recommended maximum 20000 bytes. Move detailed guidance into references/* and keep SKILL.md focused on activation, workflow, and navigation. Raise skill.recommended-skill-md-max-bytes only when references cannot reasonably reduce the size.

## Notes
- This document is supporting output only.
- It does not override `SKILL.md`.