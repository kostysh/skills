The catalogue desk uses the primary shelf mark to direct transfers between reading rooms. Keep the catalogue number exactly as printed.
