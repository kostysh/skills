# Compile report
Generated from `skill.yaml`.

## Versions
- Skill source version: `1.3.9`

## Source files
- `fragments/overview.md`
- `references/entries.md`
- `skill.yaml`

## Required references
- `references/entries.md`

## Warnings
- none

## Notes
- This document is supporting output only.
- It does not override `SKILL.md`.