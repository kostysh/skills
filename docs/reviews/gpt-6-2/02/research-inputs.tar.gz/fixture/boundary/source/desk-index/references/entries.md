# Entries

A card may list a primary shelf mark and an exhibition mark. Preserve the primary mark for a transfer.
