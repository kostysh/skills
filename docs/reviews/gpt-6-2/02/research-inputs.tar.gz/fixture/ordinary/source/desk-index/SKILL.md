---
name: desk-index
description: Prepare catalogue transfer labels for desk index cards.
metadata:
  source-version: 1.3.9
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: 7f50733f0d5aa84627dd967a2388c6dc3e744727f6dcb4a05ed3c92086172b49
---

# desk-index

## Start here

1. Read the catalogue card and its recorded shelf mark.

## When to use this skill

- An operator needs the label for a catalogue transfer.

## When NOT to use this skill

- The operator asks for a new acquisition decision.

## Overview

The catalogue desk uses the primary shelf mark to direct transfers between reading rooms. Keep the catalogue number exactly as printed.

## Workflow stages

### Workflow stage: Prepare the transfer label

Give the receiving desk a usable label.

1. Copy the primary shelf mark to the receiving label.

Validation:

- Match the catalogue number and shelf mark against the card.

## Required active references
- [Entry examples](references/entries.md) — Read when the card has more than one shelf or label.

## Portability rules

- Use the entries supplied with the skill.

## Portability checklist before finishing

- Confirm the entry examples can be read from this folder.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
