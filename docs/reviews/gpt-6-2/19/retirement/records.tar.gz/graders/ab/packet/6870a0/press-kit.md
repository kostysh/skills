# Approved press sheet

On “Counter slip” set “Evening handover” in Display, 32 px, bold, dark ink (#192c38). Keep “Collection 516 · Upper counter” in Body, 16 px, regular. Set “Confirm pickup” in Amber action, 18 px, bold, dark amber (#9a4000). This color identifies the action. All three lines are left aligned to the existing 24 px guide. Keep their wording, baselines, the 480 × 240 frame and the neighboring “Archive slip” as supplied. This is a press proof and editable design deliverable.
