# Approved press sheet

On “Morning board” set “Morning dispatch” in Display, 32 px, bold, dark ink (#192c38). Keep “Order 214 · Linen stock” in Body, 16 px, regular. Set “Print docket” in Amber action, 18 px, bold, dark amber (#9a4000). This color identifies the action. All three lines are left aligned to the existing 24 px guide. Keep their wording, baselines, the 480 × 240 frame and the neighboring “Evening board” as supplied. This is a press proof and editable design deliverable.
