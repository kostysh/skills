# Approved press sheet

On “Proof desk” set “Weekly proof sheet” in Display, 32 px, bold, dark ink (#192c38). Keep “Batch 782 · Soft finish” in Body, 16 px, regular. Set “Release proof” in Amber action, 18 px, bold, dark amber (#9a4000). This color identifies the action. All three lines are left aligned to the existing 24 px guide. Keep their wording, baselines, the 480 × 240 frame and the neighboring “Dispatch desk” as supplied. This is a press proof and editable design deliverable.
