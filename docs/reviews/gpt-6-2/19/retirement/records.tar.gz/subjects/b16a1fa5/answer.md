Обновил экран «Morning board» в редактируемом [press-board.pen](/tmp/casework-m86ccqfp/press-board.pen) и экспортировал [morning.svg](/tmp/casework-m86ccqfp/morning.svg) для печатника.

«Morning dispatch» теперь набран жирным тёмным шрифтом 32 px, строка заказа — обычным шрифтом 16 px, а «Print docket» — жирным тёмно-янтарным шрифтом 18 px.

Проверил сохранённый макет и отрисовку SVG. Тексты, базовые линии, выравнивание по направляющей 24 px, размер кадра 480 × 240 и соседний экран «Evening board» сохранены.