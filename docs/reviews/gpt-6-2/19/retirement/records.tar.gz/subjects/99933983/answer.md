Обновил [редактируемый оригинал press-board.pen](/tmp/casework-dy_wpocw/press-board.pen) и проверил [SVG-пробу morning.svg](/tmp/casework-dy_wpocw/morning.svg), экспортированную из сохранённой версии макета.

«Morning dispatch» теперь набран стилем Display, 32 px, полужирным тёмным цветом. «Print docket» выделен стилем Amber action, 18 px, полужирным тёмно-янтарным цветом. Строка заказа сохранила стиль Body, 16 px.

Проверил тексты, базовые линии, выравнивание по отметке 24 px и размер 480 × 240. Соседний экран «Evening board» остался без изменений.