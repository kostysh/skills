Готовы [редактируемый оригинал press-board.pen](/tmp/casework-2vxk26bx/press-board.pen) и [SVG-проба morning.svg](/tmp/casework-2vxk26bx/morning.svg) для печатника.

На «Morning board» заголовок получил стиль Display, 32 px, полужирный, а «Print docket» — Amber action, 18 px, полужирный, тёмно-янтарный. Строка заказа сохранила стиль Body, 16 px.

Проверил сохранённый макет и SVG. Тексты, базовые линии, выравнивание по направляющей 24 px и размер 480 × 240 сохранены. Слои «Evening board» совпадают с исходными.