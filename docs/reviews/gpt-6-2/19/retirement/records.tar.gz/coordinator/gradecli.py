"""Run an independent scorer with the precommitted criteria and a sealed, randomized packet."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from slots import available_session
from study_context import memory_settings
parser=argparse.ArgumentParser()
parser.add_argument('packet',type=Path)
parser.add_argument('receipt',type=Path)
args=parser.parse_args()
packet=args.packet.resolve()
receipt=args.receipt.resolve()
assert packet.is_dir() and (packet/'criteria.md').is_file()
receipt.mkdir(mode=0o700,parents=True,exist_ok=False)
task='''Ты независимый оценщик. Работай только в текущем каталоге. Используй закрытые до опыта критерии criteria.md, выданные по нейтральным кодам задания, материалы до/после, реальные ответы, операции и независимые проверки, если они приложены. Сопоставь действия и наблюдаемое состояние каждого случая с критериями. Зачти эквивалентное решение. Для каждого кода зафиксируй необходимые аспекты, PASS/FAIL/INCONCLUSIVE по ним и общий исход с конкретными основаниями. Оцени заявленные возможности в пределах фактической среды. Не обращайся к другим каталогам и не пытайся определить неизвестное соответствие редакций. Ничего не изменяй. Выдай таблицу и основание каждого результата по-русски в финальном ответе. Подпиши его как независимый оценщик.'''
cmd=['codex','exec','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--model','gpt-6.2-sol','-c','model_reasoning_effort="high"','--cd',str(packet),'--json','--output-last-message',str(receipt/'grades.md'),'-']
cmd[2:2] = memory_settings(receipt)
def digest(b):return hashlib.sha256(b).hexdigest()
files={str(f.relative_to(packet)):digest(f.read_bytes()) for f in packet.rglob('*') if f.is_file()}
(receipt/'dispatch.json').write_text(json.dumps({'argv':cmd,'prompt':task,'inputs':files},ensure_ascii=False,indent=2)+'\n')
with available_session(), (receipt/'events.jsonl').open('w') as events,(receipt/'stderr.txt').open('w') as errors:
    result=subprocess.run(cmd,cwd=packet,input=task,text=True,stdout=events,stderr=errors)
assert result.returncode==0 and (receipt/'grades.md').is_file() and (receipt/'grades.md').read_text().strip()
hash_value=digest((receipt/'grades.md').read_bytes())
(receipt/'result.json').write_text(json.dumps({'exit':result.returncode,'sha256':hash_value,'events_sha256':digest((receipt/'events.jsonl').read_bytes())})+'\n')
print(receipt/'grades.md',hash_value)
