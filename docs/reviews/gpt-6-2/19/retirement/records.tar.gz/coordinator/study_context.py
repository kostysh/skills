from pathlib import Path

def uses_revised_capture(receipt):
    study = Path(__file__).resolve().parent
    try:
        path = receipt.resolve().relative_to(study).parts
        row = path[0]
    except (IndexError, ValueError):
        return False
    return (row.isdigit() and 7 <= int(row) <= 38) or row == "handoffs" or path[:2] == ("05", "remediation")

def memory_settings(receipt):
    return ["--disable", "memories"] if uses_revised_capture(receipt) else []
