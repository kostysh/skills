"""Dispatch one task per Codex context through the existing coordinator."""
import concurrent.futures
import json
import secrets
import subprocess
import sys
from pathlib import Path
from prepare import study, save

mode = sys.argv[1]
plan = {
    "ab": [(variant, case) for variant in ("A","B") for case in ("ordinary","boundary")],
    "confirm": [("C",case) for case in ("ordinary","boundary","holdout")],
}[mode]
secrets.SystemRandom().shuffle(plan)
key_file = study / f"{mode}-private.json"
if key_file.exists():
    key = json.loads(key_file.read_text())
else:
    key = {secrets.token_hex(4): {"variant":variant,"case":case} for variant, case in plan}
    save(key_file,key)
def execute(item):
    code, val = item
    result = study / ("record-"+code)
    if result.exists():
        error = result / "stderr.txt"
        outcome = result / "result.json"
        if "--retry-init" not in sys.argv or not error.is_file() or not outcome.is_file() or "failed to initialize in-process app-server" not in error.read_text() or json.loads(outcome.read_text())["changed"]:
            raise RuntimeError("Receipt already exists: "+str(result))
        moved = study / "init-failed" / result.name
        moved.parent.mkdir(exist_ok=True)
        result.rename(moved)
    cmd=[sys.executable, str(study.parents[1]/"trial.py"), str(study/"sealed"/val["variant"]), str(study/"fixtures"/val["case"]), str(study/"tasks"/(val["case"]+".md")), str(result), "--model","gpt-6.2-sol","--effort","medium"]
    run = subprocess.run(cmd, text=True, capture_output=True)
    print(code,run.returncode,run.stdout,run.stderr,flush=True)
    return run.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    codes = list(pool.map(execute,key.items()))
sys.exit(max(codes))
