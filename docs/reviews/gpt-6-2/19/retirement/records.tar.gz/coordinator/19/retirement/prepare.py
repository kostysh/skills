import difflib
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path

study = Path(__file__).resolve().parent
work = Path("/home/kostysh/.codex/skills/custom/.worktrees/gpt-6-2-skill-revision")
evidence = work / "docs/reviews/gpt-6-2/19/retirement"
inputs = evidence / "inputs"
archive = evidence.parent / "frontend-design-0.2.5.tgz"
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(folder):
    return {file.relative_to(folder).as_posix(): digest(file) for file in sorted(folder.rglob("*")) if file.is_file()}
def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
def delta(a, b, label1, label2):
    lines = []
    for name in sorted(set(inventory(a)) | set(inventory(b))):
        af, bf = a / name, b / name
        if af.read_bytes() != bf.read_bytes():
            lines.extend(difflib.unified_diff(af.read_text().splitlines(True), bf.read_text().splitlines(True), f"{label1}/{name}", f"{label2}/{name}"))
    return "".join(lines)

if __name__ == "__main__":
    a = study / "sealed/A"
    b = study / "sealed/B"
    assert digest(archive) == "ae0f50652bf114c53a0389d44765d49d629ba3252184a007674691678ee8c1bb"
    with tarfile.open(archive) as tgz:
        tgz.extractall(a, filter="data")
    shutil.copytree(a,b)
    for name, rule in {
        "SKILL.md": "- **durable .pen inspection, editing, validation, screenshots, and exports:** pencil-dev. frontend-design defines strategy and frames; pencil-dev owns Pencil MCP mechanics.\n",
        "references/strategy-to-implementation.md": "- Route durable `.pen` creation, inspection, editing, and export mechanics to\n  `pencil-dev`; the design artifact still follows this strategy contract.\n"
    }.items():
        target = b / name
        original = target.read_text()
        assert original.count(rule) == 1
        target.write_text(original.replace(rule, ""))
    (evidence / "A-B.patch").write_text(delta(a,b,"A","B"))
    cases = json.loads((inputs / "cases.json").read_text())
    fixtures = {}
    tasks = study / "tasks"
    tasks.mkdir()
    for case, spec in cases.items():
        dest = study / "fixtures" / case
        subprocess.run([sys.executable, "-B", str(inputs / "build-fixture.py"), case, str(dest)], check=True)
        (tasks / f"{case}.md").write_text(spec["task"]+"\n")
        fixtures[case] = inventory(dest)
    for name, value in inventory(a).items():
        assert digest(work / "skills/frontend-design" / name) == value, name
    tools_root = study.parents[1]
    save(evidence / "input-freeze.json", {
        "at": datetime.now(timezone.utc).isoformat(),
        "basis": "Row 19 accepted frontend-design 0.2.5, repository HEAD 45197c44d459c15e5b64256a48a0e96342bcf451. All 7 package entries were identical to those working-tree release files when frozen.",
        "A": {"archive":"../frontend-design-0.2.5.tgz", "archiveSHA256":digest(archive), "files":inventory(a)},
        "B": {"ruleRemoved":"Both active occurrences of pencil-dev in the full delivered package, with root metadata aligned to A.", "patchSHA256":digest(evidence / "A-B.patch"), "files":inventory(b)},
        "inputs": inventory(inputs), "fixtureFiles": fixtures, "taskBodies":inventory(tasks),
        "cases": {"firstStage":["ordinary","boundary"], "confirm":["ordinary","boundary"], "reserved":["holdout"]},
        "taskPrefix": "Работай только в предоставленном текущем каталоге. \n\n",
        "assigned":{"subjects":{"model":"gpt-6.2-sol","reasoning":"medium","session":"ephemeral, each context fresh; persistent memories disabled"},"assessor":{"model":"gpt-6.2-sol","reasoning":"high","session":"separate ephemeral, persistent memories disabled; receives shuffled code-only observations"}},
        "equivalentCues":"The remaining root verification workflow, status contract and strategy reference require checking artifacts and exports. The team brief specifies its deliverables; the adapter documents its commands and format/connection. B isolates removal of the two retired ownership cues, not unaided visual behavior.",
        "studyToolsSHA256": {name: digest(tools_root/name) for name in ["trial.py","gradecli.py","slots.py","study_context.py"]},
        "boundaries":"Local simulated adapter on fixture SQLite or detached pointer. Forced active skill. No external editor, production .pen, natural selection, publication, or runtime verification claim. Holdout has separate raw task and is only opened by an executor after C freeze."
    })
    print(digest(evidence / "input-freeze.json"))
