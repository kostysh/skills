"""Produce the redacted views handed to a fresh scorer, and preserve the map privately."""
import hashlib
import json
import re
import secrets
import shutil
import sqlite3
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from prepare import study, inputs, save, evidence

def readjson(path):
    return json.loads(path.read_text())
def dbdata(path):
    con=sqlite3.connect(path.resolve().as_uri()+"?mode=ro",uri=True)
    try:
        return {"revision":con.execute("select revision from document").fetchone()[0], "layers":con.execute("select frame,id,text,x,y,style from layers order by frame,y").fetchall()}
    finally:
        con.close()

def observed(case, fixture, location, run):
    native=case["document"]
    proof=case["proof"]
    data={"changedNames":run["changed"],"exit":run["exit"]}
    if case["connection"]=="attached":
        data["inputNative"]=dbdata(fixture/native)
        data["deliveredNative"]=dbdata(location/native)
    else:
        data["pointerBefore"]=(fixture/native).read_text()
        data["pointerAfter"]=(location/native).read_text()
    svg=location/proof
    data["proofExists"]=svg.is_file()
    if svg.is_file():
        tree=ET.parse(svg).getroot()
        data["outputSVG"]={"root":tree.attrib,"layers":[{"kind":n.tag.split("}")[-1],"text":n.text,"attributes":n.attrib} for n in tree]}
    note=location/"layout-note.md"
    if note.is_file():
        data["handoffMarkdown"]=note.read_text()
    return data

def redact(text,project):
    return text.replace(str(project),"<project>").replace("pencil-dev","[специализированный навык]").replace("Pencil MCP","[редактор]")

def actions(receipt,project):
    events=[]
    output=(receipt/"events.jsonl").read_text()
    for e in map(json.loads,output.splitlines()):
        if e["type"]!="item.completed":
            continue
        item=e["item"]
        kind=item["type"]
        if kind=="command_execution":
            cmd=redact(item["command"],project)
            raw=redact(item["aggregated_output"],project)
            if re.search(r'SKILL\.md|references/|agents/openai.yaml',cmd,re.I):
                kept=[l for l in raw.splitlines() if l.startswith('{"') and not 'source-version' in l and not 'skillforge' in l]
                raw="[Вывод чтения активной инструкции скрыт от оценщика; доступные ответы рабочего адаптера ниже.]"+"\n"+"\n".join(kept)
            elif re.search(r'\bls\b',cmd) and ('SKILL.md' in raw or 'references/' in raw) and not re.search(r'python3 studio.py',cmd):
                raw="[Перечень файлов выданного проекта; размеры и сведения об инструкции скрыты.]"
            events.append({"type":kind,"command":cmd,"exit":item["exit_code"],"output":raw})
        elif kind=="agent_message":
            events.append({"type":kind,"text":redact(item["text"],project)})
        else:
            row={k:v for k,v in item.items() if k not in ["id","type"]}
            events.append({"type":kind,**json.loads(redact(json.dumps(row,ensure_ascii=False),project))})
    return events

def publish(mode):
    plan=readjson(study/(mode+"-private.json"))
    if mode=="confirm":
        originals=readjson(study/"ab-private.json")
        plan={**{k:v for k,v in originals.items() if v["variant"]=="A"},**plan}
    rng=secrets.SystemRandom()
    quiz=list(plan.items())
    rng.shuffle(quiz)
    packet=Path(tempfile.mkdtemp(prefix="proof-desk-review-"))
    criteria=(inputs/"criteria.md").read_text()
    protocol="Отложенное задание выдаётся только фиксированной окончательной редакции и проверяется по O1–O3 и S. Там обычная команда"
    assert criteria.count(protocol)==1
    (packet/"criteria.md").write_text(criteria.replace(protocol,"Для weekly-sheet.pen применить O1–O3 и S. Обычная команда"))
    cases=readjson(inputs/"cases.json")
    labels={}
    for raw,setting in quiz:
        code=secrets.token_hex(3)
        labels[code]={"record":raw,**setting}
        folder=packet/code
        folder.mkdir()
        receipt=study/("record-"+raw)
        case=cases[setting["case"]];fixture=study/"fixtures"/setting["case"]
        project=Path(readjson(receipt/"dispatch.json")["project"])
        run=readjson(receipt/"result.json")
        assert run["exit"]==0 and (receipt/"answer.md").read_text().strip()
        save(folder/"operations.json",actions(receipt,project))
        save(folder/"observer.json",observed(case,fixture,project,run))
        trace=project/".studio/operations.jsonl"
        if trace.exists():
            shutil.copyfile(trace,folder/"adapter-operations.jsonl")
        for name in ["STUDIO.md","press-kit.md"]:
            shutil.copyfile(fixture/name,folder/name)
        (folder/"task.md").write_text((receipt/"task.md").read_text())
        (folder/"answer.md").write_text(redact((receipt/"answer.md").read_text(),project))
        for name in ["layout-note.md",case["proof"]]:
            if (project/name).exists():
                shutil.copyfile(project/name,folder/name)
    save(study/(mode+"-grading-map.json"),labels)
    (study/(mode+"-packet.txt")).write_text(str(packet))
    print(packet)

if __name__=="__main__":
    publish(sys.argv[1])
