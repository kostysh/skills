from datetime import datetime, timezone
import json
import sys
import tarfile
from pathlib import Path
from prepare import study, work, evidence, digest, inventory, save, delta

archive=Path(sys.argv[1])
receipt=study/"scorer-ab/result.json"
scores=json.loads(receipt.read_text())
assert scores["exit"]==0 and scores["sha256"]==digest(study/"scorer-ab/grades.md")
assert digest(archive)=="15ff2849d06f277aede6a988029443deef0b0ba1be2fda0b9b67282cd4649a33"
c=study/"sealed/C"
a=study/"sealed/A"
b=study/"sealed/B"
with tarfile.open(archive) as package:
    assert sorted(package.getnames())==sorted(inventory(a))
    package.extractall(c,filter="data")
assert all(digest(work/"skills/frontend-design"/name)==value for name,value in inventory(c).items())
for label,base in (("A",a),("B",b)):
    patch=delta(base,c,label,"C")
    (evidence/(label+"-C.patch")).write_text(patch)
save(evidence/"candidate-freeze.json", {
    "usedAfterSignedAB": {"receiptSha256":digest(receipt),"scoreSha256":scores["sha256"]},
    "verifiedAt":datetime.now(timezone.utc).isoformat(),
    "source":"Exact seven entries from the separately frozen frontend-design-0.2.6.tgz supplied by the package owner after the initial input freeze; its bytes were not revised in response to grading.",
    "archiveSha256":digest(archive), "archiveName":archive.name,
    "files":inventory(c), "patches":{name:digest(evidence/name) for name in ["A-C.patch","B-C.patch"]},
    "rootMetadata":"Use the emitted archive as is. Exact C header identifies 0.2.6 and its own manifest. Scorers receive no instruction headers or bodies.",
    "comparison":"C on the two original fixtures plus the held fixture in fresh sessions. Reblind and regrade the actual original A answers on the common fixtures alongside C; no duplicate subjects used as independent repeats."
})
print(digest(evidence/"candidate-freeze.json"))
