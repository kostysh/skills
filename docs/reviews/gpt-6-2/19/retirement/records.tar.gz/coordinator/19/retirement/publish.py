import gzip
import io
import json
import re
import shutil
import sqlite3
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as et
from pathlib import Path
from prepare import study, evidence, inputs, save, inventory, digest
from packet import readjson

def files_in(folder):
    return [p for p in sorted(folder.rglob("*")) if p.is_file()]

def pack(destination, members):
    with destination.open("wb") as sink,gzip.GzipFile(fileobj=sink,mode="wb",mtime=0,filename="") as gz,tarfile.open(fileobj=gz,mode="w") as tar:
        for name,p in sorted(members.items()):
            data=p.read_bytes()
            entry=tarfile.TarInfo(name)
            entry.size=len(data)
            entry.mode=0o644
            tar.addfile(entry,io.BytesIO(data))

def patch_check():
    out={}
    for src,dest in [("A","B"),("A","C"),("B","C")]:
        with tempfile.TemporaryDirectory(prefix="proof-desk-apply-") as folder:
            shutil.copytree(study/"sealed"/src,folder,dirs_exist_ok=True)
            r=subprocess.run(["patch","--batch","--fuzz=0","-p1","-i",str(evidence/f"{src}-{dest}.patch")],cwd=folder,capture_output=True,check=True)
            assert inventory(Path(folder))==inventory(study/"sealed"/dest)
            out[f"{src}-{dest}"]={"exit":r.returncode,"allSevenFilesIdentical":True}
    return out

def cache_probe():
    with tempfile.TemporaryDirectory(prefix="proof-desk-cache-") as folder:
        cwd=Path(folder)
        shutil.copytree(study/"fixtures/holdout",cwd,dirs_exist_ok=True)
        args=["python3","studio.py","weekly-sheet.pen"]
        steps=[["style","Proof desk","heading","Display"],["style","Proof desk","action","Amber action"],
               ["export","Proof desk","cached.svg"],["export","Proof desk","current.svg","--current"]]
        for step in steps:
            subprocess.run([*args,*step],cwd=cwd,check=True,capture_output=True)
        observed={}
        for name in ["cached.svg","current.svg"]:
            element=next(n for n in et.parse(cwd/name).getroot() if n.attrib.get("id")=="heading")
            observed[name]={"SHA256":digest(cwd/name),"headingPx":element.attrib["font-size"]}
        assert observed["cached.svg"]["headingPx"]=="16" and observed["current.svg"]["headingPx"]=="32"
        return {"kind":"case-author calibration on a separate disposable copy, after the blind tasks","commands":steps,"commandExits":[0,0,0,0],"proofs":observed}

def rating_display(raw,stage):
    # Preserve the signed original in the archive. Make only hyperlinks portable here.
    def relative(match):
        label,target=match.groups()
        if target.endswith("/criteria.md"):
            return f"[{label}](inputs/criteria.md)"
        return label
    display=re.sub(r"\[([^\]]+)\]\((?:\<)?(/tmp/[^)]+?)(?:\>)?\)",relative,raw.read_text())
    (evidence/("ratings-"+stage+".md")).write_text(display+"\n")

def main():
    members={}
    report={"inputFreezeSha256":digest(evidence/"input-freeze.json"),"candidateFreezeSha256":digest(evidence/"candidate-freeze.json"),"patchReplay":patch_check(),"calibration":cache_probe(),"runs":{},"graders":{}}
    studies={**readjson(study/"ab-private.json"),**readjson(study/"confirm-private.json")}
    cases=readjson(inputs/"cases.json")
    capture_files=["answer.md","dispatch.json","events.jsonl","result.json","stderr.txt","task.md"]
    for code,spec in studies.items():
        case=spec["case"];variant=spec["variant"];case_data=cases[case]
        record=study/("record-"+code)
        dispatch=readjson(record/"dispatch.json");result=readjson(record/"result.json")
        assert dispatch["input_files"]=={**inventory(study/"fixtures"/case),**inventory(study/"sealed"/variant)}
        argv=dispatch["argv"]
        assert argv[argv.index("--model")+1]=="gpt-6.2-sol" and 'model_reasoning_effort="medium"' in argv and "--ephemeral" in argv and "--disable" in argv and "memories" in argv
        assert result["exit"]==0 and (record/"answer.md").stat().st_size
        events=[json.loads(l) for l in (record/"events.jsonl").read_text().splitlines() if l]
        assert events[0]["type"]=="thread.started" and events[-1]["type"]=="turn.completed"
        complete=[e["item"] for e in events if e["type"]=="item.completed" and e["item"]["type"]=="command_execution"]
        evidence_read=[i for i in complete if "references/strategy-to-implementation.md" in i["command"] and "# Strategy To Implementation" in i["aggregated_output"]]
        assert evidence_read
        phrase_read=any("Use an available editor that supports the requested format" in i["aggregated_output"] for i in evidence_read)
        assert phrase_read==(variant=="C")
        trace=record/"files/.studio/operations.jsonl"
        operations=[json.loads(l) for l in trace.read_text().splitlines()]
        for path in [*(record/f for f in capture_files),*files_in(record/"files")]:
            members["subjects/"+code+"/"+path.relative_to(record).as_posix()]=path
        base=report["runs"][code]={"variant":variant,"case":case,"threadId":events[0]["thread_id"],"assignedModel":"gpt-6.2-sol","assignedEffort":"medium","exit":result["exit"],"inputHashesMatched":True,"readStrategyReference":True,"positiveRuleInObservedReferenceOutput":phrase_read,"changed":result["changed"],"answerSHA256":digest(record/"answer.md"),"eventsSHA256":digest(record/"events.jsonl"),"stderrSHA256":digest(record/"stderr.txt"),"record":"subjects/"+code+"/"}
        if variant=="C":
            sample=case_data["proof"] if case!="boundary" else "layout-note.md"
            out=evidence/"examples"/sample
            out.parent.mkdir(exist_ok=True)
            shutil.copyfile(record/"files"/sample,out)
            base["exampleSHA256"]=digest(out)
        if case=="holdout":
            base["subjectExportRequests"]=[i for i in operations if i["command"]=="export"]
        else:
            base["adapterOperationCount"]=len(operations)
    for stage in ["ab","confirm"]:
        location=Path((study/(stage+"-packet.txt")).read_text());key=readjson(study/(stage+"-grading-map.json"))
        receipt=study/("scorer-"+stage); dispatch=readjson(receipt/"dispatch.json")
        assert inventory(location)==dispatch["inputs"]
        source=receipt/"grades.md"; score=readjson(receipt/"result.json")
        assert score["sha256"]==digest(source) and score["events_sha256"]==digest(receipt/"events.jsonl")
        argv=dispatch["argv"]
        assert argv[argv.index("--model")+1]=="gpt-6.2-sol" and 'model_reasoning_effort="high"' in argv and "--ephemeral" in argv and "memories" in argv
        ratings=source.read_text()
        assert all(code in ratings for code in key)
        codes={k:{"run":s["record"],"variant":s["variant"],"case":s["case"]} for k,s in key.items()}
        for file in files_in(location):
            members["graders/"+stage+"/packet/"+file.relative_to(location).as_posix()]=file
        for name in ["dispatch.json","grades.md","result.json","stderr.txt","events.jsonl"]:
            members["graders/"+stage+"/"+name]=receipt/name
        rating_display(source,stage)
        first=json.loads((receipt/"events.jsonl").read_text().splitlines()[0])
        assert first["type"]=="thread.started"
        report["graders"][stage]={"threadId":first["thread_id"],"assignedModel":"gpt-6.2-sol","assignedEffort":"high","exit":score["exit"],"scoresSHA256":score["sha256"],"eventsSHA256":score["events_sha256"],"stderrSHA256":digest(receipt/"stderr.txt"),"allPacketFilesMatched":True,"keysAfterGrading":codes}
    ids=[v["threadId"] for v in [*report["runs"].values(),*report["graders"].values()]]
    assert len(ids)==len(set(ids))==9
    # Failed host startup attempts returned before an executor saw its task.
    report["unscoredInitialStarts"]=[]
    for rec in sorted((study/"init-failed").iterdir()):
        start=readjson(rec/"result.json")
        assert start["exit"]==1 and not start["changed"] and not (rec/"events.jsonl").read_text().strip() and not (rec/"answer.md").read_text().strip()
        report["unscoredInitialStarts"].append({"run":rec.name,"exit":1,"stdoutBytes":0,"answerBytes":0,"changed":[],"message":"Read-only file system when initializing local in-process app-server","stderrSHA256":digest(rec/"stderr.txt")})
        for name in capture_files:
            members["startup/"+rec.name+"/"+name]=rec/name
    candidate=Path("/tmp/skills-retirement-OtSJ0d6I/dist/frontend-design-0.2.6.tgz")
    assert digest(candidate)==readjson(evidence/"candidate-freeze.json")["archiveSha256"]
    members["archives/"+candidate.name]=candidate
    for name in ["trial.py","gradecli.py","study_context.py","slots.py"]:
        source=study.parents[1]/name
        assert digest(source)==readjson(evidence/"input-freeze.json")["studyToolsSHA256"][name]
        members["coordinator/"+name]=source
    for name in ["prepare.py","execute.py","packet.py","candidate.py","publish.py"]:
        members["coordinator/19/retirement/"+name]=study/name
    output=evidence/"records.tar.gz"
    pack(output,members)
    with tarfile.open(output) as tr:
        assert sorted(tr.getnames())==sorted(members)
        assert all(tr.extractfile(k).read()==v.read_bytes() for k,v in members.items())
    report["archive"]={"file":output.name,"files":len(members),"bytes":output.stat().st_size,"sha256":digest(output),"allEntriesReadBack":True}
    save(evidence/"provenance.json",report)
    print(report["archive"],"provenance",digest(evidence/"provenance.json"))

if __name__=="__main__":
    main()
