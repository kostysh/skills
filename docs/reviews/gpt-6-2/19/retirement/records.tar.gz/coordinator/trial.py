"""Coordinate one fresh Codex session. All receipts live outside its project."""
import argparse
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from slots import available_session
from study_context import memory_settings, uses_revised_capture

parser = argparse.ArgumentParser()
parser.add_argument("instructions", type=Path)
parser.add_argument("fixture", type=Path)
parser.add_argument("task", type=Path)
parser.add_argument("receipt", type=Path)
parser.add_argument("--model", default="gpt-6.2-sol")
parser.add_argument("--effort", choices=("low", "medium"), default="medium")
args = parser.parse_args()
receipt = args.receipt.resolve()
receipt.mkdir(parents=True, exist_ok=False)
project = Path(tempfile.mkdtemp(prefix="casework-"))
if args.fixture.is_dir():
    shutil.copytree(args.fixture, project, dirs_exist_ok=True)
shutil.copytree(args.instructions, project, dirs_exist_ok=True)

def inventory():
    return {
        f.relative_to(project).as_posix(): hashlib.sha256(f.read_bytes()).hexdigest()
        for f in sorted(project.rglob("*")) if f.is_file() and ".git" not in f.parts
    }

def save(name, data):
    (receipt / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def file_modes():
    return {
        f.relative_to(project).as_posix(): format(f.stat().st_mode & 0o7777, "04o")
        for f in sorted(project.rglob("*")) if f.is_file() and ".git" not in f.parts
    }

before = inventory()
record_modes = uses_revised_capture(receipt)
modes_before = file_modes() if record_modes else {}
context_note = "Работай только в предоставленном текущем каталоге. "
if (project / "operator-guidance.md").is_file():
    context_note += "Применяй общие рабочие инструкции из operator-guidance.md и правила проекта из AGENTS.md. "
task_text = context_note + "\n\n" + args.task.read_text()
(receipt / "task.md").write_text(task_text)
cmd = ["codex", "exec", "--ephemeral", "--skip-git-repo-check", "--sandbox", "workspace-write",
       "--model", args.model, "-c", f'model_reasoning_effort="{args.effort}"',
       "--cd", str(project), "--json", "--output-last-message", str(receipt / "answer.md"), "-"]
cmd[2:2] = memory_settings(receipt)
dispatch = {"project": str(project), "argv": cmd, "input_files": before}
if record_modes:
    dispatch["input_modes"] = modes_before
save("dispatch.json", dispatch)
with available_session(), (receipt / "events.jsonl").open("w") as events, (receipt / "stderr.txt").open("w") as errors:
    run = subprocess.run(cmd, input=task_text, cwd=project, text=True, stdout=events, stderr=errors)
after = inventory()
modes_after = file_modes() if record_modes else {}
changed = sorted(n for n in before.keys() | after.keys() if before.get(n) != after.get(n) or modes_before.get(n) != modes_after.get(n))
for name in changed:
    f = project / name
    if f.is_file():
        destination = receipt / "files" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, destination)
result = {"exit": run.returncode, "changed": changed, "output_files": after}
if record_modes:
    result["output_modes"] = modes_after
save("result.json", result)
print(json.dumps({"id": receipt.name, "exit": run.returncode, "changed": changed, "observed_answer": (receipt / "answer.md").is_file()}))
raise SystemExit(run.returncode)
