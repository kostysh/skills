from contextlib import contextmanager
import fcntl
from pathlib import Path
import time

@contextmanager
def available_session():
    directory=Path(__file__).resolve().parent/'worker-slots'
    directory.mkdir(exist_ok=True)
    handle=None
    while handle is None:
        for index in range(3):
            attempt=(directory/str(index)).open('a')
            try:
                fcntl.flock(attempt.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError:
                attempt.close()
                continue
            handle=attempt
            break
        if handle is None:
            time.sleep(0.6)
    try:
        yield
    finally:
        handle.close()
