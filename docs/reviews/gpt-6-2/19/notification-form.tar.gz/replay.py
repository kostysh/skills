"""Exercise the delivered notification form through its public controls."""
import json
from pathlib import Path

from lab import Preview


ROOT = Path(__file__).resolve().parent
READ = """(() => {
  const area = document.querySelector('[role=status]');
  const dialog = document.querySelector('[role=dialog][data-state=open]');
  const active = document.activeElement;
  const button = [...document.querySelectorAll('form button')].find(b => b.type === 'submit');
  const focusStyle = getComputedStyle(active);
  return {
    viewport: [innerWidth, innerHeight], pageWidth: document.documentElement.scrollWidth,
    email: document.querySelector('#email').value, weekly: document.querySelector('#weekly').ariaChecked,
    enabled: document.querySelector('#notifications').ariaChecked,
    error: document.querySelector('#email-error')?.textContent ?? null,
    reviewDisabled: button.disabled, dialog: dialog?.innerText ?? null,
    buttons: dialog ? [...dialog.querySelectorAll('button')].map(b =>
      ({label:b.textContent, disabled:b.disabled, variant:b.dataset.variant})) : [],
    status: area.innerText, focus: active.id || active.getAttribute('role') ||
      (active.tagName === 'BUTTON' ? active.textContent : active.tagName),
    focusVisible: active.matches(':focus-visible'), outline: focusStyle.outline,
    boxShadow:focusStyle.boxShadow
  };
})()"""


def exercise(preview, name, width, height):
    out = ROOT / "observations" / name
    out.mkdir(parents=True, exist_ok=True)

    def run(*args):
        output, code = preview.browser(list(args))
        if code:
            raise RuntimeError(f"{args}: {output}")
        return output

    def wait_for(condition):
        run("wait", "--fn", condition)

    def press(key):
        run("press", key)

    rows = {}

    def read(stage, screenshot=True):
        row = json.loads(run("eval", READ))
        assert row["pageWidth"] == width and row["viewport"] == [width, height], row
        rows[stage] = row
        if screenshot:
            run("screenshot", str((out / f"{stage}.png").relative_to(ROOT)))
        return row

    def review():
        run("find", "role", "button", "click", "--name", "Review changes")
        wait_for("document.querySelector('[role=dialog][data-state=open]') && document.getAnimations().every(a => a.playState !== 'running')")

    def applied(email):
        wait_for(f"document.querySelector('[role=status]').innerText.includes('{email}') && !document.querySelector('[role=dialog]')")

    run("open", "PREVIEW_URL")
    run("set", "viewport", str(width), str(height))
    run("snapshot", "-i")
    read("edit")
    run("fill", "#email", "first@example.test")
    review()
    press("Tab")
    assert read("first-confirm", False)["focus"] == "Confirm"
    press("Enter")
    applied("first@example.test")
    assert "Frequency: Daily" in read("previous", False)["status"]

    run("fill", "#email", "not-an-email")
    run("click", "#weekly")
    run("find", "role", "button", "click", "--name", "Review changes")
    invalid = read("invalid")
    assert invalid["focus"] == "email" and invalid["error"] and invalid["weekly"] == "true"
    run("fill", "#email", "team@example.test")
    review()
    before = read("review")
    assert before["focus"] == "Cancel" and "team@example.test" in before["dialog"] and "Weekly" in before["dialog"]
    press("Escape")
    wait_for("!document.querySelector('[role=dialog]')")
    dismissed = read("cancelled", False)
    assert dismissed["focus"] == "Review changes" and dismissed["email"] == "team@example.test"
    assert "first@example.test" in dismissed["status"] and dismissed["weekly"] == "true"

    press("Enter")
    wait_for("document.activeElement?.textContent === 'Cancel' && document.getAnimations().every(a => a.playState !== 'running')")
    press("Tab")
    assert read("confirm", False)["focus"] == "Confirm"
    press("Enter")
    pending = read("applying")
    assert pending["focus"] == "Close" and pending["focusVisible"]
    assert "continue to apply" in pending["dialog"] and pending["buttons"] == [
        {"label":"Close", "disabled":False, "variant":"brand"},
        {"label":"Applying…", "disabled":True, "variant":"outline"}]
    press("Enter")
    wait_for("!document.querySelector('[role=dialog]') && document.activeElement.matches('[role=status]')")
    closed = read("closed-during")
    assert closed["focus"] == "status" and closed["focusVisible"] and closed["reviewDisabled"]
    assert all(text in closed["status"] for text in ["Applying changes", "Previously applied settings", "first@example.test"])
    applied("team@example.test")
    final = read("applied")
    assert final["focus"] == "status" and not final["reviewDisabled"] and final["weekly"] == "true"
    assert "Frequency: Weekly" in final["status"] and "first@example.test" not in final["status"]
    press("Shift+Tab")
    previous_action = read("back-to-review", False)
    assert previous_action["focus"] == "Review changes" and previous_action["focusVisible"]
    run("reload")
    wait_for("!!document.querySelector('#email')")
    reloaded = read("reloaded", False)
    assert not reloaded["status"] and not reloaded["email"] and reloaded["weekly"] == "false"
    (out / "states.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n")
    (out / "network.txt").write_text(run("network", "requests"))
    (out / "errors.txt").write_text(run("errors"))


if __name__ == "__main__":
    for target in [("wide",1180,820), ("narrow",390,844)]:
        with Preview() as preview:
            exercise(preview, *target)
