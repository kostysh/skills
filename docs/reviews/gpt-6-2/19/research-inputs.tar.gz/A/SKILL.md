---
name: frontend-design
description: "Design and implement visual strategies for web interfaces: landing
  pages, product UI, dashboards, and redesigns. Own composition, typography,
  styling, and motion; express accepted interactions and verify rendered
  results. Route task-flow choices and UX audits to web-ux-engineer."
metadata:
  source-version: 0.2.4
  skillforge-source-manifest: skill.yaml
  skillforge-source-hash: a084e96b522d3a5327ac12637ac9481884730dfecb998ecc33404b90dbdb245d
---

# frontend-design

## Start here

1. Confirm that visual direction, design strategy, or translating design into a rendered interface is material to the request.
2. Name the requested deliverable as strategy-only, design-artifact, runtime-implementation, or a combination.
3. Inspect the authoritative brief, existing runtime, design system, component inventory, and assets that can govern the work before making visual decisions.
4. Classify surface type, constraint profile, and primary visual engine; load only the references whose conditions match the task.
5. Define the evidence required for the strongest honest completion status before building.

## When to use this skill

- Create or refine an implementation-ready visual strategy and the visual expression of accepted interactions.
- Visually strong landing pages, marketing websites, hero sections, or branded surfaces
- Product UI, dashboards, workspaces, admin surfaces, or app redesigns that need better hierarchy and visual discipline
- Translate an accepted design, mockup, or visual direction into React, HTML/CSS, or another component-based UI
- Prototypes, demo UI, and secondary web formats such as poster-like artifacts or game UI mock surfaces

## When NOT to use this skill

- Choosing or auditing a user-task flow is the primary result; use web-ux-engineer for interaction choices and scenario continuity.
- Pure frontend architecture, state management, routing, or data-fetching work with no design direction requirement
- Pure component API lookup or design-system component selection; use `shadcn` for that
- Reusable React component correctness/hardening work where the core problem is rendering behavior, SSR, portals, or future React semantics; use `react-components-engineer`
- Formal guidelines-based review of an implemented interface without design or remediation work; use `web-ui-reviewer`

## Overview

Goal: produce deliberate, current interfaces and implementation-ready design
strategies whose claims match the evidence. Prefer one clear idea, strong
hierarchy, rigorous spacing, and only the imagery or motion the selected surface
needs.

## Working Model

Before designing or building, establish:

- `deliverable`: `strategy-only`, `design-artifact`, or `runtime-implementation`
- `source hierarchy`: the brief, product behavior, existing runtime, design system, and assets that govern decisions
- `surface type`: `brand/landing`, `product/app`, or `secondary format`
- `constraint profile`: `greenfield` or `system-constrained`
- `visual engine`: one primary engine and, only when useful, one supporting engine
- `visual thesis`: one sentence describing mood, material, energy, and the dominant visual idea
- `content and state plan`: content order plus the relevant loading, empty, error, success, permission, responsive, and long-content states
- `interaction thesis`: the visual expression of accepted behavior through transitions or motion that materially improve presence, hierarchy, feedback, or affordance; task-flow choices belong to `web-ux-engineer`
- `reuse and evidence plan`: existing components/assets to reuse and the rendered checks required for the requested completion claim

Each section gets one job, one dominant visual idea, and one primary takeaway or action.

## Cross-Mode Defaults

- Start with composition, not components.
- Keep copy short enough to scan in seconds.
- Use whitespace, alignment, scale, cropping, and contrast before adding chrome.
- In greenfield work, limit the system to two typefaces and one accent color by default; in system-constrained work, preserve the accepted token system.
- Use expressive typography when the brief allows it; avoid safe, overused default choices that flatten the page.
- Default to cardless layouts. Use sections, columns, dividers, lists, and media blocks instead.
- Build atmosphere with backgrounds, texture, depth, overlays, or pattern only when they reinforce hierarchy and mood.
- Avoid AI-slop aesthetics: generic SaaS card stacks, weak branding, filler gradients, predictable component mosaics, and cookie-cutter visual language.

## Mode Application

For landing work, use a concise hero-support-detail-CTA sequence and one
dominant first-screen composition. The anchor may be imagery, expressive type,
product proof, data, or grid structure; do not force imagery into a non-image
engine. Count persistent headers against the initial viewport budget.

For product work, lead with the working surface, navigation, secondary context,
and one clear action or state accent. Prefer dense but readable layout over
marketing heroes, decorative backgrounds, or card mosaics.

When imagery is selected, make it carry narrative meaning, crop it around the
composition, and keep text away from visual or typographic clutter. Read
`references/surface-modes.md` and `references/visual-engines.md` for the full
mode and engine guidance.

## Copy

- Write in product language, not design commentary.
- Let the headline carry the meaning.
- Supporting copy should usually be one short sentence.
- Cut repetition between sections.
- Do not include prompt language or design commentary in the UI.
- Give every section one responsibility: explain, prove, deepen, or convert.

If deleting 30 percent of the copy improves the page, keep deleting.

## Utility Copy For Product UI

When the work is a dashboard, app surface, admin tool, or operational workspace, default to utility copy over marketing copy.

- Prioritize orientation, status, and action over promise, mood, or brand voice.
- Start with the working surface itself: KPIs, charts, filters, tables, status, or task context. Do not introduce a hero section unless the user explicitly asks for one.
- Section headings should say what the area is or what the user can do there.
- Good: `Selected KPIs`, `Plan status`, `Search metrics`, `Top segments`, `Last sync`
- Avoid aspirational hero lines, metaphors, campaign-style language, and executive-summary banners on product surfaces unless specifically requested.
- Supporting text should explain scope, behavior, freshness, or decision value in one sentence.
- If a sentence could appear in a homepage hero or ad, rewrite it until it sounds like product UI.
- If a section does not help someone operate, monitor, or decide, remove it.
- Litmus check: if an operator scans only headings, labels, and numbers, can they understand the page immediately?

## Motion

Use motion to create presence and hierarchy, not noise.

Choose only the motions the brief and surface can justify. A visually led
landing page may use several coordinated motions; a routine product surface may
need one transition or none.

Possible roles include:

- one entrance sequence in the hero
- one scroll-linked, sticky, or depth effect
- one hover, reveal, or layout transition that sharpens affordance

Use the existing project motion stack. Prefer CSS for simple state changes and,
when a React motion dependency is already installed or explicitly approved,
verify its current package and framework API before use. Motion for React is
appropriate for:

- section reveals
- shared layout transitions
- scroll-linked opacity, translate, or scale shifts
- sticky storytelling
- carousels that advance narrative rather than filling space
- menus, drawers, and modal presence effects

Motion rules:

- observable when it is part of the intended experience
- smooth on mobile
- fast and restrained
- consistent across the page
- removed if ornamental only
- non-essential transform, parallax, or autoplay behavior is disabled or replaced when the user prefers reduced motion

## Guardrails

Accepted product behavior, accessibility constraints, and an existing design
system take precedence over the aesthetic defaults below.

- No cards by default.
- No hero cards by default.
- No boxed or center-column hero when the brief calls for full bleed.
- No more than one dominant idea per section.
- No section should need many tiny UI devices to explain itself.
- No headline should overpower the brand on branded pages.
- No filler copy.
- No split-screen hero unless text sits on a calm, unified side.
- No more than two typefaces without a clear reason.
- No more than one accent color unless the product already has a strong system.
- No generic AI-slop styling: safe default fonts, generic purple-on-white gradients, predictable SaaS block stacks, or interchangeable component soup.

## Reject These Failures

- Generic SaaS card grid as the first impression
- Beautiful image with weak brand presence
- Strong headline with no clear action
- Busy imagery behind text
- Sections that repeat the same mood statement
- Carousel with no narrative purpose
- App UI made of stacked cards instead of layout
- “Creative” styling that breaks the existing design system or framework conventions

## Final Review Loop

Before finishing the requested deliverable, verify:

- first-screen hierarchy is obvious
- each section has one dominant idea
- card use is necessary rather than habitual
- copy is compressed to the shortest useful version
- motion improves meaning, hierarchy, or affordance
- desktop and mobile viewport composition both hold up
- contrast, tap targets, focus states, and reduced-motion behavior are acceptable

For a runtime implementation, these checks must come from the current rendered
interface at representative viewports and relevant states. If rendered checks
cannot run, report `implemented-not-verified`; do not imply runtime completion.
For strategy-only or design-artifact work, report the corresponding scoped
status and the runtime evidence still outstanding.

## Workflow stages

### Workflow stage: Establish the design basis

Prevent visual work from inventing product behavior or bypassing the current UI system.

1. Name the deliverable and its downstream consumer.
2. Inspect the user brief, accepted product or UX sources, current runtime, design-system tokens, reusable components, Storybook or equivalent examples, and available assets that govern the task.
3. Record source precedence when multiple inputs govern the same decision.
4. Before visual direction or polish for non-trivial module UI, inventory applicable peer capabilities, record reuse, justified divergence, or `N/A`, and keep library, mockup, and runtime roles distinct.
5. Separate missing visual inspiration, which may be resolved with a labeled thesis, from missing product behavior, which must not be invented.
6. Stop the affected path as blocked when equal-authority sources conflict or a required product decision is absent.

Validation:

- Product behavior and design-system constraints have traceable owners.
- Applicable peer-view capabilities have an explicit disposition before visual direction or polish can hide a functional gap.
- The agent has not invented actions, states, permissions, backend truth, validation, or copy authority.

### Workflow stage: Write a proportional design strategy

Give implementation a clear visual, state, reuse, and evidence contract without unnecessary process artifacts.

1. Classify surface type separately from the greenfield or system-constrained profile, then select one primary visual engine.
2. State the capability, consumer, anti-claims, visual thesis, content and state plan, interaction thesis, responsive intent, reuse plan, and evidence plan.
3. For complex operational UI, map material states to their existing component or owner; keep small changes inline when a matrix would add no clarity.
4. Apply mode-specific composition, typography, imagery, copy, and motion guidance from the overview and matching references.

Validation:

- A downstream implementer can act without inventing visual intent, product behavior, material states, or component ownership.
- Strategy-only output names the runtime evidence it still does not provide.

### Workflow stage: Translate the strategy into the requested artifact or implementation

Preserve the accepted strategy and current system while producing the requested surface.

1. Reuse existing tokens, components, patterns, and assets before introducing screen-local primitives or styling.
2. Resolve design-artifact and runtime-component conflicts by source authority instead of copying either blindly.
3. Route design-tool mechanics, framework architecture, component APIs, and browser execution to their owning skills while preserving the visual contract.
4. Implement responsive behavior, material states, content extremes, and reduced-motion behavior as part of the surface rather than as a later polish pass.

Validation:

- The result traces to the strategy and does not create an unapproved parallel design or component system.
- Any custom component or visual-system exception has a concrete gap and owner.

### Workflow stage: Verify the deliverable and report an honest status

Match completion claims to current artifact or runtime evidence.

1. For strategy-only work, verify contract completeness and report strategy-ready without a runtime claim.
2. For design artifacts, inspect the current artifact and read back required exports or screenshots before reporting artifact-ready.
3. For runtime implementation, inspect the current rendered interface at representative desktop and mobile viewports, relevant states and interactions, keyboard and focus behavior, reduced-motion behavior when applicable, and console or network state when applicable.
4. Use `agent-browser` for interactive diagnostics and terminal-state evidence or `playwright` for reproducible scripted evidence; require both only when they prove distinct needed conditions.
5. Report implemented-not-verified when required rendered evidence is missing or failed; use verified only when the requested runtime path and proportionate checks pass.

Validation:

- Status, evidence, unrun checks, and anti-claims are consistent.
- Source, mockups, stories, screenshots, or compiler success alone cannot close an integrated runtime claim.

## Interop priority

- **task-flow interaction choices, continuity, recovery, and scenario UX audit:** web-ux-engineer. Consume the accepted interaction and express it visually; retain local state, accessibility, peer-view completeness, and rendered-evidence checks.
- **product behavior, actors, actions, states, validation, and copy authority:** The relevant product or specification skill and accepted project sources. frontend-design expresses authoritative behavior visually but must not invent or override it.
- **application architecture, state, routing, data, testing, and runtime accessibility mechanics:** The relevant framework skill such as react-spa-engineer. frontend-design owns visual strategy and rendered expression, not framework correctness.
- **reusable React component correctness, SSR, hydration, portals, and lifecycle behavior:** react-components-engineer. Visual intent must adapt to component correctness rather than weaken it.
- **shadcn registry discovery, component selection, and registry-aware implementation:** shadcn. frontend-design supplies page-level direction while shadcn owns component-system mechanics.
- **durable .pen inspection, editing, validation, screenshots, and exports:** pencil-dev. frontend-design defines strategy and frames; pencil-dev owns Pencil MCP mechanics.
- **interactive browser diagnostics, screenshots, and terminal-state checks:** agent-browser. frontend-design defines evidence conditions while agent-browser executes exploratory browser verification.
- **reproducible scripted browser scenarios and visual, network, or console evidence:** playwright. frontend-design defines evidence conditions while playwright owns repeatable browser automation.
- **guidelines-based web UI and accessibility review:** web-ui-reviewer. frontend-design performs design self-checks; web-ui-reviewer owns the review contract, and a separate reviewer context is still required when the verdict must be independent.

## Gotchas

- **high** — Do not turn missing product behavior, controls, states, permissions, or copy authority into a visual-design decision.
- **high** — A strategy, mockup, export, screenshot, Storybook story, component catalog, or source inspection is not integrated runtime evidence.
- **high** — In system-constrained work, inspect the current runtime component and design-system surface before introducing new primitives or one-off styling.
- **high** — Do not add motion to satisfy a quota; use only motion that improves hierarchy, continuity, feedback, or affordance and provide reduced behavior for non-essential physical motion.
- **medium** — Do not approve a design artifact from a stale export or a runtime implementation from an outdated mockup when current source and rendered behavior disagree.

## Policies

### Proportional collaboration
Honor an explicitly selected skill within its supported scope. In mixed work choose the lead by the requested result and consult another skill for a concrete decision only. Missing neighbors do not block supported local work; preserve evidence limits without cycling handoffs or loading every specialist.

### Source-authority policy
Resolve product behavior, design-system constraints, runtime behavior, and visual inspiration from their named authorities; stop rather than silently resolve equal-authority conflicts.

### System-constraint precedence
Accepted product behavior, accessibility constraints, and the existing design system override generic aesthetic defaults unless the user explicitly authorizes a system change.

### Capability-evidence policy
Match evidence to the requested deliverable and never use artifact-level or structural evidence to claim an integrated runtime capability.

### Status contract
Report strategy-ready, artifact-ready, implemented-not-verified, verified, or blocked per deliverable; do not collapse several deliverables into the strongest status achieved by only one.

## Required active references
- [Surface Modes](references/surface-modes.md) — Read this when surface type or the design-system constraint profile is ambiguous.
- [Visual Engines](references/visual-engines.md) — Read this after classifying the surface when the primary visual engine is not already established.
- [Strategy To Implementation](references/strategy-to-implementation.md) — Read this for non-trivial strategy, system-constrained work, implementation handoff, or runtime completion claims.

## Optional references
- [Anti Patterns](references/anti-patterns.md) — Consult this when output feels generic, overdesigned, weakly grounded, or at risk of substrate-only closure.

## Portability rules

- Do not reference machine-specific absolute paths or local files outside this skill folder.
- Keep all mandatory frontend-design guidance inside this skill folder.
- Use relative links for local references, assets, scripts, tests, and supporting docs.

## Portability checklist before finishing

- Only when editing or packaging this skill itself, run compiler lint, regenerate, check, and an isolated compile; verify generated parity, local references, portability, and packaged files. These maintenance checks are not prerequisites for ordinary tasks performed with the skill.

## Supporting and historical surface

- `docs/*` and `docs/issues/*` are non-normative unless explicitly promoted by this file.
- Supporting glob: `docs/*`
- Supporting glob: `docs/forward-tests/*`
- Supporting glob: `docs/logs/*`
