Подготовил [design-note.md](/tmp/casework-ek5k8qle/design-note.md). Проверил оба пути в Chrome на ширине 390 px. В записке есть точные подписи, визуальные акценты и ссылки на снимки.

- **Cancel** оставляет `weekly@example.com` и **Weekly** в черновике. Фокус возвращается на **Review changes**.
- **Close** закрывает окно, пока применение продолжается. Фокус переходит на **Applying changes…**, затем на **Settings applied**. Адрес и частота применяются на текущую сессию.