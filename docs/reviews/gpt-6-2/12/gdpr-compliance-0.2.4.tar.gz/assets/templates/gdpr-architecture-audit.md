# GDPR Architecture Audit

## Scope

- Target:
- Sources reviewed:
- Official-source status/as-of date:
- In scope:
- Out of scope:
- Coverage limits:
- Assumptions:
- Accountable decisions, legal interpretation, or DPO advice not supplied by this audit:

## Capability vs substrate

- Observable GDPR-relevant capabilities expected:
- Substrate reviewed:
- Anti-claims:
- Acceptance criteria that could pass without real behavior:

## Processing map summary

| Activity | Purpose | Basis decision status | Data subjects/categories | Operational identities | Environments/technical activation | Systems/stores | Access boundary | Recipients/transfers | Retention/deletion | Evidence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |  |  |  |

Technical activation does not establish a lawful-basis decision, controller
approval, legal conclusion, DPO advice, vendor approval, or release
authorization.

## Control coverage

Use `control_evidenced`, `confirmed_gap`, `missing_evidence`, `accountable_or_specialist_decision_needed`, `assumption`, or `not_in_scope` for status.

| Control | Status | Evidence | Notes |
| --- | --- | --- | --- |
| Scope and personal-data classification |  |  |  |
| Roles and responsibility boundaries |  |  |  |
| Purpose and lawful basis |  |  |  |
| Data minimisation and privacy by default |  |  |  |
| Transparency and notice architecture |  |  |  |
| Consent and ePrivacy-dependent gating |  |  |  |
| Data subject rights architecture |  |  |  |
| Retention, deletion, and anonymisation |  |  |  |
| Integrity, confidentiality, and Article 32 security |  |  |  |
| Processors, subprocessors, recipients, and vendors |  |  |  |
| International transfers |  |  |  |
| DPIA and high-risk processing |  |  |  |
| Automated decisions and profiling |  |  |  |
| Children and vulnerable data subjects |  |  |  |
| Breach detection and response |  |  |  |
| Accountability and evidence |  |  |  |
| Non-production, support, analytics, and AI reuse |  |  |  |

## Findings

### GDPR-001 — Finding title

- Status:
- Severity:
- Affected processing activity:
- GDPR control:
- Evidence or missing evidence:
- Risk to people or accountability:
- Required observable capability:
- Insufficient substrate:
- Recommended constraint:
- Verification path:
- Accountable decision, legal counsel, or DPO advice needed:
- Residual risk:

## Handoff to the next owner

| Finding/source | Next owner and requested output | Constraint and scope | Acceptance evidence to return | Accountable or specialist dependency |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

Use the owner needed for the actual remaining decision or correction; a completed spec does not require a new architecture artifact. Record returned observations against the affected finding before re-assessing the control.

## Residual risk

- Unverified behavior:
- Missing evidence:
- Accountable decisions or specialist advice:
- Operational follow-up:

## Assessment outcome

- Assessment status: `COMPLETE_FOR_STATED_SCOPE` | `PARTIAL` | `ASSESSMENT_BLOCKED`
- Assessment-status basis:
- Processing/release gate when requested: `BLOCK` | `NO_ENGINEERING_BLOCKER_IDENTIFIED_IN_ASSESSED_SCOPE`
- Gate basis:
- Evidence for every applicable accountable decision:

These statuses describe the engineering assessment and reviewed evidence. They are not legal approval or GDPR certification.
