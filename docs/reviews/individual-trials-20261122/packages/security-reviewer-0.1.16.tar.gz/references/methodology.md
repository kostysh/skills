# Security Review Methodology

Use this file for the common workflow, regardless of stack.

## Review Basis and Input Contract

Select one mode before analysis:

- `targeted`: bounded review of an identifiable diff, file set, snippet, or security-sensitive path; never emits PASS;
- `formal`: scoped audit with an explicit status and reproducible coverage;
- `re-audit`: verification of prior findings against a new stable snapshot.

Record or derive:

1. stable target identity: commit, base/head diff, aggregate content hash, or exact supplied artifact;
2. report scope and any wider research scope used only to confirm or clear findings;
3. actors, assets, trust boundaries, and allowed attacker capabilities;
4. authoritative requirements, documented exceptions, and project-specific security contracts;
5. available runtime, deployment, configuration, test, and boundary evidence;
6. prior findings and remediation evidence for `re-audit`.

The default external-attacker model is an exploration hypothesis, not authority for a project-specific requirement. Do not invent an actor, deployment control, compliance requirement, or application contract that the available sources do not establish.

Use `BLOCKED` when the target or snapshot is unavailable, moving, or internally conflicting enough that conclusions are not reproducible. Use `INCOMPLETE` when the review can proceed but mandatory coverage or evidence for the requested formal assurance is absent. Missing evidence alone is not `FAIL`.

### Bounded remediation re-audit

On a new stable snapshot, fix the re-audit scope to the accepted prior findings, exact remediation delta, original attack paths, current closure evidence, and adjacent controls or surfaces identified by a blast-radius check. Record unchanged previously cleared scope as excluded; do not repeat the full audit merely because remediation occurred.

An expected behavior correction within the accepted findings and remediation boundary does not itself widen re-audit; verify it against the original attack path and adjacent controls. Widen to a fresh formal or targeted review when changes exceed that boundary: a new threat model or authoritative security contract, public behavior or material scope beyond the accepted correction, unrelated changes overlapping the attack path, or a blast radius that cannot be bounded. Cosmetic or prose-only edits do not close a finding without evidence against the original attack path.

## Review Standard

For each candidate, state the security invariant as a concrete boundary claim: the lower-trust actor or principal and starting authority, the protected action or resource, the boundary that should constrain it, the affected principal or resource, and the observable result. For agent actions, evaluate generic authorization and intent/action binding separately: a principal may be allowed to perform an action without having intentionally requested or approved the exact action that attacker-controlled content caused.

Report only findings that survive all of these checks:

1. **Attacker control**: the attacker controls input, identity, trigger, or reachable code path.
2. **Reachability**: the vulnerable path can actually execute in the reviewed context.
3. **Mitigation check**: no surrounding validation, escaping, parameterization, access control, or deployment boundary already neutralizes it.
4. **Impact**: the outcome matters for confidentiality, integrity, availability, or privilege.

This Review Standard and the Confidence Rubric govern every specialized checklist, including `Flag`, `Always flag`, and expected `FAIL` examples. Those signals are candidates for investigation, not independent finding or status rules; report only HIGH-confidence findings that satisfy all four checks. Missing tests alone are an evidence gap, not proof of a missing runtime control.

If any link is weak, downgrade the concern.

Do not infer helper, middleware, client, role, or credential semantics from names such as `requireUser`, `adminClient`, `safeQuery`, or `validated`. Absence of a control in a supplied snippet or diff is not proof that the control is absent from the reachable path unless the supplied scope establishes the path is complete or surrounding definitions were inspected. Keep the item in `needs verification` when unseen middleware, client construction, schema, policy, or downstream authorization can decide exploitability.

For policy-governance admission surfaces, security-relevant operator/control-plane impact can satisfy the impact side of a finding only when the review explicitly states the actor and control path.

Fix direction should name the source boundary where the invariant must be enforced and the smallest regression case that would fail if the weakness returned. Keep these details in the existing `Impact`, `Evidence`, and `Next` fields; do not add a separate invariant field.

## Surface Discovery

Before finalizing a review or audit, identify which of these surfaces are in scope:

- backend request handlers, jobs, and worker code
- frontend browser code, rendered templates, and client-side state
- browser durable storage such as IndexedDB, `localStorage`, and `sessionStorage`
- auth, sessions, cookies, and identity boundaries
- telemetry, logging, and error-reporting flows
- CI, release, and automation paths
- data plane and privilege boundaries such as SQL, RLS, grants, or storage policies
- server-side data-access construction such as REST/PostgREST filters, SDK query builders, RPC args, storage keys, search filters, or service-role paths
- direct data-access authorization such as RLS helper functions, RPC identity checks, service-role store methods, storage policies, and user-JWT PostgREST behavior
- required audit/security event capture paths, including same-transaction failure behavior or durable fallback where required
- inbound or outbound integrations such as webhooks, callbacks, and URL fetchers
- policy-governance admission gates for external invocation, executable approval capability, policy activation, active-scope selection, governance/audit persistence preconditions, fail-closed decisions, stored `allowed` replay, conflict replay, authority binding, or security-relevant replay/idempotency controls

Inspect frontend and backend when both are in the agreed scope or participate in the trust/attack path needed for a conclusion. The existence of an unrelated stack does not expand a complete bounded review. Missing cross-layer evidence limits the dependent conclusion; retain independently supported findings and state what remains unverified.

Within each selected boundary, compare the primary path with discovered sibling, legacy, batch, retry, background, error, and fallback paths that can reach the same operation. Compare upstream guarantees such as authentication, tenant scope, normalization, freshness, or approval with the assumptions made by each downstream consumer. Inspect only paths that can affect the selected boundary. Stop each hypothesis after it is proved, refuted, or reduced to one exact decisive missing fact; this is a per-hypothesis stop rule, not permission to skip the remaining agreed scope.

## Audit Order Template

For an explicit formal audit, use this order unless the user gives a narrower scope. When a dedicated security scan orchestrator owns repository traversal, do not run a parallel scan; consume its resolved scope and artifacts instead.

1. Entrypoints, deployment config, trust-boundary assumptions, and environment handling.
2. Auth, session, cookie, and privilege transitions.
3. Attacker-controlled input reaching sensitive sinks or missing permission checks.
4. Server-side data-access construction and direct authorization: raw SQL, REST/PostgREST URLs, SDK query builders, RPC args, storage/search keys, user-JWT RLS/RPC behavior, and service-role paths.
5. Browser durable storage and telemetry/error reporting: credential/session material, sensitive or authoritative identity/provider/network data, exposure and access controls, retention, redaction, sentinel payload behavior, and negative API tests.
6. CSRF refresh/reissue when present: selected synchronizer, signed double-submit, or other accepted pattern; session binding, Origin/CORS and request validation, response leakage, pending-session scope, and rotation atomicity only when the stateful contract requires rotation.
7. File handling, redirects, outbound requests, and integration boundaries.
8. Policy-governance admission when the trigger is present: deny/no-invocation, failed/conflicting persistence, historical replay versus current executable capability, conflict replay, freshness authority, evidence identity, release/runtime/deployment binding, activation races, and audit sufficiency.
9. CI, automation, secrets exposure, and supply chain paths.
10. Stack-specific deep dives through `references/domain-handoffs.md` when implementation details change exploitability.

## Confidence Rubric

| Level | Meaning | Action |
|---|---|---|
| HIGH | full exploit chain or missing control is demonstrated from the reviewed code | report |
| MEDIUM | a source-grounded hypothesis has one decisive trust-boundary or mitigation fact unresolved | "needs verification" only; name the exact unknown and resolution path, with no severity |
| LOW | theoretical, cosmetic, or obviously mitigated | do not report |

Assign severity only to confirmed findings and base it on demonstrated impact, affected authority or resources, blast radius, and practical preconditions. Do not infer remote code execution from a crash, and do not make an authorization bypass Critical without demonstrating the authority and resources exposed.

## Evidence Checklist

For every reported finding, prove:

- which lower-trust actor or principal acts, what starting authority it has, and where attacker-controlled data or identity comes from
- which protected action or resource is reached across which boundary, and which principal or resource is affected
- why framework defaults do not already make it safe
- which middleware, helper, client construction, schema, policy, and downstream guard definitions were inspected when their behavior decides the path
- which applicable sibling or alternate paths and upstream-guarantee/downstream-assumption pair were compared
- what observable attacker outcome becomes possible
- what assumption still depends on runtime, edge, or deployment config if the repo does not show it
- where the invariant should be enforced and which minimal regression case would detect its return

Source-text tests, source-grep checks, and absence/presence string checks are not security evidence by themselves. When a runtime claim needs confirmation, use behavioral tests, sentinel payloads, negative API tests, or runtime traces that exercise the control.

Tests, fixtures, generated reports, and compiler success can prove their own structural or exercised contract only. They do not establish complete security review behavior or a real production boundary unless the tested path reaches that boundary under the claimed conditions.

### Minimal safe reproduction

Run a reproduction only when it resolves a concrete uncertainty. Prefer an existing test or a small isolated fixture, dummy data, unchanged target source, and the minimum observable effect; stop as soon as the boundary result is established. Before executing target-controlled code, consider credential exposure, environment contents, external network access, and shared writable resources, and do not run the check when those risks cannot be bounded safely.

A local proof of concept is not mandatory for every finding: a complete source trace is sufficient for the claims it actually proves. If decisive behavior requires an unavailable safe environment, keep the hypothesis in `needs verification` with the exact blocker and owner-observed or local resolution step; do not build sandbox infrastructure as part of an ordinary review.

## Common False Positives

Do not flag these without stronger context:

- constants or deployment config treated as attacker-controlled
- framework-autoescaped template output
- parameterized ORM or query builder usage
- security semantics inferred only from helper, middleware, role, or client names
- a missing check inferred only from its absence in a partial snippet or diff while a reachable surrounding layer remains unseen
- privileged-only flows where the same privilege is required to exploit the path
- test-only helpers or dead code
- missing TLS or `Secure` cookies in obviously local or non-HTTPS development setups

## Uncertainty and Overrides

- If a protection may live at the edge, reverse proxy, platform config, or runtime environment, say `not visible in reviewed code; verify at runtime/config`.
- If the project intentionally deviates from a best practice, check whether the deviation still leaves an exploit path. Report the exploit path, not the policy disagreement.
- Use `needs verification` only for a concrete source-grounded hypothesis. Name the exact decisive unknown fact, the minimal safe way to resolve it, and the owner or evidence source; do not assign severity. Drop a hypothesis when source or observed behavior refutes it rather than parking it there.
- If the decisive unknown is a stack-specific fact, hand it off through `references/domain-handoffs.md` without weakening independently supported findings.

## Status and Ownership Contract

Use these formal statuses exactly:

| Status | Required condition |
|---|---|
| `FAIL` | At least one confirmed, reachable, in-scope security finding survives mitigation checks. |
| `PASS (scoped)` | The named stable security-review scope has complete required coverage and evidence, with no confirmed findings. |
| `INCOMPLETE` | Analysis ran, but mandatory scope, surfaces, or evidence for the requested assurance remain missing. |
| `BLOCKED` | The target, snapshot, or indispensable authority is unavailable, unstable, or irreconcilably conflicting. |

Rules:

- Targeted review reports confirmed findings, needs verification, or `no confirmed findings in reviewed scope`; it never emits PASS.
- `PASS (scoped)` does not imply whole-system security, penetration testing, SAST/DAST, dependency scanning, exhaustive repository coverage, or any standards-compliance status.
- ASVS and other implementation-to-control-set mapping, control fulfillment, and compliance verdicts belong to `spec-conformance-reviewer` whether or not a complete versioned control set is supplied. This skill may contribute exploitability findings and evidence limits, but must not issue per-control pass/fail or the compliance status.
- `security-reviewer` does not issue an overall merge recommendation. Send confirmed security blockers and residual risk to `code-reviewer`, which owns the merge decision.
- Review is read-only by default. A domain or implementation owner applies authorized remediation; this skill re-audits the new stable snapshot.

When the project uses closure types (a)–(d), label each confirmed finding with one type.
Use **(d)** for an outside-task finding and name its owner. For in-scope
findings, use **(c)** for a non-blocking finding, **(a)** for a blocker whose
correction the same test can prove by failing before the fix and passing after
it through the required operation and transport, or **(b)** for a blocker whose
correction requires judgment in a delta review. For (a), retain domain review
of fixes involving security, money, permissions, or migrations.

## Default Output

Begin with one plain-language outcome sentence before severity, confidence, result, or status terminology.

```markdown
Plain-language outcome: what was fixed, what remains, and what the reviewed boundary can now claim

[Review basis: target/snapshot and report scope]

[high] `path/to/file.ts:42` Short title
Confidence: HIGH
Impact: what an attacker gains
Evidence: attacker input -> vulnerable path -> effect
Next: the safest remediation or investigation direction

Needs verification
- source-grounded hypothesis — Unknown: one decisive fact. Resolve: minimal safe check and owner/evidence.

Result: confirmed findings | no confirmed findings in reviewed scope
Evidence limits: untested or unavailable boundary
```

## Formal Audit Output

For an explicit audit or report, prefer:

```markdown
Plain-language outcome: what was fixed, what remains, and what the reviewed boundary can now claim

Executive summary
- Mode, stable target/snapshot, report scope, research scope, actors, and top risks

Confirmed findings
[critical] SR-001 `path/to/file.ts:42` Short title
Confidence: HIGH
Impact: what an attacker gains
Evidence: attacker input -> vulnerable path -> effect
Next: the safest remediation or investigation direction

Needs verification
- `path/to/file.ts:99` Source-grounded hypothesis — Unknown: one decisive fact. Resolve: minimal safe check and owner/evidence. No severity.

Reviewed and cleared
- Only surfaces cleared by named code, configuration, behavioral, or boundary evidence

Uninspected surfaces and residual risk
- Missing surface/evidence and why it limits the result

Data-access construction reviewed
- State whether raw SQL, REST/PostgREST, SDK query builders, RPC, and service-role paths were inspected, or explicitly say they were out of scope.

Status: FAIL | PASS (scoped) | INCOMPLETE | BLOCKED
Evidence limits: What this status does not prove
Next owner: Domain fact, implementation, spec-conformance, scan orchestration, or merge decision owner
```

For re-audit, add `prior finding -> current change -> evidence -> status`, re-run the original attack path and adjacent regression surface, and tie the result to the new snapshot. If the same or a materially related confirmed finding survives remediation, set `Next` to root-cause investigation before more fixes.

Do not repeat unchanged previously cleared scope in the re-audit report. Name it as excluded, and widen only when the blast-radius rule requires a fresh review.

## Review Close-Out

Before finalizing:

- ensure the reviewed surfaces are clear from the response
- ensure the mode, stable target, report scope, research scope, actors, authoritative inputs, and evidence limits are explicit
- for formal audits that include backend/database code, name whether raw SQL, REST/PostgREST, SDK query builders, RPC, and service-role paths were inspected
- ensure all reported findings are high confidence
- ensure each finding names a concrete attacker outcome
- drop anything that is really just a best-practice suggestion
- keep medium-confidence items separate from confirmed findings
- say what must still be verified at runtime if that affects confidence
- do not claim storage, telemetry, or CSRF protection is verified from source-text tests alone
- do not use `FAIL` for missing evidence, issue PASS in targeted mode, or make an overall merge recommendation
- invalidate the result if the reviewed code, configuration, runtime contract, tests, or evidence changed after the recorded snapshot
